<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
	Route::middleware('auth:api')->get('/member/adminUser', function (Request $request) {
		return $request->user();
	});
	Route::post('/home', 'HomeController@store')->name('store');

	/* Start mail send message */
	Route::get('/mail', function () {
		return (new \App\Notifications\EmailHistory())->toMail(request()->user());
	});
	Route::post('/emailqr', 'HomeController@emailqr')->name('emailqr');
	Route::get('/emailqr', function () {
		return (new \App\Notifications\Emailto())->toMail(request()->user());
	});
	Route::post('/reviewEamil', 'HomeController@reviewEamil')->name('reviewEamil');
	Route::get('/reviewEamil', function () {
		return (new \App\Notifications\Reviews())->toMail(request()->user());
	});
	/* End mail send message */

	/* Start Sms message */
	Route::post('/smsSend', 'HomeController@sendCustomMessage')->name('smsSend');
	Route::post('/reviewSms', 'HomeController@reviewSms')->name('reviewSms');
	/* End Sms message */

	Route::post('/referred/patient/qrGenerate', 'HomeController@qrGenerate')->name('qrGenerate');
	
	Route::post('/member/phonewords/keywordGenerator', 'PhoneController@keywordGenerator')->name('keywordGenerator');
    Route::get('Phones/export/Excel', 'PhoneController@exportdata');

  ////////////// yemen ////////////////
    Route::post('addphonecontactsyemen', 'API\ContactsPhoneController@createyemen');
    Route::post('searchphonecontactsyemen', 'API\ContactsPhoneController@indexyemen');
    Route::get('searchphonecontactsyemen', 'API\ContactsPhoneController@indexyemen');


    Route::post('addphonecontacts', 'API\ContactsPhoneController@create');
    Route::post('addstorecontacts', 'API\ContactsPhoneController@store');
    Route::post('searchphonecontacts', 'API\ContactsPhoneController@index');
    Route::post('addfeedback', 'API\FeedBackController@create');
    Route::get('deletecontact/{id}', 'API\ContactsPhoneController@deletecontact');
    Route::get('searchcontacts/{id}', 'API\ContactsPhoneController@getphone');
    Route::post('addphonecontactsegypt', 'API\ContactsPhoneController@createegypt');
    Route::post('support-ticket/create', 'API\ContactsPhoneController@feedbackcreate');

	Route::post('register', 'API\UserController@create');
	Route::post('delete', 'API\UserController@destroy');
	Route::post('update', 'API\UserController@update');
	Route::resource('user', 'API\UserController');
	
	Route::post('login', 'API\UserController@login');

	Route::post('uplodedata', 'API\AccountsController@create');
	Route::post('addbranches', 'API\BranchesController@create');
	
    Route::post('syncdata', 'API\SyncController@SyncData');
    
    Route::post('adduserhistorydata', 'API\UserHistoryController@adduserhistor');
    
    Route::post('addcomentdata', 'API\CommentDataController@create');
    
    ////////////// emart ////////////////
    
    Route::post('addphonecontactsemart', 'API\ContactsPhoneController@createemart');
    Route::post('addstorecontactsemart', 'API\ContactsPhoneController@storeemart');
    Route::post('searchphonecontactsemart', 'API\ContactsPhoneController@indexemart');
    Route::post('addfeedbackemart', 'API\FeedBackController@createemart');
    Route::get('deletecontactemart/{id}', 'API\ContactsPhoneController@deletecontactemart');
    Route::get('searchcontactsemart/{id}', 'API\ContactsPhoneController@getphoneemart');


  ////////////// kuwait ////////////////
    
    Route::post('addphonecontactskuwait', 'API\ContactsPhoneController@createkuwait');
    Route::post('addstorecontactskuwait', 'API\ContactsPhoneController@storekuwait');
    Route::post('searchphonecontactskuwait', 'API\ContactsPhoneController@indexkuwait');
    Route::post('addfeedbackkuwait', 'API\FeedBackController@feedbackcreatekuwait');
    Route::get('deletecontactkuwait/{id}', 'API\ContactsPhoneController@deletecontactkuwait');
    Route::get('searchcontactskuwait/{id}', 'API\ContactsPhoneController@getphonekuwait');
    Route::get('sendwhatsapp', 'API\ContactsPhoneController@send_all_whatsapp_kuwait');
    Route::get('sendwhatsappcheck', 'API\ContactsPhoneController@sendwhatsappcheck');
    Route::post('sendwhatsappcheck', 'API\ContactsPhoneController@sendwhatsappcheck');
    
    
    