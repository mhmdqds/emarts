<?php
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('auth.login');
});
Route::get('/referrerRegister', 'ReferRegisterController@showBusinessRegistrationForm');
Route::post('/referrerRegister', 'ReferRegisterController@create')->name('referrerRegister');

Route::post('autocomplete', 'MedicineController@autocomplete')->name('autocomplete');
Route::get('/autocomplete', 'MedicineController@autocomplete')->name('autocomplete');
Route::post('autocompleteqname', 'MedicineController@autocompleteqname')->name('autocompleteqname');
Route::get('/autocompleteqname', 'MedicineController@autocompleteqname')->name('autocompleteqname');


Route::get('/offline', function () {
    return view('vendor.laravelpwa.offline');
});

Auth::routes(['verify' => true]);

Route::group(['middleware' => ['auth', 'verified']], function () {

    Route::get('/home', 'HomeController@index')->name('home');
    Route::get('/patient/info/{id}', 'Api\PatientController@patientInfo');

});

Route::group(['prefix' => 'member', 'middleware' => ['auth', 'verified']], function () {
    /* Start Member Manual */
    Route::post('/registerPatient', 'MemberController@storePatient');
    Route::get('/patient/{id}', 'MemberController@show');
    Route::get('/patient/{id}/edit', 'MemberController@edit');
    Route::get('/patient/destroy/{id}', 'MemberController@destroy');

    Route::post('/emailSubmit', 'MemberController@emailSubmit');
    Route::post('/smsSubmit', 'MemberController@smsSubmit');

    /* Start medicine Top medicine */
    Route::get('/medicineReport', 'MedicineController@medicineReport')->name('medicineReport');
    Route::post('/autocomplete', 'MedicineController@autocomplete')->name('autocomplete');
    Route::post('autocomplete', 'MedicineController@autocomplete')->name('autocomplete');
    Route::get('/autocomplete', 'MedicineController@autocomplete')->name('autocomplete');
    Route::get('suggestion','MedicineController@suggestion');

	/* Start PHONE MY */
	Route::get('/phoneList', 'PhoneController@phoneList')->name('phoneList');
	Route::get('/phoneListsearch', 'PhoneController@phoneListsearch')->name('phoneListsearch');
	Route::get('/phoneListsearchidentifier', 'PhoneController@phoneListsearchidentifier')->name('phoneListsearchidentifier');
	Route::get('/phonesearchbyphones', 'PhoneController@phonesearchbyphones')->name('phonesearchbyphones');
	
	//Emarat
	Route::get('/phoneListemarat', 'PhoneController@phoneListemarat')->name('phoneListemarat');
	Route::get('/phonesearchbyphonesEmarat', 'PhoneController@phonesearchbyphonesEmarat')->name('phonesearchbyphonesEmarat');
	Route::get('/phoneListsearchEmarat', 'PhoneController@phoneListsearchEmarat')->name('phoneListsearchEmarat');
	Route::get('/phoneListsearchidentifierEmarat', 'PhoneController@phoneListsearchidentifierEmarat')->name('phoneListsearchidentifierEmarat');
	Route::get('/phoneListsearchnumberlenghtEmarat', 'PhoneController@phoneListsearchnumberlenghtEmarat')->name('phoneListsearchnumberlenghtEmarat');

	
    /* Start Member Top Referrer */
    Route::get('/portalTopReferrer', 'MemberController@portalTopReferrer')->name('portalTopReferrer');
    Route::get('/portalTopReferrer-edit/{id}', 'MemberController@portalTopReferrerEdit')->name('portalTopReferrerEdit');
    Route::post('/portalTopReferrer-edit/{id}', 'MemberController@portalTopReferrerEditProfile');
    Route::get('/portalTopReferrer/{id}', 'MemberController@portalTopReferrerView');
    Route::post('/activeTopReferrer/{id}', 'MemberController@activeTopReferrer');
    Route::post('/activation', 'MemberController@activation')->name('activation');
    Route::post('/activeReferrer/{id}', 'MemberController@activeReferrer');
    /* End Member Top Referrer */

	Route::get('/keywordList', 'PhoneController@KeyWordList')->name('keywordList');
	Route::get('/phonewords', 'PhoneController@phonewords')->name('phonewords');
    Route::post('/keywordGenerators', 'PhoneController@keywordGenerator');
	
	Route::get('/keywordsearch', 'PhoneController@keywordsearch')->name('keywordsearch');
    Route::get('/keywordhome-edit/{id}', 'PhoneController@keywordhomeEdit')->name('keywordhomeEdit');
	Route::post('/keywordhome-edit/{id}', 'MemberController@keywordhomeProfile');


	Route::get('/samenaumbers', 'PhoneController@samenaumbers')->name('samenaumbers');
	Route::get('/samenaumberscheack', 'PhoneController@samenaumberscheack')->name('samenaumberscheack');
	Route::post('/samenaumberscheack', 'PhoneController@samenaumberscheack')->name('samenaumberscheack');

	Route::get('export', 'PhoneController@exportsData')->name('export');
	Route::post('export', 'PhoneController@exportsData')->name('export');
	Route::post('exportsdatas', 'PhoneController@exportsData')->name('exportsdatas');
	Route::get('exportsdatas/{keyword_name}', 'PhoneController@exportsData')->name('exportsdatas');
	Route::post('exportsemarat', 'PhoneController@exportsemarat')->name('exportsemarat');
	Route::get('exportsemarat/{keyword_name}', 'PhoneController@exportsemarat')->name('exportsemarat');

	Route::get('/keywordupdate/{id}', 'PhoneController@keywordupdate')->name('keyword.update');
	Route::get('/keywordshow/{id}', 'PhoneController@keywordshow')->name('keyword.show');
	Route::get('/keyworddit/{id}', 'PhoneController@keywordedit')->name('keyword.edit');
	Route::get('/keyworddestroy/{id}', 'PhoneController@keyworddestroy')->name('keyword.destroy');
	Route::post('/keyworddestroy/{id}', 'PhoneController@keyworddestroy')->name('keyword.destroy');
	
	Route::get('/phoneshow/{id}', 'PhoneController@phoneshow')->name('phone.show');
	Route::get('/phoneedit/{id}', 'PhoneController@phoneedit')->name('phone.edit');
	Route::get('/phonedestroy/{id}', 'PhoneController@phonedestroy')->name('phone.destroy');
	Route::get('/phonesend/{id}', 'PhoneController@send')->name('phone.send');



    Route::post('/medicineReport', 'MedicineController@activation')->name('activation');
    Route::get('/medicineReport-edit/{id}', 'MedicineController@medicineReportEdit')->name('medicineReportEdit');

    Route::post('/medicineReport-edit/{id}', 'MedicineController@medicineReportEditProfile');
    Route::get('/medicineReport/{id}', 'MedicineController@medicineReportView');
    Route::post('/activeTopReferrer/{id}', 'MedicineController@activeTopReferrer');
    Route::post('/activeReferrer/{id}', 'MedicineController@activeReferrer');
    /* End medicine Top medicine */
    Route::post('/import', 'ProductController@import')->name('import');
    Route::get('/import', 'ProductController@import')->name('import');
	Route::post('/importjson', 'ProductController@importjson')->name('importjson');
    Route::get('/importView', 'ProductController@importView')->name('importView');

});

Route::group(['prefix' => 'member', 'middleware' => ['auth', 'verified']], function () {

    Route::resource('/adminUsers', 'UserController');
    Route::get('/adminOffice', 'UserController@adminOffice')->name('adminOffice');
    Route::post('/adminOfficeAdd', 'UserController@adminOfficeAdd');
    Route::get('/adminProfile', 'UserController@adminProfile')->name('adminProfile');

});

//-------------------------- Notification ------------------------
Route::prefix('notification')->name('notification.')->group(function () {
    Route::get('/index', 'NotificationController@index')->name('index');
    Route::post('/submit', 'NotificationController@store')->name('store');
    Route::get('/create', 'NotificationController@create')->name('create');
    Route::get('/search','NotificationController@search')->name('search');
    Route::get('/status', 'NotificationController@status')->name('status');
    Route::get('/edit/{id}', 'NotificationController@edit')->name('edit');
    Route::post('/update/{id}', 'NotificationController@update')->name('update');
    Route::get('/delete/{id}', 'NotificationController@destroy')->name('destroy');
    Route::get('/destroy', 'DeliveryController@destroy')->name('destroy');
    Route::post('/destroy', 'DeliveryController@destroy')->name('destroy');
});



Route::get('review/{dest?}/{emp_id?}', 'HomeController@reviewEmployee');

Route::post('send/qrcode/sms', 'HomeController@sendSMS')->name('sendQrCodeSms');

Route::get('patient/{id}', 'Api\PatientController@activatePatient')->name('activatePatient');
Route::get('patientInformation/{id}', 'Api\PatientController@patientInformation')->name('patientInformation');
Route::get('allPatientData', 'Api\PatientController@allPatientData')->name('allPatientData');
