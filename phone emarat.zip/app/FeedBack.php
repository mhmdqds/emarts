<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Eloquent as Model;

class FeedBack extends Model
{
    use Notifiable;
    protected $table = 'FeedBacks';
    protected $primaryKey = 'id';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
   protected $fillable = [
        'feedname', 'feedname',
        'feedmessege', 'feedmessege',
        'feedphone', 'feedphone',
    ];

 
}
