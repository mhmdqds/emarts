<?php

namespace App\Exports;

use App\Models\ContactsPhone;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Events\AfterSheet;

class PhoneExports implements FromArray, WithHeadings, ShouldAutoSize, WithEvents
{
    /**
     * @return \Illuminate\Support\Collection
     */
    function array(): array
    {
        $contacts = ContactsPhone::where('givenName', '=', null)->orderBy('id', 'DESC')->get();
        if ($contacts->isNotEmpty()) {

            foreach ($contacts as $client) {

                $item['displayName'] 	= $client->displayName;
                $item['phone1'] 		= $client->phone1;
                $item['phone2'] 		= $client->phone2;
                $item['phone3'] 		= $client->phone3;
                $item['phone4'] 		= $client->phone4;
                $item['countryCode'] 	= $client->countryCode;
                $item['identifier'] 	= $client->identifier;
                $item['dateNow'] 		= $client->dateNow;

                $data[] = $item;
            }
        } else {
            $data = [];
        }

        return $data;
    }

    public function registerEvents(): array
    {
        return [
            AfterSheet::class => function (AfterSheet $event) {
                $cellRange = 'A1:E1'; // All headers
                $event->sheet->getDelegate()->getStyle($cellRange)->getFont()->setSize(14);

                $styleArray = [
                    'borders' => [
                        'outline' => [
                            'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THICK,
                            'color' => ['argb' => 'FFFF0000'],
                        ],
                    ],

                    'alignment' => [
                        'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT,
                    ],
                ];

            },
        ];

    }

    public function headings(): array
    {
        return [
            'displayName',
            'phone1',
            'phone2',
            'phone3',
            'phone4',
            'countryCode',
            'identifier',
            'dateNow',
        ];
    }
}
