<?php

namespace App\Exports;

use App\Models\ContactsPhone;
use Maatwebsite\Excel\Concerns\FromCollection;

class PhonesExports implements FromCollection
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        return ContactsPhone::where('displayName', 'like', '%'.$keywordName.'%')->orderBy('id', 'DESC')->get()
		([
		
	]);
    }
}
