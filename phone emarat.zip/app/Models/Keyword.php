<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;

class Keyword extends Model
{
    use Notifiable;

    protected $table = 'keywords';

    protected $fillable = [
        'keyword_id', 'keyword_number', 'keyword_name', 'keyword_old', 'keyword_new'
    ];
    /**
     * @var mixed
     */

}
