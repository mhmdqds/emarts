<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ContactsPhone extends Model
{
    protected $table = 'contactlistapp';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
   protected $fillable = [
        'displayName', 'displayName',
        'familyName', 'familyName',
        'givenName', 'givenName',
        'middleName', 'middleName',
        'company', 'company',
        'phones', 'phones',
        'phone1', 'phone1',
        'phone2', 'phone2',
        'phone3', 'phone3',
        'phone4', 'phone4',
        'countryCode', 'countryCode',
        'dateNow', 'dateNow',
        'emails', 'emails',
        'jobTitle', 'jobTitle',
        'identifier', 'identifier',
        'postalAddresses', 'postalAddresses',
        'birthday', 'birthday',
        'androidAccountName', 'androidAccountName',
        'androidAccountTypeRaw', 'androidAccountTypeRaw',
        'contactprefix', 'contactprefix',
        'contactsuffix', 'contactsuffix',
        'HideContact', 'HideContact',
    ];
}
