<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FeedBack extends Model
{
    protected $table = 'FeedBacks';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
   protected $fillable = [
        'feedname', 'feedname',
        'feedmessege', 'feedmessege',
        'feedphone', 'feedphone',
    ];
}
