<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Eloquent as Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class PhoneSeeder extends Model
{
    use Notifiable;
    protected $table = 'PhoneSeeder';
    protected $primaryKey = 'id';
	use HasFactory;

    public $timestamps = false;
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
   protected $fillable = [
        'displayName', 'displayName',
        'familyName', 'familyName',
        'givenName', 'givenName',
        'middleName', 'middleName',
        'company', 'company',
        'phones', 'phones',
        'phone1', 'phone1',
        'phone2', 'phone2',
        'phone3', 'phone3',
        'phone4', 'phone3',
        'countryCode', 'countryCode',
        'dateNow', 'dateNow',
        'emails', 'emails',
        'jobTitle', 'jobTitle',
        'identifier', 'identifier',
        'postalAddresses', 'postalAddresses',
        'birthday', 'birthday',
        'androidAccountName', 'androidAccountName',
        'androidAccountTypeRaw', 'androidAccountTypeRaw',
        'contactprefix', 'contactprefix',
        'contactsuffix', 'contactsuffix',
        'HideContact', 'HideContact',
    ];
}
