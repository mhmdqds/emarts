<?php

use App\Http\Controllers\ContactsPhoneController;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\ContactsPhones;
use App\Models\Contactsegypt;
use App\Models\ContactsEmarat;
use App\Models\ContactsKuwait;
use App\Models\User;
use App\Models\FeedBack;

use Illuminate\Database\Eloquent\Model;
use IlluminateDatabaseEloquentModel;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

//sensSMS function for OTP
if (!function_exists('sendWhatsapp')) {
    function sendWhatsapp()
    {
        $search = 965;
        $lenthses = 11;
        $users =DB::table('contactskuwaits')->where('phone1', 'like', $search.'%')->where('whatssend', 0)->where(DB::raw('CHAR_LENGTH(phone1)'),'=',$lenthses)->limit(5)->get();
        
        foreach ($users as $user) {
            sleep(5);
            $phone = str_replace('+', '', $user->phone1);
            $phoneToSend = preg_replace("~[^0-9]~", "", $phone);
        if (strlen($phoneToSend) == 11) {

            $sender =  '967779132016';
            $dest = $phoneToSend;
            $verifyCode = rand(100000, 999999);
            $verification_code ='التطبيق الأول في الكويت';
            $massagestouser1 = "حمل تطبيق دليلي - دليل جوال الكويت من جوجل بلاي الأن, لقد حمل التطبيق العديد من أصدقائك ";
            $englishCode =" Download Dalili - Kuwait Mobile Guide application from Google Play now, many of your friends have downloaded the application, it is really great";
            $massagestouser2 = "https://play.google.com/store/apps/details?id=com.contact.kuwait";
            $messageToSend =  $massagestouser1. "\n\n" ."*".$verification_code."*" ."\n\n" .$massagestouser2 ."\n\n\n" .$verifyCode ."\n\n\n" .$englishCode;
            
            $data = [
                'api_key' => 'CAqkzyz1P9hpnd4ChEWiv3kZAkywE1',
                'sender' => $sender,
                'number' => $phoneToSend,
                'message' => $messageToSend
            ];
            $curl = curl_init();
            
            curl_setopt_array($curl, array(
              CURLOPT_URL => "https://wpser.smartapps.top/public/send-message",
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => '',
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 0,
              CURLOPT_FOLLOWLOCATION => true,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => 'POST',
              CURLOPT_POSTFIELDS => json_encode($data),
              CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json'
              ),
            ));
            
            $response = curl_exec($curl);
            
            curl_close($curl);
            
            $oksend = ContactsKuwait::find( $user->id);
            $oksend->whatssend = 1;
            $oksend->save();
            
            $results = json_decode($response);    
         }
        }
        return response()->json( [
		    'success' => true,
			'results' => $results
	   ]);
    }
}


