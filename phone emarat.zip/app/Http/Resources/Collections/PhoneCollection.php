<?php

namespace App\Http\Resources\Collections;

use App\Http\Resources\PhoneResource;
use Illuminate\Http\Resources\Json\ResourceCollection;

class PhoneCollection extends ResourceCollection
{
    /**
     * Transform the resource collection into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return PatientResource::collection($this->collection);
    }
}
