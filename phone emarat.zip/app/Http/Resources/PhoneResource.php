<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class PhoneResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param \Illuminate\Http\Request $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'displayName' => $this->displayName,
            'familyName' => $this->familyName,
            'givenName' => $this->givenName,
            'middleName' => $this->middleName,
            'company' => $this->company,
            'phones' => $this->phones,
            'phone1' => $this->phone1,
            'phone2' => $this->phone2
            'phone3' => $this->phone3
            'emails' => $this->emails
            'jobTitle' => $this->jobTitle
            'identifier' => $this->identifier
            'postalAddresses' => $this->postalAddresses
            'androidAccountName' => $this->androidAccountName
            'androidAccountTypeRaw' => $this->androidAccountTypeRaw
            'contactprefix' => $this->contactprefix
            'contactsuffix' => $this->contactsuffix
        ];
    } 
}
