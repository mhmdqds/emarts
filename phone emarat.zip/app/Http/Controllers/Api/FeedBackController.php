<?php
namespace App\Http\Controllers\API;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\FeedBack;
use App\User;

class FeedBackController extends Controller {
		protected $per_page;

    public function create(Request $request)
    {
       
 
		try {
		    $data = json_encode($request);
			$ContactsPhone = FeedBack::create ($request->all());
			return json_encode ( [
					'success' => true,
					'ContactsPhone' => $ContactsPhone
			] );
		} catch ( \Exception $e ) {
			$message = array (
					'message' => $e->getMessage ()
			);
			return json_encode ( [
					'error' => true,
					'message' => $message
			] );
		}
    }
}