<?php
namespace App\Http\Controllers\API;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;
use App\Account;
use App\Stock;
use App\CashAccount;
use App\Collection_Item;
use App\Currency;
use App\ItemBarcode;
use App\ItemGroup;
use App\ItemUnit;
use App\Item;
use App\Picture;
use App\Price;
use App\Setting;
use App\Signiture;
use App\Transaction;
use App\Unit;
use App\LabelsConfigration;


class AccountsController extends Controller {
	

    public function create(Request $request)
    {
        // return all
        $AccountsData = $request->all()['data'];
        $json = json_decode($AccountsData, true); 
        //then use

        // Tabel Insert Row
        $Accounts = $json['Accounts'];
        $Stocks = $json['Stocks'];
        $CashAccounts = $json['CashAccounts'];
        $CollectionItems = $json['Collection_Items'];
        $Currencies = $json['Currencies'];
        $ItemBarcodes = $json['ItemBarcodes'];
        $ItemGroups = $json['ItemGroups'];
        $ItemUnits = $json['ItemUnits'];
        $Items = $json['Items'];
        $Pictures = $json['Pictures'];
        $Pricing = $json['Pricing'];
        $Settings = $json['Settings'];
        $Signitures = $json['Signitures'];
        $Transactions = $json['Transactions'];
        $Units = $json['Units'];
        $LabelsConfigrations = $json['LabelsConfigration'];

        
        // CHEECK Insert Row
        $AccountInsert = false;
        $StocktInsert = false;
        $CashAccountsInsert = false;
        $CollectionItemsInsert = false;
        $CurrencyInsertInsert = false;
        $ItemBarcodesInsert = false;
        $ItemGroupsInsert = false;
        $ItemUnitsInsert = false;
        $ItemsInsert = false;
        $PicturesInsert = false;
        $PricingInsert = false;
        $SettingsInsert = false;
        $SignituresInsert = false;
        $TransactionsInsert = false;
        $UnitsInsert = false;
        $LabelsConfigrationInsert = false;
        
        
        
        // CHEECK Last Insert Id
        $lastInsertedAccountID = 0;
        $StockLastId = 0;
        $CashAccountLastId = 0;
        $Collection_ItemLastId = 0; 
        $CurrencyLastId = 0;
        $ItemBarcodeLastId = 0;
        $ItemGroupLastId = 0;
        $ItemUnitLastId = 0;
        $ItemLastId = 0;
        $PictureLastId = 0;
        $PriceLastId = 0;
        $SettingLastId = 0;
        $SignitureLastId = 0;
        $TransactionLastId = 0;
        $UnitLastId = 0;
        $LabelsConfigrationLastId = 0;
        
        //coonvert time to timestamp for sync
        $syncdatetime = date("YmdHis");

        
    //start get data 
        // Account Table
            try {
                foreach($Accounts as $ans) {
                      $Account = new Account;
                      $Account->SeqqID = $ans['SeqqID'];
                      $Account->AccountID = $ans['AccountID']; 
                      $Account->SubAccountID = $ans['SubAccountID'];
                      $Account->AccountName = $ans['AccountName'];
                      $Account->AccountType = $ans['AccountType'];
                      $Account->AccountMobile = $ans['AccountMobile'];
                      $Account->AddDate = $ans['AddDate'];
                      $Account->UpdateDate = $ans['UpdateDate'];
                      $Account->Flag = $ans['Flag'];
                      $Account->MainAccountID = $ans['MainAccountID'];
                      $Account->SubMainAccountID = $ans['SubMainAccountID'];
                      $Account->Synch = $ans['Synch'];
                      $Account->MainAccount_Seq = $syncdatetime;
                      $Account->branchid = $ans['BranchID'];
                      $Account->save();
                      $AccountInsert = true;
                    }
                } catch ( \Exception $e ) {
            		$message = array (
            				'message' => $e->getMessage (),
            				'messageforme' => 'all data not found! Account'
            		);
            		return json_encode ( [
            				'error' => true,
            				'message' => $message
            		] );
                }
        
        
        // Stocks Table
            try {
				foreach($Stocks as $stocksreq) {
                      $Stock = new Stock;
                      $Stock->StockID = $stocksreq['StockID'];
                      $Stock->StockName = $stocksreq['StockName']; 
                      $Stock->AddDate = $stocksreq['AddDate'];
                      $Stock->UpdateDate = $stocksreq['UpdateDate'];
                      $Stock->Flag = $stocksreq['Flag'];
                      $Stock->MainAccountID = $stocksreq['MainAccountID'];
                      $Stock->SubMainAccountID = $stocksreq['SubMainAccountID'];
                      $Stock->BranchID = $stocksreq['BranchID'];
                      $Stock->Synch = $stocksreq['Synch'];
                      $Stock->MainAccount_Seq = $syncdatetime;
                      $Stock->save();
                      $StocktInsert = true;
                    }
                } catch ( \Exception $e ) {
            		$message = array (
            				'message' => $e->getMessage (),
            				'messageforme' => 'all data not found! Stock'
            		);
            		return json_encode ( [
            				'error' => true,
            				'message' => $message
            		] );
            }
             
            	
        // CashAccounts
            try {
				foreach($CashAccounts as $Cashreq) {
                      $CashAccount = new CashAccount;
                      $CashAccount->SeqqID = $Cashreq['SeqqID'];
                      $CashAccount->AccountID = $Cashreq['AccountID']; 
                      $CashAccount->Join_AccountID = $Cashreq['Join_AccountID']; 
                      $CashAccount->SubAccountID = $Cashreq['SubAccountID'];
                      $CashAccount->AccountName = $Cashreq['AccountName'];
                      $CashAccount->AccountType = $Cashreq['AccountType'];
                      $CashAccount->AccountMobile = $Cashreq['AccountMobile'];
                      $CashAccount->AddDate = $Cashreq['AddDate'];
                      $CashAccount->UpdateDate = $Cashreq['UpdateDate'];
                      $CashAccount->Flag = $Cashreq['Flag'];
                      $CashAccount->MainAccountID = $Cashreq['MainAccountID'];
                      $CashAccount->SubMainAccountID = $Cashreq['SubMainAccountID'];
                      $CashAccount->BranchID = $Cashreq['BranchID'];
                      $CashAccount->Synch = $Cashreq['Synch'];
                      $CashAccount->MainAccount_Seq = $syncdatetime;
                      $CashAccount->save();
                      $CashAccountsInsert = true;
                    }
                } catch ( \Exception $e ) {
            		$message = array (
            				'message' => $e->getMessage (),
            				'messageforme' => 'all data not found! CashAccount'
            		);
            		return json_encode ( [
            				'error' => true,
            				'message' => $message
            		] );
            }
            

        // Collection_Item
            try {
				foreach($CollectionItems as $ColItemreq) {
                      $Collection_Item = new Collection_Item;
                      $Collection_Item->CollectionID = $ColItemreq['CollectionID'];
                      $Collection_Item->Collection_Name = $ColItemreq['Collection_Name']; 
                      $Collection_Item->ItemID = $ColItemreq['ItemID']; 
                      $Collection_Item->Barcode = $ColItemreq['Barcode'];
                      $Collection_Item->Seq_ID = $ColItemreq['Seq_ID'];
                      $Collection_Item->Qty = $ColItemreq['Qty'];
                      $Collection_Item->UID = $ColItemreq['UID'];
                      $Collection_Item->PackageSize = $ColItemreq['PackageSize'];
                      $Collection_Item->Price = $ColItemreq['Price'];
                      $Collection_Item->MainAccountID = $ColItemreq['MainAccountID'];
                      $Collection_Item->SubMainAccountID = $ColItemreq['SubMainAccountID'];
                      $Collection_Item->BranchID = $ColItemreq['BranchID'];
                      $Collection_Item->Synch = $ColItemreq['Synch'];
                      $Collection_Item->MainAccount_Seq = $syncdatetime;
                      $Collection_Item->save();
                      $CollectionItemsInsert = true;
                    }
                } catch ( \Exception $e ) {
            		$message = array (
            				'message' => $e->getMessage (),
            				'messageforme' => 'all data not found! Collection_Item'
            		);
            		return json_encode ( [
            				'error' => true,
            				'message' => $message
            		] );
            }
             

        // Currencies
            try {
				foreach($Currencies as $Currencreq) {
                      $Currency = new Currency;
                      $Currency->CurrencyID = $Currencreq['CurrencyID'];
                      $Currency->CurrencySample = $Currencreq['CurrencySample']; 
                      $Currency->CurrencyName = $Currencreq['CurrencyName']; 
                      $Currency->EnglishName = $Currencreq['EnglishName'];
                      $Currency->CurrencyExchange = $Currencreq['CurrencyExchange'];
                      $Currency->HeighestExchange = $Currencreq['HeighestExchange'];
                      $Currency->LowestExchange = $Currencreq['LowestExchange'];
                      $Currency->AddDate = $Currencreq['AddDate'];
                      $Currency->UpdateDate = $Currencreq['UpdateDate'];
                      $Currency->Flag = $Currencreq['Flag'];
                      $Currency->MainAccountID = $Currencreq['MainAccountID'];
                      $Currency->SubMainAccountID = $Currencreq['SubMainAccountID'];
                      $Currency->Synch = $Currencreq['Synch'];
                      $Currency->MainAccount_Seq = $syncdatetime;
                      $Currency->BranchID = $Currencreq['BranchID'];
                      $Currency->save();
                      $CurrencyInsertInsert = true;
                    }
                } catch ( \Exception $e ) {
            		$message = array (
            				'message' => $e->getMessage (),
            				'messageforme' => 'all data not found! Currency'
            		);
            		return json_encode ( [
            				'error' => true,
            				'message' => $message
            		] );
            }
            
            
        // ItemBarcodes
            try {
				foreach($ItemBarcodes as $ItemBarcodescreq) {
                      $ItemBarcode = new ItemBarcode;
                      $ItemBarcode->BranchID = $ItemBarcodescreq['BranchID'];
                      $ItemBarcode->Line_Seq = $ItemBarcodescreq['Line_Seq']; 
                      $ItemBarcode->ItemID = $ItemBarcodescreq['ItemID']; 
                      $ItemBarcode->ItemCode = $ItemBarcodescreq['ItemCode'];
                      $ItemBarcode->Barcode = $ItemBarcodescreq['Barcode'];
                      $ItemBarcode->ItemName = $ItemBarcodescreq['ItemName'];
                      $ItemBarcode->State = $ItemBarcodescreq['State'];
                      $ItemBarcode->AddDate = $ItemBarcodescreq['AddDate'];
                      $ItemBarcode->UpdateDate = $ItemBarcodescreq['UpdateDate'];
                      $ItemBarcode->Flag = $ItemBarcodescreq['Flag'];
                      $ItemBarcode->MainAccountID = $ItemBarcodescreq['MainAccountID'];
                      $ItemBarcode->SubMainAccountID = $ItemBarcodescreq['SubMainAccountID'];
                      $ItemBarcode->Synch = $ItemBarcodescreq['Synch'];
                      $ItemBarcode->MainAccount_Seq = $syncdatetime;
                      $ItemBarcode->save();
                      $ItemBarcodesInsert = true;
                    }
                } catch ( \Exception $e ) {
            		$message = array (
            				'message' => $e->getMessage (),
            				'messageforme' => 'all data not found!  ItemBarcode'
            		);
            		return json_encode ( [
            				'error' => true,
            				'message' => $message
            		] );
            }
            

        // ItemGroups
            try {
				foreach($ItemGroups as $ItemGroupreq) {
                      $ItemGroup = new ItemGroup;
                      $ItemGroup->GroupID = $ItemGroupreq['GroupID'];
                      $ItemGroup->GroupName = $ItemGroupreq['GroupName']; 
                      $ItemGroup->AddDate = $ItemGroupreq['AddDate'];
                      $ItemGroup->UpdateDate = $ItemGroupreq['UpdateDate'];
                      $ItemGroup->Flag = $ItemGroupreq['Flag'];
                      $ItemGroup->MainAccountID = $ItemGroupreq['MainAccountID'];
                      $ItemGroup->SubMainAccountID = $ItemGroupreq['SubMainAccountID'];
                      $ItemGroup->BranchID = $ItemGroupreq['BranchID'];
                      $ItemGroup->Synch = $ItemGroupreq['Synch'];
                      $ItemGroup->MainAccount_Seq = $syncdatetime;
                      $ItemGroup->save();
                      $ItemGroupsInsert = true;
                    }
                } catch ( \Exception $e ) {
            		$message = array (
            				'message' => $e->getMessage (),
            				'messageforme' => 'all data not found! ItemGroup'
            		);
            		return json_encode ( [
            				'error' => true,
            				'message' => $message
            		] );
            }
            
            
        // ItemUnits
            try {
				foreach($ItemUnits as $ItemUnitreq) {
                      $ItemUnit = new ItemUnit;
                      $ItemUnit->UID = $ItemUnitreq['UID'];
                      $ItemUnit->ItemID = $ItemUnitreq['ItemID']; 
                      $ItemUnit->ItemCode = $ItemUnitreq['ItemCode'];
                      $ItemUnit->Barcode = $ItemUnitreq['Barcode'];
                      $ItemUnit->Package = $ItemUnitreq['Package'];
                      $ItemUnit->UType = $ItemUnitreq['UType'];
                      $ItemUnit->AddDate = $ItemUnitreq['AddDate'];
                      $ItemUnit->UpdateDate = $ItemUnitreq['UpdateDate'];
                      $ItemUnit->Flag = $ItemUnitreq['Flag'];
                      $ItemUnit->MainAccountID = $ItemUnitreq['MainAccountID'];
                      $ItemUnit->SubMainAccountID = $ItemUnitreq['SubMainAccountID'];
                      $ItemUnit->BranchID = $ItemUnitreq['BranchID'];
                      $ItemUnit->Synch = $ItemUnitreq['Synch'];
                      $ItemUnit->MainAccount_Seq = $syncdatetime;
                      $ItemUnit->save();
                      $ItemUnitsInsert = true;
                    }
                } catch ( \Exception $e ) {
            		$message = array (
            				'message' => $e->getMessage (),
            				'messageforme' => 'all data not found! ItemUnit'
            		);
            		return json_encode ( [
            				'error' => true,
            				'message' => $message
            		] );
            }
            
   
        // Items
            try {
				foreach($Items as $Itemtreq) {
                      $Item = new Item;
                      $Item->ItemID = $Itemtreq['ItemID'];
                      $Item->ItemCode = $Itemtreq['ItemCode']; 
                      $Item->ItemName = $Itemtreq['ItemName'];
                      $Item->ScienceItemName = $Itemtreq['ScienceItemName'];
                      $Item->GroupID = $Itemtreq['GroupID'];
                      $Item->UID = $Itemtreq['UID'];
                      $Item->AddDate = $Itemtreq['AddDate'];
                      $Item->UpdateDate = $Itemtreq['UpdateDate'];
                      $Item->Flag = $Itemtreq['Flag'];
                      $Item->Item_Cost = $Itemtreq['Item_Cost'];
                      $Item->Use_ExpiryDate = $Itemtreq['Use_ExpiryDate'];
                      $Item->MainAccountID = $Itemtreq['MainAccountID'];
                      $Item->SubMainAccountID = $Itemtreq['SubMainAccountID'];
                      $Item->BranchID = $Itemtreq['BranchID'];
                      $Item->Synch = $Itemtreq['Synch'];
                      $Item->MainAccount_Seq = $syncdatetime;
                      $Item->save();
                      $ItemsInsert = true;
                    }
                } catch ( \Exception $e ) {
            		$message = array (
            				'message' => $e->getMessage (),
            				'messageforme' => 'all data not found! Item'
            		);
            		return json_encode ( [
            				'error' => true,
            				'message' => $message
            		] );
            }
            

          
        // Pictures
            try {
				foreach($Pictures as $Picturereq) {
                      $Picture = new Picture;
                      $Picture->ItemID = $Picturereq['ItemID'];
                      $Picture->PIC_ID = $Picturereq['PIC_ID']; 
                     // $Picture->PIC_DATA = $Picturereq['PIC_DATA'];
                      $Picture->MainAccountID = $Picturereq['MainAccountID'];
                      $Picture->SubMainAccountID = $Picturereq['SubMainAccountID'];
                      $Picture->BranchID = $Picturereq['BranchID'];
                      $Picture->Synch = $Picturereq['Synch'];
                      $Picture->MainAccount_Seq = $syncdatetime;
                      $Picture->save();
                      $PicturesInsert = true;
                    }
                } catch ( \Exception $e ) {
            		$message = array (
            				'message' => $e->getMessage (),
            				'messageforme' => 'all data not found! Picture'
            		);
            		return json_encode ( [
            				'error' => true,
            				'message' => $message
            		] );
            }
            
            

            
        // Pricing
            try {
				foreach($Pricing as $Pricingreq) {
                      $Price = new Price;
                      $Price->ItemID = $Pricingreq['ItemID'];
                      $Price->ItemCode = $Pricingreq['ItemCode']; 
                      $Price->Barcode = $Pricingreq['Barcode'];
                      $Price->UID = $Pricingreq['UID'];
                      $Price->SalePrice = $Pricingreq['SalePrice'];
                      $Price->AddDate = $Pricingreq['AddDate'];
                      $Price->UpdateDate = $Pricingreq['UpdateDate'];
                      $Price->Flag = $Pricingreq['Flag'];
                      $Price->MainAccountID = $Pricingreq['MainAccountID'];
                      $Price->SubMainAccountID = $Pricingreq['SubMainAccountID'];
                      $Price->BranchID = $Pricingreq['BranchID'];
                      $Price->Synch = $Pricingreq['Synch'];
                      $Price->MainAccount_Seq = $syncdatetime;
                      $Price->save();
                      $PricingInsert = true;
                    }
                } catch ( \Exception $e ) {
            		$message = array (
            				'message' => $e->getMessage (),
            				'messageforme' => 'all data not found! Price'
            		);
            		return json_encode ( [
            				'error' => true,
            				'message' => $message
            		] );
            }

            
        // Settings
            try {
				foreach($Settings as $Settingsreq) {
                      $Setting = new Setting;
                      $Setting->ParmValue = $Settingsreq['ParmValue'];
                      $Setting->MainAccountID = $Settingsreq['MainAccountID'];
                      $Setting->SubMainAccountID = $Settingsreq['SubMainAccountID'];
                      $Setting->Synch = $Settingsreq['Synch'];
                      $Setting->BranchID = $Settingsreq['BranchID'];
                      $Setting->MainAccount_Seq = $syncdatetime;
                      $Setting->save();
                      $SettingsInsert = true;
                    }
                } catch ( \Exception $e ) {
            		$message = array (
            				'message' => $e->getMessage (),
            				'messageforme' => 'all data not found! Setting'
            		);
            		return json_encode ( [
            				'error' => true,
            				'message' => $message
            		] );
            }
            

            
        // Signiture
            try {
				foreach($Signitures as $Signituresreq) {
                      $Signiture = new Signiture;
                      $Signiture->TransID = $Signituresreq['TransID'];
                      $Signiture->SignID = $Signituresreq['SignID'];
                      $Signiture->Sign_Seq = $Signituresreq['Sign_Seq'];
                      $Signiture->MainAccountID = $Signituresreq['MainAccountID'];
                      $Signiture->SubMainAccountID = $Signituresreq['SubMainAccountID'];
                      $Signiture->Synch = $Signituresreq['Synch'];
                      $Signiture->BranchID = $Signituresreq['BranchID'];
                      $Signiture->Sign_Tital = $Signituresreq['Sign_Tital'];
                      $Signiture->MainAccount_Seq = $syncdatetime;
                      $Signiture->save();
                      $SignituresInsert = true;
                    }
                } catch ( \Exception $e ) {
            		$message = array (
            				'message' => $e->getMessage (),
            				'messageforme' => 'all data not found! Signiture'
            		);
            		return json_encode ( [
            				'error' => true,
            				'message' => $message
            		] );
            }
            

            
        // Transactions
            try {
				foreach($Transactions as $Transactionreq) {
                    $Transaction = new Transaction;
                    $Transaction->ComID = $Transactionreq['ComID'];
                    $Transaction->BranchID = $Transactionreq['BranchID'];
                    $Transaction->TransID = $Transactionreq['TransID'];
                    $Transaction->TypeID = $Transactionreq['TypeID'];
                    $Transaction->SeqID = $Transactionreq['SeqID'];
                    $Transaction->HeaderCode = $Transactionreq['HeaderCode'];
                    $Transaction->DocID = $Transactionreq['DocID'];
                    $Transaction->DocDate = $Transactionreq['DocDate'];
                    $Transaction->FromAccountID = $Transactionreq['FromAccountID'];
                    $Transaction->ToAccountID = $Transactionreq['ToAccountID'];
                    $Transaction->FromSubAccountID = $Transactionreq['FromSubAccountID'];
                    $Transaction->ToSubAccountID = $Transactionreq['ToSubAccountID'];
                    $Transaction->CurrencyID = $Transactionreq['CurrencyID'];
                    $Transaction->CurrencyExchange = $Transactionreq['CurrencyExchange'];
                    $Transaction->PaymentMethod = $Transactionreq['PaymentMethod'];
                    $Transaction->Debit = $Transactionreq['Debit'];
                    $Transaction->Credit = $Transactionreq['Credit'];
                    $Transaction->InQty = $Transactionreq['InQty'];
                    $Transaction->OutQty = $Transactionreq['OutQty'];
                    $Transaction->InBouns_Qty = $Transactionreq['InBouns_Qty'];
                    $Transaction->InBouns_AMT = $Transactionreq['InBouns_AMT'];
                    $Transaction->OutBouns_Qty = $Transactionreq['OutBouns_Qty'];
                    $Transaction->OutBouns_AMT = $Transactionreq['OutBouns_AMT'];
                    $Transaction->PackageSize = $Transactionreq['PackageSize'];
                    $Transaction->LineSeq = $Transactionreq['LineSeq'];
                    $Transaction->ItemSeq = $Transactionreq['ItemSeq'];
                    $Transaction->ItemCode = $Transactionreq['ItemCode'];
                    $Transaction->UID = $Transactionreq['UID'];
                    $Transaction->Barcode = $Transactionreq['Barcode'];
                    $Transaction->Price = $Transactionreq['Price'];
                    $Transaction->FromStockID = $Transactionreq['FromStockID'];
                    $Transaction->ToStockID = $Transactionreq['ToStockID'];
                    $Transaction->Explaines = $Transactionreq['Explaines'];
                    $Transaction->UserID = $Transactionreq['UserID'];
                    $Transaction->AddDate = $Transactionreq['AddDate'];
                    $Transaction->UpdateDate = $Transactionreq['UpdateDate'];
                    $Transaction->Purchase_Tax = $Transactionreq['Purchase_Tax'];
                    $Transaction->RPurchase_Tax = $Transactionreq['RPurchase_Tax'];
                    $Transaction->RSale_Tax = $Transactionreq['RSale_Tax'];
                    $Transaction->Discount_AMT = $Transactionreq['Discount_AMT'];
                    $Transaction->RDiscount_AMT = $Transactionreq['RDiscount_AMT'];
                    $Transaction->Flag = $Transactionreq['Flag'];
                    $Transaction->Customer_Name_Disocunt = $Transactionreq['Customer_Name_Disocunt'];
                    $Transaction->POS_Invoice = $Transactionreq['POS_Invoice'];
                    $Transaction->Batch_No = $Transactionreq['Batch_No'];
                    $Transaction->Expire_Date = $Transactionreq['Expire_Date'];
                    $Transaction->Expire_DateSystem = $Transactionreq['Expire_DateSystem'];
                    $Transaction->MainAccountID = $Transactionreq['MainAccountID'];
                    $Transaction->SubMainAccountID = $Transactionreq['SubMainAccountID'];
                    $Transaction->Synch = $Transactionreq['Synch'];
                    $Transaction->MainAccount_Seq = $syncdatetime;
                    $Transaction->CashAccountID = $Transactionreq['CashAccountID'];
                    $Transaction->save();
                    $TransactionsInsert = true;
                    }
                } catch ( \Exception $e ) {
            		$message = array (
            				'message' => $e->getMessage (),
            				'messageforme' => 'all data not found! Transaction'
            		);
            		return json_encode ( [
            				'error' => true,
            				'message' => $message
            		] );
            }
            

            
        // Units
            try {
				foreach($Units as $Unitsreq) {
                      $Unit = new Unit;
                      $Unit->UID = $Unitsreq['UID'];
                      $Unit->UnitName = $Unitsreq['UnitName'];
                      $Unit->AddDate = $Unitsreq['AddDate'];
                      $Unit->UpdateDate = $Unitsreq['UpdateDate'];
                      $Unit->Flag = $Unitsreq['Flag'];
                      $Unit->MainAccountID = $Unitsreq['MainAccountID'];
                      $Unit->SubMainAccountID = $Unitsreq['SubMainAccountID'];
                      $Unit->BranchID = $Unitsreq['BranchID'];
                      $Unit->Synch = $Unitsreq['Synch'];
                      $Unit->MainAccount_Seq = $syncdatetime;
                      $Unit->save();
                      $UnitsInsert = true;
                    }
                } catch ( \Exception $e ) {
            		$message = array (
            				'message' => $e->getMessage (),
            				'messageforme' => 'all data not found! Units'
            		);
            		return json_encode ( [
            				'error' => true,
            				'message' => $message
            		] );
            }
            
            
    // LabelsConfigration
            try {
				foreach($LabelsConfigrations as $LabelsConf) {
				    $LabelsConfigration = new LabelsConfigration;
                    $LabelsConfigration->Name = $LabelsConf['Name'];
                    $LabelsConfigration->companyfontsize = $LabelsConf['companyfontsize'];
                    $LabelsConfigration->pricefontsize = $LabelsConf['pricefontsize'];
                    $LabelsConfigration->defaultfontsize = $LabelsConf['defaultfontsize'];
                    $LabelsConfigration->imagewidth = $LabelsConf['imagewidth'];
                    $LabelsConfigration->imagehight = $LabelsConf['imagehight'];
                    $LabelsConfigration->lablewidht = $LabelsConf['lablewidht'];
                    $LabelsConfigration->lableheight = $LabelsConf['lableheight'];
                    $LabelsConfigration->barcodewidth = $LabelsConf['barcodewidth'];
                    $LabelsConfigration->barcodeheight = $LabelsConf['barcodeheight'];
                    $LabelsConfigration->showcompany = $LabelsConf['showcompany'];
                    $LabelsConfigration->showitemname = $LabelsConf['showitemname'];
                    $LabelsConfigration->showbarcodeimage = $LabelsConf['showbarcodeimage'];
                    $LabelsConfigration->showbarcode = $LabelsConf['showbarcode'];
                    $LabelsConfigration->showitemcode = $LabelsConf['showitemcode'];
                    $LabelsConfigration->showitemprice = $LabelsConf['showitemprice'];
                    $LabelsConfigration->MainAccountID = $LabelsConf['MainAccountID'];
                    $LabelsConfigration->SubMainAccountID = $LabelsConf['SubMainAccountID'];
                    $LabelsConfigration->Synch = $LabelsConf['Synch'];
                    $LabelsConfigration->MainAccount_Seq = $syncdatetime;
                    $LabelsConfigration->DefaultLable = $LabelsConf['DefaultLable'];
                    $LabelsConfigration->BranchID = $LabelsConf['BranchID'];
                    $LabelsConfigration->save();
                    $LabelsConfigrationInsert = true;
                    }
                } catch ( \Exception $e ) {
            		$message = array (
            				'message' => $e->getMessage (),
            				'messageforme' => 'all data not found! Units'
            		);
            		return json_encode ( [
            				'error' => true,
            				'message' => $message
            		] );
            }
            
     
     
        //get max from db for all tables
                 $lastAccount = Account::max('MainAccount_Seq');
                 $StockLastId = Stock::max('MainAccount_Seq');
                 $CashAccountLastId = CashAccount::max('MainAccount_Seq');
                 $Collection_ItemLastId = Collection_Item::max('MainAccount_Seq');
                 $CurrencyLastId = Currency::max('MainAccount_Seq');
                 $ItemBarcodeLastId = ItemBarcode::max('MainAccount_Seq');
                 $ItemGroupLastId = ItemGroup::max('MainAccount_Seq');
                 $ItemUnitLastId = ItemUnit::max('MainAccount_Seq');
                 $ItemLastId = Item::max('MainAccount_Seq');
                 $PictureLastId = Picture::max('MainAccount_Seq');
                 $PriceLastId = Price::max('MainAccount_Seq');
                 $SettingLastId = Setting::max('MainAccount_Seq');
                 $SignitureLastId = Signiture::max('MainAccount_Seq');
                 $TransactionLastId = Transaction::max('MainAccount_Seq');
                 $UnitLastId = Unit::max('MainAccount_Seq');
                 $LabelsConfigrationLastId = LabelsConfigration::max('MainAccount_Seq');
                 
        //return data 
            	 return json_encode ( [
        			'success' => true,
        			'message' => "تم مزامنة البيانات بنجاح",
        			
        			'Accounts' => $AccountInsert,
        			'AccountsLastId' => $lastAccount,
        			
        			'Stocks' => $StocktInsert,
        			'StocksLastId' => $StockLastId,
        			
        			'CashAccounts' => $CashAccountsInsert,
        			'CashAccountsLastId' => $CashAccountLastId,
        			
        			'Collection_Items' => $CollectionItemsInsert,
        			'Collection_ItemsLastId' => $Collection_ItemLastId,
        			
        			'Currencies' => $CurrencyInsertInsert,
        			'CurrenciesLastId' => $CurrencyLastId,
        			
        			'ItemBarcodes' => $ItemBarcodesInsert,
        			'ItemBarcodesLastId' => $ItemBarcodeLastId,
        			
        			'ItemGroups' => $ItemGroupsInsert,
        			'ItemGroupsLastId' => $ItemGroupLastId,
        			
       			    'ItemUnits' => $ItemUnitsInsert,
        			'ItemUnitsLastId' => $ItemUnitLastId,
        			
       			    'Items' => $ItemsInsert,
        			'ItemsLastId' => $ItemLastId,
        			
       			    'Pictures' => $PicturesInsert,
        			'PicturesLastId' => $PictureLastId,
        			
       			    'Pricing' => $PricingInsert,
        			'PricingLastId' => $PriceLastId,
        			
       			    'Settings' => $SettingsInsert,
        			'SettingsLastId' => $SettingLastId,
        			
       			    'Signitures' => $SignituresInsert,
        			'SignituresLastId' => $SignitureLastId,
        			
       			    'Transactions' => $TransactionsInsert,
        			'TransactionsLastId' => $TransactionLastId,
        			
       			    'Units' => $UnitsInsert,
        			'UnitsLastId' => $UnitLastId,

       			    'LabelsConfigration' => $LabelsConfigrationInsert,
        			'LabelsConfigrationLastId' => $LabelsConfigrationLastId,
        			]);
             }
             
             
            
    public function insertArrayValues() 
    {
    }
}