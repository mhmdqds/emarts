<?php
namespace App\Http\Controllers\API;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;
use App\CommentData;

class CommentDataController extends Controller {
	

 public function create(Request $request)
    {
        //$AccountNames = $request->AccountNames;
        //$Mobiles = $request->Mobiles;
        //$Addresss = $request->Addresss;
        //$Comments = $request->Comments;
       
          // return json_encode ( [
				//		'success' => true,
			//			'CommentData' => $Comments
			//	] );
			try {
		$data = json_encode($request);
		
	    $CommentData2 = CommentData::create ($request->all());
        return json_encode ( [
						'success' => true,
						'CommentData' => $CommentData2
				] );
			} catch ( \Exception $e ) {
			$message = array (
					'message' => $e->getMessage ()
			);
			return json_encode ( [
					'error' => true,
					'message' => $message
			] );
		}
    
      //$CommentData = new CommentData;
      //$CommentData->AccountNames = $request->AccountNames;
      //$CommentData->Mobiles = $request->Mobiles; 
      //$CommentData->Addresss = $request->Addresss;
     // $CommentData->Comments = $request->Comments;
	  //$CommentData->save();
       
         
      

    }

	

}