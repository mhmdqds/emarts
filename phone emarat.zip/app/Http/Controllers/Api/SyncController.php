<?php
namespace App\Http\Controllers\API;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;
use App\Account;
use App\Stock;
use App\CashAccount;
use App\Collection_Item;
use App\Currency;
use App\ItemBarcode;
use App\ItemGroup;
use App\ItemUnit;
use App\Item;
use App\Picture;
use App\Price;
use App\Setting;
use App\Signiture;
use App\Transaction;
use App\Unit;
use App\LabelsConfigration;

class SyncController extends Controller {
     
    public function SyncData(Request $request)
    {
        
        $lastAccount = 0;
        $StockLastId = 0;
        $CashAccountLastId = 0;
        $Collection_ItemLastId = 0; 
        $CurrencyLastId = 0;
        $ItemBarcodeLastId = 0;
        $ItemGroupLastId = 0;
        $ItemUnitLastId = 0;
        $ItemLastId = 0;
        $PictureLastId = 0;
        $PriceLastId = 0;
        $SettingLastId = 0;
        $SignitureLastId = 0;
        $TransactionLastId = 0;
        $UnitLastId = 0;
        $LabelsConfigrationLastId = 0;
        
    
     
        //get max from db for all tables
                 $lastAccount = Account::max('MainAccount_Seq');
                 $StockLastId = Stock::max('MainAccount_Seq');
                 $CashAccountLastId = CashAccount::max('MainAccount_Seq');
                 $Collection_ItemLastId = Collection_Item::max('MainAccount_Seq');
                 $CurrencyLastId = Currency::max('MainAccount_Seq');
                 $ItemBarcodeLastId = ItemBarcode::max('MainAccount_Seq');
                 $ItemGroupLastId = ItemGroup::max('MainAccount_Seq');
                 $ItemUnitLastId = ItemUnit::max('MainAccount_Seq');
                 $ItemLastId = Item::max('MainAccount_Seq');
                 $PictureLastId = Picture::max('MainAccount_Seq');
                 $PriceLastId = Price::max('MainAccount_Seq');
                 $SettingLastId = Setting::max('MainAccount_Seq');
                 $SignitureLastId = Signiture::max('MainAccount_Seq');
                 $TransactionLastId = Transaction::max('MainAccount_Seq');
                 $UnitLastId = Unit::max('MainAccount_Seq');
                 $LabelsConfigrationLastId = LabelsConfigration::max('MainAccount_Seq');
                 
                 

		// Check if the phone exists
        if ($request->MainAccountID == $request->SubMainAccountID) 
        {
			try {
				$AccountData = Account::where('MainAccountID', $request->MainAccountID)->where('MainAccount_Seq', '>' ,$request->AccountsLastId)->get();
				$StocksData  = Stock::where('MainAccountID', $request->MainAccountID)->where('MainAccount_Seq', '>' ,$request->StocksLastId)->get();
				$CashAccountData = CashAccount::where('MainAccountID', $request->MainAccountID)->where('MainAccount_Seq', '>' ,$request->CashAccountsLastId)->get();
				$Collection_ItemData = Collection_Item::where('MainAccountID', $request->MainAccountID)->where('MainAccount_Seq', '>' ,$request->Collection_ItemsLastId)->get();
				$CurrencyData = Currency::where('MainAccountID', $request->MainAccountID)->where('MainAccount_Seq', '>' ,$request->CurrenciesLastId)->get();
				$ItemBarcodeData = ItemBarcode::where('MainAccountID', $request->MainAccountID)->where('MainAccount_Seq', '>' ,$request->ItemBarcodesLastId)->get();
				$ItemGroupData = ItemGroup::where('MainAccountID', $request->MainAccountID)->where('MainAccount_Seq', '>' ,$request->ItemGroupsLastId)->get();
				$ItemUnitsData = ItemUnit::where('MainAccountID', $request->MainAccountID)->where('MainAccount_Seq', '>' ,$request->ItemUnitsLastId)->get();
				$ItemsData = Item::where('MainAccountID', $request->MainAccountID)->where('MainAccount_Seq', '>' ,$request->ItemsLastId)->get();
				$PicturesData = Picture::where('MainAccountID', $request->MainAccountID)->where('MainAccount_Seq', '>' ,$request->PicturesLastId)->get();
				$PricingData = Price::where('MainAccountID', $request->MainAccountID)->where('MainAccount_Seq', '>' ,$request->PricingLastId)->get();
				$SettingsData = Setting::where('MainAccountID', $request->MainAccountID)->where('MainAccount_Seq', '>' ,$request->SettingsLastId)->get();
				$SignituresData = Signiture::where('MainAccountID', $request->MainAccountID)->where('MainAccount_Seq', '>' ,$request->SignituresLastId)->get();
				$TransactionsData = Transaction::where('MainAccountID', $request->MainAccountID)->where('MainAccount_Seq', '>' ,$request->TransactionsLastId)->get();
				$UnitsData = Unit::where('MainAccountID', $request->MainAccountID)->where('MainAccount_Seq', '>' ,$request->UnitsLastId)->get();
				$LabelsConfigrationData = LabelsConfigration::where('MainAccountID', $request->MainAccountID)->where('MainAccount_Seq', '>' ,$request->LabelsConfigrationLastId)->get();
				return json_encode ( [
        			'success' => true,
        			'message' => "تم مزامنه البيانات",
        			'AccountsData' => $AccountData,
        			'StocksData' => $StocksData,
        			'CashAccountData' => $CashAccountData,
        			'Collection_ItemData' => $Collection_ItemData,
        			'CurrencyData' => $CurrencyData,
        			'ItemBarcodeData' => $ItemBarcodeData,
        			'ItemGroupData' => $ItemGroupData,
        			'ItemUnitsData' => $ItemUnitsData,
        			'ItemsData' => $ItemsData,
        			'PicturesData' => $PicturesData,
        			'PricingData' => $PricingData,
        			'SettingsData' => $SettingsData,
        			'SignituresData' => $SignituresData,
        			'TransactionsData' => $TransactionsData,
        			'UnitsData' => $UnitsData,
        			'LabelsConfigrationData' => $LabelsConfigrationData,
        		    'AccountsLastId' => $lastAccount,
        			'StocksLastId' => $StockLastId,
        			'CashAccountsLastId' => $CashAccountLastId,
        			'Collection_ItemsLastId' => $Collection_ItemLastId,
        			'CurrenciesLastId' => $CurrencyLastId,
        			'ItemBarcodesLastId' => $ItemBarcodeLastId,
        			'ItemGroupsLastId' => $ItemGroupLastId,
        			'ItemUnitsLastId' => $ItemUnitLastId,
        			'ItemsLastId' => $ItemLastId,
        			'PicturesLastId' => $PictureLastId,
        			'PricingLastId' => $PriceLastId,
        			'SettingsLastId' => $SettingLastId,
        			'SignituresLastId' => $SignitureLastId,
        			'TransactionsLastId' => $TransactionLastId,
        			'UnitsLastId' => $UnitLastId,
        			'LabelsConfigrationLastId' => $LabelsConfigrationLastId,
        			]);
				}catch ( \Exception $e ) {
            		$message = array (
            				'message' => $e->getMessage (),
            				'messageforme' => 'all data not found! Account'
            		);
            		return json_encode ( [
            				'error' => true,
            				'message' => $message
            		] );
                }
		} 
		else {
		    try {
			$AccountData = Account::where('SubMainAccountID', $request->SubMainAccountID)->where('MainAccount_Seq', '>' ,$request->AccountsLastId)->get();
			$StocksData  = Stock::where('SubMainAccountID', $request->SubMainAccountID)->where('MainAccount_Seq', '>' ,$request->StocksLastId)->get();
			$CashAccountData = CashAccount::where('SubMainAccountID', $request->SubMainAccountID)->where('MainAccount_Seq', '>' ,$request->CashAccountsLastId)->get();
			$Collection_Item = Collection_Item::where('SubMainAccountID', $request->SubMainAccountID)->where('MainAccount_Seq', '>' ,$request->Collection_ItemsLastId)->get();
			$CurrencyData = Currency::where('SubMainAccountID', $request->SubMainAccountID)->where('MainAccount_Seq', '>' ,$request->CurrenciesLastId)->get();
			$ItemBarcodeData = ItemBarcode::where('SubMainAccountID', $request->SubMainAccountID)->where('MainAccount_Seq', '>' ,$request->ItemBarcodesLastId)->get();
			$ItemGroupData = ItemGroup::where('SubMainAccountID', $request->SubMainAccountID)->where('MainAccount_Seq', '>' ,$request->ItemGroupsLastId)->get();
			$ItemUnitsData = ItemUnit::where('SubMainAccountID', $request->SubMainAccountID)->where('MainAccount_Seq', '>' ,$request->ItemUnitsLastId)->get();
			$ItemsData = Item::where('SubMainAccountID', $request->SubMainAccountID)->where('MainAccount_Seq', '>' ,$request->ItemsLastId)->get();
			$PicturesData = Picture::where('SubMainAccountID', $request->SubMainAccountID)->where('MainAccount_Seq', '>' ,$request->PicturesLastId)->get();
			$PricingData = Price::where('SubMainAccountID', $request->SubMainAccountID)->where('MainAccount_Seq', '>' ,$request->PricingLastId)->get();
			$SettingsData = Setting::where('SubMainAccountID', $request->SubMainAccountID)->where('MainAccount_Seq', '>' ,$request->SettingsLastId)->get();
			$SignituresData = Signiture::where('SubMainAccountID', $request->SubMainAccountID)->where('MainAccount_Seq', '>' ,$request->SignituresLastId)->get();
			$TransactionsData = Transaction::where('SubMainAccountID', $request->SubMainAccountID)->where('MainAccount_Seq', '>' ,$request->TransactionsLastId)->get();
			$UnitsData = Unit::where('SubMainAccountID', $request->SubMainAccountID)->where('MainAccount_Seq', '>' ,$request->UnitsLastId)->get();
			$LabelsConfigrationData = LabelsConfigration::where('SubMainAccountID', $request->SubMainAccountID)->where('MainAccount_Seq', '>' ,$request->LabelsConfigrationLastId)->get();
			return json_encode ( [
        			'success' => true,
        			'message' => "تم مزامنه البيانات",
        			'AccountsData' => $AccountData,
        			'StocksData' => $StocksData,
        			'CashAccountData' => $CashAccountData,
        			'Collection_Item' => $Collection_Item,
        			'CurrencyData' => $CurrencyData,
        			'ItemBarcodeData' => $ItemBarcodeData,
        			'ItemGroupData' => $ItemGroupData,
        			'ItemUnitsData' => $ItemUnitsData,
        			'ItemsData' => $ItemsData,
        			'PicturesData' => $PicturesData,
        			'PricingData' => $PricingData,
        			'SettingsData' => $SettingsData,
        			'SignituresData' => $SignituresData,
        			'TransactionsData' => $TransactionsData,
        			'UnitsData' => $UnitsData,
        			'LabelsConfigrationData' => $LabelsConfigrationData,
        		    'AccountsLastId' => $lastAccount,
        			'StocksLastId' => $StockLastId,
        			'CashAccountsLastId' => $CashAccountLastId,
        			'Collection_ItemsLastId' => $Collection_ItemLastId,
        			'CurrenciesLastId' => $CurrencyLastId,
        			'ItemBarcodesLastId' => $ItemBarcodeLastId,
        			'ItemGroupsLastId' => $ItemGroupLastId,
        			'ItemUnitsLastId' => $ItemUnitLastId,
        			'ItemsLastId' => $ItemLastId,
        			'PicturesLastId' => $PictureLastId,
        			'PricingLastId' => $PriceLastId,
        			'SettingsLastId' => $SettingLastId,
        			'SignituresLastId' => $SignitureLastId,
        			'TransactionsLastId' => $TransactionLastId,
        			'UnitsLastId' => $UnitLastId,
        			'LabelsConfigrationLastId' => $LabelsConfigrationLastId,
        			]);
				}catch ( \Exception $e ) {
            		$message = array (
            				'message' => $e->getMessage (),
            				'messageforme' => 'all data not found! Account'
            		);
            		return json_encode ( [
            				'error' => true,
            				'message' => $message
            		] );
                }
		}
	}
}