<?php
namespace App\Http\Controllers\API;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;
use App\UsersHistoryUse;



class UserHistoryController extends Controller {
	
	protected $per_page;


 public function adduserhistory(Request $request)
    {
       
      $UsersHistoryUse = new UsersHistoryUse;
      $UsersHistoryUse->email = $request->email;
      $UsersHistoryUse->name = $request->name;
      $UsersHistoryUse->phone = $request->phone;
      $UsersHistoryUse->numberoprtion = $request->numberoprtion;
      $UsersHistoryUse->department = $request->department;
	  $UsersHistoryUse->save();
        if ($UsersHistoryUse) {
           return json_encode ( [
						'success' => true,
						'UsersHistoryUse' => $UsersHistoryUse
				] );
        } else {
			return json_encode ( [
						'success' => false,
						'UsersHistoryUse' => null,
						'message' => 'User not found', 
						 401
				] );
        }

    }

	

}