<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Admin\Customer;
use App\Admin\Contact;
use Illuminate\Support\Str;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Intervention\Image\Facades\Image;
use App\CPU\ImageManager;



class SupportTicketController extends Controller
{
    public $successStatus = 200;

    public function index()
    {
        //$data = Ticket::where(['user_id' => $request['user_id']])->first();
        $data = Contact::all();
        return response()->json($data);
    }

    public function addcompint(Request $request)
    {
        
     $cheacklsit = Contact::where('ticketId',$request->ticketId)->first();
     

        if($cheacklsit){
            Contact::where('productname',$request->productname)->where('ticketId',$request->ticketId)->first();
            return response()->json($cheacklsit);
        } else {
             $file_data = $request->photo;
             $file_name = 'image_' . time() . '.png'; //generating unique file name;
             $uploadPath = 'public/uploads/';
             $imageUrl = $uploadPath.$file_name; 

             if ($file_data != "") {
                   // storing image in storage/app/public Folder
                   Storage::disk('uploads')->put($file_name, base64_decode($file_data));
             }
             $Contact = Contact::create([
            'name'              => $request->name,
            'mobile'            => $request->mobile,
            'email'             => $request->mobile,
            'subject'           => $request->subject,
            'description'       => $request->description,
            'complinttype'      => $request->complinttype,
            'producttype'       => $request->producttype,
            'status'            => '1',
            'productname'       => $request->productname,
            'user_id'           => $request->user_id,
            'message'           => $request->message,
            'ticketId'          => $request->ticketId,
            'ticketdate'        => $request->ticketdate,
            'photo'             => $imageUrl,
            ]);
        return response()->json($Contact);
        }

    }

   public function addcompintphoto(Request $request)
    {
        
     $cheacklsit = Contact::where('mobile',$request->mobile)->where('subject',$request->subject)->where('description',$request->description)->where('complinttype',$request->complinttype)
     ->where('producttype',$request->producttype)->where('productname',$request->productname)->where('message',$request->message)
     ->where('ticketId',$request->ticketId)->first();

     if ($request->has('photo')) {
            $imageName = ImageManager::upload('profile/', 'png', $request->file('photo'));
        }

        if($cheacklsit){
            $Contact = Contact::where('mobile',$request->mobile)->where('subject',$request->subject)->where('description',$request->description)->where('complinttype',$request->complinttype)
            ->where('producttype',$request->producttype)->where('productname',$request->productname)->where('message',$request->message)
            ->where('ticketId',$request->ticketId)->first();
            return response()->json($Contact);
        } else {
              $Contact = Contact::create([
            'name'              => $request->name,
            'mobile'            => $request->mobile,
            'email'             => $request->mobile,
            'subject'           => $request->subject,
            'description'       => $request->description,
            'complinttype'      => $request->complinttype,
            'producttype'       => $request->producttype,
            'status'            => '1',
            'productname'       => $request->productname,
            'user_id'           => $request->user_id,
            'message'           => $request->message,
            'ticketId'          => $request->ticketId,
            'photo'             => $imageName,
            ]);
        return response()->json($Contact);
        }

    }
    
    public function edit(Request $request)
    {
        $data = Contact::find($request->id);
        return response()->json($data);
    }

    public function update(Request $request)
    {
        Contact::where('id',$request->id)
            ->update([
                    'name'    => $request->name,
                    'mobile'  => $request->mobile,
                    'address' => $request->address,
                    'balance' => $request->balance,
                ]);
        $msg = 'Updated Successfully';
        return response()->json($msg);
    }

    public function status(Request $request)
    {
        $data = Contact::find($request->id);
        if ($data->status == '1') {
            $data->status = '0';    
        }
        else{   
            $data->status = '1';    
        }
        $data->save();
        $msg = 'Status Changed Successfully';
        return response()->json($msg);
    }

    public function delete(Request $request)
    {
        $data = Contact::find($request->id);
        $data->delete();
        $msg = 'Delete Successfully';
        return response()->json($msg);
    }
}
