<?php
namespace App\Http\Controllers\API;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;
use App\Branche;



class BranchesController extends Controller {
	
        //$data = json_decode($jsonData, true);
		//$data = json_decode($res->getBody(), true); // to array
		//$Account = Account::insert(@$data['data']); 
		//$Account = DB::table('status_employee')->insert(json_decode($res->getBody(),true)['data']);


    public function create(Request $request)
    {
        $branshlimtnumber = User::where('MainAccountID', $request->MainAccountID)->first()->Branchlimit;
        $Branchecountfromuser = Branche::where('MainAccountID', $request->MainAccountID)->count();

		if ($branshlimtnumber < $Branchecountfromuser) {
			   return json_encode ( [
							'success' => false,
							'Branche' => null,
                            'message' => 'لا يمكن اضافه فروع جديده تجاوزت الحدد المسموح به يرجى التواصل مع الدعم الفني للبرنامج',
                            ] );
		} else {
		try {
		    $data = json_encode($request);
			$Branche = Branche::create ($request->all());
			return json_encode ( [
					'success' => true,
					'Branche' => $Branche
			] );
		} catch ( \Exception $e ) {
			$message = array (
					'message' => $e->getMessage ()
			);
			return json_encode ( [
					'error' => true,
					'message' => $message
			] );
		}
        }
    
    }
    
	/**
	 *
	 * @return \Illuminate\Http\Response
	 * Display a listing of the resource.
	*/

    public function insertArrayValues() 
    {



    }
}