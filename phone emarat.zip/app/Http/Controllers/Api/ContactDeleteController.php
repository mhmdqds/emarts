<?php
namespace App\Http\Controllers\API;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\ContactsPhones;
use App\User;

class ContactDeleteController extends Controller {
		
		protected $per_page;

    
    public function update(Request $request)
    {
        $id = $request->input('DeleteContactId');
        $ContactsPhone = ContactsPhones::find($id);
        $ContactsPhone->HideContact = 1;
        $ContactsPhone->save();
        return json_encode ( [
					'success' => true,
		] );    
    
    }   

}