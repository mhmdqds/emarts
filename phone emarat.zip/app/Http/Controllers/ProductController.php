<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Medicine;
use App\Models\ContactsPhone;
use Illuminate\Support\Facades\Auth;
use App\Imports\MedicineImport;
use Maatwebsite\Excel\Facades\Excel;

class ProductController extends Controller
{

    public function index()
    {
        
        $data = Medicine::orderBy('id', 'DESC')->get();
        return view('pages.member.medicineReport', compact('data'));
    }

    public function create(){
        $data = Medicine::orderBy('id', 'DESC')->get();

        return view('pages.member.medicineReport', compact('data'));
    }

    public function store(Request $request){
        $user_id = Auth::user()->id;
        $status = 1;

        $this->validate(request(), [        
            'barcode' => 'required|unique:products',
            'name' => 'required|unique:products',
            'category' => 'required',     
            'medicine_unit'=>'required',     
            'medicine_shelf'=>'required',     
            'generic_name'=>'required',     
            'medicine_type' => 'required',     
            'min_stock' => 'required',     
            'seller_price' => 'required',     
            'manufacturer_id' => 'required',     
            'manufacturer_price' => 'required',     
        ]);

        $medicine = Product::create([
            'user_id' => $user_id,
            'barcode' => $request->barcode,
            'name' => $request->name,
            'category' => $request->category,
            'medicine_shelf' => $request->medicine_shelf,
            'strength' => $request->strength,
            'medicine_unit' => $request->medicine_unit,
            'generic_name' => $request->generic_name,
            'min_stock' => $request->min_stock,
            'medicine_type' => $request->medicine_type,
            'details' => $request->details,
            'vat' => $request->vat,
            'tax' => $request->tax,
            'seller_price' => $request->seller_price,
            'manufacturer_id' => $request->manufacturer_id,
            'manufacturer_price' => $request->manufacturer_price,
            'status' => $status,
            'shop' => $user_id,
        ]);
       return redirect(route('pages.member.medicineReport'))->with('success','Medicine Added Successfully');
    }


    public function importView(){
       return view('pages.member.importView');
    }

    public function import( Request $request ) {
        $file  = $request->file('file');
        Excel::import(new MedicineImport,$file);
        return redirect(route('phoneList'))->with('success','Data Imported Successfully');
    }
	
	public function importjson( Request $request ) {
        $file  = $request->file('file');
		$data = json_decode(file_get_contents($file), true);
		foreach ($data as $person_name => $person_a) {
			echo $person_a['displayName'];
	}
		foreach($data as $row) {
			DB::table('contactlistapp')->insert(array(
				'displayName' => ((isset($obj->displayName) ? $obj->displayName : null)),
				'phone1' => ((isset($obj->phone1) ? $obj->phone1 : null)),
				'phone2' => ((isset($obj->phone2) ? $obj->phone2 : null)),
				'phone3' => ((isset($obj->phone3) ? $obj->phone3 : null)),
				'phone4' => ((isset($obj->phone4) ? $obj->phone4 : null)),
				'countryCode' => ((isset($obj->countryCode) ? $obj->countryCode : null)),
				'dateNow' => ((isset($obj->dateNow) ? $obj->dateNow : null)),
				'HideContact' => ((isset($obj->HideContact) ? $obj->HideContact : null)),
			));
		}

        return redirect(route('medicineReport'))->with('success','Data Imported Successfully');
    }

}



