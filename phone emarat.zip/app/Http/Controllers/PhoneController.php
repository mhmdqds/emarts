<?php

namespace App\Http\Controllers;

use App\Employee;
use App\Helpers\QRCodeHelper;
use App\Models\History;
use App\Models\Patient;
use App\Models\UserLog;
use App\Models\Keyword;
use App\Models\User;
use App\Models\Office;
use App\Models\ContactsEmarat;
use App\Models\ContactsPhones;
use App\Models\Contactsegypt;
use App\Models\ContactsKuwait;
use App\Models\SameContact;
use App\Models\Medicine;
use App\Notifications\EmailHistory;
use http\Message;
use Illuminate\Http\Request;
use http\Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use jeremykenedy\LaravelRoles\Models\Role;
use SimpleSoftwareIO\QrCode\Facades\QrCode;
use Twilio\Rest\Client;
use Yajra\DataTables\Facades\DataTables;
use Illuminate\Database\Eloquent\Model;
use IlluminateDatabaseEloquentModel;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Intervention\Image\Facades\Image;
use Carbon\Carbon;

use App\Notifications\Reviews;
use Illuminate\Http\Response;
use Notification;
use App\Notifications\Emailto;
use PDF;
use App\Exports\SalesExport;
use App\Exports\PhoneExport;
use App\Exports\PhoneExports;
use App\Exports\PhonesExports;
use Maatwebsite\Excel\Facades\Excel;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xls;
use PhpOffice\PhpSpreadsheet\IOFactory;

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use Illuminate\Support\Str;

class PhoneController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Create a new user instance after a valid registration.
     *
     * @param array $data
     * @return \App\Models\Patient
     */
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */

	public function phoneList()
    {
		$users = User::all();
        $roles = Role::all()->sortBy('level');
        $offices = Office::all()->sortBy('office_id');
        $Contactsegypt = DB::table('contactsegypts')->orderBy('created_at', 'DESC')->paginate(10000);
		return view('pages.member.portalPhone')->with([
            'users' => $users,
            'roles' => $roles,
            'offices' => $offices,
			'contactphones' => $Contactsegypt
        ]);
    }
    
    
	public function phoneListemarat()
    {
		$users = User::all();
        $roles = Role::all()->sortBy('level');
        $offices = Office::all()->sortBy('office_id');
        $Contactsegypt = DB::table('contactsemarats')->orderBy('created_at', 'DESC')->paginate(2000);
		return view('pages.member.portalPhoneEmarat')->with([
            'users' => $users,
            'roles' => $roles,
            'offices' => $offices,
			'contactphones' => $Contactsegypt
        ]);
    }
    
    
		
	public function KeyWordList()
    {
        $keywords = Keyword::all()->sortBy('keyword_name');
   		return view('pages.phonelist.keywordlist')->with([
			'keywords' => $keywords
        ]);
       
    }
	
	public function phonewords()
    {
		$users = User::all();
        $roles = Role::all()->sortBy('level');
        $offices = Office::all()->sortBy('office_id');
        $Contactsegypt = DB::table('contactsegypts')->orderBy('created_at', 'DESC')->paginate(1000);
		return view('pages.phonelist.addkeyword')->with([
            'users' => $users,
            'roles' => $roles,
            'offices' => $offices,
			'contactphones' => $Contactsegypt
        ]);
       
    }
	
	public function keywordsearch(Request $request)
    {
        $search = $request->search;
		$keywords = Keyword::all()->sortBy('keyword_name');
		if($search == 'All'){
				if ($request->has('search')) {
				$search = $request->search;
				$contactsegypts = DB::table('contactsegypts')->orderBy('created_at', 'DESC')->paginate(10000);
			}
			return view('pages.member.portalPhone')->with([
				'keywords' => $keywords,
				'contactphones' => $contactsegypts,
				
			]);
		} else {
			$keywords = Keyword::all()->sortBy('keyword_name');
			$contactsegypts = DB::table('contactsegypts')->orderBy('created_at', 'DESC')->paginate(10000);
			$search = null;
			if ($request->has('search')) {
				$search = $request->search;
				$contactsegypts = DB::table('contactsegypts')->where('created_at', 'like', '%'.$search.'%')->orderBy('created_at', 'DESC')->paginate(10000);
			}
			return view('pages.phonelist.keywordHome')->with([
				'keywords' => $keywords,
				'contactlistapp' => $contactsegypts,
				
			]);
		}
    }

	public function samenaumbers()
    {
        $Contactsegypts = Contactsegypt::all();
        $samecontacts = SameContact::all();
		$keywords = Keyword::all()->sortBy('keyword_name');
		$identifiers = Contactsegypt::all()->groupBy('identifier');

        return view('pages.phonelist.samenumber')->with([
            'contactlistapp' => $Contactsegypts,
			'keywords' => $keywords,
			'samecontacts' => $samecontacts,
			'identifiers' => $identifiers
        ]);
    }
	
	public function samenaumberscheack()
    {
        $Contactsegypts = Contactsegypt::all()->sortBy('phone1');
        $ContactsAll = Contactsegypt::all()->sortBy('identifier');
        $samecontacts = SameContact::all();
		$keywords = Keyword::all()->sortBy('keyword_name');
			//Log::debug("Contactsegypts###" . json_encode($Contactsegypts));

		foreach ($Contactsegypts as $Contacts) {
			
			 $countdublcate = 0;

			try {
			
			  foreach ($ContactsAll as $ContactSub) {
				if(
					$Contacts->displayName 	== $ContactSub->displayName &&
					$Contacts->phone1 		== $ContactSub->phone1 &&
					$Contacts->phone2 		== $ContactSub->phone2 &&
					$Contacts->phone3 		== $ContactSub->phone3 &&
					$Contacts->phone4 		== $ContactSub->phone4 &&
					$Contacts->identifier 	== $ContactSub->identifier 
				){

				$countdublcate = $countdublcate +1;
				
				if($countdublcate == 2){
						$countdublcate = $countdublcate -1;
						
						$samecontacts = new SameContact;
						$samecontacts->displayName	= $ContactSub->displayName;
						$samecontacts->phone1		= $ContactSub->phone1;
						$samecontacts->phone2		= $ContactSub->phone2;
						$samecontacts->phone3 		= $ContactSub->phone3;
						$samecontacts->phone4 		= $ContactSub->phone4;
						$samecontacts->identifier 	= $ContactSub->identifier;
						$samecontacts->countryCode 	= $ContactSub->countryCode;
						$samecontacts->dateNow 		= $ContactSub->dateNow;
						$samecontacts->HideContact 	= $ContactSub->HideContact;
						$samecontacts->active 		= $ContactSub->active;
						
						$samecontacts->save();
						
						//$NumberReturn = Contactsegypt::findOrFail($ContactSub->id);
						$ContactSub->delete();
					}

				}  
			}
		
		} catch (Exception $e) {
                    return redirect()->route('samenaumberscheack')->with([
                        'active' => $patient->active
                    ]);
                }
		}
        return view('pages.phonelist.samenumber')->with([
            'contactlistapp' => $Contactsegypts,
			'keywords' => $keywords,
			'samecontacts' => $samecontacts
        ]);
    }

	public function keywordhomeEdit(Request $request, $id)
    {

    }
	
	public function keywordhomeProfile(Request $request, $id)
    {

    }
	
	public function keywordGenerator(Request $request)
    {
			Log::debug("request data ### " . json_encode($request->all()));
            $data = $request->input();
			try {
                $keyword = new Keyword;
                $keyword->keyword_name = $data['name']; 
                $keyword->notes = $data['notes'];
                $keyword->active = 0;
                $keyword->counter = 0;
                $keyword->save();
				
				$contactscount = DB::table('contactsegypts')->where('displayName', $data['name'])->count();
				$contactslike  = DB::table('contactsegypts')->where('displayName', 'like', '%'.$data['name'].'%')->count();
				$keyword->keyword_old = $contactslike;
				$keyword->keyword_new = $contactscount;
				$keyword->counter = $contactslike + $contactscount;
				$keyword->active = 1;
				$keyword->save();

                return redirect()->route('phoneList');
            } catch (Exception $e) {
                return response()->json([
                    'success' => false,
                    'message' => $e->messages()
                ]);
            }
    }
	
	public function keywordedit($id)
    {
        $keyword = Keyword::query()->findOrFail($id);
        return view('pages.phonelist.Editkyeword')->with([
            'keyword' => $keyword
        ]);
    }
	
	public function keywordshow($id)
    {
         $keyword = Keyword::query()->findOrFail($id);
        return view('pages.phonelist.Editkyeword')->with([
            'keyword' => $keyword
        ]);
    }
	
	public function keywordupdate(Request $request, $id)
    {
       $keyword = Keyword::query()->findOrFail($id);
	   try {
                $keyword->keyword_name = $data['name']; 
                $keyword->notes = $data['notes'];
                $keyword->active = 0;
                $keyword->counter = 0;
                $keyword->save();
                return redirect()->route('keywordList');
            } catch (Exception $e) {
                return redirect()->route('keywordList');
            }

    }
	
	public function keyworddestroy($id)
    {
        $keyword = Keyword::query()->findOrFail($id);
//        $user->roles()->detach();
        $keyword->delete();
//        return redirect()->route('adminUsers.index');
        return redirect()->route('keywordList');
    }
	
	public function phoneListsearch(Request $request)
    {
        $Contactsegypt = DB::table('contactsegypts')->orderBy('displayName', 'DESC')->paginate(10000);
		$search = null;
        if ($request->has('search')) {
            $search = $request->search;
            $Contactsegypt = DB::table('contactsegypts')->where('displayName', 'like', '%'.$search.'%')->orderBy('displayName', 'DESC')->paginate(10000);
        }
		return view('pages.member.portalPhone')->with([
			'contactphones' => $Contactsegypt
        ]);
    }
    
    	public function phoneListsearchEmarat(Request $request)
    {
        $Contactsegypt = DB::table('contactsemarats')->orderBy('identifier', 'DESC')->paginate(10000);
		$search = null;
        if ($request->has('search')) {
            $search = $request->search;
            $Contactsegypt = DB::table('contactsemarats')->where('displayName', 'like', '%'.$search.'%')->orderBy('created_at', 'DESC')->paginate(10000);
            // $Contactsegypt2 = DB::table('contactsegypts')->where('displayName', 'like', '%'.$search.'%')->orderBy('created_at', 'DESC')->paginate(10000);
            // $Contactsegypt = array_merge($Contactsegypt1, $Contactsegypt2);
        }

		return view('pages.member.portalPhoneEmarat')->with([
			'contactphones' => $Contactsegypt
        ]);
    }
	
	public function phonesearchbyphones(Request $request)
    {
        $Contactsegypt = DB::table('contactsegypts')->orderBy('displayName', 'DESC')->paginate(10000);
		$search = null;
        if ($request->has('search')) {
            $search = $request->search;
            $Contactsegypt = DB::table('contactsegypts')->where('phone1', $search)->orwhere('phone2', $search)->orwhere('phone3', $search)->orwhere('phone4', $search)->orderBy('created_at', 'DESC')->paginate(10000);
        }
		return view('pages.member.portalPhone')->with([
			'contactphones' => $Contactsegypt
        ]);
    }
    
    public function phonesearchbyphonesEmarat(Request $request)
    {
        $Contactsegypt = DB::table('contactsemarats')->orderBy('identifier', 'DESC')->paginate(10000);
		$search = null;
        if ($request->has('search')) {
            $search = $request->search;
            $Contactsegypt = DB::table('contactsemarats')->where('phone1', $search)->orwhere('phone2', $search)->orwhere('phone3', $search)->orwhere('phone4', $search)->orderBy('created_at', 'DESC')->paginate(10000);
        }
		return view('pages.member.portalPhoneEmarat')->with([
			'contactphones' => $Contactsegypt
        ]);
    }
	
	public function phoneListsearchidentifier(Request $request)
    {
        $Contactsegypt = DB::table('contactsegypts')->orderBy('displayName', 'DESC')->paginate(10000);
		$search = null;
        if ($request->has('searchidentifier')) {
            $search = $request->searchidentifier;
            $Contactsegypt = DB::table('contactsegypts')->where('identifier', 'like', '%'.$search.'%')->orderBy('created_at', 'DESC')->paginate(10000);
        }
		return view('pages.member.portalPhone')->with([
			'contactphones' => $Contactsegypt
        ]);
    }
    
    	
	public function phoneListsearchidentifierEmarat(Request $request)
    {
        $Contactsegypt = DB::table('contactsemarats')->orderBy('displayName', 'DESC')->paginate(10000);
		$search = null;
        if ($request->has('searchidentifier')) {
            $search = $request->searchidentifier;
            $Contactsegypt = DB::table('contactsemarats')->where('identifier', 'like', '%'.$search.'%')->paginate(10000);
        }
		return view('pages.member.portalPhoneEmarat')->with([
			'contactphones' => $Contactsegypt
        ]);
    }
    
    public function phoneListsearchnumberlenghtEmarat(Request $request)
    {
        $Contactsegypt = DB::table('contactsemarats')->orderBy('displayName', 'DESC')->paginate(10000);
		$search = null;
        if ($request->has('searchnumber')) {
            $search = $request->searchnumber;
            $Contactsegypt = DB::table('contactsemarats')->where(DB::raw('CHAR_LENGTH(phone1)'),'=',$search)->orwhere(DB::raw('CHAR_LENGTH(phone2)'),'=',$search)->orwhere(DB::raw('CHAR_LENGTH(phone3)'),'=',$search)->orderBy('created_at', 'DESC')->paginate(10000);
        }
		return view('pages.member.portalPhoneEmarat')->with([
			'contactphones' => $Contactsegypt
        ]);
    }
	
	
	public function phoneedit($id)
    {
        $Contactsegypt = Contactsegypt::query()->findOrFail($id);
        return view('pages.phonelist.edit')->with([
            'Contactsegypt' => $Contactsegypt
        ]);
    }
	
	public function phoneshow($id)
    {
         $Contactsegypt = Contactsegypt::query()->findOrFail($id);
        return view('pages.phonelist.edit')->with([
            'Contactsegypt' => $Contactsegypt
        ]);
    }
	
	public function phonedestroy($id)
    {
        $user = Patient::query()->findOrFail($id);
//        $user->roles()->detach();
        $user->delete();
//        return redirect()->route('adminUsers.index');
        return redirect()->route('portalPatients');
    }
		
    public function show($id)
    {
        $user = Patient::query()->findOrFail($id);
        return view('pages.admin.adminUsersViews')->with([
            'user' => $user
        ]);
    }
	
	public function ExportsExcel($customer_data){
       ini_set('max_execution_time', 0);
       ini_set('memory_limit', '40000M');
       try {
           $spreadSheet = new Spreadsheet();
           $spreadSheet->getActiveSheet()->getDefaultColumnDimension()->setWidth(20);
           $spreadSheet->getActiveSheet()->fromArray($customer_data);
           $Excel_writer = new Xls($spreadSheet);
           header('Content-Type: application/vnd.ms-excel');
           header('Content-Disposition: attachment;filename="Customer_ExportedData.xls"');
           header('Cache-Control: max-age=0');
           ob_end_clean();
           $Excel_writer->save('php://output');
           exit();
       } catch (Exception $e) {
           return;
       }
   }
   
	function exportsData(Request $request, $keywordsNames){
		$keywordsNames = $request->keyword_name;
       if($keywordsNames == 'All'){
		$keywordsall = Keyword::all()->sortBy('keyword_name');
		foreach($keywordsall as $keywordone)
			   {
				  $keywordsNames =  $keywordone->keyword_name;
				   $data = DB::table('contactsegypts')->where('displayName', 'like', '%'.$keywordsNames.'%')->orderBy('displayName', 'DESC')->get();
				   $data_array [] = array("displayName","phone1","phone2","phone3","phone4","identifier","HideContact","dateNow","countryCode");
				   foreach($data as $data_item)
				   {
					   $data_array[] = array(
						   'keywordsNames' =>$keywordsNames,
						   'displayName' =>$data_item->displayName,
						   'phone1' => $data_item->phone1,
						   'phone2' => $data_item->phone2,
						   'phone3' => $data_item->phone3,
						   'phone4' => $data_item->phone4,
						   'identifier' => $data_item->identifier,
						   'HideContact' => $data_item->HideContact,
						   'dateNow' => $data_item->dateNow,
						   'countryCode' =>$data_item->countryCode
					   );
				   }
			   }
			    $this->ExportsExcel($data_array);
	   } else {
	   $data = DB::table('contactsegypts')->where('displayName', 'like', '%'.$keywordsNames.'%')->orderBy('displayName', 'DESC')->get();
       $data_array [] = array("displayName","phone1","phone2","phone3","phone4","identifier","HideContact","dateNow","countryCode");
       foreach($data as $data_item)
       {
           $data_array[] = array(
               'keywordsNames' =>$keywordsNames,
               'displayName' =>$data_item->displayName,
               'phone1' => $data_item->phone1,
               'phone2' => $data_item->phone2,
               'phone3' => $data_item->phone3,
               'phone4' => $data_item->phone4,
               'identifier' => $data_item->identifier,
               'HideContact' => $data_item->HideContact,
               'dateNow' => $data_item->dateNow,
               'countryCode' =>$data_item->countryCode
           );
       }
       $this->ExportsExcel($data_array);
	   }
   }

    function exportsemarat(Request $request){
		$keywordsNames = 971;
    
				   $data = DB::table('contactsemarats')->where('phone1', 'like', $keywordsNames.'%')->orderBy('displayName', 'DESC')->get();
				   $data_array [] = array("displayName","phone1","phone2","phone3","phone4","identifier","HideContact","dateNow","countryCode");
				   foreach($data as $data_item)
				   {
					   $data_array[] = array(
						   'keywordsNames' =>$keywordsNames,
						   'displayName' =>$data_item->displayName,
						   'phone1' => $data_item->phone1,
						   'phone2' => $data_item->phone2,
						   'phone3' => $data_item->phone3,
						   'phone4' => $data_item->phone4,
						   'identifier' => $data_item->identifier,
						   'HideContact' => $data_item->HideContact,
						   'dateNow' => $data_item->dateNow,
						   'countryCode' =>$data_item->countryCode
					   );
				   }
			  
			    $this->ExportsExcel($data_array);
	  
   }
   
	public function edit($id)
    {
        $user = Patient::query()->findOrFail($id);
        return view('pages.admin.adminUsersEdit')->with([
            'user' => $user
        ]);
    }
    
	public function autocompleteSearch(Request $request)
    {
          $query = $request->get('query');
          $filterResult = Medicine::where('genericname', 'LIKE', '%'. $query. '%')->get();
          return response()->json($filterResult);
    } 
    
	public function autocompletes(Request $request)
    {
        $query = $request->genericname;
         Log::info('User failed to login.', ['id' => $request->genericname]);

       $data = Medicine::where("genericname","LIKE","%{$query}%")->limit(10)->select('genericname')->pluck('genericname');
         Log::info('data.', ['data' => $data]);

        return response()->json($data);
    } 
    
	function autocomplete(Request $request)
    {
     if($request->genericname)
     {
      $query = $request->genericname;
      $data = Medicine::where('genericname', 'LIKE', "%{$query}%")->limit(10)
        ->get();
      $output = '<ul class="dropdown-menu" style="display:block; position:relative">';
      foreach($data as $row)
      {
       $output .= '
       <li><a href="#">'.$row->genericname.'</a></li>
       ';
      }
      $output .= '</ul>';
      echo $output;
     }
     return $output;
    }
   
	function autocompleteqname(Request $request)
    {
     if($request->manufacturername)
     {
      $query = $request->manufacturername;
      $data = Medicine::where('manufacturername', 'LIKE', "%{$query}%")->limit(10)
        ->get();
      $output = '<ul class="dropdown-menu" style="display:block; position:relative">';
      foreach($data as $row)
      {
       $output .= '
       <li><a href="#">'.$row->manufacturername.'</a></li>
       ';
      }
      $output .= '</ul>';
      echo $output;
     }
     return $output;
    }
     
	public function destroy($id)
    {
        $user = Patient::query()->findOrFail($id);
//        $user->roles()->detach();
        $user->delete();
//        return redirect()->route('adminUsers.index');
        return redirect()->route('portalPatients');
    }

	public function medicineReport(Request $request)
    {
                $mediciness = Medicine::latest()->take(1)->get();
                  return view('pages.member.medicineReport')->with([
                 'medicines' => $mediciness,
                 ]);

    }

	public function send(Request $request, $id)
    {
        $contactsend = ContactsEmarat::query()->findOrFail($id);
	    Log::debug("Contactsegypts###", [$contactsend]);
		try {

            sleep(5);
            $phoneToSend = str_replace('+', '', $contactsend->phone1);

            $sender =  '967736751277';
            $dest = $phoneToSend;
            $verifyCode = rand(100000, 999999);
            // $massagestouser1 ="'سمعت انك أهلا للخير والعطاء  \nانا محمد 33 سنه من اليمن تعز مبرمج تطبيقات اندرويد محترف باستخدام تقنيه فلاتر كان لدي اكثر من مائة تطبيق منشور على جوجل بلاي واعيش انا واسرتي من الارباح من الإعلانات داخل التطبيقات ولاكن تم إغلاق حسابي وحذف كل التطبيقات من قبل جوجل للمطورين بسبب استخدامي شعار واتس اب في احد التطبيقات  \n انا من اليمن واسكن في صنعاء وبسبب الحرب لا اجد وظيفه اعيش منها بكرامه ولا يوجد لي  مصدر دخل ثابت \n أنا بامس الحاجه الى:- \n كمبيوتر محمول جديد لم يستخدم بحسابي السابق اطلاقاً  \n Lenovo Legion 7i  Gaming Laptop \n Intel core i9-10980HK :المعالج \n Ram 32GB DDR4 :الذاكرة العشوائية  \n HD 1.5TB SSD :مساحة التخزين  \n VGA 8GB RTX 2080 Super :كرت الشاشة\n Sc 15.6 FHD 240Hz :الشاشة \n Windows 10  \n 1950$ \n \n جهاز تلفون جديد استخدم الشبكه 4G  ولااستخدم الشبكة السابقه اطلاقاً $650  \n حساب بنكي جديد باسم احد اقاربي او باسم زوجتي لانه لا استطيع استخدام الحساب البنكي السابق ولا سيتم اغلاق حسابي الجديد $650  \n انشاء حساب مطور جديد في جوجل بالبطاقه الجديده $25   \n تعديل تطبيقاتي كلها وتغير الخوارزميات والاكواد بحيث لا تظهر لجوجل اني نفس الحساب السابق ولا سيتم إغلاق حسابي الجديد  \n تكرموا فضلاً باعطائي مبلغ $3075  كدين في رقبتي من اجل النقاط المذكورة أعلاه لإبداء حياتي من جديد لان حياتي الان توقفت واصبت بالاحباط لاني كنت اعيش على الارباح من الاعلانات في التطبيقات التي تم ازالتها وازالت حسابي بجوجل للمطورين  \n رقم حسابي بنك اليمن الدولي لارسال اي مبلغ نكون شاكرين لكم بعد الله '";
            $massagestouser1 ="'كي لا تخسر ثروتك يوجد من هم قريبين منك يعملوا بكل سريه لتدميرك وتدمير ثروتك \n اذا تريد ان تعرف التفاصيل يجب أن ترسل خمسه الف دولار بـ وسترن يونيون  بإسم Mohammed Ahmed Mohsen Moqbel  الى اليمن صنعاء وبعدها ارسل لنا تفاصيل الحواله MTCN \n إياك وان تخبر أي شخص بمضمون هذه الرساله ولا تترك هاتفك حتى وقت نومك\n وبعد إرسالك المبلغ سنعلمك بكل التفاصيل التي تثبت لك الخيانه وحينها تصرف بهدووووو وبذكاء كي لا تخسر '";
            // $verification_code = "\n Bank: INTERNATIONAL BANK OF YEMEN Y.S.C \n Name: Mohammed Ahmed Mohsen Moqbel  \n Acc. NO: 0002505685002 \n SWIFT: IBOYYESA\n";
            $verification_code = "\n بالتوفيق\n";
            $messageToSend =  $massagestouser1."\n\n\n" .$verification_code."\n\n\n" ."*"."\n\n\n".$verifyCode."*";
            
             
             $data = [
                'api_key' => 'XA0SOBBLmE30gVb4zFlSGQgNaqcvO7',
                'sender' => $sender,
                'number' => $phoneToSend,
                'message' => $messageToSend
            ];
            

            $curl = curl_init();
            curl_setopt_array($curl, [
              CURLOPT_URL => "https://api.wassenger.com/v1/numbers/exists",
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => "",
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 30,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => "POST",
              CURLOPT_POSTFIELDS => "{\"phone\":\"+$phoneToSend\"}",
              CURLOPT_HTTPHEADER => [
                "Content-Type: application/json",
                "Token: 066f35090cd6e1403c8c62cb8fdfbb2cec1afa37f8522d85200245997ad75130f889c44eeb732f4a"
              ],
            ]);
            
            $response = curl_exec($curl);
            $err = curl_error($curl);
            curl_close($curl);
                          
            $results = json_decode($response);    
            if (isset($results->exists)) {
                $results1 = $results->exists;
                } else { 	
                    $results1 = false; 
                    }

              if($results1 == 'true'){
                    $curl2 = curl_init();
                    curl_setopt_array($curl2, array(
                      CURLOPT_URL => "https://wpser.smartapps.top/send-message",
                      CURLOPT_RETURNTRANSFER => true,
                      CURLOPT_ENCODING => '',
                      CURLOPT_MAXREDIRS => 10,
                      CURLOPT_TIMEOUT => 0,
                      CURLOPT_FOLLOWLOCATION => true,
                      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                      CURLOPT_CUSTOMREQUEST => 'POST',
                      CURLOPT_POSTFIELDS => json_encode($data),
                      CURLOPT_HTTPHEADER => array(
                        'Content-Type: application/json'
                      ),
                    ));
                    $response2 = curl_exec($curl2);
                    curl_close($curl2);
                
                $oksend = ContactsEmarat::find($id);
                $oksend->whatssend = 1;
                $oksend->save();
              } else {
                $oksend = ContactsEmarat::find($id);
                $oksend->whatssend = 1;
                $oksend->save();
              }; 
         
 
 
        return response()->json( [
		    'success' => true,
			'ContactsPhone' => $results
	        ] );
		} catch ( \Exception $e ) {
			$message = array (
					'message' => $e->getMessage ()
			);
			return response()->json( [
					'error' => true,
					'message' => $message
			] );
		}

    }


}
