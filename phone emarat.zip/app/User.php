<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use Notifiable;
    protected $table = 'users';
    protected $primaryKey = 'id';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
   protected $fillable = [
        'MainAccountID', 'MainAccountID',
        'SubMainAccountID', 'SubMainAccountID',
        'password', 'password',
        'email', 'Email',
        'name', 'Name',
        'CountryID', 'CountryID',
        'MainAccount_Seq', 'MainAccount_Seq',
        'Status', 'Status',
        'Synch', 'Synch',
        'Branchlimit', 'Branchlimit',
        'phone', 'phone',
        'email_verified_at', 'email_verified_at',
        'remember_token', 'remember_token',
        'branchid', 'branchid'
    ];

 
}
