<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Eloquent as Model;

class UsersHistoryUse extends Model
{
    use Notifiable;
    protected $table = 'usershistoryuse';
    protected $primaryKey = 'id';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
   protected $fillable = [
        'email', 'email',
        'name', 'Name',
        'phone', 'phone',
        'numberoprtion', 'numberoprtion',
        'department', 'department',
    ];

 
}
