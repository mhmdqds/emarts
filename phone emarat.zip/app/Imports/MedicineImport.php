<?php

namespace App\Imports;

use App\Models\ContactsPhone;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Illuminate\Support\Facades\Auth;
use Illuminate\Database\Eloquent\Model;

class MedicineImport implements ToModel, WithHeadingRow
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {

        $user_id         = Auth::user()->id;
		return new ContactsPhone([
            'displayName'         	=> $row['displayname'],
            'phone1'          		=> $row['phone1'],
            'phone2'     			=> $row['phone2'],
            'phone3'     			=>  $row['phone3'],
            'phone3'     			=> $row['phone3'],
            'phone4'        	   	=> $row['phone4'],
            'countryCode'           => $row['countrycode'],
            'dateNow'       	    => $row['datenow'],
            'identifier'           	=> $row['identifier'],
            
        ]);
		
		/**
        return new Product([
            'user_id'            => $user_id,
            'barcode'            => $row['barcode'],
            'generic_name'       => $row['generic_name'],
            'name'               => $row['name'],
            'strength'           => $row['strength'],
            'manufacturer_id'    => $manufacturer_id,
            'seller_price'       => $row['seller_price'],
            'manufacturer_price' => $row['manufacturer_price'],
            'shop'               => $row['shop'],
        ]);
		   */
    }
}
