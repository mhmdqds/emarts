<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Eloquent as Model;

class Setting extends Model
{
    use Notifiable;
    protected $table = 'Settings';
    protected $primaryKey = 'id';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
   protected $fillable = [
        'ParmValue', 'ParmValue',
        'UpdateDate', 'UpdateDate',
        'MainAccountID', 'MainAccountID',
        'SubMainAccountID', 'SubMainAccountID',
        'Synch', 'Synch',
        'BranchID', 'BranchID',
        'MainAccount_Seq', 'MainAccount_Seq',
    ];

 
}
