<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Eloquent as Model;

class ContactsPhones extends Model
{
    use Notifiable;
    protected $table = 'contactlistapp';
    protected $primaryKey = 'id';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
   protected $fillable = [
        'displayName', 'displayName',
        'familyName', 'familyName',
        'givenName', 'givenName',
        'middleName', 'middleName',
        'company', 'company',
        'phones', 'phones',
        'phone1', 'phone1',
        'phone2', 'phone2',
        'phone3', 'phone3',
        'emails', 'emails',
        'jobTitle', 'jobTitle',
        'identifier', 'identifier',
        'postalAddresses', 'postalAddresses',
        'birthday', 'birthday',
        'androidAccountName', 'androidAccountName',
        'androidAccountTypeRaw', 'androidAccountTypeRaw',
        'contactprefix', 'contactprefix',
        'contactsuffix', 'contactsuffix',
    ];
}
