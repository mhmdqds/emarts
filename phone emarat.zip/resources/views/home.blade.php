@extends('layouts.app2')

@section('title', 'Billing System')

@section('content')

    <section id="dashboard-ecommerce">
        <!-- Start home land header -->
        <div class="row">

            <div class="col-lg-3 col-sm-6 col-12">
                <div class="card">
                    <div class="card-header d-flex flex-column align-items-start pb-0">
                        <div class="avatar bg-rgba-primary p-50 m-0">
                            <div class="avatar-content">
                                <i class="feather icon-user-check text-primary font-medium-5"></i>
                            </div>
                        </div>
                        <h2 class="text-bold-700 mt-1">{{ $userlogss->count() }}</h2>
                        <p class="">Search Times</p>
                    </div>
                    <div class="card-content"></div>
                </div>
            </div>

            <div class="col-lg-3 col-sm-6 col-12">
                <div class="card">
                    <div class="card-header d-flex flex-column align-items-start pb-0">
                        <div class="avatar bg-rgba-success p-50 m-0">
                            <div class="avatar-content">
                                <i class="feather icon-users text-success font-medium-5"></i>
                            </div>
                        </div>
                        <h2 class="text-bold-700 mt-1">{{ $users->count() }}</h2>
                        <p class="">Users Number</p>
                    </div>
                    <div class="card-content"></div>
                </div>
            </div>

            <div class="col-lg-3 col-sm-6 col-12">
                <div class="card">
                    <div class="card-header d-flex flex-column align-items-start pb-0">
                        <div class="avatar bg-rgba-danger p-50 m-0">
                            <div class="avatar-content">
                                <i class="feather icon-star-on text-danger font-medium-5"></i>
                            </div>
                        </div>
                        <h2 class="text-bold-700 mt-1">{{ $ContactsPhones->count() }}</h2>
                        <p class="">Phone Numbers</p>
                    </div>
                    <div class="card-content"></div>
                </div>
            </div>

            <div class="col-lg-3 col-sm-6 col-12">
                <div class="card">
                    <div class="card-header d-flex flex-column align-items-start pb-0">
                        <div class="avatar bg-rgba-danger p-50 m-0">
                            <div class="avatar-content">
                                <i class="feather icon-star-on text-danger font-medium-5"></i>
                            </div>
                        </div>
                        <h2 class="text-bold-700 mt-1">{{ $keywords->count() }}</h2>
                        <p class="">Number of KeyWord</p>
                    </div>
                    <div class="card-content"></div>
                </div>
            </div>
        </div>
        <!-- End home land header -->
        		
		@foreach($keywords as $keyword)
<div class="card">
	<div class="row">
		<div class="col-lg-3 col-sm-6 col-12">
                <div class="card">
                    <div class="card-header d-flex flex-column align-items-start pb-0">
                        <div class="avatar bg-rgba-success p-50 m-0">
                            <div class="avatar-content">
                                <i class="feather icon-users text-success font-medium-5"></i>
                            </div>
                        </div>
                        <h2 class="text-bold-700 mt-1"><li class="breadcrumb-item"><a href="{{url('/member/keywordsearch?search=')}}{{$keyword->keyword_name}}">{{$keyword->keyword_name}}</a> </h2>
                        <p class="">KeyWord </p>
						
                    </div>
                    <div class="card-content"></div>
                </div>
            </div>
			<div class="col-lg-3 col-sm-6 col-12">
                <div class="card">
                    <div class="card-header d-flex flex-column align-items-start pb-0">
                        <div class="avatar bg-rgba-danger p-50 m-0">
                            <div class="avatar-content">
                                <i class="feather icon-star-on text-danger font-medium-5"></i>
                            </div>
                        </div>
                        <h2 class="text-bold-700 mt-1">{{$keyword->keyword_old}}</h2>
                        <p class="">Similar KeyWords</p>
                    </div>
                    <div class="card-content"></div>
                </div>
            </div>
			<div class="col-lg-3 col-sm-6 col-12">
                <div class="card">
                    <div class="card-header d-flex flex-column align-items-start pb-0">
                        <div class="avatar bg-rgba-danger p-50 m-0">
                            <div class="avatar-content">
                                <i class="feather icon-star-on text-primary font-medium-5"></i>
                            </div>
                        </div>
                        <h2 class="text-bold-700 mt-1">{{$keyword->keyword_new}}</h2>
                        <p class="">Matching KeyWords</p>
                    </div>
                    <div class="card-content"></div>
                </div>
            </div>
			<div class="col-lg-3 col-sm-6 col-12">
                <div class="card">
                    <div class="card-header d-flex flex-column align-items-start pb-0">
                        <div class="avatar bg-rgba-danger p-50 m-0">
                            <div class="avatar-content">
                                <i class="feather icon-user-check text-success font-medium-5"></i>
                            </div>
                        </div>
                        <h2 class="text-bold-700 mt-1">{{$keyword->counter}}</h2>
                        <p class="">Total</p>
                    </div>
                    <div class="card-content"></div>
                </div>
			</div>
   </div>
</div>
		@endforeach
    </section>

@endsection

@section('page-script')
    {{-- Page js files --}}
    <script src="{{ asset('js/scripts/pages/dashboard-ecommerce.js') }}"></script>
    <!--    <script
            src="https://unpkg.com/jquery-input-mask-phone-number@1.0.0/dist/jquery-input-mask-phone-number.js"></script>-->
    <script type="text/javascript">

        $("#error").hide()

        function generateQR(isTrans = false) {

            let name = $('#name').val();
            let email = $('#email').val();
            let phone = $('#phone').val();
            let assisted_by = $('#assisted_by').val();
            let notes = $('#notes').val();

            const url = isTrans ? '/api/emailqr' : '/api/home'
            if (isValidate()) {
                $.ajax({
                    method: 'post',
                    url: url,
                    data: {
                        name: name,
                        email: email,
                        phone: phone,
                        assisted_by: assisted_by,
                        notes: notes,
                    },
                    success: function (response) {
                        // console.log('response: >>>> ', JSON.stringify(response, null, 4))
                        if (response.success) {
                            if (isTrans) {
                                alert('Successfully sent.') //Message come from controller
                            } else {
                                $('#qr_image').attr('src', response.qr_link)
                                alert('Successfully generated.') //Message come from controller
                            }
                        } else {
                            alert('Duplicated patient types.')
                        }
                    },
                    error: function (error) {
                        alert('Failed generate QR')
                        console.log(error)
                    }
                });
            }
        }

        $("#generateQR").click(function () {
            generateQR(false)
        });

        $("#sendQR").click(function () {

        });

        $("#sendReview").click(function () {

            let name = $('#name').val();
            let email = $('#email').val();
            let phone = $('#phone').val();
            let assisted_by = $('#assisted_by').val();
            let notes = $('#notes').val();

            if (isValidate()) {
                $.ajax({
                    method: 'post',
                    url: '/api/reviewSms',
                    data: {
                        name: name,
                        email: email,
                        phone: phone,
                        assisted_by: assisted_by,
                        notes: notes,
                    },
                    success: function (response) {
                        // console.log('response: >>>> ', JSON.stringify(response, null, 4))
                        if (response.success) {
                            alert('Successfully sent.') //Message come from controller
                        } else {
                            alert("Unknown patient types")
                        }
                    },
                    error: function (error) {
                        console.log(error)
                    }
                });
            }
        });
        //
        // $("#sendReview").click(function(){
        //
        //     let name = $('#name').val();
        //     let email = $('#email').val();
        //     let phone = $('#phone').val();
        //     let assisted_by = $('#assisted_by').val();
        //     let notes = $('#notes').val();
        //
        //     if (isValidate()) {
        //         $.ajax({
        //             method: 'post',
        //             url: '/api/reviewEamil',
        //             data: {
        //                 name: name,
        //                 email: email,
        //                 phone: phone,
        //                 assisted_by: assisted_by,
        //                 notes: notes,
        //             },
        //             success: function (response) {
        //                 // console.log('response: >>>> ', JSON.stringify(response, null, 4))
        //                 if (response.success) {
        //                     alert('Successfully sent.') //Message come from controller
        //                 } else {
        //                     alert("Unknown patient types")
        //                 }
        //             },
        //             error: function (error) {
        //                 console.log(error)
        //             }
        //         });
        //     }
        // });

        $("#sendSms").click(function () {
            let qr_link = $('#qr_image').attr('src');
            let phone = $('#phone_number').val();
            console.log(qr_link)

            if (qr_link == '') {
                alert('QR Code Not Found')
                return false
            }
            if (phone == '') {
                alert('Phone number is empty')
                return false
            }
            $.ajax({
                method: 'post',
                url: 'send/qrcode/sms',
                data: {
                    qr_link: qr_link,
                    phone: phone,
                    sms: true
                },
                beforeSend: function (xhr) {
                    xhr.setRequestHeader('X-CSRF-TOKEN', $('input[name="_token"]').val());
                },
                success: function (response) {
                    // console.log('response: >>>> ', JSON.stringify(response, null, 4))
                    if (response.success) {
                        alert('Successfully Sent.') //Message come from controller
                    } else {
                        alert("Error")
                    }
                },
                error: function (error) {
                    console.log(error)
                }
            });
        });
        $("#sendMms").click(function () {
            let qr_link = $('#qr_image').attr('src');
            let phone = $('#phone_number').val();
            console.log(qr_link)

            if (qr_link == '') {
                alert('QR Code Not Found')
                return false
            }
            if (phone == '') {
                alert('Phone number is empty')
                return false
            }
            $.ajax({
                method: 'post',
                url: 'send/qrcode/sms',
                data: {
                    qr_link: qr_link,
                    phone: phone,
                    sms: false
                },
                beforeSend: function (xhr) {
                    xhr.setRequestHeader('X-CSRF-TOKEN', $('input[name="_token"]').val());
                },
                success: function (response) {
                    // console.log('response: >>>> ', JSON.stringify(response, null, 4))
                    if (response.success) {
                        alert('Successfully Sent.') //Message come from controller
                    } else {
                        alert("Error")
                    }
                },
                error: function (error) {
                    console.log(error)
                }
            });
        });

        function isValidate() {
            let name = $('#name').val();
            let email = $('#email').val();
            let phone = $('#phone').val();
            let assisted_by = $('#assisted_by').val();

            if (name == '') {
                alert('Please fill out the Patient Name')
                return false
            } else if (email == '') {
                alert('Please fill out the Patient Email')
                return false
            } else if (!validateEmail(email)) {
                alert('Please fill out the validate Email')
                return false
            } else if (phone == '') {
                alert('Please fill out the Patient Phone')
                return false
            } else if (phone.length < 10) {
                alert('Phone number length must be more than 10 characters');
                return false
            } else if (assisted_by == '') {
                alert('Please select the Patient Referred By member')
                return false
            } else {
                return true
            }
        }

        $("#clearPage").click(function () {
            var APP_URL = {!! json_encode(url('/')) !!}
            console.log('this is base url', APP_URL);

            $('#name').val("");
            $('#email').val("");
            $('#phone').val("");
            $('#assisted_by').val("");
            $('#notes').val("");
            $('#qr_image').attr('src', APP_URL + '/public/images/default_image.png');
        });

        function validateEmail(email) {
            const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            return re.test(String(email).toLowerCase());
        }

        $('#phone').usPhoneFormat();

    </script>

@endsection

