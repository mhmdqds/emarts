<!-- BEGIN: Main Menu-->
<div class="main-menu menu-fixed menu-light menu-accordion menu-shadow" data-scroll-to-active="true">
    <div class="navbar-header">
        <ul class="nav navbar-nav flex-row">
            <li class="nav-item mr-auto">
                <a class="navbar-brand" href="{{ url('home') }}">
{{--                    <div class="brand-logo">--}}
{{--                        <img class="img-fluid" src="{{ asset('images/vuexy-logo.png') }}">--}}
{{--                    </div>--}}
                    <h2 class="brand-text pl-3 mb-0">Dashboard</h2>
                </a></li>
            <li class="nav-item nav-toggle"><a class="nav-link modern-nav-toggle pr-0" data-toggle="collapse"><i class="feather icon-x d-block d-xl-none font-medium-4 primary toggle-icon"></i><i class="toggle-icon feather icon-disc font-medium-4 d-none d-xl-block collapse-toggle-icon primary" data-ticon="icon-disc"></i></a></li>
        </ul>
    </div>
    <div class="shadow-bottom"></div>
    <div class="main-menu-content">
        <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">

            @if(!auth()->user()->hasRole('member'))
			<li class=" nav-item"><a href="{{ url('home') }}"><i class="fa fa-tachometer"></i><span class="menu-title"> Dashboard</span></a>
                 
            </li>  
            <li class=" nav-item"><a href="#"><i class="fa fa-phone-square"></i><span class="menu-title"> Contacts Manage</span></a>
                    <ul class="menu-content">
                        <li class="nav-item @if(request()->routeIs('phoneList')) active @endif">
                            <a href="{{ route('phoneList') }}">
                                <i class="fa fa-search-plus"></i>
                                <span class="menu-title" data-i18n="User">Search</span>
                            </a>
                        </li>
                         <li class="nav-item @if(request()->routeIs('phoneList')) active @endif">
                            <a href="{{ route('phoneListemarat') }}">
                                <i class="fa fa-search"></i>
                                <span class="menu-title" data-i18n="User">SearchEmarat</span>
                            </a>
                        </li>
                    </ul>
            </li>  
			<li class=" nav-item"><a href="#"><i class="fa fa-upload"></i><span class="menu-title"> Import Manage</span></a> 
					<ul class="menu-content">
                        <li class="nav-item @if(request()->routeIs('importView')) active @endif">
                            <a href="{{ route('importView') }}">
                                <i class="fa fa-download "></i>
                                <span class="menu-title" data-i18n="User">From Excel</span>
                            </a>
                        </li>   
                    </ul>
            </li> 	
			<li class="nav-item"><a href="#"><i class="fa fa-key"></i><span class="menu-title">KeyWords Manage</span></a> 
					<ul class="menu-content">
                        <li class="nav-item @if(request()->routeIs('keywordList')) active @endif">
                            <a href="{{ route('keywordList') }}">
                                <i class="fa fa-area-chart"></i>
                                <span class="menu-title" data-i18n="User">KeyWords</span>
                            </a>
                        </li>
						<li class="nav-item @if(request()->routeIs('phonewords')) active @endif">
                            <a href="{{ route('phonewords') }}">
                                <i class="fa fa-edit "></i>
                                <span class="menu-title" data-i18n="User">Add KeyWord</span>
                            </a>
                        </li> 
						<li class="nav-item @if(request()->routeIs('keywordsearch')) active @endif">
                            <a href="{{ route('keywordsearch') }}">
                                <i class="fa fa-search "></i>
                                <span class="menu-title" data-i18n="User">Search By KeyWord</span>
                            </a>
                        </li> 							
                    </ul>
            </li> 	
			<li class=" nav-item"><a href="#"><i class="fa fa-database"></i><span class="menu-title">Data Base Manage</span></a>
                    <ul class="menu-content">
						<li class="nav-item @if(request()->routeIs('samenaumbers')) active @endif">
                            <a href="{{route('samenaumbers')}}">
                                <i class="feather icon-list"></i>
                                <span class="menu-title">Remove Duplicates</span>
                            </a>
                        </li>
                    </ul>
                </li>				
							
            @endif

            @if(auth()->user()->hasRole('superadmin'))
                <li class=" nav-item"><a href="#"><i class="fa fa-user-circle-o"></i><span class="menu-title">Admin</span></a>
                    <ul class="menu-content">
                        <li class="nav-item @if(request()->routeIs('adminUsers.index')) active @endif">
                            <a href="{{ route('adminUsers.index') }}">
                                <i class="feather icon-users"></i>
                                <span class="menu-title" data-i18n="User">Team Management</span>
                            </a>
                        </li>
                    </ul>
                </li>
            @endif
            
            
        </ul>
    </div>

</div>
<!-- END: Main Menu-->
