@extends('layouts.app2')

@section('vendor-style')
    {{-- vendor css files --}}
    <link rel="stylesheet" href="{{ asset('vendors/css/tables/datatable/datatables.min.css') }}">
    <link rel="stylesheet" href="{{ asset('vendors/css/pickers/pickadate/pickadate.css') }}">
@endsection

@section('content')

    <div class="content-header row">
        <div class="content-header-left col-md-9 col-12 mb-2">
            <div class="row breadcrumbs-top">
                <div class="col-md-12">
                    <h2 class="col-md-12 content-header-title float-left mb-0">keyword add</h2>
                    <div class="breadcrumb-wrapper col-md-12">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{url('/home')}}">Home</a>
                            </li>
                            <li class="breadcrumb-item">keyword adder
                            </li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="content-body">
        <!-- end row -->
        <div class="row">
            <div class="col-xl-12 col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Keyword Information</h4>
                    </div>
                    <div class="card-content">
                        <div class="card-body">
                            <div class="form-body">
                                <div class="row">
                                    <!-- Start P's Info name -->
                                    <div class="col-12">
                                        <div class="form-group">
                                            <label for="name" class="col-md-12 col-form-label">keyword <a
                                                    class="text-danger font-14">*</a></label>
                                            <div class="position-relative has-icon-left">
                                                <input type="text" id="name"
                                                       class="form-control @error('name') is-invalid @enderror"
                                                       name="name"
                                                       required autocomplete="name" autofocus>
                                                @error('name')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                                @enderror
                                                <div class="form-control-position">
                                                    <i class="feather icon-info"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End P's Info name -->
                                    <!-- Start P's Info notes -->
                                    <div class="col-12">
                                        <div class="form-group">
                                            <label for="notes" class="col-md-12 col-form-label">Notes </label>
                                            <textarea class="form-control @error('notes') is-invalid @enderror" rows="3"
                                                      id="notes" name="notes" required autocomplete="notes"></textarea>
                                            @error('notes')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <!-- End P's Info notes -->
                                    <!-- Start P's Info action -->
                                    <div class="col-12">
                                        <div class="row justify-content-center">
                                            <div class="col-lg-3 col-md-12">
                                                <button type="button"
                                                        class="col-12 btn btn-success waves-effect waves-light px-1"
                                                        id="clearPage">
                                                    <i class="fa fa-refresh m-r-5"></i>
                                                    Clear
                                                </button>
                                            </div>
                                            <div class="p-t-10 d-lg-none d-sm-flex">&nbsp;</div>
                                            <div class="col-lg-3 col-md-12">
                                                <button id="AddKeywords" type="button"
                                                        class="col-12 btn btn-primary waves-effect waves-light px-1">
                                                    <i class="fa fa-qrcode m-r-5"></i> Add Keyword
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Start P's Info action -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
      
        </div>
    </div>

@endsection
@section('vendor-script')
    {{-- vendor files --}}
    <script src="{{ asset('vendors/js/tables/datatable/pdfmake.min.js') }}"></script>
    <script src="{{ asset('vendors/js/tables/datatable/vfs_fonts.js') }}"></script>
    <script src="{{ asset('vendors/js/tables/datatable/datatables.min.js') }}"></script>
    <script src="{{ asset('vendors/js/tables/datatable/datatables.buttons.min.js') }}"></script>
    <script src="{{ asset('vendors/js/tables/datatable/buttons.html5.min.js') }}"></script>
    <script src="{{ asset('vendors/js/tables/datatable/buttons.print.min.js') }}"></script>
    <script src="{{ asset('vendors/js/tables/datatable/buttons.bootstrap.min.js') }}"></script>
    <script src="{{ asset('vendors/js/tables/datatable/datatables.bootstrap4.min.js') }}"></script>
@endsection
@section('page-script')
    {{-- Page js files --}}
    <script src="{{ asset('js/scripts/datatables/datatable.js') }}"></script>
    <script src="{{ asset('js/scripts/pickers/dateTime/pick-a-datetime.js') }}"></script>
    <script src="{{ asset('js/scripts/pages/dashboard-ecommerce.js') }}"></script>

    <script>
        function AddKeywords() {
            var APP_URL = {!! json_encode(url('/')) !!};
            let name = $('#name').val();
            let notes = $('#notes').val();

            const url = '/api/keywordGenerator'
            if (isValidate()) {
                $.ajax({
                    method: 'post',
                    url: '/api/member/phonewords/keywordGenerator',
                    data: {
                        name: name,
                        notes: notes,
                    },
                    success: function (response) {
                        console.log('response: >>>> ', JSON.stringify(response, null, 4))
                        if (response.success) {
                            alert('Successfully generated.') //Message come from controller
                        } else {
                            alert('Duplicated patient types.')
                        }
                    },
                    error: function (error) {
                        alert('Failed generate QR')
                        console.log(error)
                    }
                });
            }
        }

        $("#AddKeywords").click(function () {
            console.log("Generate qr code")
            AddKeywords()
        });

        function isValidate() {
            let name = $('#name').val();
    
            if (name == '') {
                alert('Please fill out the Patient Name')
                return false
            } else {
                return true
            }
        }
        
    </script>
    <!-- End script-->
@endsection
