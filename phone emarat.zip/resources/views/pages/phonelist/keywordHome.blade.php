@extends('layouts.app2')

@section('vendor-style')
    <link rel="stylesheet" href="{{ asset('vendors/css/tables/datatable/datatables.min.css') }}">
    <link rel="stylesheet" href="{{ asset('vendors/css/pickers/pickadate/pickadate.css') }}">
@endsection

@section('page-style')
    <link rel="stylesheet" href="{{asset('css/pages/app-user.css')}}">
    <style>
        th, td {
            padding-top: 10px;
            padding-bottom: 10px;
        }
    </style>
@endsection

@section('content')
    <!-- users edit start -->
    <div class="content-header row">
        <div class="content-header-left col-md-12 col-12 mb-2">
            <div class="row breadcrumbs-top">
                <div class="col-md-6">
                    <div class="breadcrumb-wrapper col-md-8">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{url('/home')}}">Home</a>
                            </li>
                            <li class="breadcrumb-item">KeyWord Portal
                            </li>
                            <li class="breadcrumb-item">Search In KeyWord
                            </li>
							
                        </ol>
                    </div>
					 
                </div>
				<div class="breadcrumb-wrapper col-md-3">
                       		<a class="btn btn-success" href="{{ route('exportsdatas', ['All']) }}">Export All KeyWords Data</a>

                    </div>
                 	<div class="breadcrumb-wrapper col-md-3">
                       		<a class="btn btn-success" href="{{ route('exportsemarat', ['All']) }}">Export 9671</a>
                    </div>

            </div>
        </div>
    </div>

    <div class="content-body">
        <section id="">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                     
                        <div class="card-content">
                            <div class="card-body">
                               <div class="row">
                               </div>
                               @if(Session::has('message'))
                               {{ Session::get('message') }}
                               @endif
                                <div class="row">
								@foreach($keywords as $keyword)
                                    <div class="col-sm-1 col-sm-1">  
                            		<a class="btn btn-success" href="{{url('/member/keywordsearch?search=')}}{{$keyword->keyword_name}}">{{$keyword->keyword_name}}</a>
                            		<a class="btn btn-secondary btn-sm" href="{{ route('exportsdatas', ['keyword_name' => $keyword->keyword_name]) }}">Export</a>


										   
                                    </div>

                                @endforeach
                                </div>

                                <div class="table-responsive">
                                    <table class="table" id="dataTable">
                                        <thead>
                                        <tr>
                                            <th>Active</th>
                                            <th>display Name</th>
                                            <th>phone1</th>
                                            <th>phone2</th>
                                            <th>phone3</th>
                                            <th>phone4</th>
                                            <th>identifier</th>
                                        </tr>
                                        </thead>
                                        <tbody>
 										@foreach($contactlistapp as $contactlist)
                                               <tr class="">
                                                   <td class="">
                                                       <a  href="/member/activeReferrer/{{ $contactlist->id }}"
                                                           data-toggle="modal" data-target="#active">
                                                           @if($contactlist->active == 1)
                                                               <i class="fa fa-check text-success"></i>
                                                           @else
                                                               <i class="fa fa-times"></i>
                                                           @endif
                                                       </a>
                                                   </td>
                                                   <td>
                                                       {{ $contactlist->displayName }}
                                                   </td>
                                                   <td>
                                                       {{ $contactlist->phone1 }}
                                                   </td>
                                                   <td>
                                                       {{ $contactlist->phone2 }}
                                                   </td>
                                                   <td>
                                                       {{ $contactlist->phone3 }}
                                                   </td>
                                                   <td>
                                                       {{ $contactlist->phone4 }}
                                                   </td>
												   <td>
                                                       {{ $contactlist->identifier }}
                                                   </td>
                                               </tr>
                                       @endforeach
                                        </tbody>
                                    </table>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </section>
    </div>
    <!-- users edit ends -->


    <div class="modal fade text-left" id="keywordhome" tabindex="-1" role="dialog"
         aria-labelledby="myModalLabel110" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable" role="document">
            <div class="modal-content">
                <div class="modal-header bg-success white">
                    <h5 class="modal-title" id="myModalLabel110">Active Referrer</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form method="post" id="keywordhomeInfo" action="">
                    @csrf
                    <div class="modal-body">
                        <input type="text" class="form-control" name="active_patient" required autofocus>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success">Accept</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade text-left" id="inkeywordhome" tabindex="-1" role="dialog"
         aria-labelledby="myModalLabel110" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable" role="document">
            <div class="modal-content">
                <div class="modal-header bg-warning white">
                    <h5 class="modal-title" id="myModalLabel110">Inactive Referrer</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form method="post" id="inkeywordhomeInfo" action="">
                    @csrf
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-12 text-center">
                                <h1 class="text-warning">Are you sure?</h1>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-warning">Remove</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

@endsection


@section('page-script')
    Page js files 
    <script src="{{ asset('js/scripts/datatables/datatable.js') }}"></script>
    <script src="{{ asset('js/scripts/pickers/dateTime/pick-a-datetime.js') }}"></script>
    <script>

        $('#keywordhome').on('shown.bs.modal', function (event) {
            $('#keywordhomeInfo').attr('action', $(event.relatedTarget).attr('href'));
            console.log('request action route', $(event.relatedTarget).attr('href'));
        })

        $('#inkeywordhome').on('shown.bs.modal', function (event) {
            $('#inkeywordhomeInfo').attr('action', $(event.relatedTarget).attr('href'));
            console.log('request action route', $(event.relatedTarget).attr('href'));
        })

        function refreshPage() {
            $('#patient_name').val("");
            $('#patient_email').val("");
            $('#patient_phone').val("");
            $('#patient_dob').val("");
            $('#patient_register').val("");
            $('#patient_description').val("");
            $('#qr_image').attr('src', base_url + 'assets/images/default_image.png');
        }

        let dataTable;
        $(document).ready(function () {
            dataTable = $('#dataTable').DataTable({
                "processing": true,
                "serverSide": true,
                "responsive": true,
                "ajax": '{{ route('portalTopReferrer') }}',
                columns: [
                    {data: 'active', name: 'active', orderable: false, searchable: false},
                    {data: 'keyword_name', name: 'keyword_name'},
                    {data: 'counter', name: 'counter'},
                    {data: 'keyword_old', name: 'keyword_old'},
                    {data: 'keyword_new', name: 'keyword_new'},
                    {data: 'notes', name: 'notes'},

                ]
            });
        });

    </script>
    <!-- End script-->
@endsection

