@extends('layouts.app2')

@section('vendor-style')
    {{-- Page Css files --}}
    <link rel="stylesheet" href="{{ asset('vendors/css/tables/datatable/datatables.min.css') }}">
    <link rel="stylesheet" href="{{ asset('vendors/css/pickers/pickadate/pickadate.css') }}">
@endsection

@section('page-style')
    {{-- Page Css files --}}

@endsection

@section('content')
    <!-- users edit start -->
    <div class="content-header row">
        <div class="content-header-left col-md-9 col-12 mb-2">
            <div class="row breadcrumbs-top">
                <div class="col-md-12">
                    <h2 class="col-md-12 content-header-title float-left mb-0">Edit Keyword</h2>
                    <div class="breadcrumb-wrapper col-md-12">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{url('/home')}}">Home</a>
                            </li>
        
                            <li class="breadcrumb-item">Edit Keyword
                            </li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="content-body">
        <!-- end row -->
        <div class="row">
            <div class="col-xl-7 col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Keyword Information</h4>
                    </div>
                    <div class="card-content">
                        <div class="card-body">
                            <form class="form form-vertical" method="POST"
                                  action="{{route('keyword.update', ['id' => $keyword->id])}}"
                            >
                                @csrf
                                @method('put')
                                <div class="form-body">
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="form-group">
                                                <label for="name" class="col-md-12 col-form-label">Display Name <a class="text-danger font-14">*</a></label>
                                                <div class="position-relative has-icon-left">
                                                    <input type="text" id="keyword_name" class="form-control @error('name') is-invalid @enderror"
                                                           name="keyword_name"
                                                           value="{{ $keyword->keyword_name }}"
                                                           required autocomplete="keyword_name" autofocus>
                                                    @error('keyword_name')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                    @enderror
                                                    <div class="form-control-position">
                                                        <i class="feather icon-keyword"></i>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="form-group">
                                                <label for="keyword_old" class="col-md-12 col-form-label">Phone 1 <a class="text-danger font-14">*</a></label>
                                                <div class="position-relative has-icon-left">
                                                    <input type="keyword_old" id="keyword_old" class="form-control @error('email') is-invalid @enderror"
                                                           name="keyword_old" value="{{ $keyword->keyword_old }}" required autocomplete="keyword_old">
                                                    @error('keyword_old')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                    @enderror
                                                    <div class="form-control-position">
                                                        <i class="feather icon-mail"></i>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="form-group">
                                                <label for="phone" class="col-md-12 col-form-label">keyword_new <a class="text-danger font-14">*</a></label>
                                                <div class="position-relative has-icon-left">
                                                    <input type="number" id="keyword_new" class="form-control @error('keyword_new') is-invalid @enderror"
                                                           name="keyword_new" value="{{ $keyword->keyword_new }}" required autocomplete="keyword_new" pattern="/^-?\d+\.?\d*$/" onKeyPress="if(this.value.length==10) return false;">
                                                    @error('keyword_new')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                    @enderror
                                                    <div class="form-control-position">
                                                        <i class="feather icon-smartphone"></i>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
								<div class="col-12">
                                            <div class="form-group">
                                                <label for="phone" class="col-md-12 col-form-label">counter <a class="text-danger font-14">*</a></label>
                                                <div class="position-relative has-icon-left">
                                                    <input type="number" id="counter" class="form-control @error('counter') is-invalid @enderror"
                                                           name="counter" value="{{ $keyword->counter }}" required autocomplete="counter" pattern="/^-?\d+\.?\d*$/" onKeyPress="if(this.value.length==10) return false;">
                                                    @error('counter')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                    @enderror
                                                    <div class="form-control-position">
                                                        <i class="feather icon-smartphone"></i>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
										<div class="col-12">
                                            <div class="form-group">
                                                <label for="phone" class="col-md-12 col-form-label">notes <a class="text-danger font-14">*</a></label>
                                                <div class="position-relative has-icon-left">
                                                    <input type="number" id="notes" class="form-control @error('notes') is-invalid @enderror"
                                                           name="notes" value="{{ $keyword->notes }}" required autocomplete="notes" pattern="/^-?\d+\.?\d*$/" onKeyPress="if(this.value.length==10) return false;">
                                                    @error('notes')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                    @enderror
                                                    <div class="form-control-position">
                                                        <i class="feather icon-smartphone"></i>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                      
                                        </div>
                                        
                                        <div class="col-12 d-flex justify-content-center">
                                            <button type="button" class="btn btn-success waves-effect waves-light mr-1 px-1"
                                                    onclick="refreshPage()">
                                                <i class="fa fa-refresh mr-lg-1 mr-md-0"></i>
                                                Clear
                                            </button>
                                            <button type="submit" class="btn btn-primary waves-effect waves-light px-1">
                                                <i class="fa fa-save mr-lg-1 ml-md-0"></i> Save
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <!-- users edit ends -->
@endsection

@section('vendor-script')
    {{-- Vendor js files --}}
    <script src="{{ asset('vendors/js/tables/datatable/pdfmake.min.js') }}"></script>
    <script src="{{ asset('vendors/js/tables/datatable/vfs_fonts.js') }}"></script>
    <script src="{{ asset('vendors/js/tables/datatable/datatables.min.js') }}"></script>
    <script src="{{ asset('vendors/js/tables/datatable/datatables.buttons.min.js') }}"></script>
    <script src="{{ asset('vendors/js/tables/datatable/buttons.html5.min.js') }}"></script>
    <script src="{{ asset('vendors/js/tables/datatable/buttons.print.min.js') }}"></script>
    <script src="{{ asset('vendors/js/tables/datatable/buttons.bootstrap.min.js') }}"></script>
    <script src="{{ asset('vendors/js/tables/datatable/datatables.bootstrap4.min.js') }}"></script>
@endsection

@section('page-script')
    {{-- Page js files --}}
    <script src="{{ asset('js/scripts/datatables/datatable.js') }}"></script>
    <script src="{{ asset('js/scripts/pickers/dateTime/pick-a-datetime.js') }}"></script>
    <script>

        function refreshPage() {
            $('#name').val("");
            $('#email').val("");
            $('#phone').val("");
        }

    </script>
    <!-- End script-->
@endsection

