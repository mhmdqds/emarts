@extends('layouts.app2')

@section('vendor-style')
    {{-- Page Css files --}}
    <link rel="stylesheet" href="{{ asset('vendors/css/tables/datatable/datatables.min.css') }}">
    <link rel="stylesheet" href="{{ asset('vendors/css/pickers/pickadate/pickadate.css') }}">
@endsection

@section('page-style')
    {{-- Page Css files --}}

@endsection

@section('content')
    <!-- users edit start -->
    <div class="content-header row">
        <div class="content-header-left col-md-9 col-12 mb-2">
            <div class="row breadcrumbs-top">
                <div class="col-md-12">
                    <h2 class="col-md-12 content-header-title float-left mb-0">Edit Phone</h2>
                    <div class="breadcrumb-wrapper col-md-12">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{url('/home')}}">Home</a>
                            </li>
        
                            <li class="breadcrumb-item">Edit Phone
                            </li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="content-body">
        <!-- end row -->
        <div class="row">
            <div class="col-xl-7 col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Phone Information</h4>
                    </div>
                    <div class="card-content">
                        <div class="card-body">
                            <form class="form form-vertical" method="POST"
                                  action="{{route('adminUsers.update', ['adminUser' => $ContactsPhone->id])}}"
                            >
                                @csrf
                                @method('put')
                                <div class="form-body">
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="form-group">
                                                <label for="name" class="col-md-12 col-form-label">Display Name <a class="text-danger font-14">*</a></label>
                                                <div class="position-relative has-icon-left">
                                                    <input type="text" id="displayName" class="form-control @error('name') is-invalid @enderror"
                                                           name="displayName"
                                                           value="{{ $ContactsPhone->displayName }}"
                                                           required autocomplete="displayName" autofocus>
                                                    @error('displayName')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                    @enderror
                                                    <div class="form-control-position">
                                                        <i class="feather icon-ContactsPhone"></i>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="form-group">
                                                <label for="phone1" class="col-md-12 col-form-label">Phone 1 <a class="text-danger font-14">*</a></label>
                                                <div class="position-relative has-icon-left">
                                                    <input type="phone1" id="phone1" class="form-control @error('email') is-invalid @enderror"
                                                           name="phone1" value="{{ $ContactsPhone->phone1 }}" required autocomplete="phone1">
                                                    @error('phone1')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                    @enderror
                                                    <div class="form-control-position">
                                                        <i class="feather icon-mail"></i>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="form-group">
                                                <label for="phone" class="col-md-12 col-form-label">phone2 <a class="text-danger font-14">*</a></label>
                                                <div class="position-relative has-icon-left">
                                                    <input type="number" id="phone2" class="form-control @error('phone2') is-invalid @enderror"
                                                           name="phone2" value="{{ $ContactsPhone->phone2 }}" required autocomplete="phone2" pattern="/^-?\d+\.?\d*$/" onKeyPress="if(this.value.length==10) return false;">
                                                    @error('phone2')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                    @enderror
                                                    <div class="form-control-position">
                                                        <i class="feather icon-smartphone"></i>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
								<div class="col-12">
                                            <div class="form-group">
                                                <label for="phone" class="col-md-12 col-form-label">phone3 <a class="text-danger font-14">*</a></label>
                                                <div class="position-relative has-icon-left">
                                                    <input type="number" id="phone3" class="form-control @error('phone3') is-invalid @enderror"
                                                           name="phone3" value="{{ $ContactsPhone->phone3 }}" required autocomplete="phone3" pattern="/^-?\d+\.?\d*$/" onKeyPress="if(this.value.length==10) return false;">
                                                    @error('phone3')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                    @enderror
                                                    <div class="form-control-position">
                                                        <i class="feather icon-smartphone"></i>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
										<div class="col-12">
                                            <div class="form-group">
                                                <label for="phone" class="col-md-12 col-form-label">phone4 <a class="text-danger font-14">*</a></label>
                                                <div class="position-relative has-icon-left">
                                                    <input type="number" id="phone4" class="form-control @error('phone4') is-invalid @enderror"
                                                           name="phone4" value="{{ $ContactsPhone->phone4 }}" required autocomplete="phone4" pattern="/^-?\d+\.?\d*$/" onKeyPress="if(this.value.length==10) return false;">
                                                    @error('phone4')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                    @enderror
                                                    <div class="form-control-position">
                                                        <i class="feather icon-smartphone"></i>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                      
                                        </div>
                                        <div class="col-12">
                                            <div class="form-group">
                                                <div class="row">
                                                    <label for="note" class="col-md-12 col-form-label">note(Optional)</label>
                                                    <div class="col-md-12">
                                                        <textarea class="form-control" rows="3"
                                                                  id="note" name="register" required autocomplete="description"></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12 d-flex justify-content-center">
                                            <button type="button" class="btn btn-success waves-effect waves-light mr-1 px-1"
                                                    onclick="refreshPage()">
                                                <i class="fa fa-refresh mr-lg-1 mr-md-0"></i>
                                                Clear
                                            </button>
                                            <button type="submit" class="btn btn-primary waves-effect waves-light px-1">
                                                <i class="fa fa-save mr-lg-1 ml-md-0"></i> Save
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <!-- users edit ends -->
@endsection

@section('vendor-script')
    {{-- Vendor js files --}}
    <script src="{{ asset('vendors/js/tables/datatable/pdfmake.min.js') }}"></script>
    <script src="{{ asset('vendors/js/tables/datatable/vfs_fonts.js') }}"></script>
    <script src="{{ asset('vendors/js/tables/datatable/datatables.min.js') }}"></script>
    <script src="{{ asset('vendors/js/tables/datatable/datatables.buttons.min.js') }}"></script>
    <script src="{{ asset('vendors/js/tables/datatable/buttons.html5.min.js') }}"></script>
    <script src="{{ asset('vendors/js/tables/datatable/buttons.print.min.js') }}"></script>
    <script src="{{ asset('vendors/js/tables/datatable/buttons.bootstrap.min.js') }}"></script>
    <script src="{{ asset('vendors/js/tables/datatable/datatables.bootstrap4.min.js') }}"></script>
@endsection

@section('page-script')
    {{-- Page js files --}}
    <script src="{{ asset('js/scripts/datatables/datatable.js') }}"></script>
    <script src="{{ asset('js/scripts/pickers/dateTime/pick-a-datetime.js') }}"></script>
    <script>

        function refreshPage() {
            $('#name').val("");
            $('#email').val("");
            $('#phone').val("");
        }

    </script>
    <!-- End script-->
@endsection

