@extends('layouts.app2')

@section('vendor-style')
    {{-- Page Css files --}}
    <link rel="stylesheet" href="{{ asset('vendors/css/tables/ag-grid/ag-grid.css') }}">
    <link rel="stylesheet" href="{{ asset('vendors/css/tables/ag-grid/ag-theme-material.css') }}">
@endsection

@section('page-style')
    {{-- Page Css files --}}
    <link rel="stylesheet" href="{{ asset('css/pages/app-user.css') }}">
    <link rel="stylesheet" href="{{ asset('css/pages/aggrid.css') }}">
@endsection

@section('content')
    <div class="content-header row">
        <div class="content-header-left col-md-9 col-12 mb-2">
            <div class="row breadcrumbs-top">
                <div class="col-md-12">
                    <div class="breadcrumb-wrapper col-md-12">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{url('/home')}}">Home</a>
                            </li>
                            <li class="breadcrumb-item">Same Numbers
                            </li>
                            <li class="breadcrumb-item">Numbers Management
                            </li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="content-body">

        <form action="/phonelist/member/samenaumberscheack" method="get" >

            <section class="">
                <div id="basic-examples">
                    <div class="row">
                        <!-- Start Office Info -->
                   
                        <!-- Start QR Generate and SMS, Email -->
                        <div class="col-xl-12 col-md-12">
                            <div class="card">

                                <div class="card-header">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-12">
                                                <h4 class="card-title">Delete Duplicates</h4>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="card-content">
                                    <div class="card-body py-3">
                                        <div class="row">

                                            <div class="col-12 text-center mt-lg-3 mt-md-3">
                                               <div class="row">

            <div class="col-lg-3 col-sm-6 col-12">
                <div class="card">
                    <div class="card-header d-flex flex-column align-items-start pb-0">
                        <div class="avatar bg-rgba-primary p-50 m-0">
                            <div class="avatar-content">
                                <i class="feather icon-user-check text-primary font-medium-5"></i>
                            </div>
                        </div>
                        <h2 class="text-bold-700 mt-1">{{ $ContactsPhones->count() }}</h2>
                        <p class="">Number Count  </p>
                    </div>
                    <div class="card-content"></div>
                </div>
            </div>

            <div class="col-lg-3 col-sm-6 col-12">
                <div class="card">
                    <div class="card-header d-flex flex-column align-items-start pb-0">
                        <div class="avatar bg-rgba-success p-50 m-0">
                            <div class="avatar-content">
                                <i class="feather icon-users text-success font-medium-5"></i>
                            </div>
                        </div>
                        <h2 class="text-bold-700 mt-1">{{ $identifiers->count() }}</h2>
                        <p class="">User Count</p>
                    </div>
                    <div class="card-content"></div>
                </div>
            </div>

            <div class="col-lg-3 col-sm-6 col-12">
                <div class="card">
                    <div class="card-header d-flex flex-column align-items-start pb-0">
                        <div class="avatar bg-rgba-danger p-50 m-0">
                            <div class="avatar-content">
                                <i class="feather icon-star-on text-danger font-medium-5"></i>
                            </div>
                        </div>
                        <h2 class="text-bold-700 mt-1">{{ $samecontacts->count() }}</h2>
                        <p class="">Same Number Count</p>
                    </div>
                    <div class="card-content"></div>
                </div>
            </div>

            <div class="col-lg-3 col-sm-6 col-12">
                <div class="card">
                    <div class="card-header d-flex flex-column align-items-start pb-0">
                        <div class="avatar bg-rgba-success p-50 m-0">
                            <div class="avatar-content">
                                <i class="feather icon-star-on text-danger font-medium-5"></i>
                            </div>
                        </div>
                        <h2 class="text-bold-700 mt-1">{{ $keywords->count() }}</h2>
                        <p class="">Keyword Number</p>
                    </div>
                    <div class="card-content"></div>
                </div>
            </div>
        </div>
                                                <button type="submit" id="saveBusiness"
                                                        class="col-6 btn btn-relief-primary waves-effect waves-light px-1 mt-2">
                                                    <i class="fa fa-plus m-r-10"></i>
                                                    Filter Duplicates
                                                </button>
                                            </div>

                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <!-- End QR Generate and SMS, Email -->
                    </div>
                </div>
            </section>

        </form>

    </div>

@endsection

@section('vendor-script')
    {{-- Vendor js files --}}
    <script src="{{ asset('vendors/js/tables/ag-grid/ag-grid-community.min.noStyle.js') }}"></script>
    {{--    <script src="{{ asset('js/scripts/datatables/datatable.js') }}"></script>--}}
@endsection

@section('page-script')
    <script src="{{ asset('js/scripts/popover/popover.js') }}"></script>
    {{-- Page js files --}}
    <script type="text/javascript">

    </script>
@endsection
