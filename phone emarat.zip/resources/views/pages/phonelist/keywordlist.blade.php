@extends('layouts.app2')

@section('vendor-style')
    {{-- Page Css files --}}
    <link rel="stylesheet" href="{{ asset('vendors/css/tables/datatable/datatables.min.css') }}">
    <link rel="stylesheet" href="{{ asset('vendors/css/pickers/pickadate/pickadate.css') }}">
@endsection

@section('page-style')
    {{-- Page Css files --}}
    <link rel="stylesheet" href="{{asset('css/pages/app-user.css')}}">
    <style>
        th, td {
            padding-top: 10px;
            padding-bottom: 10px;
        }
    </style>
@endsection

@section('content')
    	 <div class="text-right">
		 <a class="btn btn-primary" href="{{ route('phonewords') }}">Create KeyWord</a>
    </div>
	<!-- users edit start -->
    <div class="content-body">
        <section class="">
            <div id="basic-examples">
                <div class="card">
						<div class="card-header">
                            <div class="card-title my-2">KeyWord Information</div>
                        </div>
                    <div class="card-content">
                        <div class="card-body">
						
                            <div class="row">
                               
                                <div class="col-12">
                                    <div class="table-responsive">
                                        <table class="table">
                                            <thead>
                                            <tr>
												<th>keyword name</th>
                                                <th>keyword old</th>
                                                <th>keyword new</th>
												<th>counter</th>
                                                <th>notes</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            @foreach($keywords as $keyword)
                                                <tr>
                                                    <td>
                                                        {{ $keyword->keyword_name}}
                                                    </td> 
													<td>
                                                        {{ $keyword->keyword_old }}
                                                    </td>
                                                    <td>
                                                        {{ $keyword->keyword_new }}
                                                    </td>
                                                    <td>
                                                        {{ $keyword->counter }}
                                                    </td>
                                                    <td>
                                                        {{$keyword->notes}}
                                                    </td>
                                                    <td style="min-width: 105px">
                                                       <a class="mr-1"
                                                        href="{{ route('keyword.show', $keyword->id) }}">
                                                        <i class="feather icon-eye"></i>
                                                        </a>
                                                        <a class="mr-1"
                                                        href="{{ route('keyword.edit', $keyword->id) }}">
                                                         <i class="fa fa-edit"></i>
                                                            </a>
                                                            <a href="{{ route('keyword.destroy', $keyword->id) }}"
                                                               data-toggle="modal" data-target="#deleteUser">
                                                                <i class="fa fa-trash"></i>
                                                            </a>
                                                    </td>

                                                </tr>
                                            @endforeach
                                              

                                            </tbody>
                                        </table>

                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
        
    </div>
	
	<div class="modal" id="deleteUser" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable" role="document">
            <div class="modal-content">
                <div class="modal-header bg-danger white">
                    <h5 class="modal-title" id="myModalLabel120">Delete keyword</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    Are you sure you want to delete keyword?
                </div>
                <div class="modal-footer">
                    <form method="POST" id="deleteForm" action="">
                        @csrf
                        @method('get')
                        <button type="submit" class="btn btn-danger">OK</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- users edit ends -->
@endsection

@section('vendor-script')
    {{-- Vendor js files --}}
    <script src="{{ asset('vendors/js/tables/datatable/pdfmake.min.js') }}"></script>
    <script src="{{ asset('vendors/js/tables/datatable/vfs_fonts.js') }}"></script>
    <script src="{{ asset('vendors/js/tables/datatable/datatables.min.js') }}"></script>
    <script src="{{ asset('vendors/js/tables/datatable/datatables.buttons.min.js') }}"></script>
    <script src="{{ asset('vendors/js/tables/datatable/buttons.html5.min.js') }}"></script>
    <script src="{{ asset('vendors/js/tables/datatable/buttons.print.min.js') }}"></script>
    <script src="{{ asset('vendors/js/tables/datatable/buttons.bootstrap.min.js') }}"></script>
    <script src="{{ asset('vendors/js/tables/datatable/datatables.bootstrap4.min.js') }}"></script>
@endsection

@section('page-script')
    {{-- Page js files --}}
    <script src="{{ asset('js/scripts/datatables/datatable.js') }}"></script>
    <script src="{{ asset('js/scripts/pickers/dateTime/pick-a-datetime.js') }}"></script>
    <script>
	
		$('#deleteUser').on('shown.bs.modal', function (event) {
            $('#deleteForm').attr('action', $(event.relatedTarget).attr('href'));
            console.log('request action route', $('#deleteForm').attr('action', $(event.relatedTarget).attr('href')));
        })

        function refreshPage() {
            $('#patient_name').val("");
            $('#patient_email').val("");
            $('#patient_phone').val("");
            $('#patient_dob').val("");
            $('#patient_register').val("");
            $('#patient_description').val("");
            $('#qr_image').attr('src', base_url+'assets/images/default_image.png');
        }

    </script>
    <!-- End script-->
@endsection

