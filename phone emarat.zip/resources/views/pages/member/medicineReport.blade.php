@extends('layouts.app2')
<head>

    <!-- Meta -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <!-- CSS -->
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.0-alpha1/css/bootstrap.min.css" integrity="sha256-IdfIcUlaMBNtk4Hjt0Y6WMMZyMU0P9PN/pH+DFzKxbI=" crossorigin="anonymous" />
    <link href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">

  <style type="text/css">
   .box{
    width:600px;
    margin:0 auto;
   }
  </style>
</head>
  
@section('vendor-style')
    {{-- Page Css files --}}
    <link rel="stylesheet" href="{{ asset('vendors/css/tables/datatable/datatables.min.css') }}">
    <link rel="stylesheet" href="{{ asset('vendors/css/pickers/pickadate/pickadate.css') }}">
@endsection

@section('page-style')
    {{-- Page Css files --}}
    <link rel="stylesheet" href="{{asset('css/pages/app-user.css')}}">
    <style>
        th, td {
            padding-top: 10px;
            padding-bottom: 10px;
        }
    </style>
@endsection

@section('content')

 <div class="row">
     <div class="col-12">
             <div class="row">
                                    <div class="col-md-2 col-sm-6 mb-2">
                                        <a href="{{route('medicineReport')}}" type="button"
                                           class="btn btn-primary text-white" data-toggle="modal" data-target="#scans" data-target-complinttype="#genname" >بحث</a>
                                    </div>
                                    
                                </div>
    </div>
    </div>
    
    <div class="content-body">
        <section id="">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="row">
                                <div class="col-12">
                                    <h4 class="card-title"></h4>
                                </div>
                            </div>
                        </div>
                        <div class="card-content">
                            <div class="card-body">
                                {{--                                <div class="row">--}}
                                {{--                                    <div class="col-lg-3 col-sm-12">--}}
                                {{--                                        <div class="form-group">--}}
                                {{--                                            <p>Analytics</p>--}}
                                {{--                                            <select id="role" class="form-control">--}}
                                {{--                                                <option value="">Select Analytics...</option>--}}
                                {{--                                                <option value="Team Analytics">Team Analytics</option>--}}
                                {{--                                                <option value="Office Analytics">Office Analytics</option>--}}
                                {{--                                                <option value="Review Request Analytics">Review Request Analytics</option>--}}
                                {{--                                                <option value="Referring Analytics">Referring Analytics</option>--}}
                                {{--                                            </select>--}}
                                {{--                                        </div>--}}
                                {{--                                    </div>--}}
                                {{--                                </div>--}}
                                {{--                                @if(Session::has('message'))--}}
                                {{--                                {{ Session::get('message') }}--}}
                                {{--                                @endif--}}
                               
                               
                               

                                @if($errors->any())
                                    <h4 class="text-danger">Please input correct email</h4>
                                @endif
                                
                                <div class="col-12">
                                <div class="table-responsive">
                                    <table class="table" id="dataTable">
                                        <thead>
                                        <tr>
                                            <th>الاسم العلمي</th>
                                            <th>الاسم التجاري</th>
                                            <th>الشكل</th>
                                            <th>التركيز</th>
                                            <th>العبوة</th>
                                            <th>الكمية</th>
                                            <th>الشركة المصنعه</th>
                                            <th>البلد</th>
                                            <th>العام</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                                                                @foreach($medicines as $patient)
                                                                                      <tr>
                                                                                           <td>
                                                                                               {{ $patient->genericname }}
                                                                                            </td>
                                                                                            <td>
                                                                                                {{ $patient->tradename }}
                                                                                            </td>
                                                                                            <td>
                                                                                               {{ $patient->dosageform }}
                                                                                           </td>
                                                                                            <td>
                                                                                                {{ $patient->strength }}
                                                                                            </td>
                                                                                            <td>
                                                                                                {{ $patient->packagesize }}
                                                                                            </td>
                                                                                            <td>
                                                                                               {{ $patient->quantity }}
                                                                                           </td>
                                                                                           <td>
                                                                                               {{ $patient->manufacturername }}
                                                                                           </td> 
                                                                                           <td>
                                                                                               {{ $patient->nationalitycompany }}
                                                                                           </td>
                                                                                           <td>
                                                                                               {{ $patient->medyear }}
                                                                                           </td> 
                                                                                       </tr>
                                                                                        
                                                                               @endforeach
                                        </tbody>
                                    </table>
                                </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </section>
    </div>
    <!-- users edit ends -->

    <div class="modal fade text-left" id="scans" tabindex="-1" role="dialog" aria-labelledby="myModalLabel110"
         aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable" role="document">
            <div class="modal-content">
                <div class="modal-header bg-success white">
                    <h5 class="modal-title text-right" id="myModalLabel110">ادخل العام المراد البحث فيه مثلا عام 2020</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form method="post" id="medicineReport" action="" ole="search">
                    @csrf
                    {{ csrf_field() }}
                     <div class="modal-body">
                     <label for="recipient-name" class="col-form-label" class="text-center" > يجب تحديد السنه المراد البحث فيها:</label>
                    <select class="form-select" size="3" aria-label="size 3 select example" name="myear" id="myear">
                      <option selected value="2019">2019</option>
                      <option value="2020">2020</option>
                      <option value="2021">2021</option>
                    </select>
                     </div>
            
                    <div class="modal-body">
                     <label for="recipient-name" class="col-form-label" class="text-center" > ادخل الاسم العلمي يجب ان يكون اكثر من ثلاثه احرف:</label>
                    <input class="typeahead form-control" type="text" name="gname" id="gname"  placeholder="الاسم العلمي">
                    <div id="countryList">
                    </div>
                    <div class="modal-body">
                     <label for="qname-name" class="col-form-label">ادخل الشركه المصنعه:</label>
                        <input class=" form-control"  type="text" name="qname" id="qname"  placeholder="الشركة المصنعه">
                    <div id="suggesstion-box"></div>

                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success">بحث</button>
                    </div>
                </form>
            </div>
        </div>
    </div>



@endsection

@section('vendor-script')
    {{-- Vendor js files --}}
    <script src="{{ asset('vendors/js/tables/datatable/pdfmake.min.js') }}"></script>
    <script src="{{ asset('vendors/js/tables/datatable/vfs_fonts.js') }}"></script>
    <script src="{{ asset('vendors/js/tables/datatable/datatables.min.js') }}"></script>
    <script src="{{ asset('vendors/js/tables/datatable/datatables.buttons.min.js') }}"></script>
    <script src="{{ asset('vendors/js/tables/datatable/buttons.html5.min.js') }}"></script>
    <script src="{{ asset('vendors/js/tables/datatable/buttons.print.min.js') }}"></script>
    <script src="{{ asset('vendors/js/tables/datatable/buttons.bootstrap.min.js') }}"></script>
    <script src="{{ asset('vendors/js/tables/datatable/datatables.bootstrap4.min.js') }}"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
    <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
@endsection

  

@section('page-script')

    {{-- Page js files --}}
    <script src="{{ asset('js/scripts/datatables/datatable.js') }}"></script>
    <script src="{{ asset('js/scripts/pickers/dateTime/pick-a-datetime.js') }}"></script>
    <!-- Script -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
    <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>

   
     <script>
    $(document).ready(function(){
     $('#gname').keyup(function(){ 
            var genericname = $(this).val();
            if(genericname != '')
            {
             var _token = $('input[name="_token"]').val();
             $.ajax({
              url:"{{ route('autocomplete') }}",
              method:"POST",
              data:{genericname:genericname, _token:_token},
              success:function(data){
                 $('#countryList').fadeIn();  
                 $('#countryList').html(data);
              }
             });
            }
        });
        $(document).on('click', 'li', function(){  
            $('#gname').val($(this).text());  
            $('#countryList').fadeOut();  
        }); 
    });
    </script>
    
 
   
   
    
    <script>

        $('#scans').on('shown.bs.modal', function (event) {
            $('#medicineReport').attr('action', $(event.relatedTarget).attr('href'));
            console.log('request action route', $(event.relatedTarget).attr('href'));
        })

        $('#activeTopPatient').on('shown.bs.modal', function (event) {
            $('#activeTopPatientInfo').attr('action', $(event.relatedTarget).attr('href'));
            console.log('request action route', $(event.relatedTarget).attr('href'));
        })

        $('#inactiveTopPatient').on('shown.bs.modal', function (event) {
            $('#inactiveTopPatientInfo').attr('action', $(event.relatedTarget).attr('href'));
            console.log('request action route', $(event.relatedTarget).attr('href'));
        })


    $('#search').typeahead({
         minLength: 2,
        source:  function (query, process) {
        return $.get(path, { query: query }, function (data) {
            var dataset = [];
                data.forEach(function(value){
                    dataset.push(value.name);
                });
                return process(dataset);
            });
        }
    });
      
      function selectval(val) {
    $("#gname").val(val);
    $('#suggestion')[0].submit();
    $("#suggesstion-box").hide();
 }
 
      
      function refreshPage() {
            $('#patient_name').val("");
            $('#patient_email').val("");
            $('#patient_phone').val("");
            $('#patient_dob').val("");
            $('#patient_register').val("");
            $('#patient_description').val("");
        }

        let dataTable;
        $(document).ready(function () {
            dataTable = $('#dataTable').DataTable({
                "processing": true,
                "serverSide": true,
                "responsive": true,
                "ajax": '{{ route('portalTopReferrer') }}',
                columns: [
                    {data: 'tradename', name: 'tradename'},
                    {data: 'genericname', name: 'genericname'},
                    {data: 'dosageform', name: 'dosageform'},
                    {data: 'manufacturername', name: 'manufacturername'},
                    {data: 'nationalitycompany', name: 'nationalitycompany'},
                    {data: 'strength', name: 'strength'},

                ]
            });
        });

    </script>

   
   

    <!-- End script-->
@endsection

