@extends('layouts.app2')

@section('vendor-style')
    {{-- Page Css files --}}
    <link rel="stylesheet" href="{{ asset('vendors/css/tables/ag-grid/ag-grid.css') }}">
    <link rel="stylesheet" href="{{ asset('vendors/css/tables/ag-grid/ag-theme-material.css') }}">
@endsection

@section('page-style')
    {{-- Page Css files --}}
    <link rel="stylesheet" href="{{ asset('css/pages/app-contactphone.css') }}">
    <link rel="stylesheet" href="{{ asset('css/pages/aggrid.css') }}">
@endsection

@section('content')
	<div class="container">
		<div class="row">
			<div class="col-md-2">
				<form class="form-inline" id="sort_categories" action="{{ route('phonesearchbyphones') }}" method="GET">
				<div class="" style="min-width: 200px;">
					<input type="text" class="form-control" id="search" name="search"@isset($sort_search) value="{{ $sort_search }}" @endisset placeholder="{{ 'insert phone number and press enter' }}">
				</div>
				</form>
			</div>
			<div class="col-md-2">
				<form class="form-inline" id="sort_categories" action="{{ route('phoneListsearch') }}" method="GET">
				<div class="" style="min-width: 200px;">
					<input type="text" class="form-control" id="search" name="search"@isset($sort_search) value="{{ $sort_search }}" @endisset placeholder="{{ 'insert name and press enter' }}">
				</div>
				</form>
			</div>
			<div class="col-md-2">
				<form class="form-inline" id="sort_categories" action="{{ route('phoneListsearchidentifier') }}" method="GET">
					<div class="" style="min-width: 200px;">
						<input type="text" class="form-control" id="searchidentifier" name="searchidentifier"@isset($sort_search) value="{{ $sort_search }}" @endisset placeholder="{{ 'insert identifier and press enter' }}">
					</div>
				</form>
			</div>
			<div class="col-md-2">
			</div>
			<div class="col-md-2">
				<button   type="button"
				 class="btn btn-sm btn-primary waves-effect waves-light text-white px-1 mr-1"
				 data-toggle="modal"
			   data-target="#addPatient">Add KEYWORD
			</button >
			</div>
	</div>	
	</div>
    <div class="content-body">
        <section class="">
            <div id="basic-examples">
                <div class="card">
                    <div class="card-content">
                        <div class="card-body">
						
                            <div class="row">
                               
                                <div class="col-12">
                                    <div class="table-responsive">
                                        <table class="table">
                                            <thead>
                                            <tr>
{{--                                            <th>Active</th>--}}
                                                <th>identifier</th>
                                                <th>displayName</th>
												<th>phone1</th>
                                                <th>phone2</th>
                                                <th>phone3</th>
                                                <th>phone4</th>
                                                <th>Action</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            @foreach($contactphones as $contactphone)
                                                <tr>
{{--                                                    <td>--}}
{{--                                                        yes--}}
{{--                                                    </td>--}}
                                                    <td>
                                                        {{ $contactphone->identifier }}
                                                    </td> 
													<td>
                                                        {{ $contactphone->displayName }}
                                                    </td>
                                                    <td>
                                                        {{ $contactphone->phone1 }}
                                                    </td>
                                                    <td>
                                                        {{ $contactphone->phone2 }}
                                                    </td>
                                                    <td>
                                                        {{$contactphone->phone3}}
                                                    </td>
                                                    <td>
                                                        {{$contactphone->phone4}}
                                                    </td>
                                                    <td style="min-width: 105px">
                                                       <a class="mr-1"
                                                        href="{{ route('phone.show', $contactphone->id) }}">
                                                        <i class="feather icon-eye"></i>
                                                        </a>
                                                        <a class="mr-1"
                                                        href="{{ route('phone.edit', $contactphone->id) }}">
                                                         <i class="fa fa-edit"></i>
                                                            </a>
                                                            <a href="{{ route('phone.destroy', $contactphone->id) }}"
                                                               data-toggle="modal" data-target="#deleteUser">
                                                                <i class="fa fa-trash"></i>
                                                            </a>
                                                    </td>

                                                </tr>
                                            @endforeach
                                                <tr class="text-right">
                                                    {{ $contactphones->links() }}
                                                </tr>

                                            </tbody>
                                        </table>

                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
    <div class="modal" id="deleteUser" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable" role="document">
            <div class="modal-content">
                <div class="modal-header bg-danger white">
                    <h5 class="modal-title" id="myModalLabel120">Delete User</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    Are you sure you want to delete User?
                </div>
                <div class="modal-footer">
                    <form method="POST" id="deleteForm" action="">
                        @csrf
                        @method('delete')
                        <button type="submit" class="btn btn-danger">OK</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
	
	<div class="modal fade" id="addPatient" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header bg-primary white">
                    <h5 class="modal-title">Add Keyword</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="/phonelist/member/keywordGenerators">
                        @csrf
                        @method('post')

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right">{{ __('Name') }}</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control @error('name') is-invalid @enderror"
                                       name="name" value="{{ old('name') }}" required autocomplete="name" autofocus>

                                @error('name')
                                <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                      
                   

                        <div class="form-group row">
                            <label for="notes"
                                   class="col-md-4 col-form-label text-md-right">{{ __('Notes') }}</label>

                            <div class="col-md-6">
                                <textarea class="form-control" rows="3"
                                          id="notes" name="notes" autocomplete="notes"></textarea>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-8 offset-md-4">
                                <button type="button" id="clearPage" class="btn btn-primary mr-3">
                                    {{ __('Clear') }}
                                </button>
                                <button type="submit" class="btn btn-primary text-right">
                                    {{ __('ADD KEYWORD') }}
                                </button>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('vendor-script')
    {{-- Vendor js files --}}
    <script src="{{ asset('vendors/js/tables/ag-grid/ag-grid-community.min.noStyle.js') }}"></script>
{{--    <script src="{{ asset('js/scripts/datatables/datatable.js') }}"></script>--}}
@endsection

@section('page-script')
    <script src="{{ asset('js/scripts/popover/popover.js') }}"></script>
    {{-- Page js files --}}

    <script>
        $('#deleteUser').on('shown.bs.modal', function (event) {
            $('#deleteForm').attr('action', $(event.relatedTarget).attr('href'));
            console.log('request action route', $('#deleteForm').attr('action', $(event.relatedTarget).attr('href')));
        })

        $('[data-toggle="popover-click"]').popover({
            html: true,
            trigger: 'click',
            title : 'QR Code <a href="#" class="close text-light" data-dismiss="alert">&times;</a>',
            placement: 'bottom',
            content: function () { return '<img src="' + $(this).data('img') + '" width="300"/>'; }
        });
        $(document).on("click", ".popover .close" , function(){
            $(this).parents(".popover").popover('hide');
        });

    </script>
	
    <script type="text/javascript">
        function update_featured(el){
            if(el.checked){
                var status = 1;
            }
            else{
                var status = 0;
            }
            $.post('{{ route('phoneListsearch') }}', {_token:'{{ csrf_token() }}', id:el.value, status:status}, function(data){
                if(data == 1){
                    AIZ.plugins.notify('success', 'Featured categories updated successfully');
                }
                else{
                    AIZ.plugins.notify('danger', 'Something went wrong');
                }
            });
        }
    </script>
@endsection

