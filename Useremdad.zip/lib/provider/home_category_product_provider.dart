import 'package:emdad/provider/seller_provider.dart';
import 'package:flutter/material.dart';
import 'package:emdad/data/model/response/home_category_product_model.dart';
import 'package:emdad/data/repository/home_category_product_repo.dart';
import 'package:emdad/data/model/response/base/api_response.dart';
import 'package:emdad/helper/api_checker.dart';
import 'package:emdad/data/model/response/product_model.dart';
import 'package:provider/provider.dart';


class HomeCategoryProductProvider extends ChangeNotifier {
  final HomeCategoryProductRepo homeCategoryProductRepo;
  HomeCategoryProductProvider({@required this.homeCategoryProductRepo});


  List<HomeCategoryProduct> _homeCategoryProductList = [];
  List<Product> _productList;
  List <int>_sellerIds=[];
  int _productIndex;
  int get productIndex => _productIndex;
  List<HomeCategoryProduct> get homeCategoryProductList => _homeCategoryProductList;
  List<Product> get productList => _productList;
  List<int> get sellerIds => _sellerIds;
  Future<void> getHomeCategoryProductList(bool reload, BuildContext context) async {
    print("<--getHomeCategoryProductList");
    if (_homeCategoryProductList.length == 0 || reload) {
      print("hiiiiiiiiiiiiiiiiiii");
      ApiResponse apiResponse = await homeCategoryProductRepo.getHomeCategoryProductList();
      if (apiResponse.response != null && apiResponse.response.statusCode == 200) {
        print("hiiiiiiiiiiiiiiiiiii2");
        _productList = [];
        _homeCategoryProductList = [];
        apiResponse.response.data.forEach((homeCategoryProduct) => _homeCategoryProductList.add(HomeCategoryProduct.fromJson(homeCategoryProduct)));
        _homeCategoryProductList.forEach((product) {
          print("ppppppppppppppppp$product");
          print(product.products);
          _productList.addAll(product.products);
          print("ppppppppppppppppp${_productList.length}");
          _productList.forEach((element) {
            print(element.userId);
            if(_sellerIds.contains(element.userId)==false)
              _sellerIds.add(element.userId); });
          print("sellllllllllllllllllllllllllllllllll: $_sellerIds");



        });
        _sellerIds.forEach((id) {
          if(id!=1)
          {
            Provider.of<SellerProvider>(context, listen: false)
                .initSeller(id.toString(), context);

          }

        });

        print("<-- _productList ::: $_sellerIds");
        print("<-- _homeCategoryProductList ::: $_homeCategoryProductList");

      } else {
        ApiChecker.checkApi(context, apiResponse);
      }
      notifyListeners();
    }
  }

}
