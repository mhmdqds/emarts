class DateModel{
  int day;
  String dayName;

  DateModel({this.day, this.dayName});
}