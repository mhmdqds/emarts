class ApoinmentTime{
  String name;
  bool isActive;

  ApoinmentTime({this.name, this.isActive});
}