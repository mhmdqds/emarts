import 'package:emdad/utility/dimensions.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:emdad/utility/custom_themes.dart';

extension EmailValidator on String {
  bool isValidEmail() {
    return RegExp(
            r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$')
        .hasMatch(this);
  }
}

class CustomTextField extends StatefulWidget {
  final TextEditingController controller;
  final String hintText;
  final TextInputType textInputType;
  final int maxLine;
  final FocusNode focusNode;
  final FocusNode nextNode;
  final TextInputAction textInputAction;
  final bool isPhoneNumber;
  final bool isValidator;
  final String validatorMessage;
   Color fillColor=Colors.red;
   bool enabled=true;
   Color textColor= Colors.black;
  final TextCapitalization capitalization;

  CustomTextField(
      {this.controller,
        this.textColor,
      this.hintText,
        this.enabled,
      this.textInputType,
      this.maxLine,
      this.focusNode,
      this.nextNode,
      this.textInputAction,
      this.isPhoneNumber = false,
      this.isValidator=false,
      this.validatorMessage,
      this.capitalization = TextCapitalization.none,
      this.fillColor});

  @override
  State<CustomTextField> createState() => _CustomTextFieldState();
}

class _CustomTextFieldState extends State<CustomTextField> {
  @override
  Widget build(context) {
    return Container(
      width: double.infinity,

      decoration: BoxDecoration(
        color: Theme.of(context).highlightColor,
        borderRadius: // isPhoneNumber ? BorderRadius.only(topRight: Radius.circular(6), bottomRight: Radius.circular(6)) :
        BorderRadius.circular(20),
        boxShadow: [
          //BoxShadow(color: Colors.grey.withOpacity(0.2), spreadRadius: 1, blurRadius: 7, offset: Offset(0, 1)) // changes position of shadow
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),

        child: TextFormField(
          enabled: widget.enabled,
          onTap: (){

            if(widget.controller.selection == TextSelection.fromPosition(TextPosition(offset: widget.controller.text.length -1))){
              setState(() {
                widget.controller.selection = TextSelection.fromPosition(TextPosition(offset: widget.controller.text.length));
              });
            }

          },

          style: TextStyle(
              fontSize: Dimensions.FONT_SIZE_DEFAULT,
              //height: 2.0,
              color:widget.textColor
          ),


          controller: widget.controller,
          maxLines: widget.maxLine ?? 1,
          textCapitalization: widget.capitalization,
          maxLength: widget.isPhoneNumber ? 15 : null,
          focusNode: widget.focusNode,
          keyboardType: widget.textInputType ?? TextInputType.text,
          //keyboardType: TextInputType.number,
          initialValue: null,
          textInputAction: widget.textInputAction ?? TextInputAction.next,
          onFieldSubmitted: (v) {
            FocusScope.of(context).requestFocus(widget.nextNode);
          },
          //autovalidate: true,
          inputFormatters: [widget.isPhoneNumber ? FilteringTextInputFormatter.digitsOnly : FilteringTextInputFormatter.singleLineFormatter],
          validator: (input){
            if(input.isEmpty){
              if(widget.isValidator){
                return widget.validatorMessage??"";
              }
            }
            return null;

          },
          decoration: InputDecoration(
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.all(Radius.circular(20.0)),
    borderSide: BorderSide(width: 1, color: Colors.grey.withOpacity(0.4)),),

            hintText: widget.hintText ?? '',
            filled: true,
            //widget.fillColor != null,
            fillColor: Colors.grey.withOpacity(0.15),
            //widget.fillColor,
            contentPadding: EdgeInsets.symmetric(vertical: 10.0, horizontal: 15),
            isDense: true,
            counterText: '',
            focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: Theme.of(context).primaryColor) ,borderRadius: BorderRadius.circular(20),),
            hintStyle: titilliumRegular.copyWith(color: Theme.of(context).hintColor),
            errorStyle: TextStyle(height: 1.5),
            border: InputBorder.none
          ),
        ),
      ),
    );
  }
}
