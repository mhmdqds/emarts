import 'package:flutter/material.dart';
import 'package:emdad/provider/theme_provider.dart';
import 'package:emdad/utility/color_resources.dart';
import 'package:emdad/utility/custom_themes.dart';
import 'package:provider/provider.dart';

class CustomButton2 extends StatelessWidget {
  final Function onTap;
  final String buttonText;
  final bool isBuy;
  double width ;
  double height ;
  Color color;

  CustomButton2({this.onTap, @required this.buttonText, this.isBuy= false
    ,this.width=double.infinity ,
    this.height=45 ,
    this.color
  });

  @override
  Widget build(BuildContext context) {
    return TextButton(
      onPressed: onTap,
      style: TextButton.styleFrom(padding: EdgeInsets.all(0)),
      child: Container(
        height: height,
        width: width,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color:Theme.of(context).primaryColor,


          border: Border.all(
              color: Theme.of(context).primaryColor, width: 1),
          borderRadius: BorderRadius.circular(30.0),),

        child: Text(buttonText,
            style: titilliumsemiBold.copyWith(
              fontSize: 12,
              color:Colors.white ,

            )),
      ),
    );
  }
}
