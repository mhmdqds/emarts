import 'package:flutter/material.dart';
import 'package:emdad/provider/auth_provider.dart';
import 'package:emdad/provider/wishlist_provider.dart';
import 'package:emdad/utility/images.dart';
import 'package:emdad/view/basewidget/animated_custom_dialog.dart';
import 'package:emdad/view/basewidget/guest_dialog.dart';
import 'package:emdad/view/basewidget/show_custom_snakbar.dart';
import 'package:provider/provider.dart';

class FavouriteButton extends StatefulWidget {
  final Color backgroundColor;
  final Color favColor;
  final bool isSelected;
  final int productId;
  FavouriteButton({this.backgroundColor = Colors.black, this.favColor = Colors.white, this.isSelected = false, this.productId});

  @override
  State<FavouriteButton> createState() => _FavouriteButtonState();
}

class _FavouriteButtonState extends State<FavouriteButton> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();

  }

  @override
  Widget build(BuildContext context) {
    bool isGuestMode = !Provider.of<AuthProvider>(context, listen: false).isLoggedIn();
    if(Provider.of<AuthProvider>(context, listen: false).isLoggedIn()) {

     // WidgetsBinding.instance.addPostFrameCallback((_){

        // Add Your Code here.
        Provider.of<WishListProvider>(context, listen: true).checkWishListById(widget.productId.toString(), context);
        //context.watch<WishListProvider>().checkWishListById(widget.productId.toString(), context);


     // });
    }
    feedbackMessage(String message) {
      if (message != '') {
        showCustomSnackBar(message, context, isError: false);
      }
    }



    return GestureDetector(
      onTap: () async {
        if (isGuestMode) {
          showAnimatedDialog(context, GuestDialog(), isFlip: true);
        } else {
          await Provider.of<WishListProvider>(context, listen: false).checkWishListById(widget.productId.toString(), context);
          Provider.of<WishListProvider>(context, listen: false).isWish
              ? Provider.of<WishListProvider>(context, listen: false).removeWishList(widget.productId, feedbackMessage: feedbackMessage)
              : Provider.of<WishListProvider>(context, listen: false).addWishList(widget.productId, feedbackMessage: feedbackMessage);
        }
      },
      child: Consumer<WishListProvider>(
        builder: (context, wishListProvider, child) => Card(
          elevation: 0,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(50)),
          color: Theme.of(context).cardColor,
          child: Padding(
            padding: EdgeInsets.all(8),
            child: Image.asset(
              wishListProvider.isWish ? Images.wish_image : Images.wishlist,
              color: wishListProvider.isWish ? widget.backgroundColor : widget.favColor,
              height: 22,
              width: 22,
            ),
          ),
        ),
      ),
    );
  }
}
