import 'package:emdad/helper/price_converter.dart';
import 'package:emdad/provider/cart_provider.dart';
import 'package:emdad/utility/Palette.dart';
import 'package:emdad/utility/images.dart';
import 'package:emdad/view/screen/cart/cart_screen.dart';
import 'package:emdad/view/screen/product/widget/brand_products.dart';
import 'package:emdad/view/screen/product/widget/brand_products_tow.dart';
import 'package:emdad/view/screen/product/widget/favourite_button.dart';
import 'package:emdad/view/screen/product/widget/related_product_view.dart';
import 'package:flutter/material.dart';
import 'package:emdad/provider/auth_provider.dart';
import 'package:emdad/utility/color_resources.dart';
import 'package:emdad/data/model/response/product_model.dart';

import 'package:emdad/localization/language_constrants.dart';
import 'package:emdad/provider/product_details_provider.dart';
import 'package:emdad/provider/product_provider.dart';
import 'package:emdad/provider/theme_provider.dart';
import 'package:emdad/provider/wishlist_provider.dart';
import 'package:emdad/utility/dimensions.dart';
import 'package:emdad/view/basewidget/no_internet_screen.dart';
import 'package:emdad/view/basewidget/title_row.dart';
import 'package:emdad/view/screen/product/widget/bottom_cart_view.dart';
import 'package:emdad/view/screen/product/widget/product_image_view.dart';
import 'package:emdad/view/screen/product/widget/product_title_view.dart';
import 'package:provider/provider.dart';
import 'package:share/share.dart';
import '../../../../utility/styles.dart';


import '../../basewidget/titlRow2.dart';


class ProductDetails extends StatefulWidget {
  final Product product;
  ProductDetails({@required this.product, });



  @override
  State<ProductDetails> createState() => _ProductDetailsState();
}

class _ProductDetailsState extends State<ProductDetails> {
  _loadData( BuildContext context) async{
      Provider.of<ProductDetailsProvider>(context, listen: false).removePrevReview();
      Provider.of<ProductDetailsProvider>(context, listen: false).initProduct(widget.product, context);
      Provider.of<ProductProvider>(context, listen: false).removePrevRelatedProduct();
      Provider.of<ProductProvider>(context, listen: false).initRelatedProductList(widget.product.id.toString(), context);
      Provider.of<ProductDetailsProvider>(context, listen: false).getCount(widget.product.id.toString(), context);
      Provider.of<ProductDetailsProvider>(context, listen: false).getSharableLink(widget.product.slug.toString(), context);
      if(Provider.of<AuthProvider>(context, listen: false).isLoggedIn()) {
        Provider.of<WishListProvider>(context, listen: false).checkWishList(widget.product.id.toString(), context);
      }
      Provider.of<ProductProvider>(context, listen: false).initSellerProductList(widget.product.userId.toString(), 1, context);
  }

  route(bool isRoute, String message) async {
    if (isRoute) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message), backgroundColor: Colors.green));
      Navigator.pop(context);
    } else {
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message), backgroundColor: Colors.red));
    }
  }
  Variation _variation;


  @override
  void initState() {
    // TODO: implement initState
    super.initState();


      // Add Your Code here.

    WidgetsBinding
        .instance
        .addPostFrameCallback((_){
      _loadData(context);
    }
    );
  }


  @override
  Widget build(BuildContext context) {
    Provider.of<ProductDetailsProvider>(context, listen: false).initData(widget.product);
    ScrollController _scrollController = ScrollController();
    //String ratting = widget.product.rating != null && widget.product.rating.length != 0? widget.product.rating[0].average.toString() : "0";
    return Consumer<ProductDetailsProvider>(
      builder: (context, details, child) {

        return details.hasConnection ? Scaffold(
          backgroundColor: Theme.of(context).cardColor,
          appBar: AppBar(
            backgroundColor: Provider.of<ThemeProvider>(context).darkTheme ? Theme.of(context).highlightColor : Theme.of(context).highlightColor,
            title: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
              InkWell(
                child: Icon(Icons.arrow_back_ios, color: Colors.black, size:  Dimensions.ICON_SIZE_DEFAULT,
                  ),
                onTap: () => Navigator.pop(context),
              ),
              SizedBox(width: Dimensions.PADDING_SIZE_SMALL),
              // Text(getTranslated('product_details', context),
              //     style: robotoRegular.copyWith(fontSize: 15, color: Theme.of(context).primaryColor)),
                  Spacer(),

  Row(
        children: [
        InkWell(
        onTap: () {
          if(Provider.of<ProductDetailsProvider>(context, listen: false).sharableLink != null) {
            Share.share(Provider.of<ProductDetailsProvider>(context, listen: false).sharableLink);
          }
        },
        child: Card(
        elevation: 2,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(50)),
        child: Container(
        width: 30,
        height: 30,
        decoration: BoxDecoration(
        color: Theme.of(context).primaryColor,
        shape: BoxShape.circle,
        ),
        child: Icon(Icons.share, color: Theme.of(context).cardColor, size: Dimensions.ICON_SIZE_SMALL),
        ),
        ),
        ),
        SizedBox(height: Dimensions.PADDING_SIZE_SMALL,),
        FavouriteButton(

          backgroundColor: Colors.red.withOpacity(0.6),

          favColor: ColorResources.colorPrimaryBlack,
        isSelected: Provider.of<WishListProvider>(context,listen: false).isWish,
        productId: widget.product.id,
        ),
        ],
        ),

                  Padding(
                    padding: const EdgeInsets.only(left: 1.0),
                    child: IconButton(
                      onPressed: () {Navigator.push(context, MaterialPageRoute(builder: (_) => CartScreen()));
                      },
                      icon: Stack(clipBehavior: Clip.none, children: [
                        Image.asset(
                          Images.cart_arrow_down_image,
                          height: Dimensions.ICON_SIZE_LARGE,
                          width: Dimensions.ICON_SIZE_LARGE,
                          color: ColorResources.colorPrimaryBlack,
                        ),
                        Positioned(top: -4, right: -4,
                          child: Consumer<CartProvider>(builder: (context, cart, child) {
                            return CircleAvatar(radius: 7, backgroundColor: ColorResources.RED,
                              child: Text(cart.cartList.length.toString(),
                                  style: titilliumSemiBold.copyWith(color: ColorResources.WHITE, fontSize: Dimensions.FONT_SIZE_EXTRA_SMALL,
                                  )),
                            );
                          }),
                        ),
                      ]),
                    ),
                  ),
            ]),

            automaticallyImplyLeading: false,
            elevation: 0,
          ),

          bottomNavigationBar: BottomCartView(product: widget.product),

          body: SingleChildScrollView(
            physics: BouncingScrollPhysics(),
            child: Column(
              children: [
                SizedBox(height: Dimensions.PADDING_SIZE_EXTRA_SMALL),
                ProductTitleView(productModel: widget.product),
                Text(widget.product.qty ??'${widget.product.qty}'),
                SizedBox(height: Dimensions.PADDING_SIZE_DEFAULT),
                Consumer<ProductDetailsProvider>(
                  builder: (context, details, child) {
                    String _variantName = widget.product.colors.length != 0 ? widget.product.colors[details.variantIndex].name : null;
                    List<String> _variationList = [];
                    for(int index=0; index < widget.product.choiceOptions.length; index++) {
                      _variationList.add(widget.product.choiceOptions[index].options[details.variationIndex[index]].trim());

                    }
                    String variationType = '';
                    if(_variantName != null) {
                      variationType = _variantName;
                      _variationList.forEach((variation) => variationType = '$variationType-$variation');
                    }else {

                      bool isFirst = true;
                      _variationList.forEach((variation) {
                        if(isFirst) {
                          variationType = '$variationType$variation';
                          isFirst = false;
                        }else {
                          variationType = '$variationType-$variation';
                        }
                      });
                    }
                    double price = widget.product.unitPrice;
                    int _stock = widget.product.currentStock;
                    variationType = variationType.replaceAll(' ', '');
                    for(Variation variation in widget.product.variation) {
                      if(variation.type == variationType) {
                        price = variation.price;
                        _variation = variation;
                        _stock = variation.qty;
                        break;
                      }
                    }
                    double priceWithDiscount = PriceConverter.convertWithDiscount(context, price, widget.product.discount, widget.product.discountType);
                    double priceWithQuantity = priceWithDiscount * details.quantity;

                    String priceOneDiscount = PriceConverter.convertPriceOne(context, price,  widget.product.unitNumbers);
                    //  String ratting = widget.product.rating != null && widget.product.rating.length != 0? widget.product.rating[0].average : "0";
                    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      // Close Button
                      // Product details

                      SizedBox(height: Dimensions.PADDING_SIZE_SMALL),
                      // Variant
                      widget.product.colors.length > 0 ?
                      Row( children: [
                        Text('${getTranslated('select_variant', context)} : ',
                            style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_DEFAULT)),
                        SizedBox(width: Dimensions.PADDING_SIZE_DEFAULT),
                        SizedBox(
                          height: 40,
                          child: ListView.builder(
                            itemCount: widget.product.colors.length,
                            shrinkWrap: true,
                            scrollDirection: Axis.horizontal,
                            itemBuilder: (context, index) {
                              String colorString = '0xff' + widget.product.colors[index].code.substring(1, 7);
                              return InkWell(
                                onTap: () {
                                  Provider.of<ProductDetailsProvider>(context, listen: false).setCartVariantIndex(index);
                                },
                                child: Container(
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(Dimensions.PADDING_SIZE_EXTRA_SMALL),
                                      border: details.variantIndex == index ? Border.all(width: 1, color: Theme.of(context).primaryColor):null
                                  ),
                                  child: Padding(padding: const EdgeInsets.all(Dimensions.PADDING_SIZE_EXTRA_SMALL),

                                    child: Container(
                                      height: 30,
                                      width: 30,
                                      padding: EdgeInsets.all( Dimensions.PADDING_SIZE_EXTRA_SMALL),
                                      alignment: Alignment.center,
                                      decoration: BoxDecoration(
                                        color: Color(int.parse(colorString)),
                                        borderRadius: BorderRadius.circular(5),
                                      ),
                                      //child: details.variantIndex == index ? Icon(Icons.done_all, color: ColorResources.WHITE, size: 12) : null,
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                      ]) : SizedBox(),
                      widget.product.colors.length > 0 ? SizedBox(height: Dimensions.PADDING_SIZE_SMALL) : SizedBox(),


                      // // Variation
                      // Container(
                      //
                      //   child: ListView.builder(
                      //     shrinkWrap: true,
                      //     itemCount: widget.product.choiceOptions.length,
                      //     physics: NeverScrollableScrollPhysics(),
                      //     itemBuilder: (context, index) {
                      //       return Row(crossAxisAlignment: CrossAxisAlignment.start,
                      //           children: [
                      //
                      //             Padding(
                      //               padding: const EdgeInsets.all(8.0),
                      //               child: ListView.builder(
                      //
                      //                 shrinkWrap: true,
                      //                 physics: NeverScrollableScrollPhysics(),
                      //                 itemCount: widget.product.choiceOptions[index].options.length,
                      //                 itemBuilder: (context, i) {
                      //                   return InkWell(
                      //                     onTap: () {
                      //                       Provider.of<ProductDetailsProvider>(context, listen: false).setCartVariationIndex(index, i);
                      //                     },
                      //                     child: Container(
                      //                       decoration: BoxDecoration(
                      //                         //color:Theme.of(context).primaryColor,
                      //                         borderRadius: BorderRadius.circular(8),
                      //                         border: Border.all(color:Theme.of(context).primaryColor,),
                      //                       ),
                      //                       child: Center(
                      //                         child: Text(widget.product.choiceOptions[index].options[i], maxLines: 1,
                      //                             // overflow: TextOverflow.visible,
                      //                             style: titilliumRegular.copyWith(
                      //                               fontSize: Dimensions.FONT_SIZE_SMALL,
                      //                               color: details.variationIndex[index] != i ? ColorResources.getTextTitle(context) : Theme.of(context).primaryColor,
                      //                             )),
                      //                       ),
                      //                     ),
                      //                   );
                      //                 },
                      //               ),
                      //             ),
                      //           ]);
                      //     },
                      //   ),
                      // ),

                      //SizedBox(height: Dimensions.PADDING_SIZE_DEFAULT,),
                     // SizedBox(height: Dimensions.PADDING_SIZE_SMALL,),
                      Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              widget.product.discount > 0 ?
                              Container(
                                margin: EdgeInsets.only(top: Dimensions.PADDING_SIZE_EXTRA_SMALL),
                                padding: EdgeInsets.symmetric(horizontal: Dimensions.PADDING_SIZE_EXTRA_SMALL),
                                alignment: Alignment.center,
                                decoration: BoxDecoration(
                                  color:Theme.of(context).primaryColor,
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Text(
                                    PriceConverter.percentageCalculation(context, widget.product.unitPrice,
                                        widget.product.discount, widget.product.discountType),
                                    style: titilliumRegular.copyWith(color: Theme.of(context).cardColor,
                                        fontSize: Dimensions.FONT_SIZE_DEFAULT),
                                  ),
                                ),
                              ) : SizedBox(width: 93),
                              SizedBox(width: Dimensions.PADDING_SIZE_DEFAULT),
                              widget.product.discount > 0 ? Text(
                                PriceConverter.convertPrice(context, widget.product.unitPrice),
                                style: titilliumRegular.copyWith(color: ColorResources.getRed(context),
                                    decoration: TextDecoration.lineThrough),
                              ) : SizedBox(),
                              SizedBox(width: Dimensions.PADDING_SIZE_DEFAULT),
                            ],
                          ),
                         // SizedBox(height: Dimensions.PADDING_SIZE_SMALL,),


                        ],
                      ),
                      // Quantity
                      //SizedBox(height: Dimensions.PADDING_SIZE_SMALL),

                    ]);
                  },
                ),




                widget.product != null?
                ProductImageView(productModel: widget.product):SizedBox(),
                //SizedBox(height: Dimensions.PADDING_SIZE_EXTRA_EXTRA_SMALL),


                Column(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Container(
                      //padding: EdgeInsets.all(Dimensions.PADDING_SIZE_DEFAULT),
                      decoration: BoxDecoration(
                        color: Theme.of(context).cardColor,
                        borderRadius: BorderRadius.only(topRight: Radius.circular(20), topLeft: Radius.circular(20)),
                      ),
                      child: Consumer<ProductDetailsProvider>(
                        builder: (context, details, child) {
                          String _variantName = widget.product.colors.length != 0 ? widget.product.colors[details.variantIndex].name : null;
                          List<String> _variationList = [];
                          for(int index=0; index < widget.product.choiceOptions.length; index++) {
                            _variationList.add(widget.product.choiceOptions[index].options[details.variationIndex[index]].trim());

                          }
                          String variationType = '';
                          if(_variantName != null) {
                            variationType = _variantName;
                            _variationList.forEach((variation) => variationType = '$variationType-$variation');
                          }else {

                            bool isFirst = true;
                            _variationList.forEach((variation) {
                              if(isFirst) {
                                variationType = '$variationType$variation';
                                isFirst = false;
                              }else {
                                variationType = '$variationType-$variation';
                              }
                            });
                          }
                          double price = widget.product.unitPrice;
                          int _stock = widget.product.currentStock;
                          variationType = variationType.replaceAll(' ', '');
                          for(Variation variation in widget.product.variation) {
                            if(variation.type == variationType) {
                              price = variation.price;
                              _variation = variation;
                              _stock = variation.qty;
                              break;
                            }
                          }
                          double priceWithDiscount = PriceConverter.convertWithDiscount(context, price, widget.product.discount, widget.product.discountType);
                          double priceWithQuantity = priceWithDiscount * details.quantity;

                          String priceOneDiscount = PriceConverter.convertPriceOne(context, price,  widget.product.unitNumbers);
                        //  String ratting = widget.product.rating != null && widget.product.rating.length != 0? widget.product.rating[0].average : "0";
                          return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            // Close Button
                            // Product details

                            SizedBox(height: Dimensions.PADDING_SIZE_SMALL),
                            // Variant
                            widget.product.colors.length > 0 ?
                            Row( children: [
                              Text('${getTranslated('select_variant', context)} : ',
                                  style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_DEFAULT)),
                              SizedBox(width: Dimensions.PADDING_SIZE_DEFAULT),
                              SizedBox(
                                height: 40,
                                child: ListView.builder(
                                  itemCount: widget.product.colors.length,
                                  shrinkWrap: true,
                                  scrollDirection: Axis.horizontal,
                                  itemBuilder: (context, index) {
                                    String colorString = '0xff' + widget.product.colors[index].code.substring(1, 7);
                                    return InkWell(
                                      onTap: () {
                                        Provider.of<ProductDetailsProvider>(context, listen: false).setCartVariantIndex(index);
                                      },
                                      child: Container(
                                        decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(Dimensions.PADDING_SIZE_EXTRA_SMALL),
                                            border: details.variantIndex == index ? Border.all(width: 1, color: Theme.of(context).primaryColor):null
                                        ),
                                        child: Padding(padding: const EdgeInsets.all(Dimensions.PADDING_SIZE_EXTRA_SMALL),

                                          child: Container(
                                            height: 30,
                                            width: 30,
                                            padding: EdgeInsets.all( Dimensions.PADDING_SIZE_EXTRA_SMALL),
                                            alignment: Alignment.center,
                                            decoration: BoxDecoration(
                                              color: Color(int.parse(colorString)),
                                              borderRadius: BorderRadius.circular(5),
                                            ),
                                            //child: details.variantIndex == index ? Icon(Icons.done_all, color: ColorResources.WHITE, size: 12) : null,
                                          ),
                                        ),
                                      ),
                                    );
                                  },
                                ),
                              ),
                            ]) : SizedBox(),
                            widget.product.colors.length > 0 ? SizedBox(height: Dimensions.PADDING_SIZE_SMALL) : SizedBox(),


                            // Variation
                            ListView.builder(
                              shrinkWrap: true,
                              itemCount: widget.product.choiceOptions.length,
                              physics: NeverScrollableScrollPhysics(),
                              itemBuilder: (context, index) {
                                return Column(crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Padding(
                                        padding: const EdgeInsets.only(right: 15.0),
                                        child: Container(
                                            width:80,
                                            child: Text('${widget.product.choiceOptions[index].title} : ', style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_DEFAULT))),
                                      ),
                                      SizedBox(width: Dimensions.PADDING_SIZE_EXTRA_SMALL),
                                      Padding(
                                        padding: const EdgeInsets.only(right: 15.0),
                                        child: Container(
                                          width:130,
                                          child: GridView.builder(
                                            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                                              crossAxisCount: 3,
                                              //crossAxisSpacing: 5,
                                             // mainAxisSpacing: 15,
                                              //childAspectRatio: (1.2 / .30),
                                            ),
                                            shrinkWrap: true,
                                            physics: NeverScrollableScrollPhysics(),
                                            itemCount: widget.product.choiceOptions[index].options.length,
                                            itemBuilder: (context, i) {
                                              return InkWell(
                                                onTap: () {
                                                  Provider.of<ProductDetailsProvider>(context, listen: false).setCartVariationIndex(index, i);
                                                },
                                                child: Container(
                                                  //width: 20,
                                                  decoration: BoxDecoration(
                                                    //color:Theme.of(context).primaryColor,
                                                    borderRadius: BorderRadius.circular(8),
                                                    border: Border.all(color:Theme.of(context).primaryColor,),
                                                  ),
                                                  child: Center(
                                                    child: Text(widget.product.choiceOptions[index].options[i], maxLines: 1,
                                                       // overflow: TextOverflow.visible,
                                                        style: titilliumRegular.copyWith(
                                                          fontSize: Dimensions.FONT_SIZE_EXTRA_SMALL,
                                                          color: details.variationIndex[index] != i ? ColorResources.getTextTitle(context) : Theme.of(context).primaryColor,
                                                        )),
                                                  ),
                                                ),
                                              );
                                            },
                                          ),
                                        ),
                                      ),
                                      SizedBox(height: Dimensions.PADDING_SIZE_SMALL),

                                    ]);
                              },
                            ),

                            SizedBox(height: Dimensions.PADDING_SIZE_DEFAULT,),
                            Divider(height: 0, color: Theme.of(context).hintColor),
                            SizedBox(height: Dimensions.PADDING_SIZE_SMALL,),
                            Column(
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    widget.product.discount > 0 ?
                                    Container(
                                      margin: EdgeInsets.only(top: Dimensions.PADDING_SIZE_EXTRA_SMALL),
                                      padding: EdgeInsets.symmetric(horizontal: Dimensions.PADDING_SIZE_EXTRA_SMALL),
                                      alignment: Alignment.center,
                                      decoration: BoxDecoration(
                                        color:Theme.of(context).primaryColor,
                                        borderRadius: BorderRadius.circular(8),
                                      ),
                                      child: Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Text(
                                          PriceConverter.percentageCalculation(context, widget.product.unitPrice,
                                              widget.product.discount, widget.product.discountType),
                                          style: titilliumRegular.copyWith(color: Theme.of(context).cardColor,
                                              fontSize: Dimensions.FONT_SIZE_DEFAULT),
                                        ),
                                      ),
                                    ) : SizedBox(width: 93),
                                    SizedBox(width: Dimensions.PADDING_SIZE_DEFAULT),
                                    widget.product.discount > 0 ? Text(
                                      PriceConverter.convertPrice(context, widget.product.unitPrice),
                                      style: titilliumRegular.copyWith(color: ColorResources.getRed(context),
                                          decoration: TextDecoration.lineThrough),
                                    ) : SizedBox(),
                                    SizedBox(width: Dimensions.PADDING_SIZE_DEFAULT),
                                  ],
                                ),
                                SizedBox(height: Dimensions.PADDING_SIZE_SMALL,),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    // Padding(
                                    //   padding: const EdgeInsets.all(8.0),
                                    //   child: Text("السعر :",
                                    //       style: titilliumRegular.copyWith(
                                    //         fontSize: Dimensions.FONT_SIZE_SMALL,
                                    //         color:  ColorResources.getTextTitle(context),
                                    //       )),
                                    // ),
                                    SizedBox(width: Dimensions.PADDING_SIZE_DEFAULT),
                                    Text(
                                      PriceConverter.convertPrice(context, widget.product.unitPrice, discountType: widget.product.discountType, discount: widget.product.discount),
                                      style: titilliumBold.copyWith(color: Colors.black.withOpacity(0.8), fontSize: Dimensions.FONT_SIZE_LARGE),
                                    ),
                                    SizedBox(width: Dimensions.PADDING_SIZE_DEFAULT),
                                  ],
                                ),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [

                                    Padding(
                                      padding: const EdgeInsets.all(2.0),
                                      child: Text("(",
                                        style: titilliumRegular.copyWith(color: ColorResources.colorPrimaryBlack, fontSize: Dimensions.FONT_SIZE_SMALL),
                                      ),
                                    ),

                                    Text(
                                      '${priceOneDiscount.toString()}  ريال ',
                                      style: titilliumRegular.copyWith(color: ColorResources.colorPrimaryBlack, fontSize: Dimensions.FONT_SIZE_SMALL),
                                    ),

                                    Padding(
                                      padding: const EdgeInsets.all(2.0),
                                      child: Text("للحبه",
                                        style: titilliumRegular.copyWith(color: ColorResources.colorPrimaryBlack, fontSize: Dimensions.FONT_SIZE_SMALL),
                                      ),
                                    ),

                                    Padding(
                                      padding: const EdgeInsets.all(2.0),
                                      child: Text(")",
                                        style: titilliumRegular.copyWith(color: ColorResources.colorPrimaryBlack, fontSize: Dimensions.FONT_SIZE_SMALL),
                                      ),
                                    ),

                                    SizedBox(width: Dimensions.PADDING_SIZE_DEFAULT),
                                  ],
                                ),
                              ],
                            ),
                            // Quantity
                            SizedBox(height: Dimensions.PADDING_SIZE_SMALL),
                            Divider(height: 0, color: Theme.of(context).hintColor),

                          ]);
                        },
                      ),
                    ),
                ],
              ),
                SizedBox(height: Dimensions.PADDING_SIZE_EXTRA_LARGE),

                Container(
                  transform: Matrix4.translationValues(0.0, -25.0, 0.0),
                  padding: EdgeInsets.only(top: Dimensions.FONT_SIZE_DEFAULT),
                  decoration: BoxDecoration(
                    color: Theme.of(context).canvasColor,
                      borderRadius: BorderRadius.only(topLeft:Radius.circular(Dimensions.PADDING_SIZE_EXTRA_LARGE),
                          topRight:Radius.circular(Dimensions.PADDING_SIZE_EXTRA_LARGE) ),
                        ),
                  child: Column(children: [


                    /*
                    // Specification
                    (widget.product.details != null && widget.product.details.isNotEmpty) ? Container(
                      height: 158,
                      margin: EdgeInsets.only(top: Dimensions.PADDING_SIZE_SMALL),
                      padding: EdgeInsets.all(Dimensions.PADDING_SIZE_SMALL),
                      child: ProductSpecification(productSpecification: widget.product.details ?? ''),
                    ) : SizedBox(),




                    //promise
                    Container(padding: EdgeInsets.symmetric(vertical: Dimensions.PADDING_SIZE_DEFAULT,
                      horizontal: Dimensions.FONT_SIZE_DEFAULT),
                          decoration: BoxDecoration(
                        color: Theme.of(context).cardColor
                      ),
                        child: PromiseScreen()),

                    widget.product.addedBy == 'seller' ? SellerView(sellerId: widget.product.userId.toString()) : SizedBox.shrink(),
                    //widget.product.addedBy == 'admin' ? SellerView(sellerId: '0') : SizedBox.shrink(),

                    // Reviews
                    Container(
                      width: MediaQuery.of(context).size.width,
                      margin: EdgeInsets.only(top: Dimensions.PADDING_SIZE_SMALL),
                      padding: EdgeInsets.all(Dimensions.PADDING_SIZE_DEFAULT),
                      color: Theme.of(context).cardColor,
                      child: Column(crossAxisAlignment: CrossAxisAlignment.center, children: [
                        Text(getTranslated('customer_reviews', context),
                          style: titilliumSemiBold.copyWith(fontSize: Dimensions.FONT_SIZE_LARGE),),
                        SizedBox(height: Dimensions.PADDING_SIZE_DEFAULT,),
                        Container(width: 230,height: 30,
                          decoration: BoxDecoration(color: ColorResources.visitShop(context),
                            borderRadius: BorderRadius.circular(Dimensions.PADDING_SIZE_EXTRA_LARGE),
                          ),


                          child: Row(mainAxisAlignment: MainAxisAlignment.center,crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              RatingBar(rating: double.parse(ratting), size: 18,),
                              SizedBox(width: Dimensions.PADDING_SIZE_DEFAULT),
                              Text('${double.parse(ratting).toStringAsFixed(1)}'+ ' '+ '${getTranslated('out_of_5', context)}'),
                            ],
                          ),
                        ),

                        SizedBox(height: Dimensions.PADDING_SIZE_DEFAULT),
                        Text('${getTranslated('total', context)}' + ' '+'${details.reviewList != null ? details.reviewList.length : 0}' +' '+ '${getTranslated('reviews', context)}'),

                        details.reviewList != null ? details.reviewList.length != 0 ? ReviewWidget(reviewModel: details.reviewList[0])
                            : SizedBox() : ReviewShimmer(),
                        details.reviewList != null ? details.reviewList.length > 1 ? ReviewWidget(reviewModel: details.reviewList[1])
                            : SizedBox() : ReviewShimmer(),
                        details.reviewList != null ? details.reviewList.length > 2 ? ReviewWidget(reviewModel: details.reviewList[2])
                            : SizedBox() : ReviewShimmer(),

                        InkWell(
                            onTap: () {
                              if(details.reviewList != null)
                              {Navigator.push(context, MaterialPageRoute(builder: (_) =>
                                  ReviewScreen(reviewList: details.reviewList)));}},
                            child: details.reviewList != null && details.reviewList.length > 3?
                            Text(getTranslated('view_more', context),
                              style: titilliumRegular.copyWith(color: Theme.of(context).primaryColor),):SizedBox())



                      ]),
                    ),

                    //saller more product
                    widget.product.addedBy == 'seller' ?
                    Padding(
                      padding: EdgeInsets.all(Dimensions.PADDING_SIZE_DEFAULT),
                      child: TitleRow(title: getTranslated('more_from_the_shop', context), isDetailsPage: true),
                    ):SizedBox(),

                    widget.product.addedBy == 'seller' ?
                    Padding(
                      padding: EdgeInsets.all(Dimensions.PADDING_SIZE_EXTRA_SMALL),
                      child: ProductView(isHomePage: false, productType: ProductType.SELLER_PRODUCT, scrollController: _scrollController, sellerId: widget.product.userId.toString()),
                    ):SizedBox(),

 */
                    // Related Products
                    // Container(
                    //   margin: EdgeInsets.only(top: Dimensions.PADDING_SIZE_SMALL),
                    //   padding: EdgeInsets.all(Dimensions.PADDING_SIZE_DEFAULT),
                    //   child: Column(
                    //     children: [
                    //       Padding(
                    //         padding: const EdgeInsets.symmetric(horizontal: Dimensions.PADDING_SIZE_EXTRA_SMALL,vertical: Dimensions.PADDING_SIZE_EXTRA_SMALL),
                    //         child: TitleRow2(title: getTranslated('mark_products', context), isDetailsPage: true),
                    //
                    //       ),
                    //       SizedBox(height: 0),
                    //       BrandProductTowView(scrollController: _scrollController,brandId: widget.product.brandId),
                    //     ],
                    //   ),
                    // ),

                    //Related Products
                    Container(
                      margin: EdgeInsets.only(top: Dimensions.PADDING_SIZE_SMALL),
                      padding: EdgeInsets.all(Dimensions.PADDING_SIZE_DEFAULT),
                      child: Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: Dimensions.PADDING_SIZE_EXTRA_SMALL,vertical: Dimensions.PADDING_SIZE_EXTRA_SMALL),
                            child: TitleRow2(title: "منتجات من نفس القسم",

                                style: titilliumBold.copyWith(
                                  fontSize: Dimensions.FONT_SIZE_SMALL,
                                  color: ColorResources.getTextTitle(context).withOpacity(0.9),),
                                isDetailsPage: true),
                          ),
                          SizedBox(height: 5),
                          Padding(
                            padding: const EdgeInsets.only(bottom: Dimensions.PADDING_SIZE_DEFAULT),
                            child: BrandProductView(scrollController: _scrollController),
                          ),
                        ],
                      ),
                    ),


                    // // Related Products
                    // Container(
                    //   margin: EdgeInsets.only(top: Dimensions.PADDING_SIZE_SMALL),
                    //   padding: EdgeInsets.all(Dimensions.PADDING_SIZE_DEFAULT),
                    //   child: Column(
                    //     children: [
                    //       Padding(
                    //         padding: const EdgeInsets.symmetric(horizontal: Dimensions.PADDING_SIZE_EXTRA_SMALL,vertical: Dimensions.PADDING_SIZE_EXTRA_SMALL),
                    //         child: TitleRow2(
                    //
                    //             style: titilliumBold.copyWith(
                    //               fontSize: Dimensions.FONT_SIZE_SMALL,
                    //               color: ColorResources.getTextTitle(context).withOpacity(0.9),),
                    //             title: getTranslated('related_products', context), isDetailsPage: true),
                    //       ),
                    //       SizedBox(height: 5),
                    //       RelatedProductView(),
                    //     ],
                    //   ),
                    // ),




                ],),),
              ],
            ),
          ),
        ) : Scaffold(body: NoInternetOrDataScreen(isNoInternet: true, child: ProductDetails(product: widget.product)));
      },
    );
  }
}


class QuantityButton extends StatelessWidget {
  final bool isIncrement;
  final int quantity;
  final bool isCartWidget;
  final int stock;

  QuantityButton({
    @required this.isIncrement,
    @required this.quantity,
    @required this.stock,
    this.isCartWidget = false,
  });

  @override
  Widget build(BuildContext context) {
    return IconButton(
      onPressed: () {
        print("preesed");
        if (!isIncrement && quantity > 1) {
          print("preesed 1");


          Provider.of<ProductDetailsProvider>(context, listen: false).setQuantity(quantity - 1);
        } else if (isIncrement && quantity < stock) {
          print("preesed 2");


          Provider.of<ProductDetailsProvider>(context, listen: false).setQuantity(quantity + 1);
        }
      },
      icon: Icon(
        isIncrement ? Icons.add : Icons.remove,
        color: isIncrement
            ? quantity >= stock ? ColorResources.colorPrimaryBlack : ColorResources.colorPrimaryBlack
            : quantity > 1
            ? ColorResources.colorPrimaryBlack
            : ColorResources.getTextTitle(context),
        size: isCartWidget?26:20,
      ),
    );
  }
}