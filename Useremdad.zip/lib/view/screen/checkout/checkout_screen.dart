import 'package:cached_network_image/cached_network_image.dart';
import 'package:emdad/main.dart';
import 'package:emdad/view/screen/checkout/widget/TimeDeliveryBottomSheet.dart';
import 'package:emdad/view/screen/checkout/widget/cargo_Widget.dart';
import 'package:emdad/view/screen/checkout/widget/customRadioButton.dart';
import 'package:emdad/view/screen/checkout/widget/customRadioButtonProduct.dart';
import 'package:emdad/view/screen/checkout/widget/custom_check_box_product.dart';
import 'package:emdad/view/screen/checkout/widget/done_payment_bottomsheet.dart';
import 'package:emdad/view/screen/checkout/widget/taxfield.dart';
import 'package:emdad/view/screen/checkout/widget/taxnuberConfirmationDialog.dart';
import 'package:emdad/view/screen/payment/payment_screen.dart';
import 'package:emdad/view/screen/tread_info/steppers_dots.dart';
import 'package:emdad/view/screen/wallet/wallet_screen.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:emdad/data/model/response/cart_model.dart';
import 'package:emdad/helper/price_converter.dart';
import 'package:emdad/localization/language_constrants.dart';
import 'package:emdad/provider/cart_provider.dart';
import 'package:emdad/provider/coupon_provider.dart';
import 'package:emdad/provider/order_provider.dart';
import 'package:emdad/provider/product_provider.dart';
import 'package:emdad/provider/profile_provider.dart';
import 'package:emdad/provider/splash_provider.dart';
import 'package:emdad/utility/color_resources.dart';
import 'package:emdad/utility/custom_themes.dart';
import 'package:emdad/utility/dimensions.dart';
import 'package:emdad/utility/images.dart';
import 'package:emdad/view/basewidget/amount_widget.dart';
import 'package:emdad/view/basewidget/animated_custom_dialog.dart';
import 'package:emdad/view/basewidget/custom_app_bar.dart';
import 'package:emdad/view/basewidget/my_dialog.dart';
import 'package:emdad/view/basewidget/textfield/custom_textfield.dart';
import 'package:emdad/view/screen/address/saved_address_list_screen.dart';
import 'package:emdad/view/screen/address/saved_billing_Address_list_screen.dart';
import 'package:emdad/view/screen/checkout/widget/custom_check_box.dart';
import 'package:emdad/view/screen/dashboard/dashboard_screen.dart';
import 'package:provider/provider.dart';
import 'package:emdad/data/model/body/order_place_model.dart';

import '../../../data/model/response/order_details.dart';
import '../../../provider/auth_provider.dart';
import '../../../provider/seller_provider.dart';
import '../../../provider/theme_provider.dart';
import '../../basewidget/shimmer_loading.dart';
import '../cart/widget/cartDetailsWidget.dart';
import '../cart/widget/cartPaymentWidget.dart';
import '../cart/widget/cart_widget.dart';
import '../chat/chat_screen.dart';

class CheckoutScreen extends StatefulWidget {
  final List<CartModel> cartList;
  final bool fromProductDetails;
  final double amount;
  final double shippingAmount;
  final double discount;
  final double tax;
  final int sellerId;
  List<String> sellerList;
  final bool fromCheckout;
  List<List<CartModel>> cartProductList;
  List<List<int>> cartProductIndexList ;
  List<CartModel> sellerGroupList ;



  CheckoutScreen({
    @required this.sellerList,
    @required this.cartProductList,

    @required this.fromCheckout,
    @required this.cartProductIndexList,

    @required this.sellerGroupList,



    @required this.cartList, this.fromProductDetails = false, @required this.discount, @required this.tax, @required this.amount, @required this.shippingAmount, this.sellerId});


  @override
  _CheckoutScreenState createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {

  bool isGuestMode;
  final GlobalKey<ScaffoldMessengerState> _scaffoldKey = GlobalKey<ScaffoldMessengerState>();
  final TextEditingController _controller = TextEditingController();
  final TextEditingController _orderNoteController = TextEditingController();

  final FocusNode _orderNoteNode = FocusNode();
  double _order = 0;
  double _orderCheckDouble = 0;
  double _minOrder = 50.000;
  String _orderCheck;
  bool _digitalPayment;
  bool _cod;
  bool _inFound;
  bool _cancelProduct;
  bool _billingAddress;
  bool _phoneverify;
  bool _switchValue=true;
  bool raqmy=false;
  @override
  void initState() {
    super.initState();
    isGuestMode = !Provider.of<AuthProvider>(context, listen: false).isLoggedIn();
    Provider.of<ProfileProvider>(context, listen: false).initAddressList(context);
    Provider.of<ProfileProvider>(context, listen: false).initAddressTypeList(context);
    Provider.of<CouponProvider>(context, listen: false).removePrevCouponData();
    Provider.of<CartProvider>(context, listen: false).getCartDataAPI(context);
    Provider.of<CartProvider>(context, listen: false).getChosenShippingMethod(context);
    Provider.of<ProfileProvider>(context, listen: false).getUserInfo(context);
    _digitalPayment = Provider.of<SplashProvider>(context, listen: false).configModel.digitalPayment;
    _cod = Provider.of<SplashProvider>(context, listen: false).configModel.cod;
    _inFound = Provider.of<SplashProvider>(context, listen: false).configModel.cod;
    _cancelProduct = true;
    _billingAddress = Provider.of<SplashProvider>(context, listen: false).configModel.billingAddress == 1;
    synAddress();
    //
    // Provider.of<OrderProvider>(context, listen: false).shippingAddressNull();
    // Provider.of<OrderProvider>(context, listen: false).billingAddressNull();
  }

  synAddress () async {
    if(Provider.of<ProfileProvider>(context, listen: false).addressList != null)
    {
      Provider.of<OrderProvider>(context, listen: false).setAddressIndex(0);
    }
  }
  final TextEditingController _taxController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    _order = widget.amount+widget.discount;
    _orderCheck = widget.amount.toStringAsFixed(3);
    _orderCheckDouble = double.parse(_orderCheck);
    return Scaffold(
      appBar: AppBar(
        backgroundColor:Color(0xfff2f2f2),
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios, size: 20, color: Colors.black),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(
          "الدفع",
          style: titilliumRegular.copyWith(
            fontSize: 17,
            color: Provider.of<ThemeProvider>(context).darkTheme
                ? Colors.white
                : Colors.black,
          ),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(left: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Container(
                  width: 100,
                  height: 30,
                  // color: Colors.grey,
                  decoration: BoxDecoration(
                      color: Color(0xfff2f2f2),
                      border: Border.all(
                        color: Color(0xfff2f2f2),
                      ),
                      borderRadius: BorderRadius.all(Radius.circular(20))),

                  child: Center(
                    child: Text(
                      "تحتاج مساعده؟",
                      style: titilliumsemiBold.copyWith(
                        fontSize: 10,
                        color: Colors.black,
                      ),
                    ),
                  ),
                )
                // IconButton(
                //   icon: Icon(
                //     Icons.search,
                //     color: Palette.loginhead,
                //   ),
                //   onPressed: () {
                //     Navigator.push(
                //         context,
                //         MaterialPageRoute(
                //             builder: (context) => SearchScreen()));
                //   },
                // ),
              ],
            ),
          )
        ],
      ),

      resizeToAvoidBottomInset: true,
      key: _scaffoldKey,
      // bottomNavigationBar: Container(
      //   height: 60,
      //   padding: EdgeInsets.symmetric(horizontal: Dimensions.PADDING_SIZE_LARGE, vertical: Dimensions.PADDING_SIZE_DEFAULT),
      //   decoration: BoxDecoration(
      //     color: ColorResources.getPrimary(context),
      //    ),
      //   child: Center(
      //     child: Consumer<OrderProvider>(
      //       builder: (context, order, child) {
      //       return !Provider.of<OrderProvider>(context).isLoading ? Builder(
      //         builder: (context) => InkWell(
      //           onTap: () async {
      //             print("_order: $_order");
      //             print("_orderCheck: $_orderCheck");
      //             print("_orderCheckDouble: $_orderCheckDouble");
      //
      //             if(Provider.of<OrderProvider>(context, listen: false).addressIndex == null) {
      //               ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(getTranslated('select_a_shipping_address', context)), backgroundColor: Colors.red));
      //             } else if(Provider.of<OrderProvider>(context, listen: false).billingAddressIndex == null && _billingAddress){
      //               ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(getTranslated('select_a_billing_address', context)), backgroundColor: Colors.red));
      //             } else if(Provider.of<ProfileProvider>(context, listen: false).userInfoModel.isDoc == 0 && Provider.of<ProfileProvider>(context, listen: false).userInfoModel.isDocReq == 0) {
      //               await showModalBottomSheet(
      //                 context: context, isScrollControlled: true, backgroundColor: Colors.transparent,
      //                 builder: (context) => CustomStepper(),
      //               );
      //             } else if(_orderCheckDouble < _minOrder) {
      //               ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("يجب ان يكون الطلب اكثر من  50  الف ريال"), backgroundColor: ColorResources.primaryColor));
      //             }  else if(Provider.of<OrderProvider>(context, listen: false).timeDeliveryIndex == 0) {
      //               await showModalBottomSheet(
      //                 context: context, isScrollControlled: true, backgroundColor: Colors.transparent,
      //                 builder: (context) => TimeDeliveryBottomSheet(groupId: 'all_cart_group',sellerIndex: 0, sellerId: 1),
      //               );
      //             } else {
      //               List<CartModel> _cartList = [];
      //               _cartList.addAll(widget.cartList);
      //               for(int index=0; index<widget.cartList.length; index++) {
      //                 for(int i=0; i<Provider.of<CartProvider>(context, listen: false).chosenShippingList.length; i++) {
      //                   if(Provider.of<CartProvider>(context, listen: false).chosenShippingList[i].cartGroupId == widget.cartList[index].cartGroupId) {
      //                     _cartList[index].shippingMethodId = Provider.of<CartProvider>(context, listen: false).chosenShippingList[i].id;
      //                     break;
      //                   }
      //                 }
      //               }
      //               String orderNote = _orderNoteController.text.trim();
      //               double couponDiscount = Provider.of<CouponProvider>(context, listen: false).discount != null ? Provider.of<CouponProvider>(context, listen: false).discount : 0;
      //               String couponCode = Provider.of<CouponProvider>(context, listen: false).discount != null ? Provider.of<CouponProvider>(context, listen: false).coupon.code : '';
      //               if(_cod && Provider.of<OrderProvider>(context, listen: false).paymentMethodIndex == 0) {
      //
      //                 Provider.of<OrderProvider>(context, listen: false).placeOrder(OrderPlaceModel(
      //                   CustomerInfo(
      //                     Provider.of<ProfileProvider>(context, listen: false).addressList[Provider.of<OrderProvider>(context, listen: false).addressIndex].id.toString(),
      //                     Provider.of<ProfileProvider>(context, listen: false).addressList[Provider.of<OrderProvider>(context, listen: false).addressIndex].address,
      //                     _billingAddress? Provider.of<ProfileProvider>(context, listen: false).billingAddressList[Provider.of<OrderProvider>(context, listen: false).billingAddressIndex].id.toString():
      //                     Provider.of<ProfileProvider>(context, listen: false).addressList[Provider.of<OrderProvider>(context, listen: false).addressIndex].id.toString(),
      //                     _billingAddress? Provider.of<ProfileProvider>(context, listen: false).billingAddressList[Provider.of<OrderProvider>(context, listen: false).billingAddressIndex].address:
      //                     Provider.of<ProfileProvider>(context, listen: false).addressList[Provider.of<OrderProvider>(context, listen: false).addressIndex].address,
      //                     orderNote,
      //                   ),
      //                   _cartList,
      //                   order.paymentMethodIndex == 0 ? 'cash_on_delivery' : '',
      //                   couponDiscount,
      //                   Provider.of<OrderProvider>(context, listen: false).timeDeliveryData,
      //                   Provider.of<OrderProvider>(context, listen: false).timeDeliveryData,
      //                 ),
      //
      //                 _callback,
      //                 _cartList,
      //                 Provider.of<ProfileProvider>(context, listen: false).addressList[Provider.of<OrderProvider>(context, listen: false).addressIndex].id.toString(),
      //                 couponCode,
      //                 _billingAddress? Provider.of<ProfileProvider>(context, listen: false).billingAddressList[Provider.of<OrderProvider>(context, listen: false).billingAddressIndex].id.toString():
      //                 Provider.of<ProfileProvider>(context, listen: false).addressList[Provider.of<OrderProvider>(context, listen: false).addressIndex].id.toString(),
      //                 orderNote );
      //                 Provider.of<OrderProvider>(context, listen: false).clearDeliveryTime();
      //               }
      //               else {
      //                 String userID = await Provider.of<ProfileProvider>(context, listen: false).getUserInfo(context);
      //                 Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => PaymentScreen(
      //                   customerID: userID,
      //                   addressID: Provider.of<ProfileProvider>(context, listen: false).addressList[Provider.of<OrderProvider>(context, listen: false).addressIndex].id.toString(),
      //                   couponCode: Provider.of<CouponProvider>(context, listen: false).discount != null ? Provider.of<CouponProvider>(context, listen: false).coupon.code : '',
      //                   billingId: _billingAddress? Provider.of<ProfileProvider>(context, listen: false).billingAddressList[Provider.of<OrderProvider>(context, listen: false).billingAddressIndex].id.toString():
      //                   Provider.of<ProfileProvider>(context, listen: false).addressList[Provider.of<OrderProvider>(context, listen: false).addressIndex].id.toString(),
      //                   orderNote: orderNote,
      //                 )));
      //               }
      //             }
      //           },
      //
      //           child: Text(getTranslated('proceed', context), style: titilliumSemiBold.copyWith(
      //             fontSize: Dimensions.FONT_SIZE_EXTRA_LARGE,
      //             color: Theme.of(context).cardColor,
      //           )),
      //         ),
      //       ) : Container(
      //         height: 30,width: 30 ,alignment: Alignment.center,
      //         child: CircularProgressIndicator(valueColor: AlwaysStoppedAnimation<Color>(Theme.of(context).highlightColor)),
      //       );
      //       },
      //     ),
      //   ),
      // ),

      body: SingleChildScrollView(
        physics: ScrollPhysics(),
        child: Container(
          width: double.infinity,
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Stack(
              children:[ Column(
                // mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,

              children: [

                //CustomAppBar(title: getTranslated('checkout', context)),
                Text("معلومات الفاتوره",style: titilliumRegular.copyWith(color: Colors.black,fontSize: 16),),
                Text("اسم المنشأه",style: titilliumsemiBold.copyWith(color: Theme.of(context).primaryColor),),
                Row(
                  children: [
                    Consumer<ProfileProvider>(
                      builder: (context, profile, child) {
                        return Row(children: [
                          Text(!isGuestMode ? profile.userInfoModel != null ? '${profile.userInfoModel.fName}' : 'Full Name' : 'Guest',
                              style: titilliumRegular.copyWith(color: ColorResources.COLOR_BLACK
                                ,fontSize: Dimensions.FONT_SIZE_DEFAULT,

                              )),

                        ],);},),
                    SizedBox(width: 18,),
                    CircleAvatar(
                      radius: 10,
                      backgroundColor: Colors.grey.withOpacity(0.1),
                      child: Image.asset("assets/images/address.png",color:Colors.grey.withOpacity(0.8),
                        width: 15,height: 15,),

                    )
                  ],
                ),
                SizedBox(height: 10,),
                // InkWell(
                //   onTap: (){
                //     //showAnimatedDialog(context, QuantityConfirmationDialog(quantityItem:widget.cartModel.quantity.toString(), index: widget.index, isIncrement: true, quantity: widget.cartModel.quantity, maxQty: 20, cartModel: widget.cartModel),  isFlip: true);
                //
                //     showAnimatedDialog(context, taxnumberConfirmationDialog(),isFlip: true);
                //   },
                //   child: Container(
                //
                //       height: 40,
                //
                //       decoration: BoxDecoration(
                //         color: Colors.grey.withOpacity(0.1),
                //         borderRadius: BorderRadius.circular(30),
                //         border: Border.all(width: .4,color: Colors.grey.withOpacity(0.3)),
                //         // boxShadow: [BoxShadow(color: Colors.grey, spreadRadius: 1, blurRadius: 1)],
                //       ),
                //       alignment: Alignment.centerLeft,
                //       padding: EdgeInsets.symmetric(horizontal: 5),
                //       child: TextField(
                //
                //         enabled: false,
                //         controller: _taxController,
                //         textAlign: TextAlign.start,
                //         style: TextStyle(
                //           fontSize: 20.0,
                //         ),
                //
                //         keyboardType: TextInputType.number,
                //         maxLines: 1,
                //         decoration: InputDecoration(
                //
                //           hintText:"رقم التسجيل ضريبه القيمه المضافه",
                //           hintStyle: titilliumRegular.copyWith(color: Colors.grey.withOpacity(0.9), fontSize: 13),
                //           border: InputBorder.none,
                //         ),
                //       )
                //   ),
                // ),
               //
               //  taxField(taxController: _taxController),
               //  SizedBox(height: 10,),
               //  Container(
               //    width: double.infinity,
               //   // margin: EdgeInsets.only(right: 8),
               //    child: Row(
               //      //mainAxisSize: MainAxisSize.min,
               //      mainAxisAlignment: MainAxisAlignment.spaceAround,
               //    // mainAxisSize: MainAxisSize.min,
               //     children: [
               //
               //       Expanded(
               //         flex:2,
               //         child: Text("هل انت مسجل في ضريبه القيمه المضافه ؟",style: titilliumvBold.copyWith(fontSize: 13),
               //
               //         ),
               //       ),
               //
               //       Transform.scale(
               //        scale: 0.8,
               //         child: CupertinoSwitch(
               //
               //           thumbColor: Colors.grey,
               //           activeColor: Theme.of(context).primaryColor,
               //
               //           value: _switchValue,
               //           onChanged: (value) {
               //             setState(() {
               //               _switchValue = value;
               //             });
               //           },
               //         ),
               //       ),
               //
               //     ],
               // ),
               //  ),
                Padding(
                  padding: const EdgeInsets.all(0),
                  child: Container(width: double.infinity,height: 1,color: Colors.grey.withOpacity(0.3),),
                ),

                // Column( children: [
                //   // Shipping Details
                //   // Consumer<OrderProvider>(
                //   //   builder: (context, shipping,_) {
                //   //     return Container(
                //   //       padding: EdgeInsets.all(Dimensions.PADDING_SIZE_SMALL),
                //   //       child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                //   //           children: [
                //   //             Card(
                //   //               child: Container(
                //   //                 padding: EdgeInsets.all(Dimensions.PADDING_SIZE_DEFAULT),
                //   //                 decoration: BoxDecoration(
                //   //                   borderRadius: BorderRadius.circular(Dimensions.PADDING_SIZE_DEFAULT),
                //   //                   color: Theme.of(context).cardColor,
                //   //                 ),
                //   //                 child: Column(crossAxisAlignment:CrossAxisAlignment.start,
                //   //                   children: [
                //   //                     Row(mainAxisAlignment:MainAxisAlignment.start, crossAxisAlignment:CrossAxisAlignment.start,
                //   //                       children: [
                //   //                         Expanded(child: Text('${getTranslated('shipping_address', context)}',
                //   //                             style: titilliumRegular.copyWith(fontWeight: FontWeight.w600))),
                //   //
                //   //                         InkWell(
                //   //                           onTap: () => Navigator.of(context).push(
                //   //                               MaterialPageRoute(builder: (BuildContext context) => SavedAddressListScreen())),
                //   //                           child: Image.asset(Images.address, scale: 3),
                //   //                         ),
                //   //                       ],
                //   //                     ),
                //   //                     SizedBox(height: Dimensions.PADDING_SIZE_DEFAULT,),
                //   //
                //   //                     Column(crossAxisAlignment: CrossAxisAlignment.start,
                //   //                       children: [
                //   //                         Container(
                //   //                           child: Text(
                //   //                             Provider.of<OrderProvider>(context,listen: false).addressIndex == null
                //   //                                 ? '${getTranslated('address_type', context)}'
                //   //                                 : Provider.of<ProfileProvider>(context, listen: false).addressList[
                //   //                             Provider.of<OrderProvider>(context, listen: false).addressIndex].addressType,
                //   //                             style: titilliumBold.copyWith(fontSize: Dimensions.FONT_SIZE_LARGE),
                //   //                             maxLines: 3, overflow: TextOverflow.fade,
                //   //                           ),
                //   //                         ),
                //   //                         Divider(),
                //   //                         Container(
                //   //                           child: Text(
                //   //                             Provider.of<OrderProvider>(context,listen: false).addressIndex == null ?
                //   //                             getTranslated('add_your_address', context)
                //   //                                 : Provider.of<ProfileProvider>(context, listen: false).addressList[
                //   //                                   shipping.addressIndex].address,
                //   //                             style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_SMALL),
                //   //                             maxLines: 3, overflow: TextOverflow.fade,
                //   //                           ),
                //   //                         ),
                //   //                       ],
                //   //                     ),
                //   //                   ],
                //   //                 ),
                //   //               ),
                //   //             ),
                //   //
                //   //             SizedBox(height: Dimensions.PADDING_SIZE_SMALL,),
                //   //             _billingAddress ?
                //   //             Card(
                //   //               child: Container(
                //   //                 padding: EdgeInsets.all(Dimensions.PADDING_SIZE_DEFAULT),
                //   //                 decoration: BoxDecoration(
                //   //                   borderRadius: BorderRadius.circular(Dimensions.PADDING_SIZE_DEFAULT),
                //   //                   color: Theme.of(context).cardColor,
                //   //                 ),
                //   //                 child: Column(crossAxisAlignment:CrossAxisAlignment.start,
                //   //                   children: [
                //   //                     Row(mainAxisAlignment:MainAxisAlignment.start, crossAxisAlignment:CrossAxisAlignment.start,
                //   //                       children: [
                //   //                         Expanded(child: Text('${getTranslated('billing_address', context)}',
                //   //                             style: titilliumRegular.copyWith(fontWeight: FontWeight.w600))),
                //   //                         InkWell(
                //   //                           onTap: () => Navigator.of(context).push(MaterialPageRoute(
                //   //                               builder: (BuildContext context) => SavedBillingAddressListScreen())),
                //   //                           child: Image.asset(Images.address, scale: 3),
                //   //                         ),
                //   //                       ],
                //   //                     ),
                //   //                     SizedBox(height: Dimensions.PADDING_SIZE_DEFAULT,),
                //   //                     Column(crossAxisAlignment: CrossAxisAlignment.start,
                //   //                       children: [
                //   //                         Container(
                //   //                           child: Text(
                //   //                             Provider.of<OrderProvider>(context).billingAddressIndex == null ? '${getTranslated('address_type', context)}'
                //   //                                 : Provider.of<ProfileProvider>(context, listen: false).billingAddressList[
                //   //                             Provider.of<OrderProvider>(context, listen: false).billingAddressIndex].addressType,
                //   //                             style: titilliumBold.copyWith(fontSize: Dimensions.FONT_SIZE_LARGE),
                //   //                             maxLines: 1, overflow: TextOverflow.fade,
                //   //                           ),
                //   //                         ),
                //   //                         Divider(),
                //   //                         Container(
                //   //                           child: Text(
                //   //                             Provider.of<OrderProvider>(context).billingAddressIndex == null ? getTranslated('add_your_address', context)
                //   //                                 : Provider.of<ProfileProvider>(context, listen: false).billingAddressList[
                //   //                                   shipping.billingAddressIndex].address,
                //   //                             style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_SMALL),
                //   //                             maxLines: 3, overflow: TextOverflow.fade,
                //   //                           ),
                //   //                         ),
                //   //                       ],
                //   //                     ),
                //   //                   ],
                //   //                 ),
                //   //               ),
                //   //             ):SizedBox(),
                //   //       ]),
                //   //     );
                //   //   }
                //   // ),
                //   // Payment Method
                //   //طريقه الدفع
                 Text('وسيله الدفع', style: titilliumvBold.copyWith(fontSize: Dimensions.FONT_SIZE_SMALL),),


                 SizedBox(height: Dimensions.FONT_SIZE_SMALL),
                Column(children: [
                  _cod? Container(
                    padding: EdgeInsets.only(right: 5),
                  height: 35,
                decoration: BoxDecoration(
                  color:Theme.of(context).primaryColor.withOpacity(0.03),
                border: Border.all(
                color: Theme.of(context).primaryColor.withOpacity(0.5),
                ),
              borderRadius: BorderRadius.all(Radius.circular(5))),
                    child: Row(
                      children: [
                        customRadioButton(index: 0,),
                        SizedBox(width: 5,),
                        Text('نقدا')
                      ],
                    ),
                  ): SizedBox(),
                  _digitalPayment&&_cod ?
                  SizedBox(height: 5,):SizedBox(),
                  //Text(getTranslated('payment_method', context), style: titilliumSemiBold.copyWith(fontSize: Dimensions.FONT_SIZE_LARGE),),
                  _digitalPayment ?
                  Container(

                    height: 35,
                    padding: EdgeInsets.only(right: 5),
                    decoration: BoxDecoration(
                        color:Theme.of(context).primaryColor.withOpacity(0.03),
                        border: Border.all(
                          color: Theme.of(context).primaryColor.withOpacity(0.5),
                        ),
                        borderRadius: BorderRadius.all(Radius.circular(5))),
                    child:
                     Row(children:[customRadioButton(index:

                      !_cod ? 0 : 1,),
                        SizedBox(width: 5,),

                        Text('رقميا')]
                    )
                  )
                  : SizedBox(),

]),
                  SizedBox(height: 10,),
                  // Order Details
                  Text("الشحنات", style: titilliumvBold.copyWith(fontSize:  Dimensions.FONT_SIZE_SMALL),),

                // Consumer<OrderProvider>(
                //   builder: (context, order, child) {
                //     List<int> sellerList = [];
                //     List<List<OrderDetailsModel>> sellerProductList = [];
                //     double _order = 0;
                //     double _discount = 0;
                //     double eeDiscount = 0;
                //     double _tax = 0;
                //
                //     double _shippingFee = 0;
                //
                //     if (order.orderDetails != null) {
                //       order.orderDetails.forEach((orderDetails) {
                //         if (!sellerList
                //             .contains(orderDetails.productDetails.userId)) {
                //           sellerList.add(orderDetails.productDetails.userId);
                //         }
                //       });
                //       sellerList.forEach((seller) {
                //         Provider.of<SellerProvider>(context, listen: false)
                //             .initSeller(seller.toString(), context);
                //         List<OrderDetailsModel> orderList = [];
                //         order.orderDetails.forEach((orderDetails) {
                //           if (seller == orderDetails.productDetails.userId) {
                //             orderList.add(orderDetails);
                //           }
                //         });
                //         sellerProductList.add(orderList);
                //       });
                //
                //       order.orderDetails.forEach((orderDetails) {
                //         _order = _order + (orderDetails.price * orderDetails.qty);
                //         _discount = _discount + orderDetails.discount;
                //         _tax = _tax + orderDetails.tax;
                //       });
                //
                //
                //
                //
                //     }
                //
                //     if (order.orderDetails != null) {
                //       int length=0;
                //       for(int i=0 ;i <  sellerList.length ; i++  ){
                //
                //         length += sellerProductList[i].length ;
                //         print("asdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddsddddddddddddddddddddddddddd");
                //         print(length);
                //       }
                //       return Container(
                //         height: 400,
                //         child: ListView(
                //           physics: BouncingScrollPhysics(),
                //           padding: EdgeInsets.all(0),
                //           children: [
                //             SizedBox(height: Dimensions.PADDING_SIZE_DEFAULT,),
                //             Container(
                //               //margin: EdgeInsets.symmetric(
                //               //vertical: Dimensions.PADDING_SIZE_DEFAULT,
                //               // horizontal: Dimensions.PADDING_SIZE_SMALL
                //               //),
                //               child: Column(
                //                 children: [
                //
                //
                //
                //
                //             ListView.builder(
                //               itemCount: sellerList.length,
                //               physics: NeverScrollableScrollPhysics(),
                //               padding: EdgeInsets.all(0),
                //               shrinkWrap: true,
                //               itemBuilder: (context, index) {
                //     return Container(
                //     padding: EdgeInsets.symmetric(
                //     horizontal: Dimensions.MARGIN_SIZE_EXTRA_LARGE),
                //     color: Theme.of(context).highlightColor,
                //     child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                //     children: [
                //     InkWell(
                //     onTap: () {
                //     if (Provider.of<SellerProvider>(context, listen: false).orderSellerList.length != 0 && sellerList[index] != 1) {
                //     // Navigator.push(context,
                //     // MaterialPageRoute(builder: (_) {
                //     // return SellerScreen(seller: Provider.of<SellerProvider>(context, listen: false).orderSellerList[index]);}));
                //     }
                //     },
                //
                //     child: sellerList[index] == 1? SizedBox():
                //     InkWell(
                //     onTap: (){
                //     Navigator.push(context, MaterialPageRoute(builder: (_) => ChatScreen(
                //     seller: Provider.of<SellerProvider>(context).orderSellerList[index],
                //     shopId:Provider.of<SellerProvider>(context).orderSellerList[index].seller.shop.id,
                //     shopName:Provider.of<SellerProvider>(context).orderSellerList[index].seller.shop.name,
                //     image: Provider.of<SellerProvider>(context).orderSellerList[index].seller.image )));
                //
                //     },
                //     child: Row(children: [
                //     Expanded(
                //     child: Text(getTranslated('seller', context),
                //
                //
                //     style: titilliumsemiBold.copyWith(color: ColorResources.HINT_TEXT_COLOR),
                //
                //
                //     )),
                //     Text(
                //     sellerList[index] == 1 ? 'Admin'
                //           : Provider.of<SellerProvider>(context).orderSellerList.length < index + 1
                //     ? sellerList[index].toString()
                //           : '${Provider.of<SellerProvider>(context).orderSellerList[index].seller.fName} '
                //     '${Provider.of<SellerProvider>(context).orderSellerList[index].seller.lName}',
                //     style: titilliumsemiBold.copyWith(color: ColorResources.HINT_TEXT_COLOR),
                //     ),
                //     SizedBox(width: Dimensions.PADDING_SIZE_EXTRA_SMALL),
                //     Icon(Icons.gamepad_outlined, color: Theme.of(context).primaryColor, size: 20),
                //     ]),
                //     ),
                //     ),
                //     // Text(getTranslated('ORDERED_PRODUCT', context), style: robotoBold.copyWith(color: ColorResources.HINT_TEXT_COLOR)),
                //     Divider(),
                //
                //
                //     // child: Row(
                //     //   children: [
                //     //     Expanded(
                //     //       child: widget.orderModel != null &&  widget.orderModel.orderStatus =='pending' && widget.orderType != "POS"?
                //     //       // CustomButton(
                //     //       //     buttonText: getTranslated('cancel_order', context),
                //     //       //     onTap: () => Provider.of<OrderProvider>(context,listen: false).cancelOrder(context, widget.orderId).then((value) {
                //     //       //       if(value.response.statusCode == 200){
                //     //       //         Provider.of<OrderProvider>(context, listen: false).initOrderList(context);
                //     //       //         Navigator.pop(context);
                //     //       //         ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                //     //       //           content: Text(getTranslated('order_cancelled_successfully', context)),
                //     //       //           backgroundColor: Colors.green,
                //     //       //         ));
                //     //       //
                //     //       //       }
                //     //       //     })
                //     //       // )
                //     //       SizedBox(width:0)
                //     //           :CustomButton(
                //     //         buttonText: getTranslated('TRACK_ORDER', context),
                //     //         onTap: () => Navigator.of(context).push(
                //     //             MaterialPageRoute(builder: (context) => TrackingScreen(orderID: widget.orderId.toString()))),
                //     //       ),
                //     //     ),
                //     //     SizedBox(width: Dimensions.PADDING_SIZE_SMALL),
                //     //     Expanded(
                //     //       child: SizedBox(
                //     //         height: 40,
                //     //         child: TextButton(
                //     //           onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SupportTicketScreen())),
                //     //           child: Text(
                //     //             getTranslated('SUPPORT_CENTER', context), style: titilliumSemiBold.copyWith(fontSize: 14, color: ColorResources.getPrimary(context)),
                //     //           ),
                //     //           style: TextButton.styleFrom(shape: RoundedRectangleBorder(
                //     //             borderRadius: BorderRadius.circular(6),
                //     //             side: BorderSide(color: ColorResources.getPrimary(context)),
                //     //           )),
                //     //         ),
                //     //       ),
                //     //     ),
                //     //   ],
                //     // ),
                //     ]
                //     )
                //     );
                //     })]))]),
                //       );
                //     } else {
                //       return LoadingPage();
                //     } //Center(child: CustomLoader(color: Theme.of(context).primaryColor));
                //   },
                // ),


                RefreshIndicator(
                  onRefresh: () async {
                    if (Provider.of<AuthProvider>(context,
                        listen: false)
                        .isLoggedIn()) {
                      await Provider.of<CartProvider>(context,
                          listen: false)
                          .getCartDataAPI(context);
                    }
                  },
                  child: ListView.builder(
                    shrinkWrap: true,
                    physics: NeverScrollableScrollPhysics(),
                    itemCount: widget.sellerList.length,
                    padding: EdgeInsets.all(0),
                    itemBuilder: (context, index) {
                      return InkWell(
                        onTap: (){
                          Navigator.push(context, MaterialPageRoute(builder: (_) =>  cargo_widget(
                            cargoDetails:  Padding(
                              padding: EdgeInsets.only(
                                  bottom: Dimensions
                                      .PADDING_SIZE_SMALL),
                              child: Column(
                                mainAxisAlignment:
                                MainAxisAlignment.start,
                                crossAxisAlignment:
                                CrossAxisAlignment.start,
                                children: [
                                  SizedBox(
                                      height: Dimensions
                                          .PADDING_SIZE_SMALL),

                                  SizedBox(height: 10,),
                                  ListView.builder(

                                    physics:
                                    NeverScrollableScrollPhysics(),
                                    shrinkWrap: true,
                                    padding: EdgeInsets.all(0),
                                    itemCount:
                                    widget.cartProductList[index]
                                        .length,
                                    itemBuilder: (context, i) {
                                      return CartDetailsWidget(
                                        cartModel:
                                        widget.cartProductList[index]
                                        [i],
                                        index:  widget.cartProductIndexList[
                                        index][i],
                                        fromCheckout:
                                        widget.fromCheckout,
                                      );
                                    },
                                  ),

                                  //Provider.of<SplashProvider>(context,listen: false).configModel.shippingMethod =='sellerwise_shipping'?
                                  Provider.of<SplashProvider>(
                                      context,
                                      listen: false)
                                      .configModel
                                      .shippingMethod ==
                                      'sellerwise_shipping' &&
                                      widget.sellerGroupList[index]
                                          .shippingType ==
                                          'order_wise'
                                      ?
                                  // Padding(
                                  //   padding: const EdgeInsets.symmetric(horizontal: Dimensions.PADDING_SIZE_DEFAULT),
                                  //   child: InkWell(
                                  //     onTap: () {
                                  //       if(Provider.of<AuthProvider>(context, listen: false).isLoggedIn()) {
                                  //         showModalBottomSheet(
                                  //           context: context, isScrollControlled: true, backgroundColor: Colors.transparent,
                                  //           builder: (context) => ShippingMethodBottomSheet(groupId: sellerGroupList[index].cartGroupId,sellerIndex: index, sellerId: sellerGroupList[index].id),
                                  //         );
                                  //       }else {
                                  //         showCustomSnackBar('not_logged_in', context);
                                  //       }
                                  //     },
                                  //
                                  //
                                  //     child: Container(
                                  //       decoration: BoxDecoration(
                                  //         border: Border.all(width: 0.5,color: Colors.grey),
                                  //         borderRadius: BorderRadius.all(Radius.circular(10)),
                                  //       ),
                                  //       child: Padding(
                                  //         padding: const EdgeInsets.all(8.0),
                                  //         child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                                  //           Text(getTranslated('SHIPPING_PARTNER', context), style: titilliumRegular),
                                  //           Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                                  //             Text(
                                  //               (cart.shippingList == null || cart.shippingList[index].shippingMethodList == null || cart.chosenShippingList.length == 0 || cart.shippingList[index].shippingIndex == -1) ? ''
                                  //                   : '${cart.shippingList[index].shippingMethodList[cart.shippingList[index].shippingIndex].title.toString()}',
                                  //               style: titilliumSemiBold.copyWith(color: ColorResources.getPrimary(context)),
                                  //               maxLines: 1,
                                  //               overflow: TextOverflow.ellipsis,
                                  //             ),
                                  //             SizedBox(width: Dimensions.PADDING_SIZE_EXTRA_SMALL),
                                  //             Icon(Icons.keyboard_arrow_down, color: Theme.of(context).primaryColor),
                                  //           ]),
                                  //         ]),
                                  //       ),
                                  //     ),
                                  //   )
                                  //   ,
                                  // ) :SizedBox(),
                                  SizedBox()
                                      : SizedBox()
                                ],
                              ),
                            ),
                            cargo:"شحنه رقم${index}" ,
                            time: Row(
                              children: [
                                Text(Provider.of<OrderProvider>(context, listen: false).selectedDate == -1 ? "غدا" : getTranslated(
                                    weekdays[Provider.of<OrderProvider>(context, listen: false).selectedDate], context)
                                  ,style: titilliumsemiBold.copyWith(fontSize: 10 ,color: ColorResources.primaryColor),),

                                Text(Provider.of<OrderProvider>(context, listen: false).timeDeliveryIndex == -1
                                    ? timeToDelivery[0]
                                    : Provider.of<OrderProvider>(context, listen: false).timeDeliveryData
                                  ,style: titilliumsemiBold.copyWith(fontSize: 10 ,color: ColorResources.primaryColor),),

                              ],
                            ) ,
                            cartList: widget.cartList,
                            totalOrderAmount:  widget.amount,
                            shippingFee:  widget.shippingAmount,
                            discount:  widget.discount,
                            tax:  widget.tax,
                            cartProductList: widget.cartProductList,
                            fromCheckout: widget.fromCheckout,
                            sellerList:  widget.sellerList,
                            cartProductIndexList: widget.cartProductIndexList,
                            sellerGroupList:  widget.sellerGroupList,                                  )));


                        },
                        child: Padding(
                          padding: EdgeInsets.only(
                              bottom: Dimensions
                                  .PADDING_SIZE_SMALL),
                          child: Column(
                            mainAxisAlignment:
                            MainAxisAlignment.start,
                            crossAxisAlignment:
                            CrossAxisAlignment.start,
                            children: [
                              SizedBox(
                                  height: Dimensions
                                      .PADDING_SIZE_SMALL),
                              Row(
                                children: [
                                  Container(
                                    width: 40,
                                    height: 40,
                                    padding: EdgeInsets.all(7),
                                    decoration: BoxDecoration(
                                        color:Colors.grey.withOpacity(0.03),
                                        border: Border.all(
                                          color: Colors.grey.withOpacity(0.5),
                                        ),
                                        borderRadius: BorderRadius.all(Radius.circular(7))),
                                    child: Image.asset("assets/images/cube2.png",
                                      color: Colors.grey,width: 10,height: 10,),
                                  ),
                                  SizedBox(width: 10,),
                                  Column(

                                    //mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text("شحنه رقم${index}",style: titilliumvBold.copyWith(fontSize: 12
                                          ,fontWeight: FontWeight.w700 ,color: Colors.black.withOpacity(0.6)
                                      ),),



                                      Consumer <OrderProvider>(
                                          builder: (context, order, child) {
                                            return Row(
                                              children: [
                                                Text(Provider.of<OrderProvider>(context, listen: false).selectedDate == -1 ? "غدا" :

                                                getTranslated(weekdays[Provider.of<OrderProvider>(context, listen: false).selectedDate], context)

                                                  ,style: titilliumsemiBold.copyWith(fontSize: 10),),

                                                Text(

                                            Provider.of<OrderProvider>(context, listen: false).timeDeliveryIndex == -1
                                                    ? timeToDelivery[0]
                                                    :
                                            Provider.of<OrderProvider>(context, listen: false).timeDeliveryData!=null?
                                            "${Provider.of<OrderProvider>(context, listen: false).timeDeliveryData}"
                                                :"حدد وقت التسليم"

                                                  ,style: titilliumsemiBold.copyWith(fontSize: 10),),

                                              ],
                                            );}),









                                    ],
                                  ),


                                ],

                              ),
                              SizedBox(height: 10,),
                              Center(
                                child: Container(
                                  width: double.infinity,
                                  height: 70,
                                  child: ListView.builder(
                                    scrollDirection: Axis.horizontal,
                                    physics:
                                    NeverScrollableScrollPhysics(),
                                    shrinkWrap: true,
                                    padding: EdgeInsets.only(right: 35),
                                    itemCount:
                                    widget.cartProductList[index]
                                        .length,
                                    itemBuilder: (context, i) {
                                      return Center(
                                        child: CartPaymentWidget(
                                          cartModel:
                                          widget.cartProductList[index]
                                          [i],
                                          index: widget.cartProductIndexList[
                                          index][i],
                                          fromCheckout:
                                          widget.fromCheckout,
                                        ),
                                      );
                                    },
                                  ),
                                ),
                              ),
                              SizedBox(height: 10,),


                              Padding(
                                padding: const EdgeInsets.only(left: 35 , right: 35 , bottom: 10),
                                child: InkWell(
                                  onTap: ()async{

                                    await showModalBottomSheet(
                                      context: context, isScrollControlled: true, backgroundColor: Colors.transparent,
                                      builder: (context) => TimeDeliveryBottomSheet(groupId: 'all_cart_group',sellerIndex: 0, sellerId: 1),
                                    );

                                  },
                                  child: Container(
                                    decoration: BoxDecoration(
                                        color:Colors.grey.withOpacity(0.1),

                                        border: Border.all(
                                          color: Colors.grey.withOpacity(0.5),
                                        ),
                                        borderRadius: BorderRadius.all(Radius.circular(7))),
                                    child: Padding(
                                      padding: const EdgeInsets.all(3.0),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          Icon(Icons.access_time_outlined,size: 20,),
                                          SizedBox(width: 5,),
                                          Text("تعديل وقت التسليم",style: titilliumsemiBold.copyWith(fontSize: 12),),

                                        ],
                                      ),
                                    ),

                                  ),
                                ),
                              ),

                              //Provider.of<SplashProvider>(context,listen: false).configModel.shippingMethod =='sellerwise_shipping'?
                              Divider(color: Colors.grey,)
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),







                // ListView.builder(
                //   scrollDirection: Axis.vertical,
                //   shrinkWrap: true,
                //   //physics: NeverScrollableScrollPhysics(),
                //   itemCount: Provider.of<CartProvider>(context,listen: false).cartList.length,
                //   itemBuilder: (ctx,index){
                //     return
                //
                //       Column(
                //         children: [
                //           Row(
                //             mainAxisAlignment: MainAxisAlignment.spaceBetween,
                //             children: [
                //               Row(
                //                 children: [
                //                   Container(
                //                     width: 40,
                //                     height: 40,
                //                     padding: EdgeInsets.all(7),
                //                     decoration: BoxDecoration(
                //                         color:Colors.grey.withOpacity(0.03),
                //                         border: Border.all(
                //                           color: Colors.grey.withOpacity(0.5),
                //                         ),
                //                         borderRadius: BorderRadius.all(Radius.circular(7))),
                //                     child: Image.asset("assets/images/cube2.png",
                //                       color: Colors.grey,width: 10,height: 10,),
                //                   ),
                //                   SizedBox(width: 10,),
                //                   Column(
                //
                //                     //mainAxisAlignment: MainAxisAlignment.start,
                //                     crossAxisAlignment: CrossAxisAlignment.start,
                //                     children: [
                //                       Text("شحنه رقم${index}",style: titilliumvBold.copyWith(fontSize: 12
                //                       ,fontWeight: FontWeight.w500
                //                       ),),
                //
                //
                //
                //                       Consumer <OrderProvider>(
                //                           builder: (context, order, child) {
                //                             return Row(
                //                               children: [
                //                                 Text(Provider.of<OrderProvider>(context, listen: false).selectedDate == -1 ? "غدا" : getTranslated(
                //                                     weekdays[Provider.of<OrderProvider>(context, listen: false).selectedDate], context)
                //                                 ,style: titilliumsemiBold.copyWith(fontSize: 12),),
                //
                //                                 Text(Provider.of<OrderProvider>(context, listen: false).timeDeliveryIndex == -1
                //                                     ? timeToDelivery[0]
                //                                     : Provider.of<OrderProvider>(context, listen: false).timeDeliveryData
                //                                 ,style: titilliumsemiBold.copyWith(fontSize: 12),),
                //
                //                               ],
                //                             );}),
                //
                //
                //
                //
                //
                //
                //
                //
                //
                //                     ],
                //                   ),
                //
                //
                //                 ],
                //
                //               ),
                //
                //               Container(
                //                 height:39,
                //                 width: 50,
                //
                //                 child: CachedNetworkImage(
                //                   width: 20, height: 1,
                //                   imageUrl: '${Provider.of<SplashProvider>(context,listen: false).baseUrls.productThumbnailUrl}'
                //                       '/${Provider.of<CartProvider>(context,listen: false).cartList[index].thumbnail}',
                //                   fit: BoxFit.cover,
                //                   imageBuilder: (BuildContext context, ImageProvider<dynamic> imageProvider) {
                //                     return Image( image: imageProvider, fit: BoxFit.cover);},
                //                   placeholder: (context, url) => Image.asset(
                //                     'assets/images/placeholder.png',
                //                     fit: BoxFit.cover,
                //                   ),
                //                   errorWidget: (context, url, error) => Icon(Icons.shopping_cart_outlined),
                //                 ),
                //               ),
                //             ],
                //           ),
                //
                //           SizedBox(height: 10,),
                //
                //           InkWell(
                //             onTap: ()async{
                //
                //               await showModalBottomSheet(
                //                 context: context, isScrollControlled: true, backgroundColor: Colors.transparent,
                //                 builder: (context) => TimeDeliveryBottomSheet(groupId: 'all_cart_group',sellerIndex: 0, sellerId: 1),
                //               );
                //
                //             },
                //             child: Container(
                //               decoration: BoxDecoration(
                //                   color:Colors.grey.withOpacity(0.1),
                //
                //                   border: Border.all(
                //                     color: Colors.grey.withOpacity(0.5),
                //                   ),
                //                   borderRadius: BorderRadius.all(Radius.circular(7))),
                //               child: Row(
                //                 mainAxisAlignment: MainAxisAlignment.center,
                //                 children: [
                //                   Icon(Icons.access_time_outlined,size: 20,),
                //                   SizedBox(width: 5,),
                //                   Text("تعديل وقت التسليم",style: titilliumsemiBold.copyWith(fontSize: 12),),
                //
                //                 ],
                //               ),
                //
                //             ),
                //           ),
                //           SizedBox(height: 10,),
                //         ],
                //       );
                //       /*
                //                   FadeInImage.assetNetwork(
                //                     placeholder: Images.placeholder, fit: BoxFit.cover, width: 50, height: 50,
                //                     image: '${Provider.of<SplashProvider>(context,listen: false).baseUrls.productThumbnailUrl}'
                //                         '/${Provider.of<CartProvider>(context,listen: false).cartList[index].thumbnail}',
                //                     imageErrorBuilder: (c, o, s) => Image.asset(Images.placeholder, fit: BoxFit.cover, width: 50, height: 50),
                //                   ),
                //
                //                    */
                //     },
                // ),
                        SizedBox(height: 10,),

                Text("في حاله عدم توفر المنتجات , وش الخيار اللي ودك نتخذه؟",
                  style: titilliumvBold.copyWith(fontSize: 12),
                ),
                SizedBox(height: 10,),
                Column(children: [
                  _inFound? Container(
                    padding: EdgeInsets.only(right: 5),
                    height: 35,
                    decoration: BoxDecoration(
                        color:Theme.of(context).primaryColor.withOpacity(0.03),
                        border: Border.all(
                          color: Theme.of(context).primaryColor.withOpacity(0.5),
                        ),
                        borderRadius: BorderRadius.all(Radius.circular(5))),
                    child: Row(
                      children: [
                        customRadioButtonProduct(index: 0,),
                        SizedBox(width: 5,),
                        Text('اعاده جدولتها عند التوفر')
                      ],
                    ),
                  ): SizedBox(),

                  SizedBox(height: 5,),
                  //Text(getTranslated('payment_method', context), style: titilliumSemiBold.copyWith(fontSize: Dimensions.FONT_SIZE_LARGE),),
        _cancelProduct  ?
                  Container(

                    height: 35,
                    padding: EdgeInsets.only(right: 5),
                    decoration: BoxDecoration(
                        color:Theme.of(context).primaryColor.withOpacity(0.03),
                        border: Border.all(
                          color: Theme.of(context).primaryColor.withOpacity(0.5),
                        ),
                        borderRadius: BorderRadius.all(Radius.circular(5))),
                    child: Row(children:[customRadioButtonProduct(index:!_inFound  ? 0 : 1,),
                      SizedBox(width: 5,),

                      Text('الغاء المنتجات الغير متوفره')]),
                  )
                      : SizedBox(),
                  SizedBox(height: 34,),
                  Container(

                      height: 50,

                      decoration: BoxDecoration(
                        color: Colors.grey.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(30),
                        border: Border.all(width: .4,color: Colors.grey.withOpacity(0.3)),
                        // boxShadow: [BoxShadow(color: Colors.grey, spreadRadius: 1, blurRadius: 1)],
                      ),
                      alignment: Alignment.centerLeft,
                      padding: EdgeInsets.symmetric(horizontal: 5),
                      child: TextFormField(
                        onTap: (){


                        },
                        enabled: true,
                        focusNode: _orderNoteNode,
                        controller: _orderNoteController,
                        textAlign: TextAlign.start,
                        style: TextStyle(
                          fontSize: 15.0,
                        ),

                        keyboardType: TextInputType.text,
                        maxLines: 1,
                        decoration: InputDecoration(

                          hintText:"اكتب ملاحظاتك على الطلب الحالى",
                          hintStyle: titilliumRegular.copyWith(color: Colors.grey.withOpacity(0.9), fontSize: 13),
                          border: InputBorder.none,
                        ),
                      )
                  ),
                  SizedBox(height: 100,),
                ]),

                //   // Container(
                //   //   transform: Matrix4.translationValues(0.0, -30.0, 0.0),
                //   //   child: ListView.builder(
                //   //       shrinkWrap: true,
                //   //       physics: NeverScrollableScrollPhysics(),
                //   //       itemCount: Provider.of<CartProvider>(context,listen: false).cartList.length,
                //   //       itemBuilder: (ctx,index){
                //   //         return Padding(
                //   //           padding: EdgeInsets.all(Dimensions.PADDING_SIZE_DEFAULT),
                //   //           child: Row(children: [
                //   //             Container(
                //   //               decoration: BoxDecoration(
                //   //                 border: Border.all(width: .5, color: Theme.of(context).primaryColor.withOpacity(.25)),
                //   //                 borderRadius: BorderRadius.circular(Dimensions.PADDING_SIZE_EXTRA_EXTRA_SMALL),
                //   //               ),
                //   //               child: ClipRRect(
                //   //                 borderRadius: BorderRadius.circular(Dimensions.PADDING_SIZE_EXTRA_EXTRA_SMALL),
                //   //                 child: CachedNetworkImage(
                //   //                   width: 50, height: 50,
                //   //                   imageUrl: '${Provider.of<SplashProvider>(context,listen: false).baseUrls.productThumbnailUrl}'
                //   //                       '/${Provider.of<CartProvider>(context,listen: false).cartList[index].thumbnail}',
                //   //                   fit: BoxFit.cover,
                //   //                   imageBuilder: (BuildContext context, ImageProvider<dynamic> imageProvider) {
                //   //                     return Image( image: imageProvider, fit: BoxFit.cover);},
                //   //                   placeholder: (context, url) => Image.asset(
                //   //                     'assets/images/placeholder.png',
                //   //                     fit: BoxFit.cover,
                //   //                   ),
                //   //                   errorWidget: (context, url, error) => Icon(Icons.shopping_cart_outlined),
                //   //                 ),
                //   //                 /*
                //   //                 FadeInImage.assetNetwork(
                //   //                   placeholder: Images.placeholder, fit: BoxFit.cover, width: 50, height: 50,
                //   //                   image: '${Provider.of<SplashProvider>(context,listen: false).baseUrls.productThumbnailUrl}'
                //   //                       '/${Provider.of<CartProvider>(context,listen: false).cartList[index].thumbnail}',
                //   //                   imageErrorBuilder: (c, o, s) => Image.asset(Images.placeholder, fit: BoxFit.cover, width: 50, height: 50),
                //   //                 ),
                //   //
                //   //                  */
                //   //               ),
                //   //             ),
                //   //             SizedBox(width: Dimensions.MARGIN_SIZE_DEFAULT),
                //   //             Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                //   //               Row(
                //   //                 children: [
                //   //                   Text(
                //   //                     Provider.of<CartProvider>(context,listen: false).cartList[index].name,
                //   //                     style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_DEFAULT,
                //   //                         color: ColorResources.getPrimary(context)),
                //   //                     maxLines: 2,
                //   //                     overflow: TextOverflow.ellipsis,
                //   //                   ),
                //   //                   SizedBox(width: Dimensions.PADDING_SIZE_SMALL,),
                //   //                   Text(PriceConverter.convertPrice(context, Provider.of<CartProvider>(context,listen: false).cartList[index].price),
                //   //                     style: titilliumSemiBold.copyWith(fontSize: Dimensions.FONT_SIZE_LARGE),),
                //   //
                //   //                 ],
                //   //               ),
                //   //               SizedBox(height: Dimensions.MARGIN_SIZE_EXTRA_SMALL),
                //   //
                //   //               Row(children: [
                //   //
                //   //                 Text('${getTranslated('qty', context)} - '+' '+Provider.of<CartProvider>(context,listen: false).cartList[index].quantity.toString(),
                //   //                     style: titilliumRegular.copyWith()),
                //   //
                //   //               ]),
                //   //             ]),
                //   //           ]),
                //   //         );
                //   //
                //   //       }),
                //   // ),
                //   // Coupon
                //   // Padding(
                //   //   padding: const EdgeInsets.only(left:Dimensions.PADDING_SIZE_DEFAULT,right:Dimensions.PADDING_SIZE_DEFAULT,
                //   //       bottom: Dimensions.PADDING_SIZE_DEFAULT),
                //   //   child: Container(height: 50,
                //   //     width: MediaQuery.of(context).size.width,
                //   //     decoration: BoxDecoration(
                //   //         color: ColorResources.couponColor(context).withOpacity(.5),
                //   //         borderRadius: BorderRadius.circular(Dimensions.PADDING_SIZE_EXTRA_SMALL),
                //   //         border: Border.all(width: .5, color: Theme.of(context).primaryColor.withOpacity(.9))
                //   //     ),
                //   //     child: Row(children: [
                //   //       SizedBox(
                //   //         height: 50,
                //   //         child: Padding(
                //   //           padding: const EdgeInsets.only(left: Dimensions.PADDING_SIZE_SMALL,bottom: 5),
                //   //           child: Center(
                //   //             child: TextField(controller: _controller, decoration: InputDecoration(
                //   //               hintText: 'هل تمتلك كود الخصم?',
                //   //               hintStyle: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_DEFAULT),
                //   //               filled: false,
                //   //               fillColor: ColorResources.getIconBg(context),
                //   //               border: InputBorder.none,
                //   //             )),
                //   //           ),
                //   //         ),
                //   //       ),
                //   //       SizedBox(width: Dimensions.PADDING_SIZE_SMALL),
                //   //       !Provider.of<CouponProvider>(context).isLoading ? InkWell(
                //   //         onTap: () {
                //   //           if(_controller.text.isNotEmpty) {
                //   //             Provider.of<CouponProvider>(context, listen: false).initCoupon(_controller.text, _order).then((value) {
                //   //               if(value > 0) {
                //   //                 ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:
                //   //                  Text('لقد حصلت على ${PriceConverter.convertPrice(context, value)} تخفيض'), backgroundColor: Colors.green));
                //   //               }else {
                //   //                 ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                //   //                   content: Text(getTranslated('invalid_coupon_or', context)),
                //   //                   backgroundColor: Colors.red,
                //   //                 ));
                //   //               }
                //   //             });
                //   //           }
                //   //         },
                //   //         // child: Container(width: 100,height: 60,
                //   //         //     decoration: BoxDecoration(
                //   //         //         color: Theme.of(context).primaryColor,
                //   //         //         borderRadius: BorderRadius.only(bottomRight: Radius.circular(Dimensions.PADDING_SIZE_EXTRA_SMALL),
                //   //         //             topRight: Radius.circular(Dimensions.PADDING_SIZE_EXTRA_SMALL))
                //   //         //
                //   //         //     ),
                //   //         //     child: Center(child: Text(getTranslated('APPLY', context),
                //   //         //       style: titleRegular.copyWith(color: Theme.of(context).cardColor, fontSize: Dimensions.FONT_SIZE_LARGE),
                //   //         //     ))),
                //   //       ) :
                //   //       CircularProgressIndicator(valueColor: AlwaysStoppedAnimation<Color>(Theme.of(context).primaryColor)),
                //   //     ]),
                //   //   ),
                //   // ),
                //
                //   SizedBox(height: Dimensions.PADDING_SIZE_SMALL,),
                //
                //   // Container(
                //   //   height: 40,width: MediaQuery.of(context).size.width,
                //   //   decoration: BoxDecoration(
                //   //     color: Theme.of(context).primaryColor.withOpacity(.055),
                //   //   ),
                //   //   child: Center(child: Text(getTranslated('order_summary', context),
                //   //     style: titilliumSemiBold.copyWith(fontSize: Dimensions.FONT_SIZE_LARGE),)),
                //   // ),
                //   // Total bill
                //   // Container(
                //   //
                //   //   margin: EdgeInsets.only(top: Dimensions.PADDING_SIZE_SMALL),
                //   //   padding: EdgeInsets.all(Dimensions.PADDING_SIZE_SMALL),
                //   //   color: Theme.of(context).highlightColor,
                //   //   child:Consumer <OrderProvider>(
                //   //     builder: (context, order, child) {
                //   //       //_shippingCost = order.shippingIndex != null ? order.shippingList[order.shippingIndex].cost : 0;
                //   //       double _couponDiscount = Provider.of<CouponProvider>(context).discount != null ?
                //   //       Provider.of<CouponProvider>(context).discount : 0;
                //   //
                //   //       return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                //   //
                //   //         AmountWidget(title: getTranslated('sub_total', context), amount: PriceConverter.convertPrice(context, _order)),
                //   //         AmountWidget(title: getTranslated('SHIPPING_FEE', context), amount: PriceConverter.convertPrice(context, widget.shippingFee)),
                //   //         AmountWidget(title: getTranslated('DISCOUNT', context), amount: PriceConverter.convertPrice(context, widget.discount)),
                //   //         AmountWidget(title: getTranslated('coupon_voucher', context), amount: PriceConverter.convertPrice(context, _couponDiscount)),
                //   //         AmountWidget(title: getTranslated('TAX', context), amount: PriceConverter.convertPrice(context, widget.tax)),
                //   //         Divider(height: 5, color: Theme.of(context).hintColor),
                //   //         AmountWidget(title: getTranslated('TOTAL_PAYABLE', context), amount: PriceConverter.convertPrice(context,
                //   //             (_order + widget.shippingFee - widget.discount - _couponDiscount + widget.tax))),
                //   //       ]);
                //   //     },
                //   //   ),
                //   // ),
                //   SizedBox(height: Dimensions.PADDING_SIZE_SMALL,),
                //   SizedBox(height: Dimensions.PADDING_SIZE_SMALL,),
                //
                //   //في حال لم تجد المنتج
                //   // Container(
                //   //   height: 140,
                //   //   margin: EdgeInsets.only(bottom: Dimensions.PADDING_SIZE_SMALL),
                //   //   padding: EdgeInsets.all(Dimensions.PADDING_SIZE_SMALL),
                //   //   color: Theme.of(context).highlightColor,
                //   //   child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                //   //       children: [
                //   //         Text(getTranslated('notFoundProduct', context), style: titilliumSemiBold.copyWith(fontSize: Dimensions.FONT_SIZE_DEFAULT),),
                //   //         SizedBox(height: Dimensions.PADDING_SIZE_EXTRA_SMALL),
                //   //         Column(children: [
                //   //           //Text(getTranslated('payment_method', context), style: titilliumSemiBold.copyWith(fontSize: Dimensions.FONT_SIZE_LARGE),),
                //   //             _inFound? CustomCheckBoxProduct(title: getTranslated('tellMeWhenCome', context), index: 0):  SizedBox(),
                //   //             _cancelProduct ? Container(
                //   //                child: CustomCheckBoxProduct(title: getTranslated('cancelProduct', context), index: !_inFound ? 0 : 1)) : SizedBox(),
                //   //         ],),
                //   //         // _cod? CustomCheckBox(title: getTranslated('cash_on_delivery', context), index: 0):  SizedBox(),
                //   //         // _digitalPayment ? CustomCheckBox(title: getTranslated('digital_payment', context), index: !_cod ? 0 : 1) : SizedBox(),
                //   //       ]),
                //   // ),
                //   //SizedBox(height: Dimensions.PADDING_SIZE_SMALL,),
                //
                //   // note
                //   // Container(
                //   //   height: 100,
                //   //   margin: EdgeInsets.only(top: Dimensions.PADDING_SIZE_SMALL),
                //   //   padding: EdgeInsets.all(Dimensions.PADDING_SIZE_SMALL),
                //   //   color: Theme.of(context).highlightColor,
                //   //   child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                //   //       children: [
                //   //     Row(
                //   //       children: [
                //   //         Text(
                //   //           '${getTranslated('order_note', context)}',
                //   //           style: robotoRegular.copyWith(fontSize: Dimensions.FONT_SIZE_LARGE),),
                //   //         Text(
                //   //           '${getTranslated('extra_inst', context)}',
                //   //           style: robotoRegular.copyWith(color: ColorResources.getHint(context)),),
                //   //       ],
                //   //     ),
                //   //     SizedBox(height: Dimensions.PADDING_SIZE_SMALL),
                //   //     CustomTextField(
                //   //       hintText: getTranslated('order_note', context),
                //   //       textInputType: TextInputType.multiline,
                //   //       textInputAction: TextInputAction.done,
                //   //       maxLine: 3,
                //   //       focusNode: _orderNoteNode,
                //   //       controller: _orderNoteController,
                //   //     ),
                //   //   ]),
                //   // ),
                //  // SizedBox(height: Dimensions.PADDING_SIZE_SMALL,),
                //
                // ]),
              ],
                ),
                Positioned(
                  bottom: 5,
                  left: 15,
                  right: 15,
                  child: Container(
                    height: 90,
                    padding: EdgeInsets.all(15),
                    width: 350,
                    child:

                    Consumer<OrderProvider>(
    builder: (context, order, child) {
      return !Provider
          .of<OrderProvider>(context)
          .isLoading ?
      FloatingActionButton(
        backgroundColor: Theme
            .of(context)
            .primaryColor,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(30.0))),
        onPressed: ()async {
          await showModalBottomSheet(
            context: context, isScrollControlled: true, backgroundColor: Colors.transparent,
            builder: (context) => Done_payment_bottomsheet( cartList: widget.cartList,
              cancelProduct: _cancelProduct ,
              digitalPayment: _digitalPayment ,
              inFound:  _inFound,
              billingAddress:_billingAddress,
              callback :_callback,
              cod:_cod ,
              orderNoteController:_orderNoteController,
              orderCheckDouble:_orderCheckDouble,
              minOrder: _minOrder,
              order:_order,
              orderCheck:_orderCheck,
                isGuestMode: isGuestMode ,
              phone:Consumer<ProfileProvider>(
                builder: (context, profile, child) {
                  return Row(children: [
                    Text(!isGuestMode ? profile.userInfoModel != null ? '${profile.userInfoModel.phone}' : 'Full Name' : 'Guest',
                        style: titilliumsemiBold
                            .copyWith(
                            fontSize: Dimensions
                                .FONT_SIZE_EXTRA_SMALLest,
                            color: ColorResources.primaryColor
                        )),

                  ],);


                },),
              company:Consumer<ProfileProvider>(
                builder: (context, profile, child) {
                  return Row(children: [
                    Text(!isGuestMode ? profile.userInfoModel != null ? '${profile.userInfoModel.fName}' : 'Full Name' : 'Guest',
                        style: titilliumsemiBold
                            .copyWith(
                          fontSize: Dimensions
                              .FONT_SIZE_EXTRA_SMALLest,
                          color: ColorResources.primaryColor
                        )),

                  ],);


                  },),
              amount:  widget.amount,
              shippingAmount:  widget.shippingAmount,
              discount:  widget.discount,
              tax:  widget.tax,
              cartProductList: widget.cartProductList,
              fromCheckout: widget.fromCheckout,
              sellerList:  widget.sellerList,
              cartProductIndexList: widget.cartProductIndexList,
              sellerGroupList:  widget.sellerGroupList,       ),
          );
          // print("_order: $_order");
          // print("_orderCheck: $_orderCheck");
          // print("_orderCheckDouble: $_orderCheckDouble");
          //
          // if(Provider.of<OrderProvider>(context, listen: false).addressIndex == null) {
          //   ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(getTranslated('select_a_shipping_address', context)), backgroundColor: Colors.red));
          // } else if(Provider.of<OrderProvider>(context, listen: false).billingAddressIndex == null && _billingAddress){
          //   ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(getTranslated('select_a_billing_address', context)), backgroundColor: Colors.red));
          // } else if(Provider.of<ProfileProvider>(context, listen: false).userInfoModel.isDoc == 0 && Provider.of<ProfileProvider>(context, listen: false).userInfoModel.isDocReq == 0) {
          //   await showModalBottomSheet(
          //     context: context, isScrollControlled: true, backgroundColor: Colors.transparent,
          //     builder: (context) => CustomStepper(),
          //   );
          // } else if(_orderCheckDouble < _minOrder) {
          //   ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("يجب ان يكون الطلب اكثر من  50  الف ريال"), backgroundColor: ColorResources.primaryColor));
          // }  else if(Provider.of<OrderProvider>(context, listen: false).timeDeliveryIndex == 0) {
          //   await showModalBottomSheet(
          //     context: context, isScrollControlled: true, backgroundColor: Colors.transparent,
          //     builder: (context) => TimeDeliveryBottomSheet(groupId: 'all_cart_group',sellerIndex: 0, sellerId: 1),
          //   );
          // } else {
          //   List<CartModel> _cartList = [];
          //   _cartList.addAll(widget.cartList);
          //   for(int index=0; index<widget.cartList.length; index++) {
          //     for(int i=0; i<Provider.of<CartProvider>(context, listen: false).chosenShippingList.length; i++) {
          //       if(Provider.of<CartProvider>(context, listen: false).chosenShippingList[i].cartGroupId == widget.cartList[index].cartGroupId) {
          //         _cartList[index].shippingMethodId = Provider.of<CartProvider>(context, listen: false).chosenShippingList[i].id;
          //         break;
          //       }
          //     }
          //   }
          //   String orderNote = _orderNoteController.text.trim();
          //   double couponDiscount = Provider.of<CouponProvider>(context, listen: false).discount != null ? Provider.of<CouponProvider>(context, listen: false).discount : 0;
          //   String couponCode = Provider.of<CouponProvider>(context, listen: false).discount != null ? Provider.of<CouponProvider>(context, listen: false).coupon.code : '';
          //   if(_cod && Provider.of<OrderProvider>(context, listen: false).paymentMethodIndex == 0) {
          //     print("kkkkkkkkkkkkkkkkkkkkkkkk2");
          //     Provider.of<OrderProvider>(context, listen: false).placeOrder(OrderPlaceModel(
          //       CustomerInfo(
          //         Provider.of<ProfileProvider>(context, listen: false).addressList[Provider.of<OrderProvider>(context, listen: false).addressIndex].id.toString(),
          //         Provider.of<ProfileProvider>(context, listen: false).addressList[Provider.of<OrderProvider>(context, listen: false).addressIndex].address,
          //         _billingAddress? Provider.of<ProfileProvider>(context, listen: false).billingAddressList[Provider.of<OrderProvider>(context, listen: false).billingAddressIndex].id.toString():
          //         Provider.of<ProfileProvider>(context, listen: false).addressList[Provider.of<OrderProvider>(context, listen: false).addressIndex].id.toString(),
          //         _billingAddress? Provider.of<ProfileProvider>(context, listen: false).billingAddressList[Provider.of<OrderProvider>(context, listen: false).billingAddressIndex].address:
          //         Provider.of<ProfileProvider>(context, listen: false).addressList[Provider.of<OrderProvider>(context, listen: false).addressIndex].address,
          //         orderNote,
          //       ),
          //       _cartList,
          //       order.paymentMethodIndex == 0 ? 'cash_on_delivery' : '',
          //       couponDiscount,
          //       Provider.of<OrderProvider>(context, listen: false).timeDeliveryData,
          //       Provider.of<OrderProvider>(context, listen: false).timeDeliveryData,
          //     ),
          //
          //         _callback,
          //         _cartList,
          //         Provider.of<ProfileProvider>(context, listen: false).addressList[Provider.of<OrderProvider>(context, listen: false).addressIndex].id.toString(),
          //         couponCode,
          //         _billingAddress? Provider.of<ProfileProvider>(context, listen: false).billingAddressList[Provider.of<OrderProvider>(context, listen: false).billingAddressIndex].id.toString():
          //         Provider.of<ProfileProvider>(context, listen: false).addressList[Provider.of<OrderProvider>(context, listen: false).addressIndex].id.toString(),
          //         orderNote );
          //     Provider.of<OrderProvider>(context, listen: false).clearDeliveryTime();
          //   }
          //   else if(_cod && Provider.of<OrderProvider>(context, listen: false).paymentMethodIndex == 1){
          //     Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => WalletScreen()));
          //
          //         }
          //   else {
          //     print("kkkkkkkkkkkkkkkkkkkkkkkk");
          //
          //     String userID = await Provider.of<ProfileProvider>(context, listen: false).getUserInfo(context);
          //     Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => PaymentScreen(
          //       customerID: userID,
          //       addressID: Provider.of<ProfileProvider>(context, listen: false).addressList[Provider.of<OrderProvider>(context, listen: false).addressIndex].id.toString(),
          //       couponCode: Provider.of<CouponProvider>(context, listen: false).discount != null ? Provider.of<CouponProvider>(context, listen: false).coupon.code : '',
          //       billingId: _billingAddress? Provider.of<ProfileProvider>(context, listen: false).billingAddressList[Provider.of<OrderProvider>(context, listen: false).billingAddressIndex].id.toString():
          //       Provider.of<ProfileProvider>(context, listen: false).addressList[Provider.of<OrderProvider>(context, listen: false).addressIndex].id.toString(),
          //       orderNote: orderNote,
          //     )));
            //}
          //}
        },
        child: Padding(
          padding: const EdgeInsets.only(left: 15, right: 15),
          child: Row(
            // mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Expanded(
                  child: Text(
                    "اتمام عمليه الشراء",
                    style: titilliumvBold.copyWith(
                      fontSize: 15,
                      color: Colors.white,
                    ),
                    textAlign: TextAlign.center,
                  )),
              Icon(
                Icons.arrow_forward_sharp,
                color: Colors.white,
                size: 25,
              )
            ],
          ),
        ),
      ) : Center(child: CupertinoActivityIndicator(radius: 20.0
          , color: ColorResources.primaryColor,
          animating: true));
    }),
                  ),
                ),
              ]),

        ),
      ),
      ));
  }

  void _callback(bool isSuccess, String message, String orderID, List<CartModel> carts) async {
    if(isSuccess) {
      Provider.of<ProductProvider>(context, listen: false).getLatestProductList(1, context, reload: true,);
      if(Provider.of<OrderProvider>(context, listen: false).paymentMethodIndex == 0) {
        Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => DashBoardScreen()), (route) => false);
        showAnimatedDialog(context, MyDialog(
          icon: Icons.check,
          title: getTranslated('order_placed', context),
          description: getTranslated('your_order_placed', context),
          isFailed: false,
        ), dismissible: false, isFlip: true);
        Provider.of<OrderProvider>(context, listen: false).clearConfirmPhone();
        Provider.of<OrderProvider>(context, listen: false).clearDeliveryTime();
      }else {

      }
      Provider.of<OrderProvider>(context, listen: false).stopLoader();
    }else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message), backgroundColor: ColorResources.RED));
    }
  }
}

class PaymentButton extends StatelessWidget {
  final String image;
  final Function onTap;
  PaymentButton({@required this.image, this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        height: 45,
        margin: EdgeInsets.symmetric(horizontal: Dimensions.PADDING_SIZE_EXTRA_SMALL),
        padding: EdgeInsets.all(Dimensions.PADDING_SIZE_EXTRA_SMALL),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          border: Border.all(width: 2, color: ColorResources.getGrey(context)),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Image.asset(image),
      ),
    );
  }
}

