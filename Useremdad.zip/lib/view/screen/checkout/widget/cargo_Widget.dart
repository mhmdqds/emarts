import 'package:cached_network_image/cached_network_image.dart';
import 'package:emdad/main.dart';
import 'package:emdad/view/screen/checkout/widget/TimeDeliveryBottomSheet.dart';
import 'package:emdad/view/screen/checkout/widget/customRadioButton.dart';
import 'package:emdad/view/screen/checkout/widget/customRadioButtonProduct.dart';
import 'package:emdad/view/screen/checkout/widget/custom_check_box_product.dart';
import 'package:emdad/view/screen/checkout/widget/taxfield.dart';
import 'package:emdad/view/screen/checkout/widget/taxnuberConfirmationDialog.dart';
import 'package:emdad/view/screen/payment/payment_screen.dart';
import 'package:emdad/view/screen/tread_info/steppers_dots.dart';
import 'package:emdad/view/screen/wallet/wallet_screen.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:emdad/data/model/response/cart_model.dart';
import 'package:emdad/helper/price_converter.dart';
import 'package:emdad/localization/language_constrants.dart';
import 'package:emdad/provider/cart_provider.dart';
import 'package:emdad/provider/coupon_provider.dart';
import 'package:emdad/provider/order_provider.dart';
import 'package:emdad/provider/product_provider.dart';
import 'package:emdad/provider/profile_provider.dart';
import 'package:emdad/provider/splash_provider.dart';
import 'package:emdad/utility/color_resources.dart';
import 'package:emdad/utility/custom_themes.dart';
import 'package:emdad/utility/dimensions.dart';
import 'package:emdad/utility/images.dart';
import 'package:emdad/view/basewidget/amount_widget.dart';
import 'package:emdad/view/basewidget/animated_custom_dialog.dart';
import 'package:emdad/view/basewidget/custom_app_bar.dart';
import 'package:emdad/view/basewidget/my_dialog.dart';
import 'package:emdad/view/basewidget/textfield/custom_textfield.dart';
import 'package:emdad/view/screen/address/saved_address_list_screen.dart';
import 'package:emdad/view/screen/address/saved_billing_Address_list_screen.dart';
import 'package:emdad/view/screen/checkout/widget/custom_check_box.dart';
import 'package:emdad/view/screen/dashboard/dashboard_screen.dart';
import 'package:provider/provider.dart';
import 'package:emdad/data/model/body/order_place_model.dart';

import '../../../../provider/auth_provider.dart';
import '../../../../provider/theme_provider.dart';
import '../../cart/widget/cartPaymentWidget.dart';
import '../../cart/widget/cart_widget.dart';



class cargo_widget extends StatefulWidget {
  String cargo;
  Widget time;

  final List<CartModel> cartList;
  final bool fromProductDetails;
  final double totalOrderAmount;
  final double shippingFee;
  final double discount;
  final double tax;
  final int sellerId;
  List<String> sellerList;
  final bool fromCheckout;
  List<List<CartModel>> cartProductList;
  List<List<int>> cartProductIndexList ;
  List<CartModel> sellerGroupList ;
  Widget cargoDetails;



  cargo_widget({
    @required this.cargoDetails,


    @required this.cargo,
    @required this.time,



    @required this.sellerList,
    @required this.cartProductList,

    @required this.fromCheckout,
    @required this.cartProductIndexList,

    @required this.sellerGroupList,



    @required this.cartList, this.fromProductDetails = false, @required this.discount, @required this.tax, @required this.totalOrderAmount, @required this.shippingFee, this.sellerId});


  @override
  _cargo_widgetState createState() => _cargo_widgetState();
}

class _cargo_widgetState extends State<cargo_widget> {

  bool isGuestMode;
  final GlobalKey<ScaffoldMessengerState> _scaffoldKey = GlobalKey<ScaffoldMessengerState>();
  final TextEditingController _controller = TextEditingController();
  final TextEditingController _orderNoteController = TextEditingController();

  final FocusNode _orderNoteNode = FocusNode();
  double _order = 0;
  double _orderCheckDouble = 0;
  double _minOrder = 50.000;
  String _orderCheck;
  bool _digitalPayment;
  bool _cod;
  bool _inFound;
  bool _cancelProduct;
  bool _billingAddress;
  bool _phoneverify;
  bool _switchValue=true;
  bool raqmy=false;
  @override
  void initState() {
    super.initState();
    isGuestMode = !Provider.of<AuthProvider>(context, listen: false).isLoggedIn();
    Provider.of<ProfileProvider>(context, listen: false).initAddressList(context);
    Provider.of<ProfileProvider>(context, listen: false).initAddressTypeList(context);
    Provider.of<CouponProvider>(context, listen: false).removePrevCouponData();
    Provider.of<CartProvider>(context, listen: false).getCartDataAPI(context);
    Provider.of<CartProvider>(context, listen: false).getChosenShippingMethod(context);
    Provider.of<ProfileProvider>(context, listen: false).getUserInfo(context);
    _digitalPayment = Provider.of<SplashProvider>(context, listen: false).configModel.digitalPayment;
    _cod = Provider.of<SplashProvider>(context, listen: false).configModel.cod;
    _inFound = Provider.of<SplashProvider>(context, listen: false).configModel.cod;
    _cancelProduct = true;
    _billingAddress = Provider.of<SplashProvider>(context, listen: false).configModel.billingAddress == 1;
    synAddress();
    //
    // Provider.of<OrderProvider>(context, listen: false).shippingAddressNull();
    // Provider.of<OrderProvider>(context, listen: false).billingAddressNull();
  }

  synAddress () async {
    if(Provider.of<ProfileProvider>(context, listen: false).addressList != null)
    {
      Provider.of<OrderProvider>(context, listen: false).setAddressIndex(0);
    }
  }
  final TextEditingController _taxController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    _order = widget.totalOrderAmount+widget.discount;
    _orderCheck = widget.totalOrderAmount.toStringAsFixed(3);
    _orderCheckDouble = double.parse(_orderCheck);
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Theme.of(context).highlightColor,
          elevation: 0,
          centerTitle: true,
          leading: IconButton(
            icon: Icon(Icons.arrow_back_ios, size: 20, color: Colors.black),
            onPressed: () => Navigator.of(context).pop(),
          ),
          title:  Text(widget.cargo,style: titilliumvBold.copyWith(fontSize: 12
              ,fontWeight: FontWeight.w700 ,color: Colors.black.withOpacity(0.6)
          ),),

        ),

        resizeToAvoidBottomInset: true,
        key: _scaffoldKey,
        // bottomNavigationBar: Container(
        //   height: 60,
        //   padding: EdgeInsets.symmetric(horizontal: Dimensions.PADDING_SIZE_LARGE, vertical: Dimensions.PADDING_SIZE_DEFAULT),
        //   decoration: BoxDecoration(
        //     color: ColorResources.getPrimary(context),
        //    ),
        //   child: Center(
        //     child: Consumer<OrderProvider>(
        //       builder: (context, order, child) {
        //       return !Provider.of<OrderProvider>(context).isLoading ? Builder(
        //         builder: (context) => InkWell(
        //           onTap: () async {
        //             print("_order: $_order");
        //             print("_orderCheck: $_orderCheck");
        //             print("_orderCheckDouble: $_orderCheckDouble");
        //
        //             if(Provider.of<OrderProvider>(context, listen: false).addressIndex == null) {
        //               ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(getTranslated('select_a_shipping_address', context)), backgroundColor: Colors.red));
        //             } else if(Provider.of<OrderProvider>(context, listen: false).billingAddressIndex == null && _billingAddress){
        //               ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(getTranslated('select_a_billing_address', context)), backgroundColor: Colors.red));
        //             } else if(Provider.of<ProfileProvider>(context, listen: false).userInfoModel.isDoc == 0 && Provider.of<ProfileProvider>(context, listen: false).userInfoModel.isDocReq == 0) {
        //               await showModalBottomSheet(
        //                 context: context, isScrollControlled: true, backgroundColor: Colors.transparent,
        //                 builder: (context) => CustomStepper(),
        //               );
        //             } else if(_orderCheckDouble < _minOrder) {
        //               ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("يجب ان يكون الطلب اكثر من  50  الف ريال"), backgroundColor: ColorResources.primaryColor));
        //             }  else if(Provider.of<OrderProvider>(context, listen: false).timeDeliveryIndex == 0) {
        //               await showModalBottomSheet(
        //                 context: context, isScrollControlled: true, backgroundColor: Colors.transparent,
        //                 builder: (context) => TimeDeliveryBottomSheet(groupId: 'all_cart_group',sellerIndex: 0, sellerId: 1),
        //               );
        //             } else {
        //               List<CartModel> _cartList = [];
        //               _cartList.addAll(widget.cartList);
        //               for(int index=0; index<widget.cartList.length; index++) {
        //                 for(int i=0; i<Provider.of<CartProvider>(context, listen: false).chosenShippingList.length; i++) {
        //                   if(Provider.of<CartProvider>(context, listen: false).chosenShippingList[i].cartGroupId == widget.cartList[index].cartGroupId) {
        //                     _cartList[index].shippingMethodId = Provider.of<CartProvider>(context, listen: false).chosenShippingList[i].id;
        //                     break;
        //                   }
        //                 }
        //               }
        //               String orderNote = _orderNoteController.text.trim();
        //               double couponDiscount = Provider.of<CouponProvider>(context, listen: false).discount != null ? Provider.of<CouponProvider>(context, listen: false).discount : 0;
        //               String couponCode = Provider.of<CouponProvider>(context, listen: false).discount != null ? Provider.of<CouponProvider>(context, listen: false).coupon.code : '';
        //               if(_cod && Provider.of<OrderProvider>(context, listen: false).paymentMethodIndex == 0) {
        //
        //                 Provider.of<OrderProvider>(context, listen: false).placeOrder(OrderPlaceModel(
        //                   CustomerInfo(
        //                     Provider.of<ProfileProvider>(context, listen: false).addressList[Provider.of<OrderProvider>(context, listen: false).addressIndex].id.toString(),
        //                     Provider.of<ProfileProvider>(context, listen: false).addressList[Provider.of<OrderProvider>(context, listen: false).addressIndex].address,
        //                     _billingAddress? Provider.of<ProfileProvider>(context, listen: false).billingAddressList[Provider.of<OrderProvider>(context, listen: false).billingAddressIndex].id.toString():
        //                     Provider.of<ProfileProvider>(context, listen: false).addressList[Provider.of<OrderProvider>(context, listen: false).addressIndex].id.toString(),
        //                     _billingAddress? Provider.of<ProfileProvider>(context, listen: false).billingAddressList[Provider.of<OrderProvider>(context, listen: false).billingAddressIndex].address:
        //                     Provider.of<ProfileProvider>(context, listen: false).addressList[Provider.of<OrderProvider>(context, listen: false).addressIndex].address,
        //                     orderNote,
        //                   ),
        //                   _cartList,
        //                   order.paymentMethodIndex == 0 ? 'cash_on_delivery' : '',
        //                   couponDiscount,
        //                   Provider.of<OrderProvider>(context, listen: false).timeDeliveryData,
        //                   Provider.of<OrderProvider>(context, listen: false).timeDeliveryData,
        //                 ),
        //
        //                 _callback,
        //                 _cartList,
        //                 Provider.of<ProfileProvider>(context, listen: false).addressList[Provider.of<OrderProvider>(context, listen: false).addressIndex].id.toString(),
        //                 couponCode,
        //                 _billingAddress? Provider.of<ProfileProvider>(context, listen: false).billingAddressList[Provider.of<OrderProvider>(context, listen: false).billingAddressIndex].id.toString():
        //                 Provider.of<ProfileProvider>(context, listen: false).addressList[Provider.of<OrderProvider>(context, listen: false).addressIndex].id.toString(),
        //                 orderNote );
        //                 Provider.of<OrderProvider>(context, listen: false).clearDeliveryTime();
        //               }
        //               else {
        //                 String userID = await Provider.of<ProfileProvider>(context, listen: false).getUserInfo(context);
        //                 Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => PaymentScreen(
        //                   customerID: userID,
        //                   addressID: Provider.of<ProfileProvider>(context, listen: false).addressList[Provider.of<OrderProvider>(context, listen: false).addressIndex].id.toString(),
        //                   couponCode: Provider.of<CouponProvider>(context, listen: false).discount != null ? Provider.of<CouponProvider>(context, listen: false).coupon.code : '',
        //                   billingId: _billingAddress? Provider.of<ProfileProvider>(context, listen: false).billingAddressList[Provider.of<OrderProvider>(context, listen: false).billingAddressIndex].id.toString():
        //                   Provider.of<ProfileProvider>(context, listen: false).addressList[Provider.of<OrderProvider>(context, listen: false).addressIndex].id.toString(),
        //                   orderNote: orderNote,
        //                 )));
        //               }
        //             }
        //           },
        //
        //           child: Text(getTranslated('proceed', context), style: titilliumSemiBold.copyWith(
        //             fontSize: Dimensions.FONT_SIZE_EXTRA_LARGE,
        //             color: Theme.of(context).cardColor,
        //           )),
        //         ),
        //       ) : Container(
        //         height: 30,width: 30 ,alignment: Alignment.center,
        //         child: CircularProgressIndicator(valueColor: AlwaysStoppedAnimation<Color>(Theme.of(context).highlightColor)),
        //       );
        //       },
        //     ),
        //   ),
        // ),

        body: SingleChildScrollView(
          physics: ScrollPhysics(),
          child: Container(
            width: double.infinity,
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Stack(
                  children:[ Column(
                    // mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,

                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 10.0 ,right: 10),
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.grey.withOpacity(0.1),

                            borderRadius: BorderRadius.circular(30.0),
                            /* border: Border(
      left: BorderSide()
    ),*/),
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text("وقت توصيل الشحنه   " , style: titilliumsemiBold.copyWith(fontSize: 10),),
                                Container(
                                  decoration: BoxDecoration(
                                    color: Colors.red.withOpacity(0.1),

                                    borderRadius: BorderRadius.circular(30.0),
                                    /* border: Border(
      left: BorderSide()
    ),*/),
                                    child: Padding(
                                      padding: const EdgeInsets.only(left: 5.0 ,right: 5),
                                      child: widget.time,
                                    )),
                              ],
                            ),
                          ),
                        ),
                      ),

                      widget.cargoDetails,

                       // ]),
                    ],
                  ),

                  ]),

            ),
          ),
        ));
  }

  void _callback(bool isSuccess, String message, String orderID, List<CartModel> carts) async {
    if(isSuccess) {
      Provider.of<ProductProvider>(context, listen: false).getLatestProductList(1, context, reload: true,);
      if(Provider.of<OrderProvider>(context, listen: false).paymentMethodIndex == 0) {
        Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => DashBoardScreen()), (route) => false);
        showAnimatedDialog(context, MyDialog(
          icon: Icons.check,
          title: getTranslated('order_placed', context),
          description: getTranslated('your_order_placed', context),
          isFailed: false,
        ), dismissible: false, isFlip: true);
        Provider.of<OrderProvider>(context, listen: false).clearConfirmPhone();
        Provider.of<OrderProvider>(context, listen: false).clearDeliveryTime();
      }else {

      }
      Provider.of<OrderProvider>(context, listen: false).stopLoader();
    }else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message), backgroundColor: ColorResources.RED));
    }
  }
}

class PaymentButton extends StatelessWidget {
  final String image;
  final Function onTap;
  PaymentButton({@required this.image, this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        height: 45,
        margin: EdgeInsets.symmetric(horizontal: Dimensions.PADDING_SIZE_EXTRA_SMALL),
        padding: EdgeInsets.all(Dimensions.PADDING_SIZE_EXTRA_SMALL),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          border: Border.all(width: 2, color: ColorResources.getGrey(context)),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Image.asset(image),
      ),
    );
  }
}

