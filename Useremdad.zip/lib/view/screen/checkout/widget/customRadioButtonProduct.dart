import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../provider/order_provider.dart';
class customRadioButtonProduct extends StatefulWidget {
  final int index;

  customRadioButtonProduct({ @required this.index});

  @override
  State<customRadioButtonProduct> createState() => _customRadioButtonProductState();
}

class _customRadioButtonProductState extends State<customRadioButtonProduct> {
  @override
  Widget build(BuildContext context) {

    return  Consumer<OrderProvider>(
        builder: (context, order, child) {
          bool ischecked= order.paymentMethodIndex == widget.index;
          return InkWell(
            onTap: (){order.setNotFoundProductMethod(widget.index);
            setState(() {
              ischecked= !ischecked;
                  (bool isChecked) => order.setNotFoundProductMethod(widget.index);
            });

            },
            child: Container(
              height: 15,
              width: 15,
              //color: Colors.grey.withOpacity(0.6),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                  border: Border.all(
                    color: Theme.of(context).primaryColor,
                  ),
                  borderRadius: BorderRadius.all(Radius.circular(20))
              ),
              child: Container(
                margin: EdgeInsets.all(2),
                //width: 7,
                // height: 7,
                //color: Theme.of(context).primaryColor,
                decoration: BoxDecoration(

                    color:
                    order.paymentMethodIndex == widget.index?
                    Theme.of(context).primaryColor:Colors.white,
                    border: Border.all(
                      color: order.paymentMethodIndex == widget.index?
                      Theme.of(context).primaryColor:Colors.white,
                    ),
                    borderRadius: BorderRadius.all(Radius.circular(20))
                ),


              ),

            ),
          );
        });}
}
