import 'package:emdad/view/screen/checkout/widget/taxnuberConfirmationDialog.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../../../utility/custom_themes.dart';
import '../../../basewidget/animated_custom_dialog.dart';

class taxField extends StatelessWidget {
  TextEditingController taxController = TextEditingController();
  taxField({@required this.taxController,});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: (){
        //showAnimatedDialog(context, QuantityConfirmationDialog(quantityItem:widget.cartModel.quantity.toString(), index: widget.index, isIncrement: true, quantity: widget.cartModel.quantity, maxQty: 20, cartModel: widget.cartModel),  isFlip: true);

        showAnimatedDialog(context, taxnumberConfirmationDialog(),isFlip: true);
      },
      child: Container(

          height: 40,

          decoration: BoxDecoration(
            color: Colors.grey.withOpacity(0.1),
            borderRadius: BorderRadius.circular(30),
            border: Border.all(width: .4,color: Colors.grey.withOpacity(0.3)),
            // boxShadow: [BoxShadow(color: Colors.grey, spreadRadius: 1, blurRadius: 1)],
          ),
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.symmetric(horizontal: 5),
          child: TextField(

            enabled: false,
            controller: taxController,
            textAlign: TextAlign.start,
            style: TextStyle(
              fontSize: 20.0,
            ),

            keyboardType: TextInputType.number,
            maxLines: 1,
            decoration: InputDecoration(

              hintText:"رقم التسجيل ضريبه القيمه المضافه",
              hintStyle: titilliumRegular.copyWith(color: Colors.grey.withOpacity(0.9), fontSize: 13),
              border: InputBorder.none,
            ),
          )
      ),
    );
  }
}
