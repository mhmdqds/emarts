import 'package:emdad/provider/order_provider.dart';
import 'package:emdad/provider/theme_provider.dart';
import 'package:emdad/utility/color_resources.dart';
import 'package:emdad/utility/custom_themes.dart';
import 'package:emdad/utility/dimensions.dart';
import 'package:emdad/utility/styles.dart';
import 'package:emdad/view/basewidget/button/custom_button.dart';
import 'package:emdad/view/basewidget/show_custom_snakbar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:emdad/localization/language_constrants.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../../../data/model/body/order_place_model.dart';
import '../../../../data/model/response/cart_model.dart';
import '../../../../helper/price_converter.dart';
import '../../../../provider/cart_provider.dart';
import '../../../../provider/coupon_provider.dart';
import '../../../../provider/profile_provider.dart';
import '../../../../utility/custom_themes.dart';
import '../../../basewidget/button/custom_button2.dart';
import '../../payment/payment_screen.dart';
import '../../tracking/tracking_result_screen.dart';
import '../../wallet/wallet_screen.dart';
import 'TimeDeliveryBottomSheet.dart';


class Done_payment_bottomsheet extends StatefulWidget {
  final List<CartModel> cartList;
  final bool fromProductDetails;
  final double amount;
  final double shippingAmount;
  final double discount;
  final double tax;
  final int sellerId;
  List<String> sellerList;
  final bool fromCheckout;
  List<List<CartModel>> cartProductList;
  List<List<int>> cartProductIndexList ;
  List<CartModel> sellerGroupList ;
  Widget company;
  Widget phone;

  bool isGuestMode;
  double order;
  double orderCheckDouble ;
  double minOrder ;
  String orderCheck;
  bool digitalPayment;
  bool cod;
  bool inFound;
  bool cancelProduct;
  bool billingAddress;
  bool phoneverify;
  bool switchValue;
  bool raqmy;
  TextEditingController orderNoteController;
  Function callback;





      Done_payment_bottomsheet({
    @required this.billingAddress,
    @required this.cancelProduct,
    @required this.cod,
    @required this.digitalPayment,
    @required this.inFound,
    @required this.minOrder,
    @required this.order,
    @required this.orderCheckDouble,
        @required this.orderCheck,
        @required this.phone,



        @required this.orderNoteController ,
        @required this.callback ,










        @required this.company,
    @required this.sellerList,
    @required this.cartProductList,
    @required this.isGuestMode,

    @required this.fromCheckout,
    @required this.cartProductIndexList,

    @required this.sellerGroupList,




    @required this.cartList, this.fromProductDetails = false, @required this.discount, @required this.tax, @required this.amount,
    @required this.shippingAmount, this.sellerId});




  @override
  _Done_payment_bottomsheetState createState() => _Done_payment_bottomsheetState();
}

class _Done_payment_bottomsheetState extends State<Done_payment_bottomsheet> {

  bool isChecked = false;
  bool isMorning = true;
  int selectedDate = -1;
  int timeSelectedIndex = -1;
  bool isVoiceCall = true;
  bool isMessage = false;
  bool isVideoCall = false;

  bool isTime = false;

  final GlobalKey<ScaffoldMessengerState> _scaffoldKey = GlobalKey<ScaffoldMessengerState>();





  @override
  void initState() {
    //Provider.of<CartProvider>(context,listen: false).getShippingMethod(context, widget.cart.sellerId,widget.sellerIndex);
    timeSelectedIndex = Provider.of<OrderProvider>(context, listen: false).timeDeliveryIndex;

    selectedDate = Provider.of<OrderProvider>(context, listen: false).dayDeliveryDataIndex;
    print("lllllllllllll");
    print( Provider.of<OrderProvider>(context, listen: false).timeDeliveryIndex);
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height *0.80,
      padding: EdgeInsets.all(Dimensions.PADDING_SIZE_SMALL),
      decoration: BoxDecoration(
        color: Theme.of(context).highlightColor,
        borderRadius: BorderRadius.only(topRight: Radius.circular(40), topLeft: Radius.circular(40)),
      ),
      child: SingleChildScrollView(
        physics:BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),

        child: Column( mainAxisSize: MainAxisSize.min, children: [

          Align(
            alignment: Alignment.centerRight,
            child: InkWell(
              onTap: () => Navigator.pop(context),
              child: Container(
                width: 25,
                height: 25,
                decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Theme.of(context).highlightColor,
                    boxShadow: [BoxShadow(color: Colors.grey[Provider.of<ThemeProvider>(context).darkTheme ? 700 : 200], spreadRadius: 1, blurRadius: 10)]),
                child: Icon(Icons.clear, size: Dimensions.ICON_SIZE_SMALL),
              ),
            ),
          ),

          Text("تأكيد الطلب", style: titilliumvBold.copyWith(fontSize: Dimensions.FONT_SIZE_EXTRA_SMALL ,fontWeight: FontWeight.w800)),
          Container(
            margin: EdgeInsets.only(right: Dimensions.MARGIN_SIZE_DEFAULT, left: Dimensions.MARGIN_SIZE_DEFAULT, top: Dimensions.MARGIN_SIZE_EXTRA_SMALL),
            child: Text("هانت اخر خطوه",
              style: titilliumSemiBold.copyWith(color: ColorResources.COLOR_GREY.withOpacity(0.5), fontSize: Dimensions.FONT_SIZE_SMALL),
            ),
          ),

          Container(
            margin: EdgeInsets.only(right: Dimensions.MARGIN_SIZE_DEFAULT, left: Dimensions.MARGIN_SIZE_DEFAULT, top: Dimensions.MARGIN_SIZE_EXTRA_SMALL),
            child: Row(

              children: [
                CircleAvatar(
                  backgroundColor: ColorResources.grey_153.withOpacity(0.2),
                  radius:15,

                  child: Icon(Icons.fire_truck , size: 15 ,color: Colors.black.withOpacity(0.7)),
                ),
                SizedBox(width: 10,),
                Text("لديك شحنات متعدده ، قد تصلك فى اوقات مختلفه",
                  style:  titilliumvBold.copyWith(fontSize: Dimensions.FONT_SIZE_EXTRA_SMALLest ,fontWeight: FontWeight.w700)
                ),
              ],
            ),
          ),
          SizedBox(
            height: 0,
          ),

          Container(
            child: Padding(
              padding: const EdgeInsets.only(top: 15.0 ,left:15  ,right:15 ),
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    Container(
                        height: 130,
                        width: MediaQuery.of(context).size.width,
                        //padding: EdgeInsets.all(Dimensions.HOME_PAGE_PADDING),
                        decoration: BoxDecoration(
                          color: Theme.of(context).highlightColor,
                          borderRadius: BorderRadius.all(
                              Radius.circular(20)),
                          border: Border.all(
                              width: 0.5,
                              color:Colors.grey.withOpacity(0.5)),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(0.0),
                          child: Column(
                              crossAxisAlignment:
                              CrossAxisAlignment.stretch,
                              children: [
                                Padding(
                                  padding:
                                  const EdgeInsets.all(8.0),
                                  child: Row(
                                      mainAxisAlignment:
                                      MainAxisAlignment
                                          .spaceBetween,
                                      mainAxisSize:
                                      MainAxisSize.min,
                                      children: [
                                        Text(
                                            getTranslated(
                                                'itemTotalPrice',
                                                context),
                                            textAlign:
                                            TextAlign.end,
                                            style: titilliumsemiBold
                                                .copyWith(
                                              fontSize: Dimensions
                                                    .FONT_SIZE_EXTRA_SMALLest,
                                            )),
                                        Text(
                                          PriceConverter.convertPrice(
                                              context,
                                              widget.amount ),
                                          style: titilliumsemiBold
                                              .copyWith(
                                              color: Theme.of(
                                                  context)
                                                  .primaryColor,
                                              fontSize: Dimensions
                                                  .FONT_SIZE_EXTRA_SMALLest),
                                        ),
                                      ]),
                                ),
                                Padding(
                                  padding:
                                  const EdgeInsets.all(8.0),
                                  child: Row(
                                      mainAxisAlignment:
                                      MainAxisAlignment
                                          .spaceBetween,
                                      mainAxisSize:
                                      MainAxisSize.min,
                                      children: [
                                        Text("رسوم التوصيل",
                                            textAlign:
                                            TextAlign.end,
                                            style: titilliumsemiBold
                                                .copyWith(
                                              fontSize: Dimensions
                                                  .FONT_SIZE_EXTRA_SMALLest,
                                            )),
                                        Text(
                                          PriceConverter
                                              .convertPrice(context,
                                              widget.shippingAmount),
                                          style: titilliumsemiBold
                                              .copyWith(
                                              color: Theme.of(
                                                  context)
                                                  .primaryColor,
                                              fontSize: Dimensions
                                                  .FONT_SIZE_EXTRA_SMALLest),
                                        ),
                                      ]),
                                ),
                                Expanded(
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: Color(0xfff2f2f2),
                                      borderRadius:
                                      BorderRadius.only(
                                          bottomRight:
                                          Radius.circular(
                                              15),
                                          bottomLeft:
                                          Radius.circular(
                                              15)),
                                      border: Border.all(
                                          width: 0.5,
                                          color: Color(0xfff2f2f2)),
                                    ),
                                    // color: Color(0xfff2f2f2),
                                    child: Padding(
                                      padding:
                                      const EdgeInsets.all(8.0),
                                      child: Row(
                                          mainAxisAlignment:
                                          MainAxisAlignment
                                              .spaceBetween,
                                          mainAxisSize:
                                          MainAxisSize.min,
                                          children: [
                                            Text("الاجمالي",
                                                textAlign:
                                                TextAlign.end,
                                                style:
                                                titilliumvBold
                                                    .copyWith(
                                                  fontSize: Dimensions
                                                      .FONT_SIZE_EXTRA_SMALLest,
                                                )),
                                            Text(
                                              PriceConverter
                                                  .convertPrice(
                                                  context,
                                                  widget.amount+widget.shippingAmount),
                                              style: titilliumsemiBold.copyWith(
                                                  color: Theme.of(
                                                      context)
                                                      .primaryColor,
                                                  fontSize: Dimensions
                                                      .FONT_SIZE_EXTRA_SMALLest),
                                            ),
                                          ]),
                                    ),
                                  ),
                                ),
                              ]),
                        )),
                    SizedBox(
                      height: 15,
                    ),

                  ],
                ),
              ),
            ),
          ),
          SizedBox(
            height: 0,
          ),
          Container(
            child: Padding(
              padding: const EdgeInsets.only(top: 8.0 ,left:15  ,right:15 ),
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    Container(
                        height: 135,
                        width: MediaQuery.of(context).size.width,
                        //padding: EdgeInsets.all(Dimensions.HOME_PAGE_PADDING),
                        decoration: BoxDecoration(
                          color: Theme.of(context).highlightColor,
                          borderRadius: BorderRadius.all(
                              Radius.circular(20)),
                          border: Border.all(
                              width: 0.5,
                              color:Colors.grey.withOpacity(0.5)),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(0.0),
                          child: Column(
                              crossAxisAlignment:
                              CrossAxisAlignment.stretch,
                              children: [
                                Padding(
                                  padding:
                                  const EdgeInsets.all(8.0),
                                  child: Row(
                                      mainAxisAlignment:
                                      MainAxisAlignment
                                          .spaceBetween,
                                      mainAxisSize:
                                      MainAxisSize.min,
                                      children: [
                                        Text(
                                           "طريقه الدفع",
                                            textAlign:
                                            TextAlign.end,
                                            style: titilliumvBold
                                                .copyWith(
                                              color: Colors.grey.withOpacity(0.6),
                                              fontSize: Dimensions
                                                  .FONT_SIZE_EXTRA_SMALL,
                                            )),
                                      ]),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(left: 230.0 ,right: 10  ,top: 8,bottom: 8) ,
                                  child: Container(

                                    decoration: BoxDecoration(
                                      color: Color(0xfff2f2f2),

                                      border: Border.all(width: 0,                                   color: Color(0xfff2f2f2),

                                      ),
                                      borderRadius: BorderRadius.circular(15),
                                    ),
                                    width: 6,
                                    child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Row(
                                          mainAxisAlignment:
                                          MainAxisAlignment
                                              .start,
                                          mainAxisSize:
                                          MainAxisSize.min,
                                          children: [
                                            Icon(Icons.monetization_on_outlined , size: 20 ,color: Colors.blueAccent.withOpacity(0.4)),
                                            SizedBox(width: 10,),
                                            Provider.of<OrderProvider>(context, listen: false).paymentMethodIndex == 1?
                                            Text("رقميا",
                                                textAlign:
                                                TextAlign.end,
                                                style: titilliumsemiBold
                                                    .copyWith(
                                                  fontSize: Dimensions
                                                      .FONT_SIZE_EXTRA_SMALLest,
                                                )) :
                                            Text("نقدا",
                                                textAlign:
                                                TextAlign.end,
                                                style: titilliumsemiBold
                                                    .copyWith(
                                                  fontSize: Dimensions
                                                      .FONT_SIZE_EXTRA_SMALLest,
                                                ))


                                          ]),
                                    ),
                                  ),
                                ),
                                Expanded(
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: Color(0xfff2f2f2),
                                      borderRadius:
                                      BorderRadius.only(
                                          bottomRight:
                                          Radius.circular(
                                              15),
                                          bottomLeft:
                                          Radius.circular(
                                              15)),
                                      border: Border.all(
                                          width: 0.5,
                                          color: Color(0xfff2f2f2)),
                                    ),
                                    // color: Color(0xfff2f2f2),
                                    child: Padding(
                                      padding:
                                      const EdgeInsets.all(8.0),
                                      child: Row(
                                          mainAxisAlignment:
                                          MainAxisAlignment
                                              .start,
                                          mainAxisSize:
                                          MainAxisSize.min,
                                          children: [
                                            Text("المبلغ المطلوب",
                                                textAlign:
                                                TextAlign.end,
                                                style:
                                                titilliumsemiBold
                                                    .copyWith(
                                                  fontSize: Dimensions
                                                      .FONT_SIZE_EXTRA_SMALLest,
                                                )),
                                            SizedBox(width: 5,),

                                            Text(
                                              PriceConverter
                                                  .convertPrice(
                                                  context,
                                                  widget.amount+widget.shippingAmount),
                                              style: titilliumsemiBold.copyWith(
                                                  color: Theme.of(
                                                      context)
                                                      .primaryColor,
                                                  fontSize: Dimensions
                                                      .FONT_SIZE_EXTRA_SMALLest),
                                            ),
                                          ]),
                                    ),
                                  ),
                                ),
                              ]),
                        )),
                    SizedBox(
                      height: 15,
                    ),

                  ],
                ),
              ),
            ),
          ),
          Container(
            child: Padding(
              padding: const EdgeInsets.only(top: 8.0 ,left:15  ,right:15 ),
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    Container(
                       // height: 100,
                        width: MediaQuery.of(context).size.width,
                        //padding: EdgeInsets.all(Dimensions.HOME_PAGE_PADDING),
                        decoration: BoxDecoration(
                          color: Theme.of(context).highlightColor,
                          borderRadius: BorderRadius.all(
                              Radius.circular(20)),
                          border: Border.all(
                              width: 0.5,
                              color:Colors.grey.withOpacity(0.5)),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Column(
                              crossAxisAlignment:
                              CrossAxisAlignment.stretch,
                              children: [
                                Padding(
                                  padding:
                                  const EdgeInsets.all(8.0),
                                  child: Row(
                                      mainAxisAlignment:
                                      MainAxisAlignment
                                          .spaceBetween,
                                      mainAxisSize:
                                      MainAxisSize.min,
                                      children: [
                                        Text(
                                            "رقم الجوال" ,
                                            textAlign:
                                            TextAlign.end,
                                            style: titilliumsemiBold
                                                .copyWith(
                                              fontSize: Dimensions
                                                  .FONT_SIZE_EXTRA_SMALLest,
                                            )),
                                        widget.phone ,
                                      ]),
                                ),
                                Padding(
                                  padding:
                                  const EdgeInsets.all(8.0),
                                  child: Row(
                                      mainAxisAlignment:
                                      MainAxisAlignment
                                          .spaceBetween,
                                      mainAxisSize:
                                      MainAxisSize.min,
                                      children: [
                                        Text(   "اسم المنشأه" ,

                                            textAlign:
                                            TextAlign.end,
                                            style: titilliumsemiBold
                                                .copyWith(
                                              fontSize: Dimensions
                                                  .FONT_SIZE_EXTRA_SMALLest,
                                            )),
                                        widget.company ,

                                        //SizedBox(width: 3,)
                                      ]),
                                ),



                              ]),
                        )),
                    SizedBox(
                      height: 10
                    ),
                    Container(
                      height: 85,
                      padding: EdgeInsets.all(15),
                      width: 300,
                      child:

                      Consumer<OrderProvider>(
                          builder: (context, order, child) {
                            return !Provider
                                .of<OrderProvider>(context)
                                .isLoading ?
                            FloatingActionButton(
                              backgroundColor: Theme
                                  .of(context)
                                  .primaryColor,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.all(Radius.circular(30.0))),
                              onPressed: ()async {

                                print("_order: ${widget.order}");
                                print("_orderCheck: ${widget.orderCheck}");
                                print("_orderCheckDouble: ${widget.orderCheckDouble}");

                                if(Provider.of<OrderProvider>(context, listen: false).addressIndex == null) {
                                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(getTranslated('select_a_shipping_address', context)), backgroundColor: Colors.red));
                                } else if(Provider.of<OrderProvider>(context, listen: false).billingAddressIndex == null && widget.billingAddress){
                                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(getTranslated('select_a_billing_address', context)), backgroundColor: Colors.red));
                                } else if(Provider.of<ProfileProvider>(context, listen: false).userInfoModel.isDoc == 0 && Provider.of<ProfileProvider>(context, listen: false).userInfoModel.isDocReq == 0) {
                                  await showModalBottomSheet(
                                    context: context, isScrollControlled: true, backgroundColor: Colors.transparent,
                                    builder: (context) => CustomStepper(),
                                  );
                                } else if(widget.orderCheckDouble < widget.minOrder) {
                                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("يجب ان يكون الطلب اكثر من  50  الف ريال"), backgroundColor: ColorResources.primaryColor));
                                }  else if(Provider.of<OrderProvider>(context, listen: false).timeDeliveryIndex == 0) {
                                  await showModalBottomSheet(
                                    context: context, isScrollControlled: true, backgroundColor: Colors.transparent,
                                    builder: (context) => TimeDeliveryBottomSheet(groupId: 'all_cart_group',sellerIndex: 0, sellerId: 1),
                                  );
                                } else {
                                  List<CartModel> _cartList = [];
                                  _cartList.addAll(widget.cartList);
                                  for(int index=0; index<widget.cartList.length; index++) {
                                    for(int i=0; i<Provider.of<CartProvider>(context, listen: false).chosenShippingList.length; i++) {
                                      if(Provider.of<CartProvider>(context, listen: false).chosenShippingList[i].cartGroupId == widget.cartList[index].cartGroupId) {
                                        _cartList[index].shippingMethodId = Provider.of<CartProvider>(context, listen: false).chosenShippingList[i].id;
                                        break;
                                      }
                                    }
                                  }
                                  String orderNote = widget.orderNoteController.text.trim();
                                  double couponDiscount = Provider.of<CouponProvider>(context, listen: false).discount != null ? Provider.of<CouponProvider>(context, listen: false).discount : 0;
                                  String couponCode = Provider.of<CouponProvider>(context, listen: false).discount != null ? Provider.of<CouponProvider>(context, listen: false).coupon.code : '';
                                  if(widget.cod && Provider.of<OrderProvider>(context, listen: false).paymentMethodIndex == 0) {
                                    print("kkkkkkkkkkkkkkkkkkkkkkkk2");
                                    Provider.of<OrderProvider>(context, listen: false).placeOrder(OrderPlaceModel(
                                      CustomerInfo(
                                        Provider.of<ProfileProvider>(context, listen: false).addressList[Provider.of<OrderProvider>(context, listen: false).addressIndex].id.toString(),
                                        Provider.of<ProfileProvider>(context, listen: false).addressList[Provider.of<OrderProvider>(context, listen: false).addressIndex].address,
                                        widget.billingAddress? Provider.of<ProfileProvider>(context, listen: false).billingAddressList[Provider.of<OrderProvider>(context, listen: false).billingAddressIndex].id.toString():
                                        Provider.of<ProfileProvider>(context, listen: false).addressList[Provider.of<OrderProvider>(context, listen: false).addressIndex].id.toString(),
                                        widget.billingAddress? Provider.of<ProfileProvider>(context, listen: false).billingAddressList[Provider.of<OrderProvider>(context, listen: false).billingAddressIndex].address:
                                        Provider.of<ProfileProvider>(context, listen: false).addressList[Provider.of<OrderProvider>(context, listen: false).addressIndex].address,
                                        orderNote,
                                      ),
                                      _cartList,
                                      order.paymentMethodIndex == 0 ? 'cash_on_delivery' : '',
                                      couponDiscount,
                                      Provider.of<OrderProvider>(context, listen: false).timeDeliveryData,
                                      Provider.of<OrderProvider>(context, listen: false).timeDeliveryData,
                                    ),

                                        widget.callback,

                                        _cartList,
                                        Provider.of<ProfileProvider>(context, listen: false).addressList[Provider.of<OrderProvider>(context, listen: false).addressIndex].id.toString(),
                                        couponCode,
                                        widget.billingAddress? Provider.of<ProfileProvider>(context, listen: false).billingAddressList[Provider.of<OrderProvider>(context, listen: false).billingAddressIndex].id.toString():
                                        Provider.of<ProfileProvider>(context, listen: false).addressList[Provider.of<OrderProvider>(context, listen: false).addressIndex].id.toString(),
                                        orderNote );
                                    print("doneeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");

                                    Provider.of<OrderProvider>(context, listen: false).clearDeliveryTime();
                                  }
                                  else if(widget.cod && Provider.of<OrderProvider>(context, listen: false).paymentMethodIndex == 1){
                                    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => WalletScreen()));

                                        }
                                  else {
                                    print("kkkkkkkkkkkkkkkkkkkkkkkk");

                                    String userID = await Provider.of<ProfileProvider>(context, listen: false).getUserInfo(context);
                                    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => PaymentScreen(
                                      customerID: userID,
                                      addressID: Provider.of<ProfileProvider>(context, listen: false).addressList[Provider.of<OrderProvider>(context, listen: false).addressIndex].id.toString(),
                                      couponCode: Provider.of<CouponProvider>(context, listen: false).discount != null ? Provider.of<CouponProvider>(context, listen: false).coupon.code : '',
                                      billingId: widget.billingAddress? Provider.of<ProfileProvider>(context, listen: false).billingAddressList[Provider.of<OrderProvider>(context, listen: false).billingAddressIndex].id.toString():
                                      Provider.of<ProfileProvider>(context, listen: false).addressList[Provider.of<OrderProvider>(context, listen: false).addressIndex].id.toString(),
                                      orderNote: orderNote,
                                    )));
                                }
                                }
                              },
                              child: Padding(
                                padding: const EdgeInsets.only(left: 15, right: 15),
                                child: Row(
                                  // mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Expanded(
                                        child: Text(
                                          " يلا نكمل الدفع !",
                                          style: titilliumvBold.copyWith(
                                            fontSize: 12,
                                            color: Colors.white,
                                          ),
                                          textAlign: TextAlign.center,
                                        )),

                                  ],
                                ),
                              ),
                            ) : Center(child: CupertinoActivityIndicator(radius: 20.0
                                , color: ColorResources.primaryColor,
                                animating: true));
                          }),
                    ),

                  ],
                ),
              ),
            ),
          ),





        ]),
      ),
    );
  }
}
