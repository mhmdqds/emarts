import 'package:emdad/provider/order_provider.dart';
import 'package:emdad/provider/theme_provider.dart';
import 'package:emdad/utility/color_resources.dart';
import 'package:emdad/utility/custom_themes.dart';
import 'package:emdad/utility/dimensions.dart';
import 'package:emdad/utility/styles.dart';
import 'package:emdad/view/basewidget/button/custom_button.dart';
import 'package:emdad/view/basewidget/show_custom_snakbar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:emdad/localization/language_constrants.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../../../utility/custom_themes.dart';
import '../../../basewidget/button/custom_button2.dart';

List weekdays = [
  "غدا",
  DateFormat('EEEE').format(DateTime.now().add(Duration(days: 2))),
  DateFormat('EEEE').format(DateTime.now().add(Duration(days: 3))),
  DateFormat('EEEE').format(DateTime.now().add(Duration(days: 4))),
  DateFormat('EEEE').format(DateTime.now().add(Duration(days: 5))),
  DateFormat('EEEE').format(DateTime.now().add(Duration(days: 6))),
  DateFormat('EEEE').format(DateTime.now().add(Duration(days: 7))),
];
List timeToDelivery = [
  ' ص 12:00-ص 8:00',
  'م 6:00-م 5:00',
];

class TimeDeliveryBottomSheet extends StatefulWidget {
  final String groupId;
  final int sellerId;
  final int sellerIndex;

  TimeDeliveryBottomSheet({@required this.groupId, @required this.sellerId, @required this.sellerIndex});

  @override
  _TimeDeliveryBottomSheetState createState() => _TimeDeliveryBottomSheetState();
}

class _TimeDeliveryBottomSheetState extends State<TimeDeliveryBottomSheet> {

  bool isChecked = false;
  bool isMorning = true;
  int selectedDate = -1;
  int timeSelectedIndex = -1;
  bool isVoiceCall = true;
  bool isMessage = false;
  bool isVideoCall = false;

  bool isTime = false;

  final GlobalKey<ScaffoldMessengerState> _scaffoldKey = GlobalKey<ScaffoldMessengerState>();





  @override
  void initState() {
    //Provider.of<CartProvider>(context,listen: false).getShippingMethod(context, widget.cart.sellerId,widget.sellerIndex);
    timeSelectedIndex = Provider.of<OrderProvider>(context, listen: false).timeDeliveryIndex;

    selectedDate = Provider.of<OrderProvider>(context, listen: false).dayDeliveryDataIndex;
    print("lllllllllllll");
    print( Provider.of<OrderProvider>(context, listen: false).timeDeliveryIndex);
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Container(
          height: MediaQuery.of(context).size.height *0.45,
          padding: EdgeInsets.all(Dimensions.PADDING_SIZE_SMALL),
          decoration: BoxDecoration(
            color: Theme.of(context).highlightColor,
            borderRadius: BorderRadius.only(topRight: Radius.circular(30), topLeft: Radius.circular(30)),
          ),
          child: Column( mainAxisSize: MainAxisSize.min, children: [

            Align(
              alignment: Alignment.centerRight,
              child: InkWell(
                onTap: () => Navigator.pop(context),
                child: Container(
                  width: 25,
                  height: 25,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Theme.of(context).highlightColor,
                      boxShadow: [BoxShadow(color: Colors.grey[Provider.of<ThemeProvider>(context).darkTheme ? 700 : 200], spreadRadius: 1, blurRadius: 10)]),
                  child: Icon(Icons.clear, size: Dimensions.ICON_SIZE_SMALL),
                ),
              ),
            ),

            Text("اختر وقت التوصيل", style: titilliumvBold.copyWith(fontSize: 16 ,fontWeight: FontWeight.w500)),
            Container(
              margin: EdgeInsets.only(right: Dimensions.MARGIN_SIZE_DEFAULT, left: Dimensions.MARGIN_SIZE_DEFAULT, top: Dimensions.MARGIN_SIZE_DEFAULT),
              child: Text("اختر اليوم",
                style: titilliumSemiBold.copyWith(color: ColorResources.COLOR_GREY.withOpacity(0.5), fontSize: Dimensions.FONT_SIZE_SMALL),
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Container(
              height: 40,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                shrinkWrap: true,
                itemCount: weekdays.length,
                itemBuilder: (context, index) => InkWell(
                  onTap: () {
                    setState(() {
                      selectedDate = index;
                    });
                  },
                  child: Container(
                    width: 60,
                    height: 10,
                    margin: EdgeInsets.all(2),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: Colors.white,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.1),
                            spreadRadius: 1,
                            blurRadius: 1,
                            offset: Offset(0, 1), // changes position of shadow
                          ),
                        ],
                      borderRadius: BorderRadius.all(Radius.circular(30)),
                      border: Border.all(width: 1, color:selectedDate == index ? ColorResources.COLOR_PRIMARY : ColorResources.grey_153,

                      ),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                    weekdays[index].toString()=="غدا"?
                    weekdays[index].toString():
                            getTranslated(weekdays[index], context),
                            style: khulaSemiBold.copyWith(
                                color:selectedDate == index ? ColorResources.COLOR_PRIMARY : ColorResources.grey_153,                                fontSize: 10
                            )),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Container(
              margin: EdgeInsets.only(right: Dimensions.MARGIN_SIZE_DEFAULT, left: Dimensions.MARGIN_SIZE_DEFAULT, top: Dimensions.MARGIN_SIZE_DEFAULT),
              child: Text("إختر الوقت",
                style: khulaSemiBold.copyWith(color:ColorResources.COLOR_GREY.withOpacity(0.5), fontSize: Dimensions.FONT_SIZE_SMALL),
              ),
            ),
            SizedBox(
              height: 20,
            ),

            Padding(
              padding: const EdgeInsets.only(right: 15.0),
              child: Container(
                width: MediaQuery.of(context).size.width,
                height: 40,
                child: ListView.separated(
                  separatorBuilder: (BuildContext cxt,int index)=>SizedBox(width: 10,),
                  scrollDirection: Axis.horizontal,
                  shrinkWrap: true,
                  itemCount: timeToDelivery.length,
                  itemBuilder: (context, index) => InkWell(
                    onTap: () {
                      setState(() {
                        timeSelectedIndex = index;
                      //  print( Provider.of<OrderProvider>(context, listen: false).timeDeliveryIndex);

                      });
                    },
                    child: Container(
                      padding: EdgeInsets.all(2),
                      height: 35,

                      width: MediaQuery.of(context).size.width * 0.40,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.1),
                            spreadRadius: 1,
                            blurRadius: 1,
                            offset: Offset(0, 1), // changes position of shadow
                          ),
                        ],
                        borderRadius: BorderRadius.all(Radius.circular(30)),
                        border: Border.all(width: 1,  color:timeSelectedIndex == index ? ColorResources.COLOR_PRIMARY : ColorResources.grey_153,)
                      ),
                      child: Text(
                          DateTime.now().day== index?
                              "غدا":
                          timeToDelivery[index].toString(),
                          textAlign: TextAlign.center,
                          style: titilliumvBold.copyWith(
                            fontSize: 10,
                            color:timeSelectedIndex == index ? ColorResources.COLOR_PRIMARY : ColorResources.grey_153,                        ) ),
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Provider.of<OrderProvider>(context).isLoadingTime
                ? Center(child: CircularProgressIndicator(valueColor: AlwaysStoppedAnimation<Color>(Theme.of(context).primaryColor)))
                : Builder(
                 key: _scaffoldKey,
                 builder: (context) => CustomButton2(
                  buttonText: "أكد الوقت",
                  onTap: () {
                    setState(() {

                    });
                    if (selectedDate == -1) {
                      showCustomSnackBarOrder('يجب اختيار اليوم والوقت', context, isError: false);
                    } else if (timeSelectedIndex == -1) {
                      showCustomSnackBarOrder('يجب اختيار اليوم والوقت', context, isError: false);
                    } else {
                      Provider.of<OrderProvider>(context, listen: false).setDeliveryTimeInfo(context, timeSelectedIndex, selectedDate, timeToDelivery[timeSelectedIndex].toString(), weekdays[selectedDate].toString());
                      Provider.of<OrderProvider>(context, listen: false).setDeliveryTime();
                      Navigator.pop(context);
                    }
                  }),
            ),
          ]),
        );
  }
}
