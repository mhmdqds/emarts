import 'package:emdad/data/model/response/cart_model.dart';
import 'package:emdad/provider/cart_provider.dart';
import 'package:flutter/material.dart';
import 'package:emdad/localization/language_constrants.dart';
import 'package:emdad/utility/color_resources.dart';
import 'package:emdad/utility/custom_themes.dart';
import 'package:emdad/utility/dimensions.dart';
import 'package:provider/provider.dart';

class taxnumberConfirmationDialog extends StatelessWidget {

  TextEditingController taxController = TextEditingController();
 // taxnumberConfirmationDialog();
  taxnumberConfirmationDialog({@required this.taxController,});



  @override
  Widget build(BuildContext context) {
    return Container(
      height: 150,
      child: Stack(
        children:[
          Positioned(
              right: 140,
              top: 220,
              child: Container(

                width: 60,
                height: 20,
                decoration: BoxDecoration(
                  color: Colors.transparent,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(width: .4,color: Colors.white),
                  // boxShadow: [BoxShadow(color: Colors.grey, spreadRadius: 1, blurRadius: 1)],
                ),
                child: DefaultTextStyle(
                    style:titilliumvBold.copyWith(fontSize: 10,color: Colors.white),
                    child: Text("اغلاق",textAlign:TextAlign.center),),),),
          Dialog(
              // insetPadding: EdgeInsets.all(20),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
          child: Container(
            padding: EdgeInsets.all(20),
            height: 200,
            child: Column(
                children: [

              Text('الرقم الضريبي', style: titilliumvBold.copyWith(fontSize: Dimensions.FONT_SIZE_LARGE,color: Colors.black.withOpacity(0.67)), textAlign: TextAlign.center),
                  SizedBox(height: 16,),
                  Container(
                      width: 200,
                      height: 36,
                      decoration: BoxDecoration(
                        color: Colors.grey.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(30),
                        border: Border.all(width: .4,color: Colors.grey.withOpacity(0.3)),
                        // boxShadow: [BoxShadow(color: Colors.grey, spreadRadius: 1, blurRadius: 1)],
                      ),
                      alignment: Alignment.centerLeft,
                      padding: EdgeInsets.symmetric(horizontal: 5),
                      child: TextField(
                        controller: taxController,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 20.0,
                        ),
                        keyboardType: TextInputType.number,
                        maxLines: 1,
                        decoration: InputDecoration(
                          hintText: "رقم تسجيل ضريبه القيمه المضافه",
                          hintStyle: titilliumvBold.copyWith(color: Colors.grey.withOpacity(0.8), fontSize: 10),
                          border: InputBorder.none,
                        ),
                      )
                  ),
              SizedBox(height: 20,),

              Column(
                children: [
                  Container(
                    width: double.infinity,
                    height: 35,
                    decoration: BoxDecoration(
                      color: Theme.of(context).primaryColor,
                      borderRadius: BorderRadius.circular(30),
                      border: Border.all(width: .4,color: Theme.of(context).primaryColor),
                      // boxShadow: [BoxShadow(color: Colors.grey, spreadRadius: 1, blurRadius: 1)],
                    ),
                    child: MaterialButton(
                      onPressed: (){
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                            content: Text("message"),
                          ));

                        Navigator.pop(context);
                      },
                      child:Text('تمام',
                          style: titilliumBold.copyWith(color: Colors.white)) ,

                    ),
                  ),



                ],

              )
              // ,Divider(height: 0, color: ColorResources.HINT_TEXT_COLOR),
              // Row(children: [
              //
              //   Expanded(child: InkWell(
              //     onTap: () {
              //       Provider.of<CartProvider>(context, listen: false).updateCartProductQuantity(cartModel.id, int.parse(_quantityController.text), context).then((value) {
              //         ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              //           content: Text(value.message), backgroundColor: value.isSuccess ? Colors.green : Colors.red,
              //         ));
              //       });
              //       Navigator.pop(context);
              //     },
              //     child: Container(
              //       padding: EdgeInsets.all(Dimensions.PADDING_SIZE_SMALL),
              //       alignment: Alignment.center,
              //       decoration: BoxDecoration(borderRadius: BorderRadius.only(bottomLeft: Radius.circular(10))),
              //       child: Text(getTranslated('set_quantity', context),
              //           style: titilliumBold.copyWith(color: Theme.of(context).primaryColor)),
              //     ),
              //   )),
              //
              //   Expanded(child: InkWell(
              //     onTap: () => Navigator.pop(context),
              //     child: Container(
              //       padding: EdgeInsets.all(Dimensions.PADDING_SIZE_SMALL),
              //       alignment: Alignment.center,
              //       decoration: BoxDecoration(color: ColorResources.RED, borderRadius: BorderRadius.only(bottomRight: Radius.circular(10))),
              //       child: Text(getTranslated('cancel', context), style: titilliumBold.copyWith(color: ColorResources.WHITE)),
              //     ),
              //   )),
              //
              // ]),
            ]),
          ),
        ),


        ]
      ),
    );
  }
}