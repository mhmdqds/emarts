import 'package:emdad/provider/order_provider.dart';
import 'package:emdad/provider/theme_provider.dart';
import 'package:emdad/utility/color_resources.dart';
import 'package:emdad/utility/custom_themes.dart';
import 'package:emdad/utility/dimensions.dart';
import 'package:emdad/utility/styles.dart';
import 'package:emdad/view/basewidget/button/custom_button.dart';
import 'package:emdad/view/basewidget/show_custom_snakbar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:emdad/localization/language_constrants.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../../../utility/custom_themes.dart';
import '../../../basewidget/button/custom_button2.dart';
import '../../tread_info/steppers_dots.dart';



class CartBottomSheet extends StatefulWidget {
  final String groupId;
  final int sellerId;
  final int sellerIndex;

  CartBottomSheet({@required this.groupId, @required this.sellerId, @required this.sellerIndex});

  @override
  _CartBottomSheetState createState() => _CartBottomSheetState();
}

class _CartBottomSheetState extends State<CartBottomSheet> {

  bool isChecked = false;
  bool isMorning = true;
  int selectedDate = -1;
  int timeSelectedIndex = -1;
  bool isVoiceCall = true;
  bool isMessage = false;
  bool isVideoCall = false;

  bool isTime = false;

  final GlobalKey<ScaffoldMessengerState> _scaffoldKey = GlobalKey<ScaffoldMessengerState>();





  @override
  void initState() {
    //Provider.of<CartProvider>(context,listen: false).getShippingMethod(context, widget.cart.sellerId,widget.sellerIndex);
    timeSelectedIndex = Provider.of<OrderProvider>(context, listen: false).timeDeliveryIndex;

    selectedDate = Provider.of<OrderProvider>(context, listen: false).dayDeliveryDataIndex;
    print("lllllllllllll");
    print( Provider.of<OrderProvider>(context, listen: false).timeDeliveryIndex);
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height *0.62,
      padding: EdgeInsets.all(Dimensions.PADDING_SIZE_SMALL),
      decoration: BoxDecoration(
        color: Theme.of(context).highlightColor,
        borderRadius: BorderRadius.only(topRight: Radius.circular(45), topLeft: Radius.circular(45)),
      ),
      child: SingleChildScrollView(
        child: Column( mainAxisSize: MainAxisSize.min, children: [

          Align(
            alignment: Alignment.centerRight,
            child: InkWell(
              onTap: () => Navigator.pop(context),
              child: Container(
                width: 25,
                height: 25,
                decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Theme.of(context).highlightColor,
                    boxShadow: [BoxShadow(color: Colors.grey[Provider.of<ThemeProvider>(context).darkTheme ? 700 : 200], spreadRadius: 1, blurRadius: 10)]),
                child: Icon(Icons.clear, size: Dimensions.ICON_SIZE_SMALL),
              ),
            ),
          ),
          Container(
            width:MediaQuery.of(context).size.width,
            height:MediaQuery.of(context).size.width/1.8,
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(10)),
            child: Image.asset("assets/images/docemdad.png", height: MediaQuery.of(context).size.width/3),
          ),

          Text("عليك استكمال التسجيل", style: titilliumvBold.copyWith(fontSize: Dimensions.FONT_SIZE_SMALL ,fontWeight: FontWeight.w600)),
          Container(
            margin: EdgeInsets.only(right: Dimensions.MARGIN_SIZE_DEFAULT, left: Dimensions.MARGIN_SIZE_DEFAULT, top: Dimensions.MARGIN_SIZE_DEFAULT),
            child: Text("الرجاء استكمال عمليه التسجيل حتى",
              style: titilliumSemiBold.copyWith(color: ColorResources.COLOR_GREY.withOpacity(0.5), fontSize: Dimensions.FONT_SIZE_EXTRA_SMALL),
            ),
          ),
          Container(
            margin: EdgeInsets.only(right: Dimensions.MARGIN_SIZE_DEFAULT, left: Dimensions.MARGIN_SIZE_DEFAULT, top: Dimensions.MARGIN_SIZE_EXTRA_SMALL),
            child: Text("تستطيع القيام بالطلب من التطبيق",
              style: titilliumSemiBold.copyWith(color: ColorResources.COLOR_GREY.withOpacity(0.5), fontSize: Dimensions.FONT_SIZE_EXTRA_SMALL),
            ),
          ),
          SizedBox(
            height: 10,
          ),

          Container(
            height: 80,
            padding: EdgeInsets.all(15),
            width: 300,
            child: FloatingActionButton(
              backgroundColor: Theme.of(context).primaryColor,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(Radius.circular(30.0))),
              onPressed: () async{




                Navigator.push(context, MaterialPageRoute(builder: (_) => CustomStepper( )));



              },
              child: Padding(
                padding: const EdgeInsets.only(left: 15, right: 15),
                child: Row(
                  // mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Expanded(
                        child: Text(
                          "استكمال التسجيل",
                          style: titilliumvBold.copyWith(
                            fontSize: Dimensions.FONT_SIZE_SMALL,
                            color: Colors.white,
                          ),
                          textAlign: TextAlign.center,
                        )),

                  ],
                ),
              ),
            ),
          ),

          InkWell(
            onTap: (){

              Navigator.pop(context);
              Navigator.pop(context);


            },
            child: Container(
              margin: EdgeInsets.only(right: Dimensions.MARGIN_SIZE_DEFAULT, left: Dimensions.MARGIN_SIZE_DEFAULT, top: Dimensions.MARGIN_SIZE_DEFAULT),
              child: Text("لا شكرا تصفح التطبيق",
                style: titilliumSemiBold.copyWith(color: ColorResources.COLOR_GREY.withOpacity(0.5), fontSize: Dimensions.FONT_SIZE_SMALL),
              ),
            ),
          ),



        ]),
      ),
    );
  }
}
