import 'package:cached_network_image/cached_network_image.dart';
import 'package:emdad/provider/profile_provider.dart';
import 'package:emdad/view/basewidget/my_text.dart';
import 'package:emdad/view/basewidget/product_widget.dart';
import 'package:emdad/view/basewidget/show_custom_snakbar.dart';
import 'package:emdad/view/basewidget/titlRow2.dart';
import 'package:emdad/view/screen/address/saved_address_list_screen.dart';
import 'package:emdad/view/screen/featureddeal/featured_deal_screen.dart';
import 'package:emdad/view/screen/flashdeal/flash_deal_screen.dart';
import 'package:emdad/view/screen/home/widget/footer_banner.dart';
import 'package:emdad/view/screen/order/order_screen.dart';
import 'package:emdad/view/screen/product/BrandAndCategoryProductScreenSubCategory.dart';
import 'package:emdad/view/screen/product/product_details_screen.dart';
import 'package:emdad/view/screen/requstOrder/order_bottom_sheet.dart';
import 'package:emdad/view/screen/tread_info/steppers_dots.dart';
import 'package:emdad/view/screen/wishlist/wishlist_screen.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'package:emdad/localization/language_constrants.dart';
import 'package:emdad/provider/auth_provider.dart';
import 'package:emdad/provider/banner_provider.dart';
import 'package:emdad/provider/cart_provider.dart';
import 'package:emdad/provider/category_provider.dart';
import 'package:emdad/provider/featured_deal_provider.dart';
import 'package:emdad/provider/flash_deal_provider.dart';
import 'package:emdad/provider/home_category_product_provider.dart';
import 'package:emdad/provider/product_provider.dart';
import 'package:emdad/provider/splash_provider.dart';
import 'package:emdad/provider/theme_provider.dart';
import 'package:emdad/provider/top_seller_provider.dart';
import 'package:emdad/utility/color_resources.dart';
import 'package:emdad/utility/custom_themes.dart';
import 'package:emdad/utility/dimensions.dart';
import 'package:emdad/utility/images.dart';
import 'package:emdad/view/basewidget/title_row.dart';
import 'package:emdad/view/screen/brand/all_brand_screen.dart';
import 'package:emdad/view/screen/cart/cart_screen.dart';
import 'package:emdad/view/screen/home/widget/announcement.dart';
import 'package:emdad/view/screen/home/widget/banners_view.dart';
import 'package:emdad/view/screen/home/widget/brand_view.dart';
import 'package:emdad/view/screen/search/search_screen.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';
import 'package:unicons/unicons.dart';

import '../../basewidget/productWidget_Without.dart';
import '../profile/address_list_screen.dart';

int isDocComplete = 1;
int isDocRequest = 0;
List<String> icons = [
  'assets/images/soup.png',
  'assets/images/drink.png',
  'assets/images/dish-soap.png'
];

class HomePage extends StatefulWidget {
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final ScrollController _scrollController = ScrollController();
  String currentAddress = "يرجى الانتضار";
  bool isCurrentAddress = false;
  GlobalKey<ScaffoldMessengerState> _scaffoldKey = GlobalKey();
  AnimationController animationController;

  Future<void> _loadData(BuildContext context, bool reload) async {
    await Provider.of<BannerProvider>(context, listen: false)
        .getBannerList(reload, context);
    await Provider.of<BannerProvider>(context, listen: false)
        .getFooterBannerList(context);
    await Provider.of<BannerProvider>(context, listen: false)
        .getMainSectionBanner(context);
    await Provider.of<TopSellerProvider>(context, listen: false)
        .getTopSellerList(reload, context);
    //await Provider.of<FlashDealProvider>(context, listen: false).getMegaDealList(reload, context,_languageCode,true);
    await Provider.of<ProductProvider>(context, listen: false)
        .getLatestProductList(1, context, reload: reload);
    await Provider.of<ProductProvider>(context, listen: false)
        .getFeaturedProductList('1', context, reload: reload);
    await Provider.of<FeaturedDealProvider>(context, listen: false)
        .getFeaturedDealList(reload, context);
    await Provider.of<ProductProvider>(context, listen: false)
        .getLProductList('1', context, reload: reload);
    Provider.of<HomeCategoryProductProvider>(context, listen: false)
        .getHomeCategoryProductList(true, context);
  }

  void passData(int index, String title) {
    index = index;
    title = title;
  }

  bool singleVendor = false;
  @override
  void initState() {
    super.initState();
    animationController =
        AnimationController(vsync: this, duration: const Duration(seconds: 4));

    Future.delayed(Duration.zero, () {
      //SystemChrome.setEnabledSystemUIMode(SystemUiMode.manual, overlays: [SystemUiOverlay.bottom]);
      singleVendor = Provider.of<SplashProvider>(context, listen: false)
              .configModel
              .businessMode ==
          "single";
      Provider.of<FlashDealProvider>(context, listen: false)
          .getMegaDealList(true, context, true);

      _loadData(context, false);

      if (Provider.of<AuthProvider>(context, listen: false).isLoggedIn()) {
        Provider.of<CartProvider>(context, listen: false)
            .uploadToServer(context);
        Provider.of<CartProvider>(context, listen: false)
            .getCartDataAPI(context);
      } else {
        Provider.of<CartProvider>(context, listen: false).getCartData();
      }

      if (Provider.of<ProfileProvider>(context, listen: false)
              .userInfoModel
              .isDoc ==
          0) {
        isDocComplete = 0;
      } else {
        isDocComplete = 1;
      }
      if (Provider.of<ProfileProvider>(context, listen: false)
              .userInfoModel
              .isDocReq ==
          0) {
        isDocRequest = 0;
      } else {
        isDocRequest = 1;
      }
    });
  }

  @override
  void dispose() {
    // TODO: implement dispose
    animationController.dispose();
    super.dispose();
  }

  @override
  // void dispose() {
  //   // TODO: implement dispose
  //   super.dispose();
  //   //SystemChrome.setEnabledSystemUIMode(SystemUiMode.manual, overlays: SystemUiOverlay.values);  // to re-show bars
  //
  //
  //
  //   singleVendor = Provider.of<SplashProvider>(context, listen: false).configModel.businessMode == "single";
  //   Provider.of<FlashDealProvider>(context, listen: false).getMegaDealList(true, context, true);
  //
  //   _loadData(context, false);
  //
  //   if (Provider.of<AuthProvider>(context, listen: false).isLoggedIn()) {
  //     Provider.of<CartProvider>(context, listen: false).uploadToServer(context);
  //     Provider.of<CartProvider>(context, listen: false).getCartDataAPI(context);
  //   } else {
  //     Provider.of<CartProvider>(context, listen: false).getCartData();
  //   }
  //
  //   if (Provider.of<ProfileProvider>(context, listen: false)
  //           .userInfoModel
  //           .isDoc ==
  //       0) {
  //     isDocComplete = 0;
  //   } else {
  //     isDocComplete = 1;
  //   }
  //   if (Provider.of<ProfileProvider>(context, listen: false)
  //           .userInfoModel
  //           .isDocReq ==
  //       0) {
  //     isDocRequest = 0;
  //   } else {
  //     isDocRequest = 1;
  //   }
  // }
  void showAlert(BuildContext context) {
    showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
              elevation: 0,
              backgroundColor: Colors.transparent,
              title:
                  //
                  // SpinKitSpinningLines(
                  //   color: Colors.green,
                  //   size: 50.0,
                  //   //controller: AnimationController(vsync: this, duration: const Duration(milliseconds: 1200)),
                  // )

                  Center(
                      child: CupertinoActivityIndicator(
                          radius: 25.0,
                          color: ColorResources.primaryColor,
                          animating: true)));
        });
  }

  @override
  Widget build(BuildContext context) {
    List<String> types = [
      getTranslated('new_arrival', context),
      getTranslated('top_product', context),
      getTranslated('best_selling', context),
      getTranslated('discounted_product', context)
    ];

    //showAlert(context);

    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: ColorResources.getHomeBg(context),
      resizeToAvoidBottomInset: false,
      body: Padding(
        padding: const EdgeInsets.only(top: 0.0),
        child: RefreshIndicator(
          backgroundColor: Theme.of(context).primaryColor,
          onRefresh: () async {
            // Future.delayed(Duration(seconds: 3)).then((_) {
            //     Navigator.pop(context);
            //     // Anything else you want
            //
            // });

            await _loadData(context, true);
            await Provider.of<FlashDealProvider>(context, listen: false)
                .getMegaDealList(true, context, false);
            return true;
          },
          child: Stack(
            children: [
              CustomScrollView(
                controller: _scrollController,
                slivers: [
                  // App Bar
                  SliverAppBar(
                    floating: true,
                    pinned: true,
                    elevation: 0,
                    centerTitle: true,
                    automaticallyImplyLeading: false,
                    backgroundColor: Theme.of(context).highlightColor,
                    titleSpacing: 0.00,
                    leadingWidth: 110,
                    leading: Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Image.asset(
                            Images.logo_with_name_image,
                            width: 90,
                            height: 50,
                            fit: BoxFit.fill,
                          ),
                        ],
                      ),
                    ),
                    title: InkWell(
                        onTap: () => Navigator.of(context).push(
                            MaterialPageRoute(
                                builder: (BuildContext context) =>
                                    AdressListScreen())),
                        child: Consumer<ProfileProvider>(
                            builder: (context, profileProviderAddress, child) {
                          return profileProviderAddress.addressList.length > 0
                              ? Padding(
                                  padding: const EdgeInsets.all(10.0),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Container(
                                        //color: Colors.white38,
                                        decoration: BoxDecoration(
                                            color: Color(0XFFf5f5f5),
                                            borderRadius:
                                                BorderRadius.circular(30),
                                            border: Border.all(
                                                width: .7,
                                                color: Color(0XFFf5f5f5))),
                                        child: Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: Row(
                                            children: [
                                              Icon(
                                                Icons.keyboard_arrow_down_sharp,
                                                color: Colors.black,
                                              ),
                                              RichText(
                                                  maxLines: 1,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  text: TextSpan(
                                                      text: "${
                                                          //"yamen Elma" }",
                                                          profileProviderAddress.addressList.first.address.length > 20 ? '${profileProviderAddress.addressList.first.address.substring(0, 20)}...' : profileProviderAddress.addressList.first.address}",
                                                      style: TextStyle(
                                                          color: Colors.black,
                                                          fontWeight: FontWeight
                                                              .bold))),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                )
                              : SizedBox.shrink();
                        })),
                    actions: [
                      Row(
                        //mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          //SizedBox(width: 50,),
                          Padding(
                            padding: const EdgeInsets.only(left: 10),
                            child: IconButton(
                              padding: EdgeInsets.zero,
                              constraints: BoxConstraints(),
                              onPressed: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (_) => CartScreen()));
                              },
                              icon: Stack(clipBehavior: Clip.none, children: [
                                Image.asset(
                                  Images.cart3_image,
                                  height: 35,
                                  width: 35,
                                  color: Colors.black,
                                ),
                                Positioned(
                                  right: -3,
                                  top: -2,
                                  child: Consumer<CartProvider>(
                                      builder: (context, cart, child) {
                                    return CircleAvatar(
                                      radius: 9,
                                      backgroundColor:
                                          Theme.of(context).primaryColor,
                                      child: Center(
                                        child: Text(
                                            cart.cartList.length.toString(),
                                            style: titilliumsemiBold.copyWith(
                                              color: ColorResources.WHITE,
                                              fontSize: Dimensions
                                                  .FONT_SIZE_EXTRA_SMALL,
                                            )),
                                      ),
                                    );
                                  }),
                                ),
                              ]),
                            ),
                          ),
                        ],
                      ),

                      // Container(
                      //  // height: 150.0,
                      //   width: 50.0,
                      //   child:  GestureDetector(
                      //     onTap: (){},
                      //     child: Consumer<CartProvider>(builder: (context, cart, child) {
                      //       return Positioned(
                      //         bottom: 30,
                      //         top: 30,
                      //         child: Stack(
                      //             clipBehavior: Clip.none,
                      //           children: <Widget>[
                      //           Image.asset( Images.cart2_image,
                      //           height: 30,
                      //             width: 30,
                      //
                      //           ),
                      //             cart.cartList.length == 0 ? new Container() :
                      //             new Positioned(
                      //                 right: 2,
                      //
                      //                 bottom: 30,
                      //                // left: 30,
                      //                 child: new Stack(
                      //                 children: <Widget>[
                      //                 new Icon(
                      //                 Icons.brightness_1,
                      //                 size: 20.0, color: Colors.green[800]),
                      //             new Positioned(
                      //               left: 4.0,
                      //                 top: 3.0,
                      //                 right: 4.0,
                      //
                      //
                      //                 child: new Center(
                      //                   child: new Text(
                      //                     cart.cartList.length.toString(),
                      //                     style: new TextStyle(
                      //                         color: Colors.white,
                      //                         fontSize: 11.0,
                      //                         fontWeight: FontWeight.w500
                      //                     ),
                      //                   ),
                      //                 )),
                      //
                      //
                      //           ],
                      //         ))]),
                      //       );
                      //     }),
                      //   ),
                      // ),
                    ],
                  ),
                  // Search Button
                  SliverPersistentHeader(
                      pinned: true,
                      delegate: SliverDelegate(
                          child: InkWell(
                        onTap: () => Navigator.push(context,
                            MaterialPageRoute(builder: (_) => SearchScreen())),
                        child: Container(
                          padding: EdgeInsets.symmetric(
                              horizontal: 20,
                              vertical: Dimensions.PADDING_SIZE_SMALL),
                          color: ColorResources.getHomeBg(context),
                          alignment: Alignment.center,
                          child: Container(
                            padding: EdgeInsets.only(
                              left: 25,
                              right: Dimensions.PADDING_SIZE_EXTRA_SMALL,
                              top: Dimensions.PADDING_SIZE_EXTRA_SMALL,
                              bottom: Dimensions.PADDING_SIZE_EXTRA_SMALL,
                            ),
                            height: 40,
                            decoration: BoxDecoration(
                              color: Color(0XFFf5f5f5),
                              border: Border.all(
                                color: Colors.grey
                                    .withOpacity(0.2), // red as border color
                              ),
                              boxShadow: [
                                BoxShadow(
                                    color: Colors.grey[
                                        Provider.of<ThemeProvider>(context)
                                                .darkTheme
                                            ? 900
                                            : 200],
                                    spreadRadius: 1,
                                    blurRadius: 1)
                              ],
                              borderRadius: BorderRadius.circular(30),
                            ),
                            child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.only(right: 10),
                                    child: Icon(
                                      UniconsLine.search,
                                      color: Colors.black,
                                      size: 15,
                                    ),
                                  ),
                                  SizedBox(
                                    width: 5,
                                  ),
                                  Text(getTranslated('SEARCH_HINT', context),
                                      style: robotoRegular.copyWith(
                                          fontSize: 12,
                                          color: Theme.of(context).hintColor)),

                                  // Container(
                                  //   width: 40,height: 40,decoration: BoxDecoration(color: Theme.of(context).primaryColor,
                                  //     borderRadius: BorderRadius.all(Radius.circular(Dimensions.PADDING_SIZE_EXTRA_SMALL))
                                  // ),
                                  //   child: Icon(Icons.search, color: Theme.of(context).cardColor, size: Dimensions.ICON_SIZE_SMALL),
                                  // ),
                                ]),
                          ),
                        ),
                      ))),

                  // Consumer<BannerProvider>(
                  //     builder: (context, bannerProvider, child) {
                  //       return
                  //         bannerProvider.mainBannerList != null ?
                  //
                  //         AlertDialog(
                  //             backgroundColor: Colors.white.withOpacity(0.5),
                  //             title: Center(child: CupertinoActivityIndicator(radius: 25.0
                  //                 , color: ColorResources.primaryColor,
                  //                 animating: true))
                  //         );
                  //
                  //
                  //     }
                  // )

                  SliverToBoxAdapter(
                      child: Stack(
                    children: [
                      isDocComplete == 1
                          ? SizedBox(height: 5)
                          : isDocRequest == 1
                              ? Column(
                                  children: [
                                    Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: <Widget>[
                                        Padding(
                                          padding: EdgeInsets.symmetric(
                                              horizontal: 30, vertical: 10),
                                          child: Container(
                                            decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(25),
                                              color:
                                                  Colors.grey.withOpacity(0.1),
                                            ),
                                            width: double.infinity,
                                            height: 150,
                                            padding: EdgeInsets.symmetric(
                                                horizontal: 30, vertical: 10),
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: [
                                                Text('حاله توثيق الحساب',
                                                    style: titilliumRegular
                                                        .copyWith(
                                                      fontSize: Dimensions
                                                          .FONT_SIZE_EXTRA_SMALL,
                                                      color: Colors.black
                                                          .withOpacity(0.7),
                                                    )),
                                                SizedBox(
                                                  height: 5,
                                                ),
                                                Text('قيد المراجعه',
                                                    style: titilliumRegular
                                                        .copyWith(
                                                      fontSize: Dimensions
                                                          .FONT_SIZE_EXTRA_SMALL,
                                                      color: ColorResources
                                                          .primaryColor,
                                                    )),
                                                SizedBox(
                                                  height: 5,
                                                ),
                                                LinearProgressIndicator(
                                                  backgroundColor: Colors.grey
                                                      .withOpacity(0.2),
                                                  valueColor:
                                                      AlwaysStoppedAnimation(
                                                          ColorResources
                                                              .primaryColor),
                                                  minHeight: 3,
                                                ),
                                                SizedBox(
                                                  height: 5,
                                                ),
                                                Text(
                                                    'لا تشيل هم ، تقدر تطلب وفريقنا شغال على توثيق حسابك',
                                                    style: titilliumRegular
                                                        .copyWith(
                                                      fontSize: Dimensions
                                                          .FONT_SIZE_EXTRA_SMALL,
                                                      color: Colors.black
                                                          .withOpacity(0.7),
                                                    )),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                )
                              : Column(
                                  children: [
                                    Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: <Widget>[
                                        Container(
                                          width: double.infinity,
                                          padding: EdgeInsets.symmetric(
                                              horizontal: 20, vertical: 10),
                                          child: OutlinedButton.icon(
                                            onPressed: () {
                                              Navigator.push(
                                                  context,
                                                  MaterialPageRoute(
                                                      builder: (_) =>
                                                          CustomStepper()));
                                            },
                                            icon: Icon(
                                              Icons.privacy_tip,
                                              color: ColorResources.RED,
                                            ),
                                            label: Container(
                                              alignment: Alignment.center,
                                              height: 40,
                                              padding: EdgeInsets.symmetric(
                                                  horizontal: 5),
                                              child: Text(
                                                  'كمل معلوماتك حتى تستطيع الطلب',
                                                  style:
                                                      titilliumRegular.copyWith(
                                                    fontSize: Dimensions
                                                        .FONT_SIZE_EXTRA_SMALL,
                                                    color: Theme.of(context)
                                                        .hintColor,
                                                  )),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                )

                      //
                      // isDocRequest == 1
                      //     ? Column(
                      //   children: [
                      //     Column(
                      //       crossAxisAlignment: CrossAxisAlignment.start,
                      //       children: <Widget>[
                      //         Padding(
                      //           padding: EdgeInsets.symmetric(horizontal: 30, vertical: 10),
                      //           child: Container(
                      //             decoration: BoxDecoration(
                      //               borderRadius: BorderRadius.circular(25),
                      //               color: Colors.grey.withOpacity(0.1),
                      //
                      //
                      //             ),
                      //             width: double.infinity,
                      //             height: 150,
                      //             padding: EdgeInsets.symmetric(horizontal: 30, vertical: 10),
                      //             child: Column(
                      //               crossAxisAlignment: CrossAxisAlignment.start,
                      //               mainAxisAlignment: MainAxisAlignment.start,
                      //
                      //               children: [
                      //                 Text('حاله توثيق الحساب', style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_EXTRA_SMALL, color: Colors.black.withOpacity(0.7),)),
                      //
                      //                 SizedBox(height: 5,),
                      //                 Text('قيد المراجعه', style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_EXTRA_SMALL, color: ColorResources.primaryColor,)),
                      //
                      //                 SizedBox(height: 5,),
                      //
                      //                 LinearProgressIndicator(
                      //                   backgroundColor: Colors.grey.withOpacity(0.2),
                      //                   valueColor: AlwaysStoppedAnimation(ColorResources.primaryColor ),
                      //                   minHeight: 3,
                      //
                      //                 ),
                      //
                      //                 SizedBox(height: 5,),
                      //
                      //                 Text('لا تشيل هم ، تقدر تطلب وفريقنا شغال على توثيق حسابك', style: titilliumRegular.copyWith(
                      //                   fontSize: Dimensions.FONT_SIZE_EXTRA_SMALL, color: Colors.black.withOpacity(0.7),)),
                      //
                      //
                      //               ],
                      //             ),
                      //           ),
                      //         ),
                      //       ],
                      //     ),
                      //   ],
                      // )
                      //     : isDocComplete == 0
                      //     ? Column(
                      //   children: [
                      //     Card(
                      //       shape: RoundedRectangleBorder(
                      //         borderRadius: BorderRadius.circular(30),
                      //       ),
                      //       margin: EdgeInsets.all(15),
                      //       clipBehavior: Clip.antiAliasWithSaveLayer,
                      //       child: Column(
                      //         crossAxisAlignment:
                      //         CrossAxisAlignment.start,
                      //         children: <Widget>[
                      //           Container(
                      //             width: double.infinity,
                      //             padding: EdgeInsets.symmetric(
                      //                 horizontal: 20, vertical: 10),
                      //             child: OutlinedButton.icon(
                      //               onPressed: () {
                      //                 Navigator.push(
                      //                     context,
                      //                     MaterialPageRoute(
                      //                         builder: (_) =>
                      //                             CustomStepper()));
                      //               },
                      //               icon: Icon(
                      //                 Icons.privacy_tip,
                      //                 color: ColorResources.RED,
                      //               ),
                      //               label: Container(
                      //                 alignment: Alignment.center,
                      //                 height: 40,
                      //                 padding: EdgeInsets.symmetric(
                      //                     horizontal: 5),
                      //                 child: Text(
                      //                     'أكمل معلوماتك حتي تستطيع الطلب',
                      //                     style: titilliumRegular
                      //                         .copyWith(
                      //                       fontSize: Dimensions
                      //                           .FONT_SIZE_SMALL,
                      //                       color: Theme.of(context)
                      //                           .hintColor,
                      //                     )),
                      //               ),
                      //             ),
                      //           ),
                      //         ],
                      //       ),
                      //     ),
                      //   ],
                      // )
                      //     : SizedBox(height: 10),
                    ],
                  )),

                  Consumer<BannerProvider>(
                      builder: (context, bannerProvider, child) {
                    return bannerProvider.mainBannerList != null
                        ? SliverToBoxAdapter(
                            child: Padding(
                              padding: EdgeInsets.fromLTRB(
                                  Dimensions.HOME_PAGE_PADDING,
                                  Dimensions.PADDING_SIZE_SMALL,
                                  Dimensions.PADDING_SIZE_DEFAULT,
                                  Dimensions.PADDING_SIZE_SMALL),
                              child: Column(
                                children: [
                                  BannersView(),
                                  SizedBox(
                                      height: Dimensions.HOME_PAGE_PADDING),
                                ],
                              ),
                            ),
                          )
                        : SliverList(
                            delegate: SliverChildListDelegate([
                            Column(
                              children: [
                                Container(
                                  color: Colors.transparent,
                                  height: 200,
                                  child: SpinKitFadingCircle(
                                      itemBuilder: (context, index) {
                                        final colors = [
                                          ColorResources.primaryColor
                                        ];
                                        final color =
                                            colors[index % colors.length];

                                        return DecoratedBox(
                                            decoration: BoxDecoration(
                                                color: color,
                                                shape: BoxShape.circle));
                                      },
                                      //color: Colors.green,
                                      size: 80.0,
                                      controller: animationController
                                      //AnimationController(vsync: this, duration: const Duration(seconds: 4)),
                                      ),
                                )
                              ],
                            )
                          ]));
                  }),

                  SliverList(
                    delegate: SliverChildListDelegate([
                      Container(),
                      Padding(
                        padding: const EdgeInsets.fromLTRB(
                          20.0,
                          0.0,
                          20.0,
                          0.0,
                        ),
                        child: buildHomeMenuRow(context),
                      ),
                    ]),
                  ),

                  SliverToBoxAdapter(
                    child: Padding(
                      padding: EdgeInsets.fromLTRB(
                          Dimensions.HOME_PAGE_PADDING,
                          Dimensions.PADDING_SIZE_SMALL,
                          Dimensions.PADDING_SIZE_DEFAULT,
                          Dimensions.PADDING_SIZE_SMALL),
                      child: Column(
                        children: [
                          /*
                          // Category
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: Dimensions.PADDING_SIZE_EXTRA_EXTRA_SMALL,vertical: Dimensions.PADDING_SIZE_EXTRA_SMALL),
                            child: TitleRow(title: getTranslated('CATEGORY', context),
                                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AllCategoryScreen()))),
                          ),
                          SizedBox(height: Dimensions.PADDING_SIZE_SMALL),
                          Padding(
                            padding: const EdgeInsets.only(bottom: Dimensions.HOME_PAGE_PADDING),
                            child: CategoryView(isHomePage: true),
                          ),
                           */
                          // Mega Deal
                          /*
                          Consumer<FlashDealProvider>(
                            builder: (context, flashDeal, child) {
                              return  (flashDeal.flashDeal != null && flashDeal.flashDealList != null
                                  && flashDeal.flashDealList.length > 0)
                                  ? TitleRow(title: getTranslated('flash_deal', context),
                                      eventDuration: flashDeal.flashDeal != null ? flashDeal.duration : null,
                                      onTap: () {
                                    Navigator.push(context, MaterialPageRoute(builder: (_) => FlashDealScreen()));
                                      },
                                  isFlash: true,
                                      )
                                  : SizedBox.shrink();
                            },
                          ),
                          SizedBox(height: Dimensions.PADDING_SIZE_SMALL),
                          Consumer<FlashDealProvider>(
                            builder: (context, megaDeal, child) {
                              return  (megaDeal.flashDeal != null && megaDeal.flashDealList != null && megaDeal.flashDealList.length > 0)
                                  ? Container(height: MediaQuery.of(context).size.width*.77,
                                  child: Padding(
                                    padding: const EdgeInsets.only(bottom: Dimensions.HOME_PAGE_PADDING),
                                    child: FlashDealsView(),
                                  )) : SizedBox.shrink();},),
                          SizedBox(height: Dimensions.PADDING_SIZE_SMALL),

                          */
                          // Brand
                          Padding(
                            padding: const EdgeInsets.only(
                              left: Dimensions.PADDING_SIZE_EXTRA_SMALL,
                              right: Dimensions.PADDING_SIZE_EXTRA_SMALL,
                              //bottom: Dimensions.PADDING_SIZE_EXTRA_EXTRA_SMALLest
                            ),
                            child: TitleRow2(
                                title: getTranslated('brand_market', context),
                                style: titilliumBold.copyWith(
                                  fontSize: Dimensions.FONT_SIZE_SMALL,
                                  color: ColorResources.getTextTitle(context)
                                      .withOpacity(0.9),
                                ),
                                onTap: () {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (_) => AllBrandScreen()));
                                }),
                          ),
                          SizedBox(height: Dimensions.PADDING_SIZE_DEFAULT),
                          BrandView(isHomePage: true),
                          //SizedBox(height: Dimensions.PADDING_SIZE_SMALL),

                          //footer banner
                          Consumer<BannerProvider>(
                              builder: (context, footerBannerProvider, child) {
                            return footerBannerProvider.footerBannerList !=
                                        null &&
                                    footerBannerProvider
                                            .footerBannerList.length >
                                        0
                                ? Container(
                                    color: Colors.black,
                                    child: Padding(
                                      padding: const EdgeInsets.only(
                                          bottom: Dimensions.HOME_PAGE_PADDING),
                                      child: FooterBannersView(
                                        index: 0,
                                      ),
                                    ),
                                  )
                                : SizedBox();
                          }),
                          SizedBox(),

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

                          Container(
                            decoration: BoxDecoration(
                              color: Colors.transparent,
                              borderRadius: BorderRadius.only(
                                  topRight: Radius.circular(20),
                                  topLeft: Radius.circular(20)),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.only(bottom: 0.0),
                              child: Consumer<CategoryProvider>(
                                  builder: (context, categoryProvider, child) {
                                return MediaQuery.removePadding(
                                  context: context,
                                  removeTop: true,
                                  child: ListView.builder(
                                    shrinkWrap: true,
                                    itemCount:
                                        categoryProvider.categoryList.length,
                                    physics: NeverScrollableScrollPhysics(),
                                    itemBuilder: (context, index) {
                                      return Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.stretch,
                                          children: [
                                            categoryProvider.categoryList[index]
                                                        .id != 1363
                                                ? Padding(
                                                    padding: const EdgeInsets
                                                        .fromLTRB(
                                                      0.0,
                                                      0.0,
                                                      0.0,
                                                      0.0,
                                                    ),
                                                    child: Row(
                                                      children: [
                                                        Text(
                                                          '${categoryProvider.categoryList[index].name}',
                                                          style: titilliumBold
                                                              .copyWith(
                                                            fontSize: Dimensions
                                                                .FONT_SIZE_SMALL,
                                                            color: ColorResources
                                                                    .getTextTitle(
                                                                        context)
                                                                .withOpacity(
                                                                    0.9),
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 4,
                                                        ),
                                                        Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                      .only(
                                                                  bottom: 10),
                                                          child: Image.asset(
                                                            icons[index],
                                                            width: 30,
                                                            height: 30,
                                                            fit: BoxFit.contain,
                                                          ),
                                                        )
                                                      ],
                                                    ),
                                                  )
                                                : SizedBox.shrink(),
                                            // Text('${categoryProvider.categoryList[index].name}', style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_EXTRA_LARGE)),
                                            SizedBox(
                                                height: Dimensions
                                                    .PADDING_SIZE_SMALL),
                                            categoryProvider.categoryList[index]
                                                        .id !=
                                                    1363
                                                ? Container(
                                                    decoration: BoxDecoration(
                                                      color: Theme.of(context)
                                                          .cardColor,
                                                      borderRadius:
                                                          BorderRadius.only(
                                                              topRight: Radius
                                                                  .circular(20),
                                                              topLeft: Radius
                                                                  .circular(
                                                                      20)),
                                                    ),
                                                    child: GridView.builder(
                                                      gridDelegate:
                                                          SliverGridDelegateWithFixedCrossAxisCount(
                                                        crossAxisCount: 3,
                                                        crossAxisSpacing: 5,
                                                        mainAxisSpacing: 3,
                                                        childAspectRatio:
                                                            (1 / 1.1),
                                                      ),
                                                      shrinkWrap: true,
                                                      physics:
                                                          NeverScrollableScrollPhysics(),
                                                      itemCount:
                                                          categoryProvider
                                                              .categoryList[
                                                                  index]
                                                              .subCategories
                                                              .length,
                                                      itemBuilder:
                                                          (context, i) {
                                                        return InkWell(
                                                          onTap: () {
                                                            Navigator.push(
                                                                context,
                                                                MaterialPageRoute(
                                                                    builder: (_) =>
                                                                        BrandAndCategoryProductScreenSubCategory(
                                                                          isBrand:
                                                                              false,
                                                                          id: categoryProvider
                                                                              .categoryList[index]
                                                                              .subCategories[i]
                                                                              .id
                                                                              .toString(),
                                                                          name: categoryProvider
                                                                              .categoryList[index]
                                                                              .subCategories[i]
                                                                              .name,
                                                                        )));
                                                          },
                                                          child: Column(
                                                              children: [

                                                                Container(
                                                                  decoration:
                                                                      BoxDecoration(
                                                                    border: Border.all(
                                                                        color: Theme.of(context)
                                                                            .primaryColor
                                                                            .withOpacity(.2)),
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            Dimensions.PADDING_SIZE_SMALL),
                                                                    color: Theme.of(
                                                                            context)
                                                                        .highlightColor,
                                                                    // boxShadow: [BoxShadow(
                                                                    //   color: Colors.grey.withOpacity(0.3),
                                                                    //   spreadRadius: 1,
                                                                    //   blurRadius: 3,
                                                                    //   offset: Offset(0, 3), // changes position of shadow
                                                                    // )],
                                                                  ),
                                                                  child:
                                                                      ClipRRect(
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            Dimensions.PADDING_SIZE_EXTRA_EXTRA_SMALL),
                                                                    child:
                                                                        CachedNetworkImage(
                                                                      width:
                                                                          100,
                                                                      height:
                                                                          90,
                                                                      imageUrl:
                                                                          '${Provider.of<SplashProvider>(context, listen: false).baseUrls.categoryImageUrl}'
                                                                          '/${categoryProvider.categoryList[index].subCategories[i].icon}',
                                                                      fit: BoxFit
                                                                          .cover,
                                                                      imageBuilder: (BuildContext
                                                                              context,
                                                                          ImageProvider<dynamic>
                                                                              imageProvider) {
                                                                        return Image(
                                                                            image:
                                                                                imageProvider,
                                                                            fit:
                                                                                BoxFit.cover);
                                                                      },
                                                                      placeholder: (context,
                                                                              url) =>
                                                                          Image
                                                                              .asset(
                                                                        'assets/images/placeholder.png',
                                                                        fit: BoxFit
                                                                            .cover,
                                                                      ),
                                                                      errorWidget: (context,
                                                                              url,
                                                                              error) =>
                                                                          Icon(Icons
                                                                              .shopping_cart_outlined),
                                                                    ),
                                                                  ),
                                                                ),
                                                                SizedBox(
                                                                    height: Dimensions
                                                                        .PADDING_SIZE_EXTRA_SMALL),
                                                                Expanded(
                                                                  child:
                                                                      Container(
                                                                    child:
                                                                        Center(
                                                                      child:
                                                                          Text(
                                                                        categoryProvider.categoryList[index].subCategories.length !=
                                                                                0
                                                                            ? categoryProvider.categoryList[index].subCategories[i].name
                                                                            : getTranslated('CATEGORY', context),
                                                                        textAlign:
                                                                            TextAlign.center,
                                                                        maxLines:
                                                                            1,
                                                                        overflow:
                                                                            TextOverflow.ellipsis,
                                                                        style: titilliumRegular.copyWith(
                                                                            fontSize:
                                                                                Dimensions.FONT_SIZE_EXTRA_SMALLest,
                                                                            color: ColorResources.getTextTitle(context)),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ]),
                                                        );
                                                      },
                                                    ),
                                                  )
                                                : SizedBox.shrink(),
                                            categoryProvider.categoryList[index]
                                                        .id !=
                                                    1363
                                                ? SizedBox(
                                                    height: Dimensions
                                                        .PADDING_SIZE_SMALL)
                                                : SizedBox.shrink(),
                                            categoryProvider.categoryList[index]
                                                        .id !=
                                                    1363
                                                ? Padding(
                                                    padding: const EdgeInsets
                                                            .symmetric(
                                                        horizontal: Dimensions
                                                            .PADDING_SIZE_EXTRA_SMALL,
                                                        vertical: Dimensions
                                                            .PADDING_SIZE_EXTRA_SMALL),
                                                    child: Padding(
                                                      padding: const EdgeInsets
                                                              .only(
                                                          bottom: Dimensions
                                                              .PADDING_SIZE_SMALL),
                                                      child: TitleRow2(
                                                          style: titilliumBold
                                                              .copyWith(
                                                            fontSize: Dimensions
                                                                .FONT_SIZE_SMALL,
                                                            color: ColorResources
                                                                    .getTextTitle(
                                                                        context)
                                                                .withOpacity(
                                                                    0.9),
                                                          ),
                                                          title:
                                                              'منتجات ${categoryProvider.categoryList[index].name} المختارة لك',
                                                          onTap: () {
                                                            print('${Provider.of<SplashProvider>(context, listen: false).baseUrls.categoryImageUrl}'
                                                            '/${categoryProvider.categoryList[1].subCategories[1].icon}');
                                                            print("kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk");
                                                            // Navigator.push(
                                                            //     context,
                                                            //     MaterialPageRoute(
                                                            //         builder: (_) =>
                                                            //             BrandAndCategoryProductScreenSubCategory(
                                                            //               isBrand:
                                                            //                   false,
                                                            //               id: categoryProvider
                                                            //                   .categoryList[index]
                                                            //                   .id
                                                            //                   .toString(),
                                                            //               name: categoryProvider
                                                            //                   .categoryList[index]
                                                            //                   .name,
                                                            //             )));
                                                          }),
                                                    ),
                                                  )
                                                : SizedBox.shrink(),
                                            categoryProvider.categoryList[index]
                                                        .id !=
                                                    1363
                                                ? SizedBox(
                                                    height: Dimensions
                                                        .PADDING_SIZE_SMALL)
                                                : SizedBox.shrink(),
                                            /*
                                                 Padding(
                                                  padding: const EdgeInsets.only(bottom: Dimensions.HOME_PAGE_PADDING),
                                                  child: FeaturedProductView(scrollController: _scrollController, isHome: true,),
                                                ),
                                               */

                                            //اظهار المنتجات
                                            categoryProvider.categoryList[index]
                                                        .id !=
                                                    1363
                                                ? Consumer<
                                                        HomeCategoryProductProvider>(
                                                    builder: (context,
                                                        homeCategoryProductProvider,
                                                        child) {
                                                    return homeCategoryProductProvider
                                                            .homeCategoryProductList
                                                            .isEmpty
                                                        ? SpinKitFadingCircle(
                                                            itemBuilder:
                                                                (context,
                                                                    index) {
                                                              final colors = [
                                                                ColorResources
                                                                    .primaryColor
                                                              ];
                                                              final color =
                                                                  colors[index %
                                                                      colors
                                                                          .length];

                                                              return DecoratedBox(
                                                                  decoration: BoxDecoration(
                                                                      color:
                                                                          color,
                                                                      shape: BoxShape
                                                                          .circle));
                                                            },
                                                            //color: Colors.green,
                                                            size: 80.0,
                                                            controller:
                                                                animationController
                                                            //  AnimationController(vsync: this, duration: const Duration(seconds: 4)),
                                                            )
                                                        : ConstrainedBox(
                                                            constraints: homeCategoryProductProvider
                                                                        .homeCategoryProductList[
                                                                            index]
                                                                        .products
                                                                        .length >
                                                                    0
                                                                ? BoxConstraints(
                                                                    maxHeight: MediaQuery.of(context)
                                                                            .size
                                                                            .width /
                                                                        1.80,
                                                                  )
                                                                : BoxConstraints(
                                                                    maxHeight:
                                                                        0),
                                                            child: homeCategoryProductProvider
                                                                        .homeCategoryProductList[
                                                                            index]
                                                                        .products
                                                                        .length >
                                                                    0
                                                                ? homeCategoryProductProvider
                                                                            .homeCategoryProductList[index]
                                                                            .products
                                                                            .length >
                                                                        0
                                                                    ? ListView.separated(
                                                                        separatorBuilder: (BuildContext context, int index) => Divider(color: Colors.red),
                                                                        physics: const PageScrollPhysics(parent: BouncingScrollPhysics()),
                                                                        itemCount: homeCategoryProductProvider.homeCategoryProductList[index].products.length,
                                                                        padding: EdgeInsets.all(0),
                                                                        scrollDirection: Axis.horizontal,
                                                                        shrinkWrap: false,
                                                                        itemBuilder: (BuildContext context, int i) {
                                                                          return InkWell(
                                                                            onTap:
                                                                                () {
                                                                              Navigator.push(
                                                                                  context,
                                                                                  PageRouteBuilder(
                                                                                    transitionDuration: Duration(milliseconds: 1000),
                                                                                    pageBuilder: (context, anim1, anim2) => ProductDetails(product: homeCategoryProductProvider.productList[i]),
                                                                                  ));
                                                                            },
                                                                            child:
                                                                                Row(
                                                                              children: [
                                                                                Padding(
                                                                                  padding: const EdgeInsets.only(left: 1.0, right: 1),
                                                                                  child: Container(width: (MediaQuery.of(context).size.width / 2) - 10, child: ProductWidget_Without(productModel: homeCategoryProductProvider.homeCategoryProductList[index].products[i])),
                                                                                ),
                                                                                Container(
                                                                                  width: 1,
                                                                                  color: Colors.grey.withOpacity(0.2),
                                                                                )
                                                                              ],
                                                                            ),
                                                                          );
                                                                        })
                                                                    : SizedBox.shrink()
                                                                : SizedBox(height: Dimensions.PADDING_SIZE_SMALL),
                                                          );
                                                  })
                                                : SizedBox.shrink(),
                                            SizedBox(
                                                height: Dimensions
                                                    .PADDING_SIZE_SMALL),
                                            // Divider(
                                            //     thickness: 1,
                                            //     color: Theme.of(context)
                                            //         .primaryColor
                                            //         .withOpacity(0.3)),
                                            SizedBox(
                                                height: Dimensions
                                                    .PADDING_SIZE_SMALL),
                                          ]);
                                    },
                                  ),
                                );
                              }),
                            ),
                          ),

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                          Container(
                            height: MediaQuery.of(context).size.height * 0.15,
                            width: MediaQuery.of(context).size.width,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(
                                    Dimensions.PADDING_SIZE_EXTRA_LARGE),
                                boxShadow: [
                                  BoxShadow(
                                      color: Colors.grey.withOpacity(0.5),
                                      spreadRadius: 3,
                                      blurRadius: 2)
                                ]),
                            margin: EdgeInsets.only(
                                bottom: Dimensions.PADDING_SIZE_SMALL),
                            child: InkWell(
                              onTap: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (_) =>
                                            BrandAndCategoryProductScreenSubCategory(
                                              isBrand: false,
                                              id: '1364',
                                              name: "طلبيات كبيرة",
                                            )));
                              },
                              child: Image.asset(
                                'assets/images/bigorder.jpg',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                          SizedBox(height: Dimensions.PADDING_SIZE_SMALL),
                          Container(
                            height: 85,
                            padding: EdgeInsets.all(
                                Dimensions.PADDING_SIZE_EXTRA_LARGE),
                            decoration: BoxDecoration(
                                color: Color(0XFFf5f5f5),
                                borderRadius: BorderRadius.circular(
                                    Dimensions.PADDING_SIZE_EXTRA_LARGE),
                                boxShadow: [
                                  BoxShadow(
                                      color: Colors.grey.withOpacity(0.3),
                                      spreadRadius: 1,
                                      blurRadius: 5)
                                ]),
                            margin: EdgeInsets.only(
                                bottom: Dimensions.PADDING_SIZE_SMALL),
                            child: InkWell(
                              onTap: () {
                                showModalBottomSheet(
                                    context: context,
                                    isScrollControlled: true,
                                    backgroundColor: Colors.transparent,
                                    builder: (con) => OrderBottomSheet(
                                          callback: () {
                                            showCustomSnackBar(
                                                getTranslated(
                                                    'added_to_cart', context),
                                                context,
                                                isError: false);
                                          },
                                        ));
                              },
                              child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      "عندك طلب خاص؟",
                                      style: robotoRegular.copyWith(
                                          color: Provider.of<ThemeProvider>(
                                                      context)
                                                  .darkTheme
                                              ? Colors.white
                                              : Colors.black,
                                          fontSize:
                                              Dimensions.FONT_SIZE_EXTRA_LARGE),
                                    ),
                                    InkWell(
                                      onTap: () {
                                        showModalBottomSheet(
                                            context: context,
                                            isScrollControlled: true,
                                            backgroundColor: Colors.transparent,
                                            builder: (con) => OrderBottomSheet(
                                                  callback: () {
                                                    showCustomSnackBar(
                                                        getTranslated(
                                                            'added_to_cart',
                                                            context),
                                                        context,
                                                        isError: false);
                                                  },
                                                ));
                                      },
                                      child: Container(
                                          decoration: BoxDecoration(
                                              color: Colors.white,
                                              borderRadius:
                                                  BorderRadius.circular(30),
                                              border: Border.all(
                                                  width: .7,
                                                  color: Colors.white)),
                                          alignment: Alignment.center,
                                          height: 40,
                                          width: 90,
                                          child: Text('اضغط هنا',
                                              style: TextStyle(
                                                  color: Colors.black,
                                                  fontSize: 15))),
                                    ),
                                  ]),
                            ),
                          ),
                          SizedBox(height: Dimensions.PADDING_SIZE_SMALL),
                          SizedBox(height: Dimensions.PADDING_SIZE_SMALL),

                          // /*

                          /*
                          //top seller
                          singleVendor?SizedBox():
                          TitleRow(title: getTranslated('top_seller', context),
                            onTap: () {
                              Shared.onPopEventHandler(_interstitialAd);
                              Navigator.push(context, MaterialPageRoute(builder: (_) => AllTopSellerScreen(topSeller: null,)));},
                          ),
                          singleVendor?SizedBox(height: 0):SizedBox(height: Dimensions.PADDING_SIZE_SMALL),
                          singleVendor?SizedBox():
                          Padding(
                            padding: const EdgeInsets.only(bottom: Dimensions.HOME_PAGE_PADDING),
                            child: TopSellerView(isHomePage: true),
                          ),

                          //footer banner
                          Consumer<BannerProvider>(builder: (context, footerBannerProvider, child){
                            return footerBannerProvider.footerBannerList != null && footerBannerProvider.footerBannerList.length > 0?
                            Padding(
                              padding: const EdgeInsets.only(bottom: Dimensions.HOME_PAGE_PADDING),
                              child: FooterBannersView(index: 0,),
                            ):SizedBox();
                          }),

                          // Featured Products
                          Consumer<ProductProvider>(
                            builder: (context, featured,_) {
                              return featured.featuredProductList!=null && featured.featuredProductList.length>0 ?
                              Padding(
                                padding: const EdgeInsets.symmetric(horizontal: Dimensions.PADDING_SIZE_EXTRA_SMALL,vertical: Dimensions.PADDING_SIZE_EXTRA_SMALL),
                                child: Padding(
                                  padding: const EdgeInsets.only(bottom: Dimensions.PADDING_SIZE_SMALL),
                                  child: TitleRow(title: getTranslated('featured_products', context),
                                      onTap: () {
                                        Shared.onPopEventHandler(_interstitialAd);
                                        Navigator.push(context, MaterialPageRoute(builder: (_) => AllProductScreen(productType: ProductType.FEATURED_PRODUCT)));}),
                                ),
                              ):SizedBox();
                            }
                          ),

                          Padding(
                            padding: const EdgeInsets.only(bottom: Dimensions.HOME_PAGE_PADDING),
                            child: FeaturedProductView(scrollController: _scrollController, isHome: true,),
                          ),

                          // Featured Deal
                          Consumer<FeaturedDealProvider>(
                            builder: (context, featuredDealProvider, child) {
                              return featuredDealProvider.featuredDealList == null
                                  ? TitleRow(title: getTranslated('featured_deals', context),
                                      onTap: () {Navigator.push(context, MaterialPageRoute(builder: (_) => FeaturedDealScreen()));}) :
                              (featuredDealProvider.featuredDealList != null && featuredDealProvider.featuredDealList.length > 0) ?
                              Padding(
                                padding: const EdgeInsets.only(bottom: Dimensions.PADDING_SIZE_SMALL),
                                child: TitleRow(title: getTranslated('featured_deals', context),
                                    onTap: () {
                                      Shared.onPopEventHandler(_interstitialAd);
                                      Navigator.push(context, MaterialPageRoute(builder: (_) => FeaturedDealScreen()));}),
                              ) : SizedBox.shrink();},),

                          Consumer<FeaturedDealProvider>(
                            builder: (context, featuredDeal, child) {
                              return featuredDeal.featuredDealList == null && featuredDeal.featuredDealList.length > 0?
                              Container(height: 150, child: FeaturedDealsView()) : (featuredDeal.featuredDealList != null && featuredDeal.featuredDealList.length > 0) ?
                              Container(height: featuredDeal.featuredDealList.length> 4 ? 120 * 4.0 : 120 * (double.parse(featuredDeal.featuredDealList.length.toString())),
                                  child: Padding(
                                    padding: const EdgeInsets.only(bottom: Dimensions.HOME_PAGE_PADDING),
                                    child: FeaturedDealsView(),
                                  )) : SizedBox.shrink();},),


                          Padding(
                            padding: const EdgeInsets.only(bottom: Dimensions.HOME_PAGE_PADDING),
                            child: RecommendedProductView(),
                          ),


                          //footer banner
                          Consumer<BannerProvider>(builder: (context, footerBannerProvider, child){
                            return footerBannerProvider.mainSectionBannerList != null &&
                                footerBannerProvider.mainSectionBannerList.length > 0?
                            Padding(
                              padding: const EdgeInsets.only(bottom: Dimensions.HOME_PAGE_PADDING),
                              child: MainSectionBannersView(index: 0,),
                            ):SizedBox();

                          }),


                          // Latest Products
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 7,vertical: Dimensions.PADDING_SIZE_EXTRA_SMALL),
                            child: TitleRow(title: getTranslated('latest_products', context),
                                onTap: () {
                                  Shared.onPopEventHandler(_interstitialAd);
                                  Navigator.push(context, MaterialPageRoute(builder: (_) => AllProductScreen(
                                    productType: ProductType.LATEST_PRODUCT)));}),
                          ),
                          SizedBox(height: Dimensions.PADDING_SIZE_SMALL),
                          LatestProductView(scrollController: _scrollController),
                          SizedBox(height: Dimensions.PADDING_SIZE_EXTRA_SMALL),

                          //Home category
                          HomeCategoryProductView(isHomePage: true),
                          SizedBox(height: Dimensions.HOME_PAGE_PADDING),


                          //footer banner
                          Consumer<BannerProvider>(builder: (context, footerBannerProvider, child){
                            return footerBannerProvider.footerBannerList != null && footerBannerProvider.footerBannerList.length>1?
                            FooterBannersView(index: 1):SizedBox();
                          }),
                          SizedBox(height: Dimensions.HOME_PAGE_PADDING),


                          //Category filter
                          Consumer<ProductProvider>(
                              builder: (ctx,prodProvider,child) {
                            return Padding(
                              padding: const EdgeInsets.symmetric(horizontal: Dimensions.PADDING_SIZE_EXTRA_SMALL,vertical: Dimensions.PADDING_SIZE_EXTRA_SMALL),
                              child: Row(children: [
                                Expanded(child: Text(prodProvider.title == 'xyz' ? getTranslated('new_arrival',context):prodProvider.title, style: titleHeader)),
                                prodProvider.latestProductList != null ? PopupMenuButton(
                                  itemBuilder: (context) {
                                    return [
                                      PopupMenuItem(value: ProductType.NEW_ARRIVAL, child: Text(getTranslated('new_arrival',context)), textStyle: robotoRegular.copyWith(
                                        color: Theme.of(context).hintColor,
                                         )),
                                      PopupMenuItem(value: ProductType.TOP_PRODUCT, child: Text(getTranslated('top_product',context)), textStyle: robotoRegular.copyWith(
                                        color: Theme.of(context).hintColor,
                                        )),
                                      PopupMenuItem(value: ProductType.BEST_SELLING, child: Text(getTranslated('best_selling',context)), textStyle: robotoRegular.copyWith(
                                        color: Theme.of(context).hintColor,
                                       )),
                                      PopupMenuItem(value: ProductType.DISCOUNTED_PRODUCT, child: Text(getTranslated('discounted_product',context)), textStyle: robotoRegular.copyWith(
                                        color: Theme.of(context).hintColor,
                                      )),
                                    ];
                                  },
                                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(Dimensions.PADDING_SIZE_SMALL)),
                                  child: Padding(
                                    padding: EdgeInsets.symmetric(horizontal: Dimensions.PADDING_SIZE_SMALL,vertical:Dimensions.PADDING_SIZE_SMALL ),
                                    child: Image.asset(Images.dropdown, scale: 3,),
                                  ),
                                  onSelected: (value) {
                                    if(value == ProductType.NEW_ARRIVAL){
                                      Provider.of<ProductProvider>(context, listen: false).changeTypeOfProduct(value, types[0]);
                                    }else if(value == ProductType.TOP_PRODUCT){
                                      Provider.of<ProductProvider>(context, listen: false).changeTypeOfProduct(value, types[1]);
                                    }else if(value == ProductType.BEST_SELLING){
                                      Provider.of<ProductProvider>(context, listen: false).changeTypeOfProduct(value, types[2]);
                                    }else if(value == ProductType.DISCOUNTED_PRODUCT){
                                      Provider.of<ProductProvider>(context, listen: false).changeTypeOfProduct(value, types[3]);
                                    }

                                    ProductView(isHomePage: false, productType: value, scrollController: _scrollController);
                                    Provider.of<ProductProvider>(context, listen: false).getLatestProductList(1, context, reload: true);


                                  }
                                ) : SizedBox(),
                              ]),
                            );
                          }),
                          ProductView(isHomePage: false, productType: ProductType.NEW_ARRIVAL, scrollController: _scrollController),
                          SizedBox(height: Dimensions.HOME_PAGE_PADDING),
                           */
                        ],
                      ),
                    ),
                  )
                ],
              ),

              /*
              //footer banner
              Consumer<BannerProvider>(builder: (context, footerBannerProvider, child){
                return footerBannerProvider.footerBannerList != null && footerBannerProvider.footerBannerList.length > 0?
                Padding(
                  padding: const EdgeInsets.only(bottom: Dimensions.HOME_PAGE_PADDING),
                  child: FooterBannersView(index: 0,),
                ):SizedBox();
              }),


               */
              Provider.of<SplashProvider>(context, listen: false)
                          .configModel
                          .announcement
                          .status ==
                      '1'
                  ? Positioned(
                      top: MediaQuery.of(context).size.height - 128,
                      left: 0,
                      right: 0,
                      child: Consumer<SplashProvider>(
                        builder: (context, announcement, _) {
                          return announcement.onOff
                              ? AnnouncementScreen(
                                  announcement:
                                      announcement.configModel.announcement)
                              : SizedBox();
                        },
                      ),
                    )
                  : SizedBox(),
            ],
          ),
        ),
      ),
    );
  }

  buildHomeMenuRow(BuildContext context) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            GestureDetector(
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) {
                  return OrderScreen();
                }));
              },
              child: Container(
                height: 100,
                width: MediaQuery.of(context).size.width / 5 - 4,
                child: Column(
                  children: [
                    Container(
                        height: 57,
                        width: 57,
                        decoration: BoxDecoration(
                            color: Theme.of(context).highlightColor,
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                  color: Colors.grey.withOpacity(0.1),
                                  spreadRadius: 2,
                                  blurRadius: 5,
                                  offset: Offset(
                                      0, 1)) // changes position of shadow
                            ]),
                        child: Icon(
                          Icons.more_time,
                          color: Colors.black,
                          size: 30,
                        )),
                    Padding(
                      padding: const EdgeInsets.only(top: 8),
                      child: Text(
                        "طلبتها سابقا",
                        textAlign: TextAlign.center,
                        style: titilliumsemiBold.copyWith(fontSize: 8),
                      ),
                    )
                  ],
                ),
              ),
            ),
            GestureDetector(
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) {
                  return FlashDealScreen();
                }));
              },
              child: Container(
                height: 100,
                width: MediaQuery.of(context).size.width / 5 - 4,
                child: Column(
                  children: [
                    Container(
                        height: 57,
                        width: 57,
                        decoration: BoxDecoration(
                            color: Theme.of(context).highlightColor,
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                  color: Colors.grey.withOpacity(0.1),
                                  spreadRadius: 1,
                                  blurRadius: 3,
                                  offset: Offset(
                                      0, 1)) // changes position of shadow
                            ]),
                        child: Icon(
                          Icons.percent_sharp,
                          color: Colors.black,
                          size: 30,
                        )),
                    Padding(
                        padding: const EdgeInsets.only(top: 8),
                        child: Text("عروض التوفير",
                            textAlign: TextAlign.center,
                            style: titilliumsemiBold.copyWith(fontSize: 8))),
                  ],
                ),
              ),
            ),
            GestureDetector(
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) {
                  return FeaturedDealScreen();
                }));
              },
              child: Container(
                height: 100,
                width: MediaQuery.of(context).size.width / 5 - 4,
                child: Column(
                  children: [
                    Container(
                        height: 57,
                        width: 57,
                        decoration: BoxDecoration(
                            color: Theme.of(context).highlightColor,
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                  color: Colors.grey.withOpacity(0.1),
                                  spreadRadius: 1,
                                  blurRadius: 3,
                                  offset: Offset(
                                      0, 1)) // changes position of shadow
                            ]),
                        child: Icon(
                          Icons.local_fire_department_outlined,
                          color: Colors.black,
                          size: 30,
                        )),
                    Padding(
                        padding: const EdgeInsets.only(top: 8),
                        child: Text("الأكثر مبيعا",
                            textAlign: TextAlign.center,
                            style: titilliumsemiBold.copyWith(fontSize: 8))),
                  ],
                ),
              ),
            ),
            GestureDetector(
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) {
                  return WishListScreen();
                }));
              },
              child: Container(
                height: 100,
                width: MediaQuery.of(context).size.width / 5 - 4,
                child: Column(
                  children: [
                    Container(
                        height: 57,
                        width: 57,
                        decoration: BoxDecoration(
                            color: Theme.of(context).highlightColor,
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                  color: Colors.grey.withOpacity(0.1),
                                  spreadRadius: 1,
                                  blurRadius: 3,
                                  offset: Offset(
                                      0, 1)) // changes position of shadow
                            ]),
                        child: Icon(
                          Icons.favorite_border,
                          color: Colors.black,
                          size: 30,
                        )),
                    Padding(
                        padding: const EdgeInsets.only(top: 8),
                        child: Text("مفضلتك",
                            textAlign: TextAlign.center,
                            style: titilliumsemiBold.copyWith(fontSize: 8))),
                  ],
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class SliverDelegate extends SliverPersistentHeaderDelegate {
  Widget child;
  SliverDelegate({@required this.child});

  @override
  Widget build(
      BuildContext context, double shrinkOffset, bool overlapsContent) {
    return child;
  }

  @override
  double get maxExtent => 70;

  @override
  double get minExtent => 70;

  @override
  bool shouldRebuild(SliverDelegate oldDelegate) {
    return oldDelegate.maxExtent != 70 ||
        oldDelegate.minExtent != 70 ||
        child != oldDelegate.child;
  }
}
