import 'package:emdad/provider/auth_provider.dart';
import 'package:emdad/utility/styles.dart';
import 'package:emdad/view/screen/address/widget/location_search_dialog.dart';
import 'package:emdad/view/screen/tread_info/treadInfo.dart';
import 'package:flutter/material.dart';
import 'package:emdad/data/model/response/address_model.dart';
import 'package:emdad/localization/language_constrants.dart';
import 'package:emdad/provider/location_provider.dart';
import 'package:emdad/provider/order_provider.dart';
import 'package:emdad/provider/profile_provider.dart';
import 'package:emdad/utility/color_resources.dart';
import 'package:emdad/utility/dimensions.dart';
import 'package:emdad/view/basewidget/button/custom_button.dart';
import 'package:emdad/view/basewidget/custom_app_bar.dart';
import 'package:emdad/view/basewidget/my_dialog.dart';
import 'package:emdad/view/basewidget/textfield/custom_textfield.dart';
import 'package:emdad/view/screen/address/select_location_screen.dart';
import 'package:geolocator/geolocator.dart';

import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:provider/provider.dart';

import 'After_Map_Add_Adress_Screen.dart';
import 'AreYouSureBottomSheet.dart';
import 'add_new_address_screen.dart';

class AddFirstAddressScreen extends StatefulWidget {
  final bool isEnableUpdate;
  final bool fromCheckout;
  final AddressModel address;
  final bool isBilling;
  AddFirstAddressScreen(
      {this.isEnableUpdate = false,
      this.address,
      this.fromCheckout = false,
      this.isBilling});

  @override
  State<AddFirstAddressScreen> createState() => _AddFirstAddressScreenState();
}

class _AddFirstAddressScreenState extends State<AddFirstAddressScreen>
    with TickerProviderStateMixin {
  final TextEditingController _contactPersonNameController =
      TextEditingController();
  final TextEditingController _contactPersonNumberController =
      TextEditingController();
  //final TextEditingController _cityController = TextEditingController();
  final TextEditingController _officeNumberController = TextEditingController();
  final TextEditingController _officeBuildController = TextEditingController();
  //final TextEditingController _moreController = TextEditingController();
  final FocusNode _addressNode = FocusNode();
  final FocusNode _nameNode = FocusNode();
  //final FocusNode _numberNode = FocusNode();
  //final FocusNode _moreNode = FocusNode();
  //final FocusNode _cityNode = FocusNode();
  //final FocusNode _zipNode = FocusNode();
  final FocusNode _officeNumberNode = FocusNode();
  final FocusNode _officeBuildNode = FocusNode();
  GoogleMapController _controller;
  CameraPosition _cameraPosition =
      CameraPosition(target: LatLng(24.903623, 67.198367));
  bool _updateAddress = true;
  Address _address;
  bool isMorning = true;
  bool isMorningSelected = false;
  int timeSelectedIndex = 0;
  bool timeSelectedIndexOk = false;

  bool rememberMe = false;

  @override
  void initState() {
    super.initState();
    _address = Address.shipping;
    Provider.of<LocationProvider>(context, listen: false)
        .initializeAllAddressType(context: context);
    Provider.of<LocationProvider>(context, listen: false)
        .updateAddressStatusMessae(message: '');
    Provider.of<LocationProvider>(context, listen: false)
        .updateErrorMessage(message: '');
    _checkPermission(
        () => Provider.of<LocationProvider>(context, listen: false)
            .getCurrentLocation(context, false, mapController: _controller),
        context);
    //Provider.of<LocationProvider>(context, listen: false).getAddressFromGeocode(LatLng(90, 103), context ,);
    // _controller.animateCamera(CameraUpdate.newCameraPosition(
    //   CameraPosition(target: LatLng(90, 103), zoom: 17),
    // ));

    if (widget.isEnableUpdate && widget.address != null) {
      _updateAddress = false;
      Provider.of<LocationProvider>(context, listen: false).updatePosition(
          CameraPosition(
              target: LatLng(double.parse(widget.address.latitude),
                  double.parse(widget.address.longitude))),
          true,
          widget.address.address,
          context);
      _contactPersonNameController.text = '';
      _contactPersonNumberController.text = '${widget.address.phone}';
      if (widget.address.addressType == 'Home') {
        Provider.of<LocationProvider>(context, listen: false)
            .updateAddressIndex(0, false);
      } else if (widget.address.addressType == 'Workplace') {
        Provider.of<LocationProvider>(context, listen: false)
            .updateAddressIndex(1, false);
      } else {
        Provider.of<LocationProvider>(context, listen: false)
            .updateAddressIndex(2, false);
      }
    } else {
      if (Provider.of<ProfileProvider>(context, listen: false).userInfoModel !=
          null) {
        _contactPersonNameController.text =
            '${Provider.of<ProfileProvider>(context, listen: false).userInfoModel.fName ?? ''}'
            ' ${Provider.of<ProfileProvider>(context, listen: false).userInfoModel.lName ?? ''}';
        _contactPersonNumberController.text =
            Provider.of<ProfileProvider>(context, listen: false)
                    .userInfoModel
                    .phone ??
                '';
      }
    }
  }

  void _openSearchDialog(BuildContext context, GoogleMapController mapController) async {
    showDialog(context: context, builder: (context) => LocationSearchDialog(mapController: mapController));
  }
  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    print('====selected shipping or billing==>${_address.toString()}');
    Provider.of<LocationProvider>(context, listen: false).setPickData();
    Provider.of<LocationProvider>(context, listen: false)
        .getCurrentLocation(context, false, mapController: _controller);
    Provider.of<ProfileProvider>(context, listen: false)
        .initAddressList(context);
    Provider.of<ProfileProvider>(context, listen: false)
        .initAddressTypeList(context);
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Column(
            children: [
              Consumer<LocationProvider>(
                builder: (context, locationProvider, child) {
                  return

                      // SizedBox(
                      //   height: 50,
                      // ),
                      Expanded(
                        child: Container(
                          child: Consumer<LocationProvider>(
                            builder: (context, locationProvider, child) => Stack(
                              clipBehavior: Clip.none,
                              children: [
                                GoogleMap(
                                  mapType: MapType.normal,
                                  //zoomGesturesEnabled: true,
                                  initialCameraPosition: CameraPosition(
                                    target:


                                    locationProvider.position.latitude!=null?
                                    LatLng(locationProvider.position.latitude, locationProvider.position.longitude)

                                        :LatLng(0.452937,3-15.697047),
                                    // widget.isEnableUpdate
                                    // //24.903623, 67.198367
                                    //     ? LatLng(double.parse(widget.address.latitude) ?? 24.903623,
                                    //     double.parse(widget.address.longitude) ?? 67.198367)
                                    //     : LatLng(locationProvider.position.latitude ?? 24.903623,
                                    //     locationProvider.position.longitude ?? 67.198367),
                                    zoom: -20,
                                  ),
                                  onTap: (latLng) {
                                    Navigator.of(context).push(
                                        MaterialPageRoute(
                                            builder:
                                                (BuildContext context) =>
                                                    SelectLocationScreen(
                                                        googleMapController:
                                                            _controller)));
                                  },
                                  zoomControlsEnabled: false,
                                  compassEnabled: false,
                                  indoorViewEnabled: true,
                                  mapToolbarEnabled: true,
                                  onCameraIdle: () {
                                    if (_updateAddress) {
                                      locationProvider.updatePosition(
                                          _cameraPosition,
                                          false,
                                          null,
                                          context);
                                    } else {
                                      _updateAddress = true;
                                    }
                                  },
                                  onCameraMove: ((_position) =>
                                      _cameraPosition = _position),
                                  onMapCreated:
                                      (GoogleMapController controller) {
                                    _controller = controller;
                                    if (!widget.isEnableUpdate &&
                                        _controller != null) {
                                      Provider.of<LocationProvider>(context,
                                              listen: false)
                                          .getCurrentLocation(context, true,
                                              mapController: _controller);
                                    }
                                  },
                                ),

                                locationProvider.pickAddress != null
                                    ? InkWell(
                                  onTap: () => _openSearchDialog(context, _controller),
                                  child: Container(
                                    width: MediaQuery.of(context).size.width,
                                    padding: const EdgeInsets.symmetric(horizontal: Dimensions.PADDING_SIZE_LARGE, vertical: 10.0),
                                    margin: const EdgeInsets.symmetric(horizontal: Dimensions.PADDING_SIZE_LARGE, vertical: 15.0),
                                    decoration:
                                    BoxDecoration(color: Colors.black, borderRadius: BorderRadius.circular(30)
                                      , border: Border.all(
                                        color: Colors.grey,  // red as border color
                                      ),

                                    ),
                                    child: Row(
                                        mainAxisAlignment: MainAxisAlignment.end,
                                        children: [
                                          Expanded(child: Text(locationProvider.pickAddress.name != null
                                              ? '${locationProvider.pickAddress.name ?? ''} ${locationProvider.pickAddress.subAdministrativeArea ?? ''} ${locationProvider.pickAddress.isoCountryCode ?? ''}'
                                              : '', maxLines: 1, overflow: TextOverflow.ellipsis
                                            ,style: TextStyle(fontSize: 12,fontWeight: FontWeight.w500
                                                ,color: Colors.white
                                            ),
                                          )),
                                          CircleAvatar(
                                              backgroundColor: Colors.transparent,
                                              radius: 15,
                                              child: Icon(Icons.search, size: 20 , color: ColorResources.white,)),
                                        ]),
                                  ),
                                )
                                    : Container(color: Colors.green,),
                                Positioned(
                                  bottom: 0,
                                  right: 0,
                                  left: 0,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      InkWell(
                                        onTap: () {
                                          locationProvider.getCurrentLocation(context, false, mapController: _controller);
                                        },
                                        child: Padding(
                                          padding: const EdgeInsets.only(left: 8.0),
                                          child: CircleAvatar(
                                            backgroundColor: Theme.of(context).primaryColor,
                                            child: Container(
                                              //width: 20,
                                              // height: 20,
                                              //margin: EdgeInsets.only(right: Dimensions.PADDING_SIZE_LARGE),
                                              decoration: BoxDecoration(
                                                borderRadius: BorderRadius.circular(Dimensions.PADDING_SIZE_SMALL),
                                                color: Colors.transparent,
                                              ),
                                              child: Center(
                                                child: Icon(
                                                  Icons.my_location,
                                                  color: Colors.white,
                                                  size: 25,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        width: double.infinity,
                                        child: Padding(
                                          padding: const EdgeInsets.all(Dimensions.PADDING_SIZE_LARGE),
                                          child: CustomButton(
                                            buttonText: getTranslated('select_location', context),
                                            onTap: () async {
                                              if(_controller != null) {
                                                _controller.moveCamera(CameraUpdate.newCameraPosition(CameraPosition(target: LatLng(
                                                  locationProvider.pickPosition.latitude, locationProvider.pickPosition.longitude,
                                                ), zoom: 17)));
                                                locationProvider.setAddAddressData();
                                              }
                                              //Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => AddFirstAddressScreen(isEnableUpdate: false,)));

                                              locationProvider.pickAddress.name!=null?
                                              locationProvider.pickAddress.name.contains("Yemen")== true?


                                              Navigator.pushReplacement(
                                                       context,
                                                       MaterialPageRoute(
                                                           builder: (_) =>
                                                               After_Map_Add_New_Adress_Screen(isBilling: false
                                                               ,controller: _controller,
                                                               ))):
                                             // Navigator.of(context).pop():
                                              await showModalBottomSheet(
                                                context: context, isScrollControlled: true, backgroundColor: Colors.transparent,
                                                builder: (context) => AreYouSureBottomSheet(groupId: locationProvider.locationController.text,sellerIndex: 0, sellerId: 1),
                                              ):
                                              print("selectLocationnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn");


                                              // Navigator.of(context).pop();
                                            },
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                locationProvider.pickAddress.name!=null?
                                locationProvider.pickAddress.name.contains("Yemen")== true?
                                Positioned(
                                    bottom: 30,
                                    right: 0,
                                    left: 0,
                                    child:  Container(
                                      decoration: BoxDecoration(
                                          color: Colors.green,
                                          border: Border.all(
                                            color: Colors.green,
                                          ),
                                          borderRadius: BorderRadius.all(Radius.circular(20))),
                                      margin:EdgeInsets.all(65) ,
                                      //padding: EdgeInsets.all(15),
                                      width: double.minPositive,
                                      height:30,
                                      //color: Colors.red,
                                      child: Center(child: Text("مكانك داخل التغطيه",style: titilliumRegular.copyWith(color: Colors.white
                                          ,fontSize: 10
                                      ),),),
                                    )):
                                Positioned(
                                    bottom: 30,
                                    right: 0,
                                    left: 0,
                                    child: Container(
                                      decoration: BoxDecoration(
                                          color: Colors.red,
                                          border: Border.all(
                                            color: Colors.red[500],
                                          ),
                                          borderRadius: BorderRadius.all(Radius.circular(20))),
                                      margin:EdgeInsets.all(65) ,
                                      //padding: EdgeInsets.all(15),
                                      width: double.minPositive,
                                      height:30,
                                      //color: Colors.red,
                                      child: Center(child: Text("مكانك قد يكون خارج التغطيه",style: titilliumRegular.copyWith(color: Colors.white
                                          ,fontSize: 10
                                      ),),),
                                    )):SizedBox(),
                                Center(
                                    child: Icon(
                                      Icons.location_on,
                                      color: Theme.of(context).primaryColor,
                                      size: 50,
                                    )),
                                locationProvider.loading
                                    ? Center(child: CircularProgressIndicator(valueColor: AlwaysStoppedAnimation<Color>(Theme.of(context).primaryColor)))
                                    : SizedBox(),


                              ],
                            ),
                          ),
                        ),
                      );
//                       locationProvider.loading
//                           ? Center(
//                               child: CircularProgressIndicator(
//                                   valueColor:
//                                       AlwaysStoppedAnimation<
//                                               Color>(
//                                           Theme.of(context)
//                                               .primaryColor)))
//                           : SizedBox(),
//                       Container(
//                           width:
//                               MediaQuery.of(context).size.width,
//                           alignment: Alignment.center,
//                           height:
//                               MediaQuery.of(context).size.height,
//                           child: Icon(
//                             Icons.location_on,
//                             size: 40,
//                             color: Theme.of(context).primaryColor,
//                           )),
//                       // Positioned(
//                       //   bottom: 10,
//                       //   right: 0,
//                       //   child: InkWell(
//                       //     onTap: () {
//                       //       _checkPermission(() => locationProvider.getCurrentLocation(context, true, mapController: _controller),context);
//                       //     },
//                       //     child: Container(
//                       //         width: 200,
//                       //         height: 30,
//                       //         margin: EdgeInsets.only(right: Dimensions.PADDING_SIZE_LARGE),
//                       //         decoration: BoxDecoration(
//                       //           borderRadius: BorderRadius.circular(Dimensions.PADDING_SIZE_SMALL),
//                       //           color: ColorResources.getChatIcon(context),
//                       //         ),
//                       //         child: Row(
//                       //             mainAxisAlignment: MainAxisAlignment.center,
//                       //             mainAxisSize: MainAxisSize.min,
//                       //             children: [ Icon(
//                       //               Icons.my_location,
//                       //               color: Theme.of(context).primaryColor,
//                       //               size: 20,
//                       //             ),
//                       //               SizedBox(width: Dimensions.PADDING_SIZE_SMALL),
//                       //               Text(
//                       //                 getTranslated('clickToSelectAutoLocation', context),
//                       //                 style: robotoRegular.copyWith(color: ColorResources.getTextTitle(context)),
//                       //               ),
//                       //             ])
//                       //     ),
//                       //   ),
//                       // ),
//                       Positioned(
//                         top: 10,
//                         right: 0,
//                         child: InkWell(
//                           onTap: () {
//                             Navigator.of(context).push(
//                                 MaterialPageRoute(
//                                     builder: (BuildContext
//                                             context) =>
//                                         SelectLocationScreen(
//                                             googleMapController:
//                                                 _controller)));
//                           },
//                           child: Container(
//                             width: 30,
//                             height: 30,
//                             margin: EdgeInsets.only(
//                                 right: Dimensions
//                                     .PADDING_SIZE_LARGE),
//                             decoration: BoxDecoration(
//                               borderRadius: BorderRadius.circular(
//                                   Dimensions.PADDING_SIZE_SMALL),
//                               color: Colors.white,
//                             ),
//                             child: Icon(
//                               Icons.fullscreen,
//                               color:
//                                   Theme.of(context).primaryColor,
//                               size: 20,
//                             ),
//                           ),
//                         ),
//                       ),
//
//                       // for Address Field
//                       SizedBox(height: Dimensions.PADDING_SIZE_SMALL),
//                       CustomTextField(
//                         hintText:
//                             getTranslated('address_line_02', context),
//                         textInputType: TextInputType.streetAddress,
//                         textInputAction: TextInputAction.next,
//                         focusNode: _addressNode,
//                         nextNode: _nameNode,
//                         controller: locationProvider.locationController,
//                       ),
//                       //SizedBox(height: Dimensions.PADDING_SIZE_DEFAULT_ADDRESS),
//                       // for Contact Person Name
//
//                       SizedBox(height: Dimensions.PADDING_SIZE_DEFAULT),
//
//                       // الارسال
//                       locationProvider.addressStatusMessage != null
//                           ? Row(
//                               crossAxisAlignment: CrossAxisAlignment.start,
//                               children: [
//                                 locationProvider.addressStatusMessage.length >
//                                         0
//                                     ? CircleAvatar(
//                                         backgroundColor: Colors.green,
//                                         radius: 5)
//                                     : SizedBox.shrink(),
//                                 SizedBox(width: 8),
//                                 Expanded(
//                                   child: Text(
//                                     locationProvider.addressStatusMessage ??
//                                         "",
//                                     style: Theme.of(context)
//                                         .textTheme
//                                         .headline2
//                                         .copyWith(
//                                             fontSize:
//                                                 Dimensions.FONT_SIZE_SMALL,
//                                             color: Colors.green,
//                                             height: 1),
//                                   ),
//                                 )
//                               ],
//                             )
//                           : Row(
//                               crossAxisAlignment: CrossAxisAlignment.start,
//                               children: [
//                                 locationProvider.errorMessage.length > 0
//                                     ? CircleAvatar(
//                                         backgroundColor:
//                                             Theme.of(context).primaryColor,
//                                         radius: 5)
//                                     : SizedBox.shrink(),
//                                 SizedBox(width: 8),
//                                 Expanded(
//                                   child: Text(
//                                     locationProvider.errorMessage ?? "",
//                                     style: Theme.of(context)
//                                         .textTheme
//                                         .headline2
//                                         .copyWith(
//                                             fontSize:
//                                                 Dimensions.FONT_SIZE_SMALL,
//                                             color: Theme.of(context)
//                                                 .primaryColor,
//                                             height: 1),
//                                   ),
//                                 )
//                               ],
//                             ),
//                       Container(
//                         height: 50.0,
//                         margin: EdgeInsets.all(Dimensions.PADDING_SIZE_SMALL),
//                         child: !locationProvider.isLoading
//                             ? CustomButton(
//                                 buttonText: widget.isEnableUpdate
//                                     ? getTranslated('update_address', context)
//                                     : getTranslated('save_location', context),
//                                 onTap: locationProvider.loading
//                                     ? null
//                                     : () async {
//                                         if (locationProvider
//                                                     .pickAddress.name !=
//                                                 null &&
//                                             locationProvider.pickAddress.name
//                                                     .contains("Yemen") ==
//                                                 true) {
//                                           AddressModel addressModel =
//                                               AddressModel(
//                                             addressType: locationProvider
//                                                     .getAllAddressType[
//                                                 locationProvider
//                                                     .selectAddressIndex],
//                                             contactPersonName:
//                                                 'الاساسيس' ?? '',
//                                             phone:
//                                                 Provider.of<ProfileProvider>(
//                                                             context,
//                                                             listen: false)
//                                                         .userInfoModel
//                                                         .phone ??
//                                                     '',
//                                             city: locationProvider
//                                                         .getAllAddressType[
//                                                     locationProvider
//                                                         .selectAddressIndex] ??
//                                                 '',
//                                             zip: Provider.of<ProfileProvider>(
//                                                         context,
//                                                         listen: false)
//                                                     .userInfoModel
//                                                     .phone ??
//                                                 '',
//                                             isBilling:
//                                                 _address == Address.billing
//                                                     ? 1
//                                                     : 0,
//                                             address: locationProvider
//                                                     .locationController
//                                                     .text ??
//                                                 '',
//                                             latitude: widget.isEnableUpdate
//                                                 ? locationProvider
//                                                         .position.latitude
//                                                         .toString() ??
//                                                     widget.address.latitude
//                                                 : locationProvider
//                                                         .position.latitude
//                                                         .toString() ??
//                                                     '',
//                                             longitude: widget.isEnableUpdate
//                                                 ? locationProvider
//                                                         .position.longitude
//                                                         .toString() ??
//                                                     widget.address.longitude
//                                                 : locationProvider
//                                                         .position.longitude
//                                                         .toString() ??
//                                                     '',
//                                           );
//
//                                           if (widget.isEnableUpdate) {
//                                             addressModel.id =
//                                                 widget.address.id;
//                                             addressModel.id =
//                                                 widget.address.id;
// // addressModel.method = 'put';
//                                             locationProvider
//                                                 .updateAddress(context,
//                                                     addressModel:
//                                                         addressModel,
//                                                     addressId:
//                                                         addressModel.id)
//                                                 .then((value) {});
//                                           } else {
//                                             locationProvider
//                                                 .addAddress(
//                                                     addressModel, context)
//                                                 .then((value) {
//                                               if (value.isSuccess) {
//                                                 Provider.of<ProfileProvider>(
//                                                         context,
//                                                         listen: false)
//                                                     .initAddressList(context);
//                                                 if (widget.fromCheckout) {
//                                                   Provider.of<ProfileProvider>(
//                                                           context,
//                                                           listen: false)
//                                                       .initAddressList(
//                                                           context);
//                                                   print(
//                                                       'fromCheckout::::: fromCheckout');
//                                                   Provider.of<OrderProvider>(
//                                                           context,
//                                                           listen: false)
//                                                       .setAddressIndex(1);
//                                                   Provider.of<AuthProvider>(
//                                                           context,
//                                                           listen: false)
//                                                       .setAddressInfoFinch();
//                                                   Provider.of<AuthProvider>(
//                                                           context,
//                                                           listen: false)
//                                                       .setTreadInfo();
//
//                                                   locationProvider.pickAddress.name!=null?
//                                                   locationProvider.pickAddress.name.contains("Yemen")== true?
//                                                   Navigator.pushReplacement(
//                                                       context,
//                                                       MaterialPageRoute(
//                                                           builder: (_) =>
//                                                               TreadInfo(
//                                                                   start:
//                                                                   true))):
//                                                   print("selectLocationnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn"):
//
//                                                   print("selectLocationnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn");
//
//
//
//                                                 } else {
//                                                   ScaffoldMessenger.of(
//                                                           context)
//                                                       .showSnackBar(SnackBar(
//                                                           content: Text(
//                                                               value.message),
//                                                           duration: Duration(
//                                                               milliseconds:
//                                                                   600),
//                                                           backgroundColor:
//                                                               Colors.green));
//                                                   Provider.of<AuthProvider>(
//                                                           context,
//                                                           listen: false)
//                                                       .setTreadInfo();
//                                                   Navigator.pushReplacement(
//                                                       context,
//                                                       MaterialPageRoute(
//                                                           builder: (_) =>
//                                                               TreadInfo(
//                                                                   start:
//                                                                       true)));
//                                                 }
//                                               } else {
//                                                 ScaffoldMessenger.of(context)
//                                                     .showSnackBar(SnackBar(
//                                                         content: Text(
//                                                             value.message),
//                                                         duration: Duration(
//                                                             milliseconds:
//                                                                 600),
//                                                         backgroundColor:
//                                                             Colors.red));
//                                               }
//                                             });
//                                           }
// // }
//
//                                         } else {
//                                           await showModalBottomSheet(
//                                               context: context,
//                                               isScrollControlled: true,
//                                               backgroundColor:
//                                                   Colors.transparent,
//                                               builder: (context) =>
//                                                   AreYouSureBottomSheet(
//                                                       groupId: locationProvider
//                                                           .locationController
//                                                           .text,
//                                                       sellerIndex: 0,
//                                                       sellerId: 1));
//                                         }
//
//                                         /*
//                             if(timeSelectedIndexOk == false) {
//                               showCustomSnackBar('يجب اختيار نوع النشاط', context, isError: false);
//                              } else if (isMorningSelected == false){
//                               showCustomSnackBar('يجب إختيار النشاط والضغط مره أخرى للتأكد', context, isError: false);
//                             } else {
//
//                             */
//                                       })
//                             : Center(
//                                 child: CircularProgressIndicator(
//                                 valueColor: new AlwaysStoppedAnimation<Color>(
//                                     Theme.of(context).primaryColor),
//                               )),
//                       )


                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _checkPermission(Function callback, BuildContext context) async {
    LocationPermission permission = await Geolocator.requestPermission();
    if (permission == LocationPermission.denied ||
        permission == LocationPermission.whileInUse) {
      InkWell(
          onTap: () async {
            Navigator.pop(context);
            await Geolocator.requestPermission();
            _checkPermission(callback, context);
          },
          child: AlertDialog(
              content: MyDialog(
                  icon: Icons.location_on_outlined,
                  title: '',
                  description: getTranslated('you_denied', context))));
    } else if (permission == LocationPermission.deniedForever) {
      InkWell(
          onTap: () async {
            Navigator.pop(context);
            await Geolocator.openAppSettings();
            _checkPermission(callback, context);
          },
          child: AlertDialog(
              content: MyDialog(
                  icon: Icons.location_on_outlined,
                  title: '',
                  description: getTranslated('you_denied', context))));
    } else {
      callback();
    }
  }
}

enum Address { shipping, billing }
