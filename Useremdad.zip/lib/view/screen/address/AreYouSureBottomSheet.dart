import 'package:emdad/provider/order_provider.dart';
import 'package:emdad/provider/theme_provider.dart';
import 'package:emdad/utility/color_resources.dart';
import 'package:emdad/utility/custom_themes.dart';
import 'package:emdad/utility/dimensions.dart';
import 'package:emdad/utility/styles.dart';
import 'package:emdad/view/basewidget/button/custom_button.dart';
import 'package:emdad/view/basewidget/show_custom_snakbar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:emdad/localization/language_constrants.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../../../utility/custom_themes.dart';
import '../../basewidget/button/custom_button2.dart';

List weekdays = [
  "غدا",
  DateFormat('EEEE').format(DateTime.now().add(Duration(days: 2))),
  DateFormat('EEEE').format(DateTime.now().add(Duration(days: 3))),
  DateFormat('EEEE').format(DateTime.now().add(Duration(days: 4))),
  DateFormat('EEEE').format(DateTime.now().add(Duration(days: 5))),
  DateFormat('EEEE').format(DateTime.now().add(Duration(days: 6))),
  DateFormat('EEEE').format(DateTime.now().add(Duration(days: 7))),
];
List timeToDelivery = [
  ' ص 12:00-ص 8:00',
  'م 6:00-م 5:00',
];

class AreYouSureBottomSheet extends StatefulWidget {
  final String groupId;
  final int sellerId;
  final int sellerIndex;

  AreYouSureBottomSheet({@required this.groupId, @required this.sellerId, @required this.sellerIndex});

  @override
  _AreYouSureBottomSheetState createState() => _AreYouSureBottomSheetState();
}

class _AreYouSureBottomSheetState extends State<AreYouSureBottomSheet> {

  bool isChecked = false;
  bool isMorning = true;
  int selectedDate = -1;
  int timeSelectedIndex = -1;
  bool isVoiceCall = true;
  bool isMessage = false;
  bool isVideoCall = false;

  bool isTime = false;

  final GlobalKey<ScaffoldMessengerState> _scaffoldKey = GlobalKey<ScaffoldMessengerState>();





  @override
  void initState() {
    //Provider.of<CartProvider>(context,listen: false).getShippingMethod(context, widget.cart.sellerId,widget.sellerIndex);
    timeSelectedIndex = Provider.of<OrderProvider>(context, listen: false).timeDeliveryIndex;

    selectedDate = Provider.of<OrderProvider>(context, listen: false).dayDeliveryDataIndex;
    print("lllllllllllll");
    print( Provider.of<OrderProvider>(context, listen: false).timeDeliveryIndex);
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [

        Padding(
          padding: const EdgeInsets.only(top: 30.0),
          child: Container(

            height: MediaQuery.of(context).size.height *0.30,
            padding: EdgeInsets.all(Dimensions.PADDING_SIZE_EXTRA_LARGE),
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.8),
              borderRadius: BorderRadius.only(topRight: Radius.circular(40), topLeft: Radius.circular(40)),
            ),
            child: Column( mainAxisSize: MainAxisSize.min, children: [


              SizedBox(height: 10,),

              Text("هذا الموقع خارج نطاق الحدود", style: titilliumvBold.copyWith(fontSize: 12 , color: Colors.white)),
              Expanded(
                child: Container(
                  //height: 60,
                  margin: EdgeInsets.only(right: Dimensions.MARGIN_SIZE_DEFAULT, left: Dimensions.MARGIN_SIZE_DEFAULT, top: Dimensions.MARGIN_SIZE_DEFAULT),
                  child: Text(widget.groupId,

                    style: titilliumSemiBold.copyWith(
                      height: 1.3,
                        overflow:  TextOverflow.visible,
                        color: Theme.of(context).primaryColor,


                        fontSize: 12),
                  ),
                ),
              ),
           SizedBox(height: 20,),

    Row(
      children: [
        // Expanded(
        //   //width: 30,
        //   child: CustomButton2(
        //     height: 40,
        //     width: 100,
        //
        //
        //     buttonText: "تأكيد",
        //     onTap: (){
        //
        //       Navigator.of(context).pop();
        //       Navigator.of(context).pop();
        //
        //
        //
        //     },
        //   ),
        // ),
       // SizedBox(width: 20,),
        Expanded(
          child: CustomButton2(
            height: 40,
            width: 100,
            buttonText: "تعديل",
            onTap: (){
              Navigator.of(context).pop();




            },
          ),
        ),

      ],
    )

            ]),
          ),
        ),
        Positioned(
          bottom: 220,
          left: 160,
          top: 0,
          child: InkWell(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 60,
              height: 60,
              decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.redAccent.withOpacity(0.9),
                  //boxShadow: [BoxShadow(color: Colors.grey[Provider.of<ThemeProvider>(context).darkTheme ? 700 : 200], spreadRadius: 1, blurRadius: 10)]
              ),
              child: Icon(Icons.location_on, size: Dimensions.ICON_SIZE_LARGE , color: ColorResources.white,)
            ),
          ),
        ),
      ],
    );
  }
}
