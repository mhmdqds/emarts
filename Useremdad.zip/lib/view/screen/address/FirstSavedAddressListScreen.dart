import 'package:emdad/provider/theme_provider.dart';
import 'package:emdad/view/screen/address/select_location_screen.dart';
import 'package:flutter/material.dart';
import 'package:emdad/localization/language_constrants.dart';
import 'package:emdad/provider/order_provider.dart';
import 'package:emdad/provider/profile_provider.dart';

import 'package:emdad/utility/images.dart';
import 'package:flutter/material.dart';
import 'package:emdad/localization/language_constrants.dart';
import 'package:emdad/provider/auth_provider.dart';
import 'package:emdad/provider/profile_provider.dart';
import 'package:emdad/utility/color_resources.dart';
import 'package:emdad/utility/dimensions.dart';
import 'package:emdad/view/basewidget/custom_app_bar.dart';
import 'package:emdad/view/basewidget/no_internet_screen.dart';
import 'package:emdad/view/basewidget/not_loggedin_widget.dart';
import 'package:emdad/view/basewidget/show_custom_modal_dialog.dart';
import 'package:emdad/view/screen/address/add_new_address_screen.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:provider/provider.dart';
import '../../../../utility/styles.dart';
import 'add_first_address_screen.dart';

class FirstSavedAddressListScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    bool isGuestMode =
        !Provider.of<AuthProvider>(context, listen: false).isLoggedIn();
    if (!isGuestMode) {
      Provider.of<ProfileProvider>(context, listen: false)
          .initAddressTypeList(context);
      Provider.of<ProfileProvider>(context, listen: false)
          .initAddressList(context);
    }
    GoogleMapController _controller;

    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
        // floatingActionButton: isGuestMode ? null : FloatingActionButton(
        //   onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (BuildContext context) => AddNewAddressScreen(isBilling: false))),
        //   child: Icon(Icons.add, color: Theme.of(context).highlightColor),
        //   backgroundColor: ColorResources.getPrimary(context),
        // ),
        body: SafeArea(
          child: SingleChildScrollView(
            //scrollDirection: Axis.,
            child: Padding(
              padding: const EdgeInsets.all(5.0),
              child: Column(
                children: [
                  Row(children: [
                    Padding(
                      padding: const EdgeInsets.only(
                          top: Dimensions.PADDING_SIZE_LARGE,
                          right: Dimensions.PADDING_SIZE_LARGE),
                      child: Row(children: [
                        SizedBox(width: Dimensions.PADDING_SIZE_SMALL),
                        Text(getTranslated('good evening', context),
                            style: titilliumBold.copyWith(
                                color: ColorResources.COLOR_BLACK,
                                fontSize: Dimensions.MARGIN_SIZE_DEFAULT)),
                        SizedBox(width: Dimensions.PADDING_SIZE_SMALL),
                        Text("👋",
                            style: titilliumRegular.copyWith(
                                fontSize: Dimensions.PADDING_SIZE_LARGE)),

                        /*
                              isGuestMode ? CircleAvatar(child: Icon(Icons.person, size: 35)) :


                                profile.userInfoModel == null ? CircleAvatar(child: Icon(Icons.person, size: 35)) : ClipRRect(
                                  borderRadius: BorderRadius.circular(15),
                                  child: FadeInImage.assetNetwork(
                                    placeholder: Images.logo_image, width: 35, height: 35, fit: BoxFit.fill,
                                    image: '${Provider.of<SplashProvider>(context,listen: false).baseUrls.customerImageUrl}/${profile.userInfoModel.image}',
                                    imageErrorBuilder: (c, o, s) => CircleAvatar(child: Icon(Icons.person, size: 35)),
                                  ),
                            ),
                               */
                      ]),
                      //Image.asset(Images.logo_with_name_image, height: 35),
                    ),
                    // Expanded(child: SizedBox.shrink()),
                  ]),
                  SizedBox(width: Dimensions.PADDING_SIZE_SMALL),
                  isGuestMode
                      ? NotLoggedInWidget()
                      : Consumer<ProfileProvider>(
                          builder: (context, profileProvider, child) {
                            return profileProvider.shippingAddressList != null
                                ? profileProvider.shippingAddressList.length > 0
                                    ? RefreshIndicator(
                                        onRefresh: () async {
                                          Provider.of<ProfileProvider>(context,
                                                  listen: false)
                                              .initAddressTypeList(context);
                                          await Provider.of<ProfileProvider>(
                                                  context,
                                                  listen: false)
                                              .initAddressList(context);
                                        },
                                        backgroundColor:
                                            Theme.of(context).primaryColor,
                                        child: ListView.builder(
                                          physics:
                                              const NeverScrollableScrollPhysics(),
                                          shrinkWrap: true,
                                          padding: EdgeInsets.all(10),
                                          itemCount: profileProvider
                                              .shippingAddressList.length,
                                          itemBuilder: (context, index) =>
                                              InkWell(
                                            onTap: () {
                                              // Navigator.of(context).push(MaterialPageRoute(builder: (BuildContext context) => AddNewAddressScreen(isBilling: false)));
                                            },
                                            child: Card(
                                              shape: RoundedRectangleBorder(
                                                side: BorderSide(
                                                  color:
                                                  profileProvider.addressList.first.address ==profileProvider.shippingAddressList[index].address?

                                                  ColorResources.primaryColor :
                                                  Colors.white//<-//<-- SEE HERE
                                                ),
                                                borderRadius:
                                                    BorderRadius.circular(40.0),
                                              ),
                                              child: Stack(
                                                children: [
                                                  SizedBox(
                                                    height: 30,
                                                  ),
                                                  Container(
                                                    height: 150,
                                                    width: 140,
                                                    decoration: BoxDecoration(
                                                      color: Colors.white,
                                                      borderRadius:
                                                          BorderRadius.all(
                                                              Radius.circular(
                                                                  40)),
                                                    ),

                                                    // shape: RoundedRectangleBorder(
                                                    //   side: BorderSide(
                                                    //     //color: Colors.deepPurpleAccent, //<-- SEE HERE
                                                    //   ),
                                                    //   borderRadius: BorderRadius.circular(30.0),
                                                    // ),
                                                    child: ClipRRect(
                                                      borderRadius:
                                                          BorderRadius.only(
                                                              topRight: Radius
                                                                  .circular(40),
                                                              bottomRight:
                                                                  Radius
                                                                      .circular(
                                                                          40)),
                                                      child: Image(
                                                        image: AssetImage(Images
                                                            .locationPoint),
                                                        fit: BoxFit.cover,
                                                        //height:220 ,
                                                        //width: 140,
                                                      ),
                                                    ),
                                                  ),

                                                  Column(
                                                    children: [
                                                      SizedBox(
                                                        height: 0,
                                                      ),
                                                      ListTile(
                                                        // title: Text('العنوان : ${profileProvider.shippingAddressList[index].address}' ?? "",style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_SMALL, color: ColorResources.COLOR_BLACK,)),
                                                        //  subtitle: Column(
                                                        //    children: [
                                                        //      Text('${getTranslated('city', context)} : ${profileProvider.shippingAddressList[index].city ?? ""}',
                                                        //          maxLines: 1, style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_EXTRA_SMALLest, color: ColorResources.COLOR_BLACK
                                                        //
                                                        //            ,)),
                                                        //      SizedBox(width: Dimensions.PADDING_SIZE_EXTRA_SMALL),
                                                        //      Text('${profileProvider.shippingAddressList[index].zip ?? ""}',
                                                        //          maxLines: 1,style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_EXTRA_SMALLest, color: ColorResources.COLOR_BLACK
                                                        //
                                                        //            ,)),
                                                        //    ],
                                                        //  ),
                                                        trailing: CircleAvatar(
                                                          backgroundColor:
                                                              Colors.teal,
                                                          radius: 15,
                                                          child: IconButton(
                                                            icon: Icon(
                                                              Icons.edit,
                                                              color:
                                                                  Colors.white,
                                                              size: 15,
                                                            ),
                                                            onPressed: () {
                                                              // showCustomModalDialog(
                                                              //   context,
                                                              //   title: getTranslated(
                                                              //       'REMOVE_ADDRESS',
                                                              //       context),
                                                              //   content: profileProvider
                                                              //       .shippingAddressList[
                                                              //           index]
                                                              //       .address,
                                                              //   cancelButtonText:
                                                              //       getTranslated(
                                                              //           'CANCEL',
                                                              //           context),
                                                              //   submitButtonText:
                                                              //       getTranslated(
                                                              //           'REMOVE',
                                                              //           context),
                                                              //   submitOnPressed:
                                                              //       () {
                                                              //     Provider.of<ProfileProvider>(
                                                              //             context,
                                                              //             listen:
                                                              //                 false)
                                                              //         .removeAddressById(
                                                              //             profileProvider
                                                              //                 .shippingAddressList[index]
                                                              //                 .id,
                                                              //             index,
                                                              //             context);
                                                              //     Provider.of<ProfileProvider>(
                                                              //             context,
                                                              //             listen:
                                                              //                 false)
                                                              //         .initAddressList(
                                                              //             context);
                                                              //     Navigator.of(
                                                              //             context)
                                                              //         .pop();
                                                              //   },
                                                              //   cancelOnPressed: () =>
                                                              //       Navigator.of(
                                                              //               context)
                                                              //           .pop(),
                                                              // );
                                                            },
                                                          ),
                                                        ),
                                                      ),

                                                      // SizedBox(height: Dimensions.PADDING_SIZE_LARGE,),

                                                      Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .end,
                                                        children: [
                                                          Container(
                                                              height: 22,
                                                              width: 180,
                                                              child: Text(
                                                                  '${profileProvider.shippingAddressList[index].address

                                                                      // .substring(
                                                                      // profileProvider.shippingAddressList[index].address.indexOf(",")+1 ,

                                                                      }' ??
                                                                      "",
                                                                  style: titilliumRegular
                                                                      .copyWith(
                                                                    fontSize:
                                                                        Dimensions
                                                                            .FONT_SIZE_SMALL,
                                                                    color: ColorResources
                                                                        .COLOR_BLACK,
                                                                  ))),
                                                          SizedBox(
                                                            width: 20,
                                                          ),
                                                        ],
                                                      ),

                                                      SizedBox(
                                                        height: 0,
                                                      ),
                                                    ],
                                                  ),

                                                  // Positioned(left: 0,top: 0,
                                                  //   child: Container(
                                                  //     decoration: BoxDecoration(
                                                  //       borderRadius: BorderRadius.only(bottomLeft: Radius.circular(5),topLeft: Radius.circular(5)),
                                                  //       color: Theme.of(context).primaryColor,
                                                  //     ),
                                                  //     child: Padding(
                                                  //       padding: const EdgeInsets.all(5.0),
                                                  //       child: Text(profileProvider.shippingAddressList[index].isBilling ==0?
                                                  //   getTranslated('shipping_address', context):getTranslated('billing_address', context),
                                                  //         style: robotoRegular.copyWith(fontSize: 8, color: Theme.of(context).cardColor),),
                                                  //     ),),
                                                  // )
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      )
                                    : SizedBox()
                                : Center(
                                    child: CircularProgressIndicator(
                                        valueColor:
                                            AlwaysStoppedAnimation<Color>(
                                                Theme.of(context)
                                                    .primaryColor)));
                          },
                        ),

                  Padding(
                    padding: const EdgeInsets.only(left: 10.0 , right: 10),
                    child: InkWell(
                      onTap: (){
                        Navigator.of(context).push(MaterialPageRoute(builder: (BuildContext context) =>
                        //SelectLocationScreen(googleMapController: _controller)));
                        //  AddNewAddressScreen(isBilling: false)));

                        //SelectLocationScreen(googleMapController: _controller,)));
                        AddFirstAddressScreen(isEnableUpdate: false)));


                      },
                      child: Card(
                        shape: RoundedRectangleBorder(
                          side: BorderSide(
                              color: Colors.white
                          ),
                          borderRadius: BorderRadius.circular(40.0),
                        ),

                        child: Stack(
                          children: [
                            SizedBox(height: 30,),
                            Container(



                              height:150 ,
                              width: 140,
                              decoration: BoxDecoration(
                                color: Colors.black.withOpacity(0.5),
                                borderRadius: BorderRadius.all(Radius.circular(40)),
                              ),

                              // shape: RoundedRectangleBorder(
                              //   side: BorderSide(
                              //     //color: Colors.deepPurpleAccent, //<-- SEE HERE
                              //   ),
                              //   borderRadius: BorderRadius.circular(30.0),
                              // ),
                              child: ClipRRect(
                                borderRadius: BorderRadius.only( topRight: Radius.circular(40)  , bottomRight: Radius.circular(40)

                                ),
                                child: Image(image: AssetImage(Images.old)
                                  ,fit: BoxFit.fill,
                                  //height:220 ,
                                  //width: 140,

                                ),
                              ),
                            ),

                            Column(
                              children: [
                                SizedBox(height: 0,),
                                ListTile(
                                  // title: Text('العنوان : ${profileProvider.shippingAddressList[index].address}' ?? "",style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_SMALL, color: ColorResources.COLOR_BLACK,)),
                                  //  subtitle: Column(
                                  //    children: [
                                  //      Text('${getTranslated('city', context)} : ${profileProvider.shippingAddressList[index].city ?? ""}',
                                  //          maxLines: 1, style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_EXTRA_SMALLest, color: ColorResources.COLOR_BLACK
                                  //
                                  //            ,)),
                                  //      SizedBox(width: Dimensions.PADDING_SIZE_EXTRA_SMALL),
                                  //      Text('${profileProvider.shippingAddressList[index].zip ?? ""}',
                                  //          maxLines: 1,style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_EXTRA_SMALLest, color: ColorResources.COLOR_BLACK
                                  //
                                  //            ,)),
                                  //    ],
                                  //  ),
                                ),

                                // SizedBox(height: Dimensions.PADDING_SIZE_LARGE,),


                                Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [


                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.start,

                                      children: [
                                        Container(


                                            height: 40,
                                            width:160,
                                            child: Row(
                                              children: [
                                                Icon(Icons.add_circle ,size: 30, color:  ColorResources.COLOR_BLACK.withOpacity(0.5), ),
                                                SizedBox(width: 5,),

                                                Text('ضيف مكان جديد' ?? "",style: titilliumBold.copyWith(fontSize: Dimensions.FONT_SIZE_SMALL, color: ColorResources.COLOR_BLACK.withOpacity(0.5),)),
                                              ],
                                            )),


                                      ],
                                    ),


                                    SizedBox(width: 30,),



                                  ],),

                                SizedBox(height: 30,),

                              ],
                            ),

                            // Positioned(left: 0,top: 0,
                            //   child: Container(
                            //     decoration: BoxDecoration(
                            //       borderRadius: BorderRadius.only(bottomLeft: Radius.circular(5),topLeft: Radius.circular(5)),
                            //       color: Theme.of(context).primaryColor,
                            //     ),
                            //     child: Padding(
                            //       padding: const EdgeInsets.all(5.0),
                            //       child: Text(profileProvider.shippingAddressList[index].isBilling ==0?
                            //   getTranslated('shipping_address', context):getTranslated('billing_address', context),
                            //         style: robotoRegular.copyWith(fontSize: 8, color: Theme.of(context).cardColor),),
                            //     ),),
                            // )
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
