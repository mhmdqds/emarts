import 'package:flutter/material.dart';
import 'package:emdad/localization/language_constrants.dart';
import 'package:emdad/provider/location_provider.dart';
import 'package:emdad/utility/color_resources.dart';
import 'package:emdad/utility/dimensions.dart';
import 'package:emdad/view/basewidget/button/custom_button.dart';
import 'package:emdad/view/basewidget/custom_app_bar.dart';
import 'package:emdad/view/screen/address/widget/location_search_dialog.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:provider/provider.dart';

import '../../../provider/home_category_product_provider.dart';
import '../../../utility/custom_themes.dart';
import 'AreYouSureBottomSheet.dart';
import 'add_first_address_screen.dart';

class SelectLocationScreen extends StatefulWidget {
  final GoogleMapController googleMapController;
  SelectLocationScreen({@required this.googleMapController});

  @override
  _SelectLocationScreenState createState() => _SelectLocationScreenState();
}

class _SelectLocationScreenState extends State<SelectLocationScreen> {
  GoogleMapController _controller;
  TextEditingController _locationController = TextEditingController();
  CameraPosition _cameraPosition;
  List<int>sellersids=[];
  @override
  void initState() {
    super.initState();
    //sellersids= Provider.of<HomeCategoryProductProvider>(context, listen: false).sellerIds;
    print("iiiiiiiiiiiiiiiiiii$sellersids");
    //Provider.of<LocationProvider>(context, listen: false).buildSellersMarkers(sellersids,context);
    print("iiiiiiiiiiiiiiiiiii$sellersids");
    //Provider.of<LocationProvider>(context, listen: false).getCurrentLocation(context, false, mapController: _controller);

    //Provider.of<LocationProvider>(context, listen: false).setPickData();

  }

  @override
  void dispose() {
    super.dispose();
    _controller.dispose();
  }

  void _openSearchDialog(BuildContext context, GoogleMapController mapController) async {
    showDialog(context: context, builder: (context) => LocationSearchDialog(mapController: mapController));
  }

  @override
  Widget build(BuildContext context) {
    if (Provider.of<LocationProvider>(context).address != null) {
      _locationController.text = '${Provider.of<LocationProvider>(context).address.name ?? ''}, '
          '${Provider.of<LocationProvider>(context).address.subAdministrativeArea ?? ''}, '
          '${Provider.of<LocationProvider>(context).address.isoCountryCode ?? ''}';
    }

    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Column(
            children: [
              Expanded(
                child: Container(
                  child: Consumer<LocationProvider>(
                    builder: (context, locationProvider, child) => Stack(
                      clipBehavior: Clip.none,
                      children: [
                        GoogleMap(
                          myLocationEnabled: true,
                          mapType: MapType.normal,

                          zoomControlsEnabled: false,
                          myLocationButtonEnabled: false,
                          initialCameraPosition: CameraPosition(

                            target:
                           // LatLng(0.452937,3-15.697047),
                            locationProvider.position.latitude!=null?
                            LatLng(locationProvider.position.latitude, locationProvider.position.longitude)

                            :LatLng(0.452937,3-15.697047),



                            //LatLng(locationProvider.position.latitude, locationProvider.position.longitude),

                            zoom:

                             locationProvider.position.latitude!=null?
                            17 :

                            -20,
                          ),


                          onCameraIdle: () {
                            locationProvider.updatePosition(_cameraPosition, false, null, context);
                            //Provider.of<LocationProvider>(context, listen: false).buildSellersMarkers(sellersids,context);
                          },
                          onCameraMove: ((_position) => _cameraPosition = _position),
                          markers: Set<Marker>.of(locationProvider.markers),
                          onMapCreated: (GoogleMapController controller) {



                            _controller = controller;
                          },
                        ),
                        locationProvider.pickAddress != null
                            ? InkWell(
                          onTap: () => _openSearchDialog(context, _controller),
                          child: Container(
                            width: MediaQuery.of(context).size.width,
                            padding: const EdgeInsets.symmetric(horizontal: Dimensions.PADDING_SIZE_LARGE, vertical: 10.0),
                            margin: const EdgeInsets.symmetric(horizontal: Dimensions.PADDING_SIZE_LARGE, vertical: 15.0),
                            decoration:
                            BoxDecoration(color: Colors.black, borderRadius: BorderRadius.circular(30)
                            , border: Border.all(
                                color: Colors.grey,  // red as border color
                              ),

                            ),
                            child: Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                              Expanded(child: Text(locationProvider.pickAddress.name != null
                                  ? '${locationProvider.pickAddress.name ?? ''} ${locationProvider.pickAddress.subAdministrativeArea ?? ''} ${locationProvider.pickAddress.isoCountryCode ?? ''}'
                                  : '', maxLines: 1, overflow: TextOverflow.ellipsis
                              ,style: TextStyle(fontSize: 12,fontWeight: FontWeight.w500
                                ,color: Colors.white
                                ),
                              )),
                              CircleAvatar(
                                backgroundColor: Colors.transparent,
                                  radius: 15,
                                  child: Icon(Icons.search, size: 20 , color: ColorResources.white,)),
                            ]),
                          ),
                        )
                            : Container(color: Colors.green,),
                        Positioned(
                          bottom: 0,
                          right: 0,
                          left: 0,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              InkWell(
                                onTap: () {
                                  locationProvider.getCurrentLocation(context, false, mapController: _controller);
                                },
                                child: Padding(
                                  padding: const EdgeInsets.only(left: 8.0),
                                  child: CircleAvatar(
                                    backgroundColor: Theme.of(context).primaryColor,
                                    child: Container(
                                      //width: 20,
                                     // height: 20,
                                      //margin: EdgeInsets.only(right: Dimensions.PADDING_SIZE_LARGE),
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(Dimensions.PADDING_SIZE_SMALL),
                                        color: Colors.transparent,
                                      ),
                                      child: Center(
                                        child: Icon(
                                          Icons.my_location,
                                          color: Colors.white,
                                          size: 25,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                width: double.infinity,
                                child: Padding(
                                  padding: const EdgeInsets.all(Dimensions.PADDING_SIZE_LARGE),
                                  child: CustomButton(
                                    buttonText: getTranslated('select_location', context),
                                    onTap: () async {
                                      if(widget.googleMapController != null) {
                                        widget.googleMapController.moveCamera(CameraUpdate.newCameraPosition(CameraPosition(target: LatLng(
                                          locationProvider.pickPosition.latitude, locationProvider.pickPosition.longitude,
                                        ), zoom: 17)));
                                        locationProvider.setAddAddressData();
                                      }
                                      //Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => AddFirstAddressScreen(isEnableUpdate: false,)));

                                      locationProvider.pickAddress.name!=null?
                                      locationProvider.pickAddress.name.contains("Yemen")== true?
                                      Navigator.of(context).pop():
                                      await showModalBottomSheet(
                                          context: context, isScrollControlled: true, backgroundColor: Colors.transparent,
                                          builder: (context) => AreYouSureBottomSheet(groupId: locationProvider.locationController.text,sellerIndex: 0, sellerId: 1),
                                      ):
                                          print("selectLocationnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn");


                                     // Navigator.of(context).pop();
                                    },
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        locationProvider.pickAddress.name!=null?
                        locationProvider.pickAddress.name.contains("Yemen")== true?
                        Positioned(
                            bottom: 30,
                            right: 0,
                            left: 0,
                            child:  Container(
                              decoration: BoxDecoration(
                                  color: Colors.green,
                                  border: Border.all(
                                    color: Colors.green,
                                  ),
                                  borderRadius: BorderRadius.all(Radius.circular(20))),
                              margin:EdgeInsets.all(65) ,
                              //padding: EdgeInsets.all(15),
                              width: double.minPositive,
                              height:30,
                              //color: Colors.red,
                              child: Center(child: Text("مكانك داخل التغطيه",style: titilliumRegular.copyWith(color: Colors.white
                              ,fontSize: 10
                              ),),),
                            )):
                        Positioned(
                            bottom: 30,
                            right: 0,
                            left: 0,
                            child: Container(
                              decoration: BoxDecoration(
                                  color: Colors.red,
                                  border: Border.all(
                                    color: Colors.red[500],
                                  ),
                                  borderRadius: BorderRadius.all(Radius.circular(20))),
                              margin:EdgeInsets.all(65) ,
                              //padding: EdgeInsets.all(15),
                              width: double.minPositive,
                              height:30,
                              //color: Colors.red,
                              child: Center(child: Text("مكانك قد يكون خارج التغطيه",style: titilliumRegular.copyWith(color: Colors.white
                              ,fontSize: 10
                              ),),),
                            )):SizedBox(),
                        Center(
                            child: Icon(
                              Icons.location_on,
                              color: Theme.of(context).primaryColor,
                              size: 50,
                            )),
                        locationProvider.loading
                            ? Center(child: CircularProgressIndicator(valueColor: AlwaysStoppedAnimation<Color>(Theme.of(context).primaryColor)))
                            : SizedBox(),


                      ],
                    ),
                  ),
                ),
              ),

            ],
          ),
        ),
      ),
    );
  }
}


// CustomAppBar(title: getTranslated('select_delivery_address', context)),