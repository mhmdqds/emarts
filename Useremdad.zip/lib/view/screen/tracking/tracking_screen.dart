import 'package:emdad/data/model/response/order_details.dart';
import 'package:emdad/data/model/response/order_model.dart';
import 'package:flutter/material.dart';

import 'package:emdad/localization/language_constrants.dart';
import 'package:emdad/utility/color_resources.dart';
import 'package:emdad/utility/custom_themes.dart';
import 'package:emdad/utility/dimensions.dart';
import 'package:emdad/view/basewidget/button/custom_button.dart';
import 'package:emdad/view/basewidget/custom_app_bar.dart';
import 'package:emdad/view/basewidget/textfield/custom_textfield.dart';
import 'package:emdad/view/screen/tracking/tracking_result_screen.dart';

class TrackingScreen extends StatelessWidget {
  final OrderDetailsModel orderDetailsModel;
  final String orderType;
  final Function callback;
  final int orderId;
  final OrderModel orderModel;

  TrackingScreen({this.orderDetailsModel, this.callback, this.orderType
    , this.orderId
    , this.orderModel
  });

  final TextEditingController _orderIdController = TextEditingController();
  final GlobalKey<ScaffoldMessengerState> _globalKey = GlobalKey();

  @override
  Widget build(BuildContext context) {

    _orderIdController.text = orderId.toString();

    return Scaffold(
      key: _globalKey,
      backgroundColor: ColorResources.getIconBg(context),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CustomAppBar(title: ""

          ,
          ),
          Expanded(
            child: ListView(
              physics: BouncingScrollPhysics(),
              children: [
                Padding(
                  padding: EdgeInsets.all(Dimensions.PADDING_SIZE_LARGE),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [

                      Image.asset(
                        'assets/images/onboarding_image_one.png',
                        fit: BoxFit.cover,
                        width: MediaQuery.of(context).size.width,
                        height: MediaQuery.of(context).size.height * 0.35,
                      ),
                      SizedBox(height: 50),

                      Text(getTranslated('TRACK_ORDER', context), style: robotoBold),
                      Stack(children: [
                        Container(
                          width: double.infinity,
                          height: 1,
                          margin: EdgeInsets.only(top: Dimensions.MARGIN_SIZE_SMALL),
                          color: ColorResources.colorMap[50],
                        ),
                        Container(
                          width: 70,
                          height: 1,
                          margin: EdgeInsets.only(top: Dimensions.MARGIN_SIZE_SMALL),
                          decoration: BoxDecoration(color: ColorResources.getPrimary(context), borderRadius: BorderRadius.circular(1)),
                        ),
                      ]),
                      SizedBox(height: Dimensions.PADDING_SIZE_LARGE),

                      CustomTextField(
                        hintText: getTranslated('TRACK_ID', context),
                        textInputType: TextInputType.number,
                        controller: _orderIdController,
                        textInputAction: TextInputAction.done,
                      ),
                      SizedBox(height: Dimensions.PADDING_SIZE_LARGE),

                      CustomButton(
                        buttonText: getTranslated('TRACK', context),
                        onTap: () {
                          if(_orderIdController.text.isNotEmpty){
                            // Navigator.of(context).push(MaterialPageRoute(builder: (context) => TrackingResultScreen(
                            //
                            //
                            //     orderID: _orderIdController.text)
                            //
                            //
                            //
                            // ));
                          }else {
                            _globalKey.currentState.showSnackBar(SnackBar(content: Text('Insert track ID'), backgroundColor: Colors.red));
                          }
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
