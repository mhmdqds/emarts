import 'package:emdad/helper/price_converter.dart';
import 'package:emdad/view/basewidget/custom_snackbar.dart';
import 'package:emdad/view/screen/order/widget/order2_details2_widget2.dart';
import 'package:emdad/view/screen/order/widget/order_details_widget.dart';
import 'package:flutter/material.dart';
import 'package:emdad/provider/order_provider.dart';

import 'package:emdad/localization/language_constrants.dart';
import 'package:emdad/utility/app_constants.dart';
import 'package:emdad/utility/color_resources.dart';
import 'package:emdad/utility/custom_themes.dart';
import 'package:emdad/utility/dimensions.dart';
import 'package:emdad/view/basewidget/custom_app_bar.dart';
import 'package:emdad/view/basewidget/custom_loader.dart';
import 'package:emdad/view/screen/dashboard/dashboard_screen.dart';
import 'package:emdad/view/screen/tracking/painter/line_dashed_painter.dart';
import 'package:provider/provider.dart';

import '../../../data/model/response/order_details.dart';
import '../../../data/model/response/order_model.dart';

class TrackingResultScreen extends StatelessWidget {
  final OrderDetailsModel orderDetailsModel;
  final String orderType;
  final Function callback;
  final int orderId;
  final OrderModel orderModel;
  final int length;
  //TrackingResultScreen({@required this.orderID});

  TrackingResultScreen({this.orderDetailsModel, this.callback, this.orderType
    , this.orderId
    , this.orderModel
    , this.length
  });

  @override
  Widget build(BuildContext context) {
    Provider.of<OrderProvider>(context, listen: false).initTrackingInfo(orderId.toString(), null, false, context);
    List<String> _statusList = ['pending', 'confirmed', 'processing', 'out_for_delivery', 'delivered'];


    return Scaffold(
      backgroundColor: ColorResources.getIconBg(context),
      body: Column(
        children: [
          CustomAppBar(title:"${ getTranslated('ORDER_ID', context)}  ${orderId.toString()}" ),

          Expanded(
            child: Consumer<OrderProvider>(
              builder: (context, tracking, child) {
                String status = tracking.trackingModel != null ? tracking.trackingModel.orderStatus : '';
                return tracking.trackingModel != null
                    ? _statusList.contains(status) ? ListView(
                  physics: BouncingScrollPhysics(),
                        children: [


                          Container(
                            margin: EdgeInsets.all(Dimensions.MARGIN_SIZE_SMALL),
                            decoration: BoxDecoration(color: Colors.white.withOpacity(0.0)
                              , borderRadius: BorderRadius.circular(20) ,
                              border: Border.all(
                                color: Colors.grey.withOpacity(0.2),
                                width: 2,
                              ),


                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceAround,

                                children: [
                                  Row(
                                    children: [
                                      Text("حاله الدفع"
                                      ,                          style: titilliumBold.copyWith(color: ColorResources.colorPrimaryBlack
                                            ,fontSize: 10
                                        ),



                                      ),
                                      SizedBox(width: 10,),

                                      Text("${tracking.trackingModel.paymentStatus}"
                                        ,                          style: titilliumBold.copyWith(

                                          color: tracking.trackingModel.paymentStatus =="paid" ? ColorResources.GREEN : ColorResources.appDarkRed
                                            ,fontSize: 14 ,

                                        ),



                                      ),
                                    ],
                                  ),


                                  Row(
                                    children: [
                                      Text("المبلغ المتبقى"
                                      ,                        style: titilliumBold.copyWith(color: ColorResources.colorPrimaryBlack
                                        ,fontSize: 10
                                        ),

                                      ),
                                      SizedBox(width: 10,),
                                      Text(
                                          tracking.trackingModel.paymentStatus =="paid"? "0 ريال" :
                                        PriceConverter.convertPrice(context, orderDetailsModel.price


                                        ),
                                        style: titilliumsemiBold.copyWith(color: ColorResources.getPrimary(context)),

                                      )

                                    ],
                                  ),
                                ],
                              )
                            ),
                          ),


                          Container(
                              margin: EdgeInsets.all(Dimensions.MARGIN_SIZE_SMALL),
                              decoration: BoxDecoration(color: Colors.grey.withOpacity(0.1)
                              , borderRadius: BorderRadius.circular(20)
                              ,border: Border.all(
                                  color: Colors.grey.withOpacity(0.2),
                                  width: 1,
                                ),

                              ),

                              child: Column(
                                children: [






                                  Padding(
                                    padding:
                                    EdgeInsets.symmetric(horizontal: Dimensions.PADDING_SIZE_SMALL, vertical: Dimensions.PADDING_SIZE_EXTRA_SMALL),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                       // Text(getTranslated('PARCEL_STATUS', context), style: titilliumSemiBold),
                                        Text("موعد التوصيل", style: titilliumsemiBold.copyWith(
                                          color: Colors.grey

                                        )),

                                        // RichText(
                                        //   text: TextSpan(
                                        //     text: getTranslated('ORDER_ID', context),
                                        //     style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_SMALL
                                        //     , color: Colors.red
                                        //     ),
                                        //     children: <TextSpan>[
                                        //       TextSpan(text: orderID, style: titilliumSemiBold),
                                        //     ],
                                        //   ),
                                        // )
                                      ],
                                    ),
                                  ),
                                  Container(
                                    width: double.infinity,
                                    height: 1,
                                    margin: EdgeInsets.all(Dimensions.PADDING_SIZE_SMALL),
                                    //color: ColorResources.getPrimary(context),
                                  ),
                                  SizedBox(height: Dimensions.PADDING_SIZE_SMALL),
                                  SingleChildScrollView(
                                    scrollDirection: Axis.horizontal,
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      mainAxisAlignment:MainAxisAlignment.center,
                                      children: [


                                        // Steppers
                                        CustomStepper(
                                            title: status == 'pending' ? getTranslated('new', context) : getTranslated('ORDER_PLACED_PREPARING', context),
                                            color: ColorResources.getHarlequin(context)),
                                        CustomStepper(
                                            title: status == 'pending'
                                                ? getTranslated('pending', context)
                                                : status == 'confirmed' ? getTranslated('processing', context) : getTranslated('ORDER_PICKED_SENDING', context),
                                            color: ColorResources.getCheris(context)),
                                        CustomStepper(
                                            title: status == 'pending'
                                                ? getTranslated('pending', context)
                                                : status == 'confirmed'
                                                    ? getTranslated('pending', context)
                                                    : status == 'processing' ? getTranslated('processing', context) : getTranslated('RECEIVED_LOCAL_WAREHOUSE', context),
                                            color: ColorResources.getColombiaBlue(context)),
                                        CustomStepper(
                                            title:status == 'pending'
                                                ? getTranslated('pending', context)
                                                : status == 'confirmed'
                                                    ? getTranslated('pending', context)
                                                    : status == 'processing' ? getTranslated('pending', context) : status == 'out_for_delivery'
                                                ? getTranslated('processing', context) : getTranslated('DELIVERED', context),
                                            color: Theme.of(context).primaryColor,
                                            isLastItem: false),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),

                          Padding(
                            padding: const EdgeInsets.all(0.0),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(
                                      left:20 , top:20 , right: 20

                                      ),
                                  child: Text("تفاصيل المنتجات", style: titilliumBold.copyWith(
                                      color: Colors.black

                                  )),
                                ),
                                //SizedBox(height:  Dimensions.PADDING_SIZE_EXTRA_LARGE,),


                                Container(
                                  margin: EdgeInsets.all(Dimensions.MARGIN_SIZE_SMALL),
                                  decoration: BoxDecoration(color: Colors.white.withOpacity(0.0)
                                      , borderRadius: BorderRadius.circular(20) ,
                                    border: Border.all(
                    color: Colors.grey.withOpacity(0.2),
                    width: 2,
                  ),


                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: ListView.builder(
                                      shrinkWrap: true,
                                      padding: EdgeInsets.all(0),
                                      itemCount: length,
                                      physics: NeverScrollableScrollPhysics(),
                                      itemBuilder: (context, i) => OrderDetailsWidget2(
                                        orderId: orderId, orderModel: orderModel,
                                        orderDetailsModel: orderDetailsModel,
                                        callback: () {showCustomSnackBar('Review submitted successfully', context, isError: false);},
                                        orderType:orderType,),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      )
                    : status == AppConstants.FAILED ? Center(child: Text('Failed')) : status == AppConstants.RETURNED ? Center(child: Text('Returned'))
                    : Center(child: Text('Cancelled')) : Center(child: CustomLoader(color: Theme.of(context).primaryColor));
              },
            ),
          ),

          // for footer button
          Container(
            height: 45,
            margin: EdgeInsets.all(Dimensions.PADDING_SIZE_DEFAULT),
            decoration: BoxDecoration(color: ColorResources.getImageBg(context), borderRadius: BorderRadius.circular(6)),
            child: TextButton(
              style: TextButton.styleFrom(padding: EdgeInsets.all(0)),
              onPressed: () {
                Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => DashBoardScreen()), (route) => false);
              },
              child: Container(
                width: double.infinity,
                alignment: Alignment.center,
                child: Text(
                  getTranslated('ORDER_MORE', context),
                  style: titilliumsemiBold.copyWith(fontSize: Dimensions.FONT_SIZE_LARGE, color: ColorResources.getPrimary(context)),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class CustomStepper extends StatelessWidget {
  final String title;
  final Color color;
  final bool isLastItem;
  CustomStepper({@required this.title, @required this.color, this.isLastItem = false});

  @override
  Widget build(BuildContext context) {
    Color myColor;
    if (title == getTranslated('processing', context) ||title == getTranslated('new', context) || title == getTranslated('pending', context)) {
      myColor = Colors.grey.withOpacity(0.5);
    } else {
      myColor = color;
    }
    return Container(
      height: isLastItem ? 50 : 70,
      padding: EdgeInsets.symmetric(horizontal: Dimensions.PADDING_SIZE_EXTRA_SMALL),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [

          isLastItem
              ? SizedBox.shrink()
              : Container(width: 75,
            //padding: EdgeInsets.only(top: Dimensions.PADDING_SIZE_EXTRA_SMALL, left: Dimensions.PADDING_SIZE_LARGE),

            height: 7,
              color: myColor ,
              ),

          SizedBox(height:  Dimensions.PADDING_SIZE_EXTRA_SMALL,),

          Row(
            children: [
              // Padding(
              //   padding: EdgeInsets.symmetric(horizontal: Dimensions.PADDING_SIZE_SMALL),
              //   child: CircleAvatar(backgroundColor: myColor, radius: 10.0),
              // ),
              Container(
                width: 77,
                child: Center(
                  child: Text(title, style: titilliumsemiBold.copyWith(
                      fontSize: 8 ,
                    color: Colors.black



                  )
                  ,      //   softWrap: false,
                    //overflow: TextOverflow.ellipsis, // new
                    //maxLines: 1,

                  ),
                ),
              )

            ],
          ),
        ],
      ),
    );
  }
}
