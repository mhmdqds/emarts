import 'package:emdad/view/basewidget/titlRow2.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:emdad/helper/date_converter.dart';
import 'package:emdad/provider/localization_provider.dart';
import 'package:emdad/provider/splash_provider.dart';
import 'package:emdad/view/basewidget/shimmer_loading.dart';
import 'package:emdad/view/screen/chat/chat_screen.dart';
import 'package:emdad/view/screen/seller/seller_screen.dart';
import 'package:emdad/data/model/response/order_details.dart';
import 'package:emdad/data/model/response/order_model.dart';

import 'package:emdad/helper/price_converter.dart';
import 'package:emdad/localization/language_constrants.dart';
import 'package:emdad/provider/order_provider.dart';
import 'package:emdad/provider/profile_provider.dart';
import 'package:emdad/provider/seller_provider.dart';
import 'package:emdad/utility/color_resources.dart';
import 'package:emdad/utility/custom_themes.dart';
import 'package:emdad/utility/dimensions.dart';
import 'package:emdad/view/basewidget/amount_widget.dart';
import 'package:emdad/view/basewidget/button/custom_button.dart';
import 'package:emdad/view/basewidget/custom_app_bar.dart';
import 'package:emdad/view/basewidget/show_custom_snakbar.dart';
import 'package:emdad/view/basewidget/title_row.dart';
import 'package:emdad/view/screen/order/widget/order_details_widget.dart';
import 'package:emdad/view/screen/payment/payment_screen.dart';
import 'package:emdad/view/screen/support/support_ticket_screen.dart';
import 'package:emdad/view/screen/tracking/tracking_screen.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class OrderDetailsScreen extends StatefulWidget {
  final OrderModel orderModel;
  final int orderId;
  final String orderType;
  final double extraDiscount;
  final String extraDiscountType;
  OrderDetailsScreen({@required this.orderModel, @required this.orderId, @required this.orderType, this.extraDiscount, this.extraDiscountType});

  @override
  State<OrderDetailsScreen> createState() => _OrderDetailsScreenState();
}

class _OrderDetailsScreenState extends State<OrderDetailsScreen> {
  void _loadData(BuildContext context) async {
    await Provider.of<OrderProvider>(context, listen: false).initTrackingInfo(widget.orderId.toString(), widget.orderModel, true, context);
    if (widget.orderModel == null) {
      await Provider.of<SplashProvider>(context, listen: false).initConfig(context);
    }
    Provider.of<SellerProvider>(context, listen: false).removePrevOrderSeller();
    await Provider.of<ProfileProvider>(context, listen: false).initAddressList(context);
    if(Provider.of<SplashProvider>(context, listen: false).configModel.shippingMethod == 'sellerwise_shipping') {
      await Provider.of<OrderProvider>(context, listen: false).initShippingList(
        context, Provider.of<OrderProvider>(context, listen: false).trackingModel.sellerId,
      );
    }else {
      await Provider.of<OrderProvider>(context, listen: false).initShippingList(context, 1);
    }
    Provider.of<OrderProvider>(context, listen: false).getOrderDetails(
      widget.orderId.toString(), context,
      Provider.of<LocalizationProvider>(context, listen: false).locale.countryCode,
    );
  }

  String shippingPartner = '';

  @override
  Widget build(BuildContext context) {
    _loadData(context);
    return Scaffold(
      appBar: AppBar(
        elevation: 0 ,

        backgroundColor: ColorResources.white,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios,  color: Colors.black),
          onPressed: (){
            Navigator.pop(context);

          }
        ) ,
        actions: [    Padding(
          padding: EdgeInsets.symmetric(
              horizontal: Dimensions.PADDING_SIZE_SMALL,
              vertical: Dimensions.PADDING_SIZE_SMALL),
          child: Row(
            children: [

              Row(
                children: [
                  //Icon(Icons.double_arrow),
                  CustomButton(
                    width: 100,
                    height: 30,

                    buttonText: getTranslated('SUPPORT_CENTER', context),
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SupportTicketScreen())),
                  ),

                ],
              ),



             // SizedBox(width: Dimensions.PADDING_SIZE_SMALL),

            ],
          ),
        ),
    ]

      ),
      backgroundColor: ColorResources.getIconBg(context),
      body: Column(
        children: [
       //   CustomAppBar(title: getTranslated('ORDER_DETAILS', context)),
          Expanded(
            child: Consumer<OrderProvider>(
              builder: (context, order, child) {
                List<int> sellerList = [];
                List<List<OrderDetailsModel>> sellerProductList = [];
                double _order = 0;
                double _discount = 0;
                double eeDiscount = 0;
                double _tax = 0;

                double _shippingFee = 0;

                if (order.orderDetails != null) {
                  order.orderDetails.forEach((orderDetails) {
                    if (!sellerList
                        .contains(orderDetails.productDetails.userId)) {
                      sellerList.add(orderDetails.productDetails.userId);
                    }
                  });
                  sellerList.forEach((seller) {
                    Provider.of<SellerProvider>(context, listen: false)
                        .initSeller(seller.toString(), context);
                    List<OrderDetailsModel> orderList = [];
                    order.orderDetails.forEach((orderDetails) {
                      if (seller == orderDetails.productDetails.userId) {
                        orderList.add(orderDetails);
                      }
                    });
                    sellerProductList.add(orderList);
                  });

                  order.orderDetails.forEach((orderDetails) {
                    _order = _order + (orderDetails.price * orderDetails.qty);
                    _discount = _discount + orderDetails.discount;
                    _tax = _tax + orderDetails.tax;
                  });


                  if(widget.orderType == 'POS'){
                    if(widget.extraDiscountType == 'percent'){
                      eeDiscount = _order * (widget.extraDiscount/100);
                    }else{
                      eeDiscount = widget.extraDiscount;
                    }
                  }


                  if (order.shippingList != null) {
                    order.shippingList.forEach((shipping) {
                      if (shipping.id == order.trackingModel.shippingMethodId) {
                        shippingPartner = shipping.title;
                        _shippingFee = shipping.cost;
                      }
                    });
                  }

                }

                if (order.orderDetails != null) {
int length=0;
                  for(int i=0 ;i <  sellerList.length ; i++  ){

                    length += sellerProductList[i].length ;
                    print("asdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddsddddddddddddddddddddddddddd");
                    print(length);
                }
                  return ListView(
                  physics: BouncingScrollPhysics(),
                  padding: EdgeInsets.all(0),
                  children: [
                    SizedBox(height: Dimensions.PADDING_SIZE_DEFAULT,),
                    Container(
                      //margin: EdgeInsets.symmetric(
                          //vertical: Dimensions.PADDING_SIZE_DEFAULT,
                         // horizontal: Dimensions.PADDING_SIZE_SMALL
                      //),
                      child: Column(
                        children: [

                          CircleAvatar(
                            radius: 93 ,
                          backgroundColor: ColorResources.GREY.withOpacity(0.9) ,

                          child: CircleAvatar(
                                radius: 90 ,
                                backgroundColor: ColorResources.white
                                ,child:

                            Column(
                              mainAxisAlignment: MainAxisAlignment.center,

                              children: [
                                //sellerProductList[index].length,

                                widget.orderModel.orderStatus.toUpperCase()=="CANCELED"?
                                    Icon(Icons.cancel, color: Colors.red,) :



                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,


                                  children: [

                                    widget.orderModel.orderStatus.toUpperCase()=="DELIVERED"?
                                    Text(

                                        length.toString(),

                                        style: titilliumBold.copyWith(fontSize: Dimensions.FONT_SIZE_OVER_LARGE,
                                          color: Theme.of(context).textTheme.bodyText1.color,
                                        )) :

                                    Text("0",

                                        style: titilliumBold.copyWith(fontSize: Dimensions.FONT_SIZE_OVER_LARGE,
                                          color: Theme.of(context).textTheme.bodyText1.color,
                                        )) ,

                                    Text("/",

                                        style: titilliumBold.copyWith(fontSize: Dimensions.FONT_SIZE_OVER_LARGE,
                                          color: Theme.of(context).textTheme.bodyText1.color,
                                        )),



                                    Text( length.toString(),

                                        //sellerProductList.length.toString(),

                                        style: titilliumBold.copyWith(fontSize: Dimensions.FONT_SIZE_OVER_LARGE,
                                          color: Theme.of(context).textTheme.bodyText1.color,
                                        )),





                                  ],
                                ),

                                Text(widget.orderModel.orderStatus.toUpperCase(),

                                  style: titilliumBold.copyWith(fontSize: Dimensions.FONT_SIZE_SMALL,
                                  color: Theme.of(context).textTheme.bodyText1.color,
                                )),
                              ],
                            )
                            ),
                          ),

                          SizedBox(height: Dimensions.PADDING_SIZE_EXTRA_LARGE),

                          RichText(
                            text: TextSpan(

                              children: <TextSpan>[
                                TextSpan(
                                    text: getTranslated('ORDER_ID', context),
                                    style: titilliumBold.copyWith(fontSize: Dimensions.FONT_SIZE_EXTRA_LARGE,
                                      color: Theme.of(context).textTheme.bodyText1.color,
                                    )),

                                TextSpan(
                                    text: " ",
                                    style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_EXTRA_LARGE,
                                    )),
                                TextSpan(
                                    text: '${order.trackingModel.id.toString()}#',
                                    style: titilliumBold.copyWith(fontSize: Dimensions.FONT_SIZE_EXTRA_LARGE,
                color: Theme.of(context).textTheme.bodyText1.color,))
                              ],
                            ),
                          ),
                          //Expanded(child: SizedBox()),


                          Row(
                mainAxisAlignment:MainAxisAlignment.center,
                            children: [
                              Text("تم انشاء الطلب فى : " ,
                                  style: titilliumRegular.copyWith(
                                      color: ColorResources.getHint(context),
                                      fontSize: Dimensions.FONT_SIZE_EXTRA_SMALL)),
                              Text(DateConverter.localDateToIsoStringAMPM(DateTime.parse(order.trackingModel.createdAt)),
                                  style: titilliumRegular.copyWith(
                                      color: ColorResources.getHint(context),
                                      fontSize: Dimensions.FONT_SIZE_SMALL)),
                            ],
                          ),
                        ],
                      ),
                    ),

                    Padding(
                      padding: const EdgeInsets.only(left: 110,right: 110),
                      child: SizedBox(
                        //width: 20,
                        //height: 100.0,
                        child: ElevatedButton(



                style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(ColorResources.white.withOpacity(0.7)),


                shape: MaterialStateProperty.all<RoundedRectangleBorder>(


                RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0),
                side: BorderSide(color: Colors.lightBlueAccent)
                )
                )
                ),

                onPressed:(){
                  Clipboard.setData(ClipboardData(

                      text: order.trackingModel.id.toString()


                  ));


                },

                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              RichText(
                                text: TextSpan(

                                  children: <TextSpan>[
                                    TextSpan(
                                        text: getTranslated('ORDER_ID', context),
                                        style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_SMALL,
                                          color: Theme.of(context).textTheme.bodyText1.color,
                                        )),

                                    TextSpan(
                                        text: "  ",
                                        style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_SMALL,
                                        )),
                                    TextSpan(
                                        text: '${order.trackingModel.id.toString()}',
                                        style: titilliumBold.copyWith(fontSize: Dimensions.FONT_SIZE_SMALL,
                                            color: ColorResources.colorPrimaryBlack)),
                                  ],
                                ),
                              ),
                              Icon(
                                Icons.copy,
                                size: 20,
                                color: Colors.black,
                              ),


                            ],
                          ),
                        ),
                      ),
                    ),

                    widget.orderModel != null && widget.orderModel.orderNote != null?
                    Padding(padding : EdgeInsets.all(Dimensions.MARGIN_SIZE_SMALL),
                      child: Text.rich(
                        TextSpan(
                          children: [
                            TextSpan(text: '${getTranslated('order_note', context)} : ',style: robotoBold.copyWith(fontSize: Dimensions.FONT_SIZE_LARGE,
                                color: ColorResources.getReviewRattingColor(context))),
                            TextSpan(text:  '${widget.orderModel.orderNote != null? widget.orderModel.orderNote ?? '': ""}',style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_SMALL)),
                          ],
                        ),
                      ),
                      // Text('${getTranslated('order_note', context)} : ${orderModel.orderNote != null?
                      // orderModel.orderNote ?? '': ""}', style: titilliumRegular),
                    ):SizedBox(),


                    SizedBox(height: Dimensions.PADDING_SIZE_SMALL),

                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: Dimensions.PADDING_SIZE_DEFAULT, vertical: Dimensions.PADDING_SIZE_DEFAULT),
                      child: Text("شحنات طلبك",
                          style: titilliumsemiBold.copyWith()),
                    ),

                    Padding(
                      padding: const EdgeInsets.only(left: 20.0 , right: 20),
                      child: Card(
                        color:ColorResources.white.withOpacity(0.9),

                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(DateConverter.localDateToIsoStringAMPM(DateTime.parse(order.trackingModel.updatedAt)),
                              style: titilliumRegular.copyWith(
                                  color: ColorResources.colorPrimaryBlack,
                                  fontSize: Dimensions.FONT_SIZE_EXTRA_SMALL)),
                )

                      ),
                    ),

                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: Dimensions.PADDING_SIZE_DEFAULT, vertical: Dimensions.PADDING_SIZE_DEFAULT),
                      child: Text(getTranslated('ORDERED_PRODUCT', context),
                          style: titilliumsemiBold.copyWith()),
                    ),

                    ListView.builder(
                      itemCount: sellerList.length,
                      physics: NeverScrollableScrollPhysics(),
                      padding: EdgeInsets.all(0),
                      shrinkWrap: true,
                      itemBuilder: (context, index) {
                        return Container(
                          padding: EdgeInsets.symmetric(
                              horizontal: Dimensions.MARGIN_SIZE_EXTRA_LARGE),
                          color: Theme.of(context).highlightColor,
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                InkWell(
                                  onTap: () {
                                    if (Provider.of<SellerProvider>(context, listen: false).orderSellerList.length != 0 && sellerList[index] != 1) {
                                      Navigator.push(context,
                                          MaterialPageRoute(builder: (_) {
                                            return SellerScreen(seller: Provider.of<SellerProvider>(context, listen: false).orderSellerList[index]);}));
                                    }
                                  },

                                  child: sellerList[index] == 1? SizedBox():
                                  InkWell(
                                    onTap: (){
                                      Navigator.push(context, MaterialPageRoute(builder: (_) => ChatScreen(
                                          seller: Provider.of<SellerProvider>(context).orderSellerList[index],
                                          shopId:Provider.of<SellerProvider>(context).orderSellerList[index].seller.shop.id,
                                          shopName:Provider.of<SellerProvider>(context).orderSellerList[index].seller.shop.name,
                                          image: Provider.of<SellerProvider>(context).orderSellerList[index].seller.image )));

                                    },
                                    child: Row(children: [
                                      Expanded(
                                          child: Text(getTranslated('seller', context),


                                      style: titilliumsemiBold.copyWith(color: ColorResources.HINT_TEXT_COLOR),


                        )),
                                      Text(
                                        sellerList[index] == 1 ? 'Admin'
                                            : Provider.of<SellerProvider>(context).orderSellerList.length < index + 1
                                            ? sellerList[index].toString()
                                            : '${Provider.of<SellerProvider>(context).orderSellerList[index].seller.fName} '
                                            '${Provider.of<SellerProvider>(context).orderSellerList[index].seller.lName}',
                                        style: titilliumsemiBold.copyWith(color: ColorResources.HINT_TEXT_COLOR),
                                      ),
                                      SizedBox(width: Dimensions.PADDING_SIZE_EXTRA_SMALL),
                                      Icon(Icons.gamepad_outlined, color: Theme.of(context).primaryColor, size: 20),
                                    ]),
                                  ),
                                ),
                                // Text(getTranslated('ORDERED_PRODUCT', context), style: robotoBold.copyWith(color: ColorResources.HINT_TEXT_COLOR)),
                                Divider(),













                                ListView.builder(
                                  shrinkWrap: true,
                                  padding: EdgeInsets.all(0),
                                  itemCount:
                                  sellerProductList[index].length,
                                  physics: NeverScrollableScrollPhysics(),
                                  itemBuilder: (context, i) => OrderDetailsWidget(
                                    length: sellerProductList[index].length,
                                    orderId: widget.orderId, orderModel: widget.orderModel,
                                    orderDetailsModel: sellerProductList[index][i],
                                    callback: () {showCustomSnackBar('Review submitted successfully', context, isError: false);},
                                    orderType: widget.orderType,),
                                ),
                              ]),
                        );
                      },
                    ),








                    SizedBox(height: Dimensions.MARGIN_SIZE_DEFAULT),




                    SizedBox(height: Dimensions.PADDING_SIZE_SMALL),

                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: Dimensions.PADDING_SIZE_DEFAULT, vertical: Dimensions.PADDING_SIZE_DEFAULT),
                      child: Text(getTranslated('order details', context),
                          style: titilliumsemiBold.copyWith()),
                    ),
                    // Payment
                    Container(padding: EdgeInsets.all(Dimensions.PADDING_SIZE_SMALL),
                      decoration: BoxDecoration(color: Theme.of(context).highlightColor),
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(height: Dimensions.MARGIN_SIZE_EXTRA_SMALL),
                            Row(
                              children: [
                                CircleAvatar(
                                    radius: 20 ,
                                    backgroundColor: ColorResources.getLightSkyBlue(context).withOpacity(0.3)
                                    ,child: Icon(Icons.money ,
                                //color: ColorResources.GREEN,
                                )),
                                SizedBox(width: 20,),

                                Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,

                                  children: [
                                    Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          //Text(getTranslated('PAYMENT_STATUS', context), style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_SMALL)),
                                          Text( "وسيله الدفع",
                                            style: titilliumBold.copyWith(fontSize: Dimensions.FONT_SIZE_EXTRA_SMALL),
                                          ),
                                        ]),
                                    Row(
                                      mainAxisAlignment:MainAxisAlignment.start,
                                      crossAxisAlignment:CrossAxisAlignment.start,
                                      children: [


                                        Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [
                                              //Text(getTranslated('PAYMENT_PLATFORM', context), style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_SMALL)),
                                              (order.trackingModel.paymentMethod != 'cash_on_delivery' && order.trackingModel.paymentStatus == 'unpaid')
                                                  ? InkWell(
                                                onTap: () async {
                                                  String userID = await Provider.of<ProfileProvider>(context, listen: false).getUserInfo(context);
                                                  Navigator.pushReplacement(context,
                                                      MaterialPageRoute(builder: (_) => PaymentScreen(
                                                        customerID: userID,
                                                        couponCode: '',
                                                        addressID: order.trackingModel.shippingAddress.toString(),
                                                        billingId: widget.orderModel.billingAddress.toString(),
                                                      )));
                                                },
                                                child: Container(
                                                  padding: EdgeInsets.symmetric(horizontal: Dimensions.PADDING_SIZE_EXTRA_SMALL),
                                                  decoration: BoxDecoration(color: ColorResources.getPrimary(context),
                                                    borderRadius: BorderRadius.circular(5),
                                                  ),
                                                  child: Text(
                                                      getTranslated('pay_now', context), style: titilliumsemiBold
                                                      .copyWith(fontSize: Dimensions.FONT_SIZE_EXTRA_SMALL, color: Theme.of(context).highlightColor,
                                                  )),
                                                ),
                                              )
                                                  : Text(
                                                  order.trackingModel.paymentMethod != null
                                                      ? order.trackingModel.paymentMethod.replaceAll('_', ' ') : 'Digital Payment',
                                                  style: titilliumBold.copyWith(color: Theme.of(context).primaryColor,
                                                     fontSize: Dimensions.FONT_SIZE_EXTRA_SMALL,

                                        )),
                                            ]),
                                        SizedBox(width: Dimensions.MARGIN_SIZE_EXTRA_SMALL),

                                        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [
                                              //Text(getTranslated('PAYMENT_STATUS', context), style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_SMALL)),
                                              Text(
                                                (order.trackingModel.paymentStatus != null && order.trackingModel.paymentStatus.isNotEmpty)
                                                    ? '(${order.trackingModel.paymentStatus})' : 'الدفع الالكترونى',
                                                style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_EXTRA_SMALL
                                                , color: Colors.red,
                                                ),
                                              ),
                                            ]),

                                      ],
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            SizedBox(height: Dimensions.MARGIN_SIZE_EXTRA_SMALL),

                            SizedBox(height: Dimensions.MARGIN_SIZE_EXTRA_SMALL),


                            Column(
                                children: [
                                  widget.orderType == 'POS'?Text(getTranslated('pos_order', context)):
                                  Row(mainAxisAlignment:MainAxisAlignment.spaceBetween, crossAxisAlignment:CrossAxisAlignment.start,
                                      children: [
                                        CircleAvatar(
                                            radius: 20 ,

                                            backgroundColor: ColorResources.getLightSkyBlue(context).withOpacity(0.4)
                                            ,child: Icon(Icons.location_on)),

                                        SizedBox(width: 0,),

                                        Container(
                                          height:100,
                                          width:300,
                                          child: Column(
                                              mainAxisAlignment:MainAxisAlignment.start,
                                              crossAxisAlignment:CrossAxisAlignment.start,

                                              children: [
                                                Text(' ${widget.orderModel !=null  && widget.orderModel.shippingAddressData != null ? widget.orderModel.shippingAddressData.address :''}', maxLines: 3, overflow: TextOverflow.ellipsis, style: titleRegular.copyWith(fontSize: Dimensions.FONT_SIZE_EXTRA_SMALL)),

                                                // widget.orderModel !=null && widget.orderModel.billingAddressData != null?
                                                // Row(mainAxisAlignment:MainAxisAlignment.start, crossAxisAlignment:CrossAxisAlignment.start,
                                                //   children: [
                                                //     // Text('${getTranslated('billing_address', context)
                                                //     //
                                                //     // } :',
                                                //     //     style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_EXTRA_SMALL)),
                                                //     Text(' ${widget.orderModel.billingAddressData != null ? widget.orderModel.billingAddressData.city : ''}',
                                                //         maxLines: 3, overflow: TextOverflow.ellipsis, style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_EXTRA_SMALL)),
                                                //   ],
                                                // ):SizedBox(
                                              ]
                                          ),
                                        ),
                                      ]),
                                ]),






                          ]),
                    ),




                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: Dimensions.PADDING_SIZE_DEFAULT, vertical: Dimensions.PADDING_SIZE_DEFAULT),
                      child: Text(getTranslated('pay summary', context),
                          style: titilliumsemiBold.copyWith()),
                    ),


                    // Amounts
                    Container(
                      padding:
                      EdgeInsets.all(Dimensions.PADDING_SIZE_SMALL),
                      color: Theme.of(context).highlightColor,
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [


                            Padding(
                              padding: const EdgeInsets.all(10.0),
                              child: Card(
                                  color:ColorResources.white.withOpacity(0.9),

                                  child: Padding(
                                    padding: const EdgeInsets.all(0.0),
                                    child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Row(
                                          children: [
                                            SizedBox(width: Dimensions.MARGIN_SIZE_EXTRA_SMALL),

                                            Icon(Icons.list_alt , size: 15,) ,

                                            SizedBox(width: Dimensions.MARGIN_SIZE_EXTRA_SMALL),

                                            Text("فاتوره الطلبات" ,
                                                style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_EXTRA_SMALL)),
                                          ],
                                        ),

                                        MaterialButton(
                                          onPressed: (){


                                          },
                                          child: Row(
                                            children: [
                                              Icon(Icons.arrow_drop_down_circle_outlined , size: 15) ,

                                              SizedBox(width: Dimensions.MARGIN_SIZE_EXTRA_SMALL),


                                              Text("طباعه" ,
                                                  style: titilliumRegular.copyWith(
                                                      color: Colors.blue,
                                                      fontSize: Dimensions.FONT_SIZE_EXTRA_SMALL)),
                                            ],
                                          ),
                                        ),

                                      ],



                                    ),
                                  )
                              ),
                            ),

                            AmountWidget(
                              style:titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_EXTRA_SMALL),


                                title: getTranslated('ORDER', context), amount: PriceConverter.convertPrice(context, _order)),
                            widget.orderType == "POS"?SizedBox():
                            AmountWidget(                              style:titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_EXTRA_SMALL),

                title: getTranslated('SHIPPING_FEE', context), amount: PriceConverter.convertPrice(context, order.trackingModel.shippingCost)),
                            AmountWidget(                              style:titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_EXTRA_SMALL),
                                title: getTranslated('DISCOUNT', context), amount: PriceConverter.convertPrice(context, _discount)),
                            widget.orderType == "POS"?
                            AmountWidget(                              style:titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_EXTRA_SMALL),
                                title: getTranslated('EXTRA_DISCOUNT', context), amount: PriceConverter.convertPrice(context, eeDiscount)):SizedBox(),
                            AmountWidget(                              style:titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_EXTRA_SMALL),
                              title: getTranslated('coupon_voucher', context), amount: PriceConverter.convertPrice(context, order.trackingModel.discountAmount),
                            ),
                            AmountWidget(                              style:titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_EXTRA_SMALL),
                                title: getTranslated('TAX', context), amount: PriceConverter.convertPrice(context, _tax)),
                            Padding(
                              padding: EdgeInsets.symmetric(vertical: Dimensions.PADDING_SIZE_EXTRA_SMALL),
                              child: Divider(height: 2, color: ColorResources.HINT_TEXT_COLOR),
                            ),
                            AmountWidget(
                              title: getTranslated('TOTAL_PAYABLE', context),
                              style:titilliumsemiBold.copyWith(fontSize: Dimensions.FONT_SIZE_LARGE
                , color: Theme.of(context).primaryColor

                ),
                              amount: PriceConverter.convertPrice(context,
                                  (_order + _shippingFee +order.trackingModel.shippingCost - eeDiscount - order.trackingModel.discountAmount -
                                      _discount  +
                                      _tax)),
                            ),


                            AmountWidget(                              style:titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_EXTRA_SMALL),
                                title: "يشمل ضريبه القيمه المضافه (15%)", amount: PriceConverter.convertPrice(context, _tax)),
                          ]),
                    ),
                    SizedBox(height: Dimensions.MARGIN_SIZE_DEFAULT),

                    //delivery info
                    order.trackingModel.deliveryMan != null?
                        //inhouse deliveryman
                    Container(padding: EdgeInsets.all(Dimensions.PADDING_SIZE_SMALL),
                      decoration: BoxDecoration(color: Theme.of(context).highlightColor),
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('${getTranslated('shipping_info', context)}', style: robotoBold),
                            SizedBox(height: Dimensions.MARGIN_SIZE_EXTRA_SMALL),
                            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text('${getTranslated('delivery_man', context)} : ', style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_SMALL)),
                                  Text(
                                    (order.trackingModel.deliveryMan != null )
                                        ? '${order.trackingModel.deliveryMan.fName} ${order.trackingModel.deliveryMan.lName}':'',
                                    style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_SMALL),
                                  ),
                                ]),

                          ]),
                    ):
                        //third party
                    order.trackingModel.thirdPartyServiceName != null?
                    Container(padding: EdgeInsets.all(Dimensions.PADDING_SIZE_SMALL),
                      decoration: BoxDecoration(color: Theme.of(context).highlightColor),
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('${getTranslated('shipping_info', context)}', style: robotoBold),
                            SizedBox(height: Dimensions.MARGIN_SIZE_EXTRA_SMALL),
                            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text('${getTranslated('delivery_service_name', context)} : ', style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_SMALL)),
                                  Text(
                                    (order.trackingModel.thirdPartyServiceName != null && order.trackingModel.thirdPartyServiceName.isNotEmpty)
                                        ? order.trackingModel.thirdPartyServiceName:'',
                                    style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_SMALL),
                                  ),
                                ]),
                            SizedBox(height: Dimensions.MARGIN_SIZE_EXTRA_SMALL),
                            Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text('${getTranslated('tracking_id', context)} : ',
                                      style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_SMALL)),

                                  Text(order.trackingModel.thirdPartyTrackingId != null
                                          ? order.trackingModel.thirdPartyTrackingId : '',
                                      style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_SMALL,
                                      )),
                                ]),
                          ]),
                    ):SizedBox(),


                    SizedBox(height: Dimensions.PADDING_SIZE_DEFAULT),



                    // Buttons
                    Padding(
                      padding: EdgeInsets.symmetric(
                          horizontal: Dimensions.PADDING_SIZE_SMALL,
                          vertical: Dimensions.PADDING_SIZE_SMALL),
                      // child: Row(
                      //   children: [
                      //     Expanded(
                      //       child: widget.orderModel != null &&  widget.orderModel.orderStatus =='pending' && widget.orderType != "POS"?
                      //       // CustomButton(
                      //       //     buttonText: getTranslated('cancel_order', context),
                      //       //     onTap: () => Provider.of<OrderProvider>(context,listen: false).cancelOrder(context, widget.orderId).then((value) {
                      //       //       if(value.response.statusCode == 200){
                      //       //         Provider.of<OrderProvider>(context, listen: false).initOrderList(context);
                      //       //         Navigator.pop(context);
                      //       //         ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                      //       //           content: Text(getTranslated('order_cancelled_successfully', context)),
                      //       //           backgroundColor: Colors.green,
                      //       //         ));
                      //       //
                      //       //       }
                      //       //     })
                      //       // )
                      //       SizedBox(width:0)
                      //           :CustomButton(
                      //         buttonText: getTranslated('TRACK_ORDER', context),
                      //         onTap: () => Navigator.of(context).push(
                      //             MaterialPageRoute(builder: (context) => TrackingScreen(orderID: widget.orderId.toString()))),
                      //       ),
                      //     ),
                      //     SizedBox(width: Dimensions.PADDING_SIZE_SMALL),
                      //     Expanded(
                      //       child: SizedBox(
                      //         height: 40,
                      //         child: TextButton(
                      //           onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SupportTicketScreen())),
                      //           child: Text(
                      //             getTranslated('SUPPORT_CENTER', context), style: titilliumSemiBold.copyWith(fontSize: 14, color: ColorResources.getPrimary(context)),
                      //           ),
                      //           style: TextButton.styleFrom(shape: RoundedRectangleBorder(
                      //             borderRadius: BorderRadius.circular(6),
                      //             side: BorderSide(color: ColorResources.getPrimary(context)),
                      //           )),
                      //         ),
                      //       ),
                      //     ),
                      //   ],
                      // ),
                    ),
                  ],
                );
                } else {
                  return LoadingPage();
                } //Center(child: CustomLoader(color: Theme.of(context).primaryColor));
              },
            ),
          )
        ],
      ),
    );
  }
}
