import 'package:cached_network_image/cached_network_image.dart';
import 'package:emdad/provider/splash_provider.dart';
import 'package:emdad/view/screen/order/widget/order2_details2_widget2.dart';
import 'package:flutter/material.dart';
import 'package:emdad/data/model/response/order_model.dart';
import 'package:emdad/helper/date_converter.dart';
import 'package:emdad/helper/price_converter.dart';
import 'package:emdad/localization/language_constrants.dart';
import 'package:emdad/utility/color_resources.dart';
import 'package:emdad/utility/custom_themes.dart';
import 'package:emdad/utility/dimensions.dart';
import 'package:emdad/view/screen/order/order_details_screen.dart';
import 'package:provider/provider.dart';

import '../../../../data/model/response/order_details.dart';
import '../../../../provider/localization_provider.dart';
import '../../../../provider/order_provider.dart';
import '../../../../provider/profile_provider.dart';
import '../../../../provider/seller_provider.dart';
import '../../../basewidget/custom_snackbar.dart';
import '../../../basewidget/shimmer_loading.dart';
import 'order_details_widget.dart';


class OrderWidget extends StatefulWidget {
  final OrderModel orderModel2;
  OrderWidget({this.orderModel2});

  @override
  State<OrderWidget> createState() => _OrderWidgetState();
}

class _OrderWidgetState extends State<OrderWidget> {
  void _loadData(BuildContext context) async {
    await Provider.of<OrderProvider>(context, listen: false).initTrackingInfo(widget.orderModel2.id.toString(), widget.orderModel2, true, context);
    if (widget.orderModel2 == null) {
      await Provider.of<SplashProvider>(context, listen: false).initConfig(context);
    }
    Provider.of<SellerProvider>(context, listen: false).removePrevOrderSeller();
    await Provider.of<ProfileProvider>(context, listen: false).initAddressList(context);
    if(Provider.of<SplashProvider>(context, listen: false).configModel.shippingMethod == 'sellerwise_shipping') {
      await Provider.of<OrderProvider>(context, listen: false).initShippingList(
        context, Provider.of<OrderProvider>(context, listen: false).trackingModel.sellerId,
      );
    }else {
      await Provider.of<OrderProvider>(context, listen: false).initShippingList(context, 1);
    }
    Provider.of<OrderProvider>(context, listen: false).getOrderDetails(
      widget.orderModel2.id.toString(), context,
      Provider.of<LocalizationProvider>(context, listen: false).locale.countryCode,
    );
  }
//  initState(){  _loadData(context);}
  @override
  Widget build(BuildContext context) {



  return InkWell(
      onTap: () {
        Navigator.of(context).push(MaterialPageRoute(builder: (context) => OrderDetailsScreen(orderModel: widget.orderModel2, orderId: widget.orderModel2.id, orderType: widget.orderModel2.orderType,extraDiscount: widget.orderModel2.extraDiscount,extraDiscountType: widget.orderModel2.extraDiscountType)));
      },
      child: Padding(
        padding: const EdgeInsets.only(left: 8.0 , right: 8),
        child: Card(
          shape: RoundedRectangleBorder(
            side: BorderSide(
              color: Colors.transparent,
            ),
            borderRadius: BorderRadius.circular(22.0), //<-- SEE HERE
          ),
          child: Container(
            margin: EdgeInsets.only(bottom: Dimensions.PADDING_SIZE_SMALL, left: Dimensions.PADDING_SIZE_SMALL, right: Dimensions.PADDING_SIZE_SMALL),
            padding: EdgeInsets.all(Dimensions.PADDING_SIZE_SMALL),
            decoration: BoxDecoration(color: Theme.of(context).highlightColor, borderRadius: BorderRadius.circular(22)),
            child: Column(children: [

              Column(crossAxisAlignment: CrossAxisAlignment.start
                  , children: [
                Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,

                children: [
                    Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(children: [
                          Text(getTranslated('ORDER_ID', context), style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_SMALL
                          , fontWeight: FontWeight.w600

                          )),
                          SizedBox(width: Dimensions.PADDING_SIZE_SMALL),
                          Text(widget.orderModel2.id.toString(), style: titilliumsemiBold),
                        ]),

                        Row(children: [
                          Text(DateConverter.localDateToIsoStringAMPM(DateTime.parse(widget.orderModel2.createdAt)), style: titilliumRegular.copyWith(
                            fontSize: Dimensions.FONT_SIZE_SMALL, color: Theme.of(context).hintColor,
                          )),
                        ]),
                      ],
                    ),




                    Container(
                      alignment: Alignment.center,
                      padding: EdgeInsets.symmetric(horizontal: Dimensions.PADDING_SIZE_SMALL),
                      decoration: BoxDecoration(
                        color: ColorResources.getLightSkyBlue(context).withOpacity(0.2),
                        borderRadius: BorderRadius.circular(5),
                      ),
                      child: Text(widget.orderModel2.orderStatus.toUpperCase(),

                          style: titilliumRegular.copyWith(fontSize: 10 ,
                      )),
                    ),

                  ],
                ),

                    Divider(),

              ]),
              SizedBox(width: Dimensions.PADDING_SIZE_LARGE),


              // ClipRRect(
              //   borderRadius: BorderRadius.circular(Dimensions.PADDING_SIZE_EXTRA_SMALL),
              //   child: CachedNetworkImage(
              //     width: 60, height: 60,
              //     imageUrl: '${Provider.of<SplashProvider>(context, listen: false).baseUrls.productThumbnailUrl}/${OrderDetailsModel().productDetails.thumbnail}',
              //     fit: BoxFit.cover,
              //     imageBuilder: (BuildContext context, ImageProvider<dynamic> imageProvider) {
              //       return Image( image: imageProvider, fit: BoxFit.cover);},
              //     placeholder: (context, url) => Image.asset(
              //       'assets/images/placeholder.png',
              //       fit: BoxFit.cover,
              //     ),
              //     errorWidget: (context, url, error) => Icon(Icons.shopping_cart_outlined),
              //   ),
              //   /*
              //     FadeInImage.assetNetwork(
              //       placeholder: Images.placeholder, fit: BoxFit.scaleDown, width: 60, height: 60,
              //       image: '${Provider.of<SplashProvider>(context, listen: false).baseUrls.productThumbnailUrl}/${widget.orderDetailsModel.productDetails.thumbnail}',
              //       imageErrorBuilder: (c, o, s) => Image.asset(Images.placeholder, fit: BoxFit.scaleDown, width: 50, height: 50),
              //     ),
              //
              //      */
              // ),
////



















              Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(getTranslated('total_price', context), style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_EXTRA_SMALL)),
                SizedBox(width: 10,),
                Text(PriceConverter.convertPrice(context, widget.orderModel2.orderAmount), style: titilliumRegular.copyWith(fontSize: 12 ,
                color: Theme.of(context).primaryColor,
                )),
                SizedBox(width: 10,),
              ]),


            ]),
          ),
        ),
      ),
    );
  }
}
