import 'package:emdad/provider/profile_provider.dart';
import 'package:emdad/utility/images.dart';
import 'package:emdad/view/basewidget/no_internet_screen.dart';
import 'package:emdad/view/screen/support/support_conversation_screen.dart';
import 'package:flutter/material.dart';
import 'package:emdad/data/model/response/support_ticket_model.dart';
import 'package:emdad/helper/date_converter.dart';

import 'package:emdad/localization/language_constrants.dart';
import 'package:emdad/provider/auth_provider.dart';
import 'package:emdad/provider/support_ticket_provider.dart';
import 'package:emdad/utility/color_resources.dart';
import 'package:emdad/utility/custom_themes.dart';
import 'package:emdad/utility/dimensions.dart';
import 'package:emdad/view/basewidget/custom_expanded_app_bar.dart';
import 'package:flutter/services.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:provider/provider.dart';
import 'package:shimmer/shimmer.dart';
import 'package:unicons/unicons.dart';

import '../../../utility/color_resources.dart';
import '../support/issue_type_screen.dart';
import 'package:timeago/timeago.dart' as timeago;

// ignore: must_be_immutable
class WalletScreen extends StatefulWidget {
  @override
  State<WalletScreen> createState() => _WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen> {
  bool first = true;
  bool isGuestMode;

  @override
  Widget build(BuildContext context) {
    isGuestMode =
        !Provider.of<AuthProvider>(context, listen: false).isLoggedIn();

    if (first) {
      first = false;
      if (Provider.of<AuthProvider>(context, listen: false).isLoggedIn()) {
        Provider.of<SupportTicketProvider>(context, listen: false)
            .getSupportTicketList(context);
      }
    }

    return Container(
      decoration: BoxDecoration(
        //border: Border.all(color: Colors.black),
        gradient: LinearGradient(
          colors: [

            Colors.green[600],






            Colors.white,
          ],
          stops: [2 / 6, 2 / 6],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: _buildBody(),
      ),
    );
  }

  Widget _buildBody() {
    return Builder(builder: (context) {
      return CustomScrollView(
        slivers: [
          SliverAppBar(
            // elevation: 0,
            //
            // collapsedHeight: 230,
            // stretch: true,
            // pinned: true,

            systemOverlayStyle: SystemUiOverlayStyle(
              // Status bar color
              statusBarColor: Colors.transparent,

              // Status bar brightness (optional)
              statusBarIconBrightness:
                  Brightness.dark, // For Android (dark icons)
              statusBarBrightness: Brightness.light,
            ),

            pinned: false,
            floating: true,
            primary: false,
            //toolbarHeight: 200,
            elevation: 0,
            automaticallyImplyLeading: false,

            backgroundColor: Colors.transparent,
            expandedHeight: 230,
            flexibleSpace: FlexibleSpaceBar(
              background: Stack(
                children: [
                  Container(
                    height: 450,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20.0),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.transparent,
                          offset: const Offset(0.0, 2.0),
                          blurRadius: 6.0,
                        ),
                      ],
                    ),
                    child: ClipRRect(
                        // borderRadius: BorderRadius.only(
                        //     bottomRight: Radius.circular(0),
                        //     bottomLeft: Radius.circular(30)),
                        child:
                            Container(height: 100, color: Colors.transparent)),
                  ),
                  Align(
                    alignment: Alignment.topCenter,
                    child: Padding(
                      padding: const EdgeInsets.only(
                          right: 0.0, left: 20, top: 20, bottom: 20),
                      child: Container(
                        height: 50,
                        //width: 250,
                        child: Padding(
                          padding: const EdgeInsets.only(
                              top: Dimensions.PADDING_SIZE_LARGE),
                          child: Row(
                            children: [
                              IconButton(
                                  icon: const Icon(Icons.cancel,
                                      size: 25,
                                      color: ColorResources.primaryLightColor),
                                  onPressed: () {
                                    Navigator.pop(context);
                                  }),
                              Expanded(child: SizedBox.shrink()),

                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Align(
                    alignment: Alignment.centerRight,
                    child: Padding(
                      padding: const EdgeInsets.all(20.0),
                      child: Padding(
                        padding: const EdgeInsets.only(
                            top: Dimensions.PADDING_SIZE_LARGE),
                        child: Column(
                          children: [
SizedBox(height: 60,),                            Row(
                              children: [
                                //Expanded(child: SizedBox.shrink()),
                                Text(
                                  "المحفظه" ,
                                  style: titilliumRegular.copyWith(
                                      fontSize:
                                          Dimensions.FONT_SIZE_EXTRA_LARGE,
                                      color: ColorResources.primaryLightColor),
                                ),
                                SizedBox(
                                  width:
                                      Dimensions.FONT_SIZE_EXTRA_SMALLest_too,
                                ),

                                SizedBox(
                                    width: Dimensions
                                        .FONT_SIZE_EXTRA_SMALLest_too),
                                Text("💰",
                                    style: titilliumRegular.copyWith(
                                        fontSize:
                                            Dimensions.PADDING_SIZE_LARGE)),
                              ],
                            ),
                            Row(
                              children: [
                               // Expanded(child: SizedBox.shrink()),
                                Text(
                                 
                                      'لا يوجد رصيد',

                                  style: titilliumRegular.copyWith(
                                      fontSize: Dimensions.FONT_SIZE_OVER_LARGE,
                                      color: ColorResources.COLOR_SILVER),
                                ),
                              ],
                            ),

                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),

            //floating: true,
            snap: true,
          ),
          SliverToBoxAdapter(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15.0),
                ),
                elevation: 30,
                margin: EdgeInsets.only(
                    top: Dimensions.PADDING_SIZE_LARGE,
                    left: Dimensions.PADDING_SIZE_SMALL,
                    right: Dimensions.PADDING_SIZE_SMALL),
                child: Container(
                  padding: EdgeInsets.all(Dimensions.PADDING_SIZE_SMALL),
                  margin: EdgeInsets.only(
                      left: Dimensions.PADDING_SIZE_SMALL,
                      right: Dimensions.PADDING_SIZE_SMALL),
                  width: 320,
                  child: Column(
                    children: [
                      SizedBox(
                        height: 12,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Text(
                            "العمليات الاخيره",
                            style: titilliumRegular.copyWith(
                                fontSize: Dimensions.FONT_SIZE_SMALL,
                                fontWeight: FontWeight.w800),
                          ),
                        ],
                      ),
                      SizedBox(height: Dimensions.PADDING_SIZE_SMALL),

                    ],
                  ),
                ),
              ),
              
              SizedBox(height: 100,),

              Container(

              height: 250,
              width: 200,

      decoration: const BoxDecoration(
      image: DecorationImage(
      image: AssetImage(Images.wallet,),
      fit: BoxFit.contain),
      ),) ,
              SizedBox(height: 0,),


              Row(
                children: [
                  SizedBox(width: 80,),
                  Text(

                    'لا توجد معاملات حاليا',

                    style: titilliumBold.copyWith(
                        fontSize: Dimensions.FONT_SIZE_LARGE,
                        color: ColorResources.colorPrimaryBlack
                    ,                                fontWeight: FontWeight.w800

                  ),
                  ),
                ],
              ),
             
            ],
          )),
        ],
      );

      //: NoInternetOrDataScreen(isNoInternet: false)
    });
  }
}

class SupportTicketShimmer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: EdgeInsets.all(Dimensions.PADDING_SIZE_LARGE),
      itemCount: 10,
      itemBuilder: (context, index) {
        return Container(
          padding: EdgeInsets.all(Dimensions.PADDING_SIZE_SMALL),
          margin: EdgeInsets.only(bottom: Dimensions.PADDING_SIZE_SMALL),
          decoration: BoxDecoration(
            color: ColorResources.IMAGE_BG,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: ColorResources.SELLER_TXT, width: 2),
          ),
          child: Shimmer.fromColors(
            baseColor: Colors.grey[300],
            highlightColor: Colors.grey[100],
            enabled:
                Provider.of<SupportTicketProvider>(context).supportTicketList ==
                    null,
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Container(height: 10, width: 100, color: ColorResources.WHITE),
              SizedBox(height: Dimensions.PADDING_SIZE_EXTRA_SMALL),
              Container(height: 15, color: ColorResources.WHITE),
              SizedBox(height: Dimensions.PADDING_SIZE_EXTRA_SMALL),
              Row(children: [
                Container(height: 15, width: 15, color: ColorResources.WHITE),
                SizedBox(width: Dimensions.PADDING_SIZE_SMALL),
                Container(height: 15, width: 50, color: ColorResources.WHITE),
                Expanded(child: SizedBox.shrink()),
                Container(height: 30, width: 70, color: ColorResources.WHITE),
              ]),
            ]),
          ),
        );
      },
    );
  }
}

// CustomExpandedAppBar(
// title:
//
// getTranslated('support_ticket', context),

// return Row(children: [
//
//   Padding(
//     padding: const EdgeInsets.only(top: Dimensions.PADDING_SIZE_LARGE),
//     child: Image.asset(Images.logo_with_name_image, height: 35),
//   ),
//   Expanded(child: SizedBox.shrink()),
//   InkWell(
//     onTap: () {
//       //if(Provider.of<ProfileProvider>(context, listen: false).userInfoModel != null) {
//      //  Navigator.of(context).push(MaterialPageRoute(builder: (context) => ProfileScreen()));
//       //}
//     },
//     child: Row(children: [
//       Text(!isGuestMode ? profile.userInfoModel != null ? '${profile.userInfoModel.fName}' : 'Full Name' : 'Guest',
//           style: titilliumRegular.copyWith(color: ColorResources.COLOR_BLACK)),
//       SizedBox(width: Dimensions.PADDING_SIZE_SMALL),
//     /*
//     isGuestMode ? CircleAvatar(child: Icon(Icons.person, size: 35)) :
//
//
//       profile.userInfoModel == null ? CircleAvatar(child: Icon(Icons.person, size: 35)) : ClipRRect(
//         borderRadius: BorderRadius.circular(15),
//         child: FadeInImage.assetNetwork(
//           placeholder: Images.logo_image, width: 35, height: 35, fit: BoxFit.fill,
//           image: '${Provider.of<SplashProvider>(context,listen: false).baseUrls.customerImageUrl}/${profile.userInfoModel.image}',
//           imageErrorBuilder: (c, o, s) => CircleAvatar(child: Icon(Icons.person, size: 35)),
//         ),
//   ),
//      */
//     ]),
//   ),
// ]);

//isGuestCheck: true,

// bottomChild: InkWell(
// onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => IssueTypeScreen())),
// child: Material(
// color: ColorResources.getColombiaBlue(context),
// elevation: 5,
// borderRadius: BorderRadius.circular(50),
// child: Row(mainAxisSize: MainAxisSize.min, children: [
// Container(
// padding: EdgeInsets.all(Dimensions.PADDING_SIZE_EXTRA_SMALL),
// decoration: BoxDecoration(
// color: ColorResources.getFloatingBtn(context),
// shape: BoxShape.circle,
// ),
// child: Icon(Icons.add, color: Colors.white, size: 35),
// ),
// Padding(
// padding: EdgeInsets.symmetric(horizontal: Dimensions.PADDING_SIZE_DEFAULT),
// child: Text(getTranslated('new_ticket', context), style: titilliumSemiBold.copyWith(color: Colors.white, fontSize: Dimensions.FONT_SIZE_LARGE)),
// ),
// ]),
// ),
// //)
