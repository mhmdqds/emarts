import 'package:flutter/material.dart';
import 'package:emdad/utility/Palette.dart';
import 'package:emdad/utility/app_strings.dart';

class CustomTabView extends StatefulWidget {
  final int itemCount;
  final IndexedWidgetBuilder tabBuilder;
  final IndexedWidgetBuilder pageBuilder;
  final Widget stub;
  final ValueChanged<int> onPositionChange;
  final ValueChanged<double> onScroll;
  final int initPosition;

  CustomTabView({
    this.itemCount,
    this.tabBuilder,
    this.pageBuilder,
    this.stub,
    this.onPositionChange,
    this.onScroll,
    this.initPosition,
  });

  @override
  _CustomTabsState createState() => _CustomTabsState();
}

class _CustomTabsState extends State<CustomTabView>
    with TickerProviderStateMixin {
  TabController controller;
  int _currentCount;
  int _currentPosition;

  @override
  void initState() {
    // _currentPosition = widget.initPosition ?? 0;
    _currentPosition = 0;
    controller = TabController(
      length: widget.itemCount,
      vsync: this,
      initialIndex: _currentPosition,
    );
    controller.addListener(onPositionChange);
    controller.animation.addListener(onScroll);
    _currentCount = widget.itemCount;
    super.initState();
  }

  @override
  void didUpdateWidget(CustomTabView oldWidget) {
    if (_currentCount != widget.itemCount) {
      controller.animation.removeListener(onScroll);
      controller.removeListener(onPositionChange);
      controller.dispose();

      if (widget.initPosition != null) {
        _currentPosition = widget.initPosition;
      }

      if (_currentPosition > widget.itemCount - 1) {
        _currentPosition = widget.itemCount - 1;
        _currentPosition = _currentPosition < 0 ? 0 : _currentPosition;
        if (widget.onPositionChange is ValueChanged<int>) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (mounted) {
              widget.onPositionChange(_currentPosition);
            }
          });
        }
      }
      print('_currentPosition:::::::$_currentPosition');

      _currentCount = widget.itemCount;
      setState(() {
        controller = TabController(
          length: widget.itemCount,
          vsync: this,
          initialIndex: _currentPosition,
        );
        controller.addListener(onPositionChange);
        controller.animation.addListener(onScroll);
      });
    } else if (widget.initPosition != null) {
      controller.animateTo(widget.initPosition);
    }

    super.didUpdateWidget(oldWidget);
  }

  @override
  void dispose() {
    controller.animation.removeListener(onScroll);
    controller.removeListener(onPositionChange);
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.itemCount < 1) return widget.stub ?? Container();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        Container(
          alignment: Alignment.centerRight,
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              height: 35,

              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(25.0)
              ),
              child: TabBar(
                isScrollable: true,
                controller: controller,
                labelStyle: TextStyle(fontFamily: proxima_nova_bold, fontSize: 12),
                labelColor:Palette.white,
                unselectedLabelColor: Palette.loginhead,
                unselectedLabelStyle: TextStyle(fontFamily: proxima_nova_reg,fontSize: 12),
                labelPadding: EdgeInsets.symmetric(horizontal: 8),
               // indicatorPadding: EdgeInsets.symmetric(horizontal: 70),



                indicator: BoxDecoration(
                    borderRadius:  BorderRadius.circular(10.0),
                  color: Theme.of(context).primaryColor
                  //Theme.of(context).dividerColor,
                  //boxShadow: [BoxShadow(color: Colors.blue[800], spreadRadius: 1, blurRadius: 1)],

                  // border: Border(
                  //   bottom: BorderSide(
                  //     color: Palette.blue,
                  //     width: 4,
                  //   ),
                  //
                  // ),
                ),
                tabs: List.generate(
                  widget.itemCount,
                  (index) => Container(
                      height: 35,
                      //width: 70,
                      decoration: BoxDecoration(
                          color: Colors.transparent,
                        borderRadius:  BorderRadius.circular(10.0),

                          border: Border.all(
                              color:  Theme.of(context).primaryColor,

                          )
                      ),
                      child: Padding(
                        padding: const EdgeInsets.only(left: 8.0 , right: 8),
                        child: widget.tabBuilder(context, index),
                      )),
                ),
              ),
            ),
          ),
        ),


        Expanded(
          child: TabBarView(
            controller: controller,
            children: List.generate(
              widget.itemCount,
              (index) => widget.pageBuilder(context, index),
            ),
          ),
        ),
      ],
    );
  }

  onPositionChange() {
    if (!controller.indexIsChanging) {
      _currentPosition = controller.index;
      if (widget.onPositionChange is ValueChanged<int>) {
        widget.onPositionChange(_currentPosition);
      }
    }
    print('_currentPosition77777777777:::::::$_currentPosition');

  }

  onScroll() {
    if (widget.onScroll is ValueChanged<double>) {
      widget.onScroll(controller.animation.value);
    }
  }
}
