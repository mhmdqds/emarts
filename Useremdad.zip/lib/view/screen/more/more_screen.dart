import 'package:emdad/view/screen/auth/auth_phone_screen.dart';
import 'package:emdad/view/screen/flashdeal/flash_deal_screen.dart';
import 'package:emdad/view/screen/tread_info/steppers_dots.dart';
import 'package:emdad/view/screen/tread_info/treadInfo.dart';
import 'package:emdad/view/screen/wallet/wallet_screen.dart';
import 'package:flutter/material.dart';
import 'package:emdad/provider/cart_provider.dart';
import 'package:emdad/provider/localization_provider.dart';
import 'package:emdad/provider/wishlist_provider.dart';
import 'package:emdad/localization/language_constrants.dart';
import 'package:emdad/provider/auth_provider.dart';
import 'package:emdad/provider/profile_provider.dart';
import 'package:emdad/provider/splash_provider.dart';
import 'package:emdad/provider/theme_provider.dart';
import 'package:emdad/utility/color_resources.dart';
import 'package:emdad/utility/dimensions.dart';
import 'package:emdad/utility/images.dart';
import 'package:emdad/view/screen/more/widget/html_view_Screen.dart';
import 'package:emdad/view/screen/notification/notification_screen.dart';
import 'package:emdad/view/screen/profile/address_list_screen.dart';
import 'package:emdad/view/screen/support/support_ticket_screen.dart';
import 'package:provider/provider.dart';
import 'package:unicons/unicons.dart';
import '../../../utility/styles.dart';


import '../profile/profile_screen.dart';
int isDocComplete = 1;
int isDocRequest = 0;

class MoreScreen extends StatefulWidget {
  @override
  State<MoreScreen> createState() => _MoreScreenState();
}

class _MoreScreenState extends State<MoreScreen> {
  bool isGuestMode;
  String version;
  bool singleVendor = false;
  @override
  void initState() {
    isGuestMode = !Provider.of<AuthProvider>(context, listen: false).isLoggedIn();
    if(!isGuestMode) {
      Provider.of<ProfileProvider>(context, listen: false).getUserInfo(context);
      Provider.of<WishListProvider>(context, listen: false).initWishList(
        context, Provider.of<LocalizationProvider>(context, listen: false).locale.countryCode,
      );
      version = Provider.of<SplashProvider>(context,listen: false).configModel.version != null?Provider.of<SplashProvider>(context,listen: false).configModel.version:'version';
    }
    singleVendor = Provider.of<SplashProvider>(context, listen: false).configModel.businessMode == "single";

    if (Provider.of<ProfileProvider>(context, listen: false)
        .userInfoModel
        .isDoc ==
        0) {
      isDocComplete = 0;
    } else {
      isDocComplete = 1;
    }
    if (Provider.of<ProfileProvider>(context, listen: false)
        .userInfoModel
        .isDocReq ==
        0) {
      isDocRequest = 0;
    } else {
      isDocRequest = 1;
    }

    super.initState();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        physics: BouncingScrollPhysics(),
        child: Stack(children: [
          // Background
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: Image.asset(
              Images.more_page_header,
              height: 150,
              fit: BoxFit.fill,
              color: Provider.of<ThemeProvider>(context).darkTheme ? Colors.black : Theme.of(context).highlightColor,
            ),
          ),


          Positioned(
              top: 30,
              left: Dimensions.PADDING_SIZE_EXTRA_EXTRA_SMALL,
              right: Dimensions.PADDING_SIZE_EXTRA_EXTRA_SMALL,
              child: Consumer<ProfileProvider>(
                  builder: (context, profile, child) {

                    return Column(
                      children: [
                        Row(children: [

                          Padding(
                            padding: const EdgeInsets.only(top: Dimensions.PADDING_SIZE_LARGE , right: Dimensions.PADDING_SIZE_LARGE),
                            child: Row(children: [
                              Text("👋" , style: titilliumRegular.copyWith(
                                  fontSize: Dimensions.PADDING_SIZE_LARGE
                              )),

                              SizedBox(width: Dimensions.PADDING_SIZE_SMALL),

                              Text(getTranslated('good evening', context) ,
                                  style: titilliumRegular.copyWith(color: ColorResources.COLOR_BLACK

                                  )),
                            //  SizedBox(width: Dimensions.PADDING_SIZE_SMALL),
                              /*
                      isGuestMode ? CircleAvatar(child: Icon(Icons.person, size: 35)) :


                        profile.userInfoModel == null ? CircleAvatar(child: Icon(Icons.person, size: 35)) : ClipRRect(
                          borderRadius: BorderRadius.circular(15),
                          child: FadeInImage.assetNetwork(
                            placeholder: Images.logo_image, width: 35, height: 35, fit: BoxFit.fill,
                            image: '${Provider.of<SplashProvider>(context,listen: false).baseUrls.customerImageUrl}/${profile.userInfoModel.image}',
                            imageErrorBuilder: (c, o, s) => CircleAvatar(child: Icon(Icons.person, size: 35)),
                          ),
                    ),
                       */
                            ]),
                            //Image.asset(Images.logo_with_name_image, height: 35),
                          ),
                          // Expanded(child: SizedBox.shrink()),

                        ]),
                        Row(children: [
                          Padding(
                            padding: const EdgeInsets.only(right: Dimensions.PADDING_SIZE_LARGE),
                            child: Text(!isGuestMode ? profile.userInfoModel != null ? '${profile.userInfoModel.fName}' : 'Full Name' : 'Guest',
                                style: titilliumRegular.copyWith(color: ColorResources.COLOR_BLACK
                                  ,   fontWeight: FontWeight.bold ,fontSize: Dimensions.FONT_SIZE_LARGE,

                                )),
                          ),
                          SizedBox(width: Dimensions.PADDING_SIZE_SMALL),
                          /*
                      isGuestMode ? CircleAvatar(child: Icon(Icons.person, size: 35)) :


                        profile.userInfoModel == null ? CircleAvatar(child: Icon(Icons.person, size: 35)) : ClipRRect(
                          borderRadius: BorderRadius.circular(15),
                          child: FadeInImage.assetNetwork(
                            placeholder: Images.logo_image, width: 35, height: 35, fit: BoxFit.fill,
                            image: '${Provider.of<SplashProvider>(context,listen: false).baseUrls.customerImageUrl}/${profile.userInfoModel.image}',
                            imageErrorBuilder: (c, o, s) => CircleAvatar(child: Icon(Icons.person, size: 35)),
                          ),
                    ),
                       */
                        ]),

                        //Text('${Provider.of<ProfileProvider>(context, listen: false).userInfoModel.isComplete}'),
                        isDocComplete == 1?
                        SizedBox(height:5,)
                            :   isDocRequest == 1?
                        Column(
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Padding(
                                  padding: EdgeInsets.symmetric(horizontal: 30, vertical: 10),
                                  child: Container(
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(25),
                                      color: Colors.grey.withOpacity(0.1),


                                    ),
                                    width: double.infinity,
                                    height: 150,
                                    padding: EdgeInsets.symmetric(horizontal: 30, vertical: 10),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      mainAxisAlignment: MainAxisAlignment.start,

                                      children: [
                                        Text('حاله توثيق الحساب', style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_EXTRA_SMALL, color: Colors.black.withOpacity(0.7),)),

                                        SizedBox(height: 5,),
                                        Text('قيد المراجعه', style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_EXTRA_SMALL, color: ColorResources.primaryColor,)),

                                        SizedBox(height: 5,),

                                        LinearProgressIndicator(
                                          backgroundColor: Colors.grey.withOpacity(0.2),
                                          valueColor: AlwaysStoppedAnimation(ColorResources.primaryColor ),
                                          minHeight: 3,

                                        ),

                                        SizedBox(height: 5,),

                                        Text('لا تشيل هم ، تقدر تطلب وفريقنا شغال على توثيق حسابك', style: titilliumRegular.copyWith(
                                          fontSize: Dimensions.FONT_SIZE_EXTRA_SMALL, color: Colors.black.withOpacity(0.7),)),


                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ) :
                        Column(
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Container(
                                  width: double.infinity,
                                  padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                                  child: OutlinedButton.icon(

                                    onPressed: () {
                                      Navigator.push(context, MaterialPageRoute(builder: (_) => CustomStepper( )));
                                    },
                                    icon: Icon(Icons.privacy_tip, color: ColorResources.RED,),
                                    label: Container(

                                      alignment: Alignment.center,
                                      height: 40, padding: EdgeInsets.symmetric(horizontal: 5),
                                      child: Text('كمل معلوماتك حتى تستطيع الطلب', style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_EXTRA_SMALL, color: Theme.of(context).hintColor,)),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        )


                        // Provider.of<ProfileProvider>(context, listen: false).userInfoModel.isDoc == 0
                        //     ? Column(
                        //   children: [
                        //     Column(
                        //       crossAxisAlignment: CrossAxisAlignment.start,
                        //       children: <Widget>[
                        //         Container(
                        //           width: double.infinity,
                        //           padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                        //           child: OutlinedButton.icon(
                        //
                        //             onPressed: () {
                        //               Navigator.push(context, MaterialPageRoute(builder: (_) => CustomStepper( )));
                        //             },
                        //             icon: Icon(Icons.privacy_tip, color: ColorResources.RED,),
                        //             label: Container(
                        //
                        //               alignment: Alignment.center,
                        //               height: 40, padding: EdgeInsets.symmetric(horizontal: 5),
                        //               child: Text('كمل معلوماتك حتى تستطيع الطلب', style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_EXTRA_SMALL, color: Theme.of(context).hintColor,)),
                        //             ),
                        //           ),
                        //         ),
                        //       ],
                        //     ),
                        //   ],
                        // )
                        //     : Provider.of<ProfileProvider>(context, listen: false).userInfoModel.isDoc == 1
                        //     ? Column(
                        //   children: [
                        //     Column(
                        //       crossAxisAlignment: CrossAxisAlignment.start,
                        //       children: <Widget>[
                        //         Padding(
                        //           padding: EdgeInsets.symmetric(horizontal: 30, vertical: 10),
                        //           child: Container(
                        //             decoration: BoxDecoration(
                        //               borderRadius: BorderRadius.circular(25),
                        //               color: Colors.grey.withOpacity(0.1),
                        //
                        //
                        //             ),
                        //             width: double.infinity,
                        //             height: 140,
                        //             padding: EdgeInsets.symmetric(horizontal: 30, vertical: 10),
                        //             child: Column(
                        //               crossAxisAlignment: CrossAxisAlignment.start,
                        //               mainAxisAlignment: MainAxisAlignment.start,
                        //
                        //               children: [
                        //                 Text('حاله توثيق الحساب', style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_EXTRA_SMALL, color: Colors.black.withOpacity(0.7),)),
                        //
                        //                 SizedBox(height: 5,),
                        //                 Text('قيد المراجعه', style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_EXTRA_SMALL, color: ColorResources.primaryColor,)),
                        //
                        //                 SizedBox(height: 5,),
                        //
                        //                 LinearProgressIndicator(
                        //                   backgroundColor: Colors.grey.withOpacity(0.2),
                        //                   valueColor: AlwaysStoppedAnimation(ColorResources.primaryColor ),
                        //                   minHeight: 3,
                        //
                        //                 ),
                        //
                        //                 SizedBox(height: 5,),
                        //
                        //                 Text('لا تشيل هم ، تقدر تطلب وفريقنا شغال على توثيق حسابك', style: titilliumRegular.copyWith(
                        //                   fontSize: Dimensions.FONT_SIZE_EXTRA_SMALL, color: Colors.black.withOpacity(0.7),)),
                        //
                        //
                        //               ],
                        //             ),
                        //           ),
                        //         ),
                        //       ],
                        //     ),
                        //   ],
                        // )
                        //     : SizedBox(height: 10),

                      ],
                    );

                  }
              )
          ),



          // AppBar
          Positioned(
            top:

            isDocComplete == 1?
            130

                :   isDocRequest == 1?
            280 :
            180 ,




            left: Dimensions.PADDING_SIZE_EXTRA_EXTRA_SMALL,
            right: Dimensions.PADDING_SIZE_EXTRA_EXTRA_SMALL,
            child: Consumer<ProfileProvider>(
              builder: (context, profile, child) {

                return  Card(
                  elevation: 0,
                  shape: RoundedRectangleBorder( borderRadius: BorderRadius.circular(15),),
                  margin: EdgeInsets.all(10),
                  clipBehavior: Clip.antiAliasWithSaveLayer,
                  child:  Container(
                    color: Colors.grey.withOpacity(0.1),
                    width: double.infinity,
                    padding: EdgeInsets.symmetric(horizontal: 20, vertical: 30),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        IconCardsWidgets(icon: UniconsLine.building , text: getTranslated('building', context),

                            navigateTo: Provider.of<AuthProvider>(context, listen: false).isLoggedIn() != null ? TreadInfo(start: false) : AuthPhoneScreen()),




                        IconCardsWidgets(icon: UniconsLine.location_point , text: getTranslated('locations', context),
                            navigateTo:  AdressListScreen()


                        ),

                        IconCardsWidgets(icon: UniconsLine.user , text: getTranslated('my account', context),

                            navigateTo: ProfileScreen()

                        ),



                      ],
                    ),
                  ),
                );




                // return Row(children: [
                //
                //   Padding(
                //     padding: const EdgeInsets.only(top: Dimensions.PADDING_SIZE_LARGE),
                //     child: Image.asset(Images.logo_with_name_image, height: 35),
                //   ),
                //   Expanded(child: SizedBox.shrink()),
                //   InkWell(
                //     onTap: () {
                //       //if(Provider.of<ProfileProvider>(context, listen: false).userInfoModel != null) {
                //      //  Navigator.of(context).push(MaterialPageRoute(builder: (context) => ProfileScreen()));
                //       //}
                //     },
                //     child: Row(children: [
                //       Text(!isGuestMode ? profile.userInfoModel != null ? '${profile.userInfoModel.fName}' : 'Full Name' : 'Guest',
                //           style: titilliumRegular.copyWith(color: ColorResources.COLOR_BLACK)),
                //       SizedBox(width: Dimensions.PADDING_SIZE_SMALL),
                //     /*
                //     isGuestMode ? CircleAvatar(child: Icon(Icons.person, size: 35)) :
                //
                //
                //       profile.userInfoModel == null ? CircleAvatar(child: Icon(Icons.person, size: 35)) : ClipRRect(
                //         borderRadius: BorderRadius.circular(15),
                //         child: FadeInImage.assetNetwork(
                //           placeholder: Images.logo_image, width: 35, height: 35, fit: BoxFit.fill,
                //           image: '${Provider.of<SplashProvider>(context,listen: false).baseUrls.customerImageUrl}/${profile.userInfoModel.image}',
                //           imageErrorBuilder: (c, o, s) => CircleAvatar(child: Icon(Icons.person, size: 35)),
                //         ),
                //   ),
                //      */
                //     ]),
                //   ),
                // ]);
              },
            ),
          ),

          Container(
            margin: EdgeInsets.only(top:
            isDocComplete == 1?
            300

                :   isDocRequest == 1?
            450 :
            350

            ),
            decoration: BoxDecoration(
              color: ColorResources.getIconBg(context),
              borderRadius: BorderRadius.only(topLeft: Radius.circular(20), topRight: Radius.circular(20)),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.center,
                children: [

                  /*
                  // Top Row Items
                  Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
                    SquareButton(//image: Images.shopping_image, title: getTranslated('orders', context), navigateTo: OrderScreen(),count: 1,hasCount: false,),
                    SquareButton(//image: Images.cart_image, title: getTranslated('CART', context), navigateTo: CartScreen(),count: Provider.of<CartProvider>(context,listen: false).cartList.length, hasCount: true,),
                    SquareButton(//image: Images.offers, title: getTranslated('offers', context), navigateTo: OffersScreen(),count: 0,hasCount: false,),
                    SquareButton(//image: Images.wishlist, title: getTranslated('wishlist', context), navigateTo: WishListScreen(),count: Provider.of<AuthProvider>(context, listen: false).isLoggedIn() && Provider.of<WishListProvider>(context, listen: false).wishList != null && Provider.of<WishListProvider>(context, listen: false).wishList.length > 0 ?   Provider.of<WishListProvider>(context, listen: false).wishList.length : 0, hasCount: false,),
                  ]),
                   */

                  SizedBox(height: Dimensions.PADDING_SIZE_SMALL),

                  Stack(
                    children: [
                      TitleButton(
                          icon: UniconsLine.wallet,
                          //image: Images.fast_delivery,
                          title: getTranslated('wallet', context), navigateTo: WalletScreen()


                      ),

                      Padding(
                        padding: const EdgeInsets.only(top: 22.0),
                        child: Align(
                          alignment: Alignment.bottomCenter,
                          child: Container(
                            height: 30,
                            width: 50,

                            decoration: BoxDecoration(
                              color:  Color(0xfff2f5fc),
                              borderRadius: BorderRadius.circular(20.0),
                              boxShadow: [
                                BoxShadow(

                                ),
                              ],
                            ),
                            child: Row(
                              children: [
                                SizedBox(width: 8,),
                                Text("0 ريال", style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_EXTRA_SMALL, color: ColorResources.mediumGrey
                                  , fontWeight: FontWeight.w800
                                  ,)),
                              ],
                            ),
                          ),

                        ),
                      )
                    ],
                  ),




                  TitleButton(
                      icon: UniconsLine.facebook_messenger,

                      // image: Images.chat_image,
                      title: getTranslated('support_ticket', context), navigateTo: SupportTicketScreen()),


                  // Buttons
                  //TitleButton(//image: Images.privacy_policy, title: getTranslated('verifyAccount', context), navigateTo: Provider.of<AuthProvider>(context, listen: false).isLoggedIn() != null ? CustomStepper() : AuthPhoneScreen()),
                  // TitleButton(
                  //     icon: UniconsLine.location_pin_alt,
                  //
                  //     //image: Images.fast_delivery,
                  //     title: getTranslated('address', context), navigateTo: AddressListScreen()),

                  // TitleButton(
                  //     icon: UniconsLine.user,
                  //
                  //     //image: Images.myShop,
                  //     title: getTranslated('PROFILE_INFO', context), navigateTo: Provider.of<AuthProvider>(context, listen: false).isLoggedIn() != null ? TreadInfo(start: false) : AuthPhoneScreen()),


                  //TitleButton(//image: Images.more_filled_image, title: getTranslated('all_category', context), navigateTo: AllCategoryScreen()),

                  TitleButton(
                      icon:Icons.notifications,

                      //image: Images.notification_filled,
                      title: getTranslated('notification', context), navigateTo: NotificationScreen()),
                  //TODO: seller
                  singleVendor?SizedBox():
                  TitleButton(
                      icon: UniconsLine.money_bill,

                      //image: Images.chats,
                      title: getTranslated('flash_deal', context), navigateTo: FlashDealScreen()),
                  /*
                  TitleButton(//image: Images.settings, title: getTranslated('settings', context), navigateTo: SettingsScreen()),
                  */
                  TitleButton(
                      icon: UniconsLine.paperclip,

                      //image: Images.term_condition,
                      title: getTranslated('terms_condition', context), navigateTo: HtmlViewScreen(
                    title: getTranslated('terms_condition', context),
                    url: Provider.of<SplashProvider>(context, listen: false).configModel.termsConditions,
                  )),
                  TitleButton(
                      icon: UniconsLine.shield,

                      //image: Images.privacy_policy,
                      title: getTranslated('privacy_policy', context), navigateTo: HtmlViewScreen(
                    title: getTranslated('privacy_policy', context),
                    url: Provider.of<SplashProvider>(context, listen: false).configModel.termsConditions,
                  )),


                  TitleButton(
                      icon: UniconsLine.exit,

                      //image: Images.chats,
                      title: getTranslated('Exit', context), navigateTo: AuthPhoneScreen()),


                  /*
                  TitleButton(//image: Images.help_center, title: getTranslated('faq', context), navigateTo: FaqScreen(
                    title: getTranslated('faq', context),
                    // url: Provider.of<SplashProvider>(context, listen: false).configModel.staticUrls.faq,
                  )),


                  TitleButton(//image: Images.about_us, title: getTranslated('about_us', context), navigateTo: HtmlViewScreen(
                    title: getTranslated('about_us', context),
                    url: Provider.of<SplashProvider>(context, listen: false).configModel.aboutUs,
                  )),

                   */

                  /*
                  TitleButton(//image: Images.contact_us, title: getTranslated('contact_us', context), navigateTo: WebViewScreen(
                    title: getTranslated('contact_us', context),
                    url: Provider.of<SplashProvider>(context, listen: false).configModel.staticUrls.contactUs,
                  )),



                  ListTile(
                    leading: Image.asset(Images.logo_image, width: 25, height: 25, fit: BoxFit.fill, color: ColorResources.getPrimary(context)),
                    title: Text(getTranslated('app_info', context), style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_LARGE)),
                    trailing: Text(version??''),
                  ),


                  isGuestMode
                      ? SizedBox()
                      : ListTile(
                    leading: Icon(Icons.exit_to_app, color: ColorResources.getPrimary(context), size: 25),
                    title: Text(getTranslated('sign_out', context), style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_LARGE)),
                    onTap: () => showAnimatedDialog(context, SignOutConfirmationDialog(), isFlip: true),
                  ),

                   */
                ]),
          ),
        ]),
      ),
    );
  }
}



class IconCardsWidgets extends StatelessWidget {
  String text;
  IconData icon ;
  final Widget navigateTo;


  IconCardsWidgets({
    Key key,
    @required this.text ,
    @required this.icon ,
    @required this.navigateTo ,


  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: InkWell(
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => navigateTo)),

        child: Column(
          children: [
            Wrap(
                runSpacing: 20.0,
                spacing: 7.0,
                children: [

                  Container(
                    width: 70.0,
                    height: 70.0,
                    padding: const EdgeInsets.all(8.0),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20.0),
                      boxShadow: [
                        BoxShadow(
                          //color: Colors.black.withOpacity(0.8),
                          //spreadRadius: 1,
                          //blurRadius: 7,
                          //offset: const Offset(
                          //    0, 2), // changes position of shadow
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        Expanded(

                          child: Icon(icon , size: 35, color: ColorResources.COLOR_BLACK.withOpacity(0.5)
                            ,
                          ),
                        ),
                        const SizedBox(
                          height: 8.0,
                        ),
                        // Text('sdasd', style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_DEFAULT, color: Theme.of(context).hintColor,)),

                      ],
                    ),
                  ),
                ]
            ),
            const SizedBox(
              height: 8.0,
            ),
            Text(text, style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_EXTRA_SMALL, color: ColorResources.COLOR_BLACK
              , fontWeight: FontWeight.w800
              ,)),

          ],
        ),
      ),
    );
  }
}

class SquareButton extends StatelessWidget {
  final String image;
  final String title;
  final Widget navigateTo;
  final int count;
  final bool hasCount;


  SquareButton({@required this.image, @required this.title, @required this.navigateTo, @required this.count, @required this.hasCount});

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width - 100;
    return InkWell(
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => navigateTo)),
      child: Column(children: [
        Container(
          width: width / 4,
          height: width / 4,
          padding: EdgeInsets.all(Dimensions.PADDING_SIZE_LARGE),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            color: ColorResources.getPrimary(context),
          ),
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              Image.asset(image, color: Theme.of(context).highlightColor),
              hasCount?
              Positioned(top: -4, right: -4,
                child: Consumer<CartProvider>(builder: (context, cart, child) {
                  return CircleAvatar(radius: 7, backgroundColor: ColorResources.RED,
                    child: Text(count.toString(),
                        style: titilliumSemiBold.copyWith(color: ColorResources.WHITE, fontSize: Dimensions.FONT_SIZE_EXTRA_SMALL,
                        )),
                  );
                }),
              ):SizedBox(),
            ],
          ),
        ),
        Align(
          alignment: Alignment.center,
          child: Text(title, style: titilliumRegular),
        ),
      ]),
    );
  }
}

class TitleButton extends StatelessWidget {
  //final String image;
  IconData icon;
  final String title;
  final Widget navigateTo;
  TitleButton({@required this.icon, @required this.title, @required this.navigateTo});

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;

    return Column(
      children: [
        ListTile(
          leading: Column(
            children: [
              Container(
                  decoration: BoxDecoration(
                    color: Color(0xfff2f5fc),
                    //ColorResources.COLOR_COLUMBIA_BLUE.withOpacity(0.9),
                    borderRadius: BorderRadius.circular(15.0),
                    boxShadow: [
                      BoxShadow(
                        //color: Colors.black.withOpacity(0.8),
                        //spreadRadius: 1,
                        //blurRadius: 7,
                        //offset: const Offset(
                        //    0, 2), // changes position of shadow
                      ),
                    ],
                  ),
                  height: width/10,
                  width: width/10,

                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(icon , size: 30 , color: Color(0xffb0bcd8))

                      // Image.asset(image, width: 20, height: 20, fit: BoxFit.fill, color: ColorResources.getTextColor(context)),

                    ],
                  )),




            ],
          ),
          title:DecoratedBox(
              decoration: BoxDecoration(

                border: Border( bottom: BorderSide(color: Colors.grey.withOpacity(0.1)),  ), ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Column(

                    children: [
                      SizedBox(height:  Dimensions.PADDING_SIZE_LARGE),


                      Text(title, style: titilliumRegular.copyWith(fontSize: Dimensions.FONT_SIZE_EXTRA_SMALL, color: ColorResources.COLOR_BLACK
                        , fontWeight: FontWeight.w800
                        ,)),

                      SizedBox(height:  Dimensions.PADDING_SIZE_EXTRA_LARGE),

                    ],
                  ),
                ],
              )),
          onTap: () => Navigator.push(
            context,
            /*PageRouteBuilder(
                transitionDuration: Duration(seconds: 1),
                pageBuilder: (context, animation, secondaryAnimation) => navigateTo,
                transitionsBuilder: (context, animation, secondaryAnimation, child) {
                  animation = CurvedAnimation(parent: animation, curve: Curves.bounceInOut);
                  return ScaleTransition(scale: animation, child: child, alignment: Alignment.center);
                },
              ),*/
            MaterialPageRoute(builder: (_) => navigateTo),
          ),
          /*onTap: () => Navigator.push(context, PageRouteBuilder(
            pageBuilder: (context, animation, secondaryAnimation) => navigateTo,
            transitionsBuilder: (context, animation, secondaryAnimation, child) => FadeTransition(opacity: animation, child: child),
            transitionDuration: Duration(milliseconds: 500),
          )),*/
        ),
        //SizedBox(height:  Dimensions.PADDING_SIZE_EXTRA_LARGE),

      ],
    );
  }
}

