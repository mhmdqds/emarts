import 'package:emdad/provider/theme_provider.dart';
import 'package:emdad/utility/Palette.dart';
import 'package:emdad/view/basewidget/no_order_in_cart.dart';
import 'package:emdad/view/screen/search/search_screen.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:emdad/data/model/response/cart_model.dart';
import 'package:emdad/helper/price_converter.dart';
import 'package:emdad/localization/language_constrants.dart';
import 'package:emdad/provider/auth_provider.dart';
import 'package:emdad/provider/cart_provider.dart';
import 'package:emdad/provider/splash_provider.dart';
import 'package:emdad/utility/color_resources.dart';
import 'package:emdad/utility/custom_themes.dart';
import 'package:emdad/utility/dimensions.dart';
import 'package:emdad/view/basewidget/animated_custom_dialog.dart';
import 'package:emdad/view/basewidget/guest_dialog.dart';
import 'package:emdad/view/basewidget/show_custom_snakbar.dart';
import 'package:emdad/view/screen/cart/widget/cart_widget.dart';
import 'package:emdad/view/screen/checkout/checkout_screen.dart';
import 'package:emdad/view/screen/checkout/widget/shipping_method_bottom_sheet.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:provider/provider.dart';

import '../../../provider/coupon_provider.dart';
import '../../../provider/profile_provider.dart';
import '../checkout/widget/TimeDeliveryBottomSheet.dart';
import '../checkout/widget/cartBottomSheet.dart';
import '../support/support_ticket_screen.dart';
int isDocComplete = 1;
int isDocRequest = 0;

class CartScreen extends StatefulWidget {
  final bool fromCheckout;
  final int sellerId;
  CartScreen({this.fromCheckout = false, this.sellerId = 1});

  @override
  _CartScreenState createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  final TextEditingController _copounController = TextEditingController();
  bool enable = false;
  bool validCopoun=false;
  Future<void> _loadData() async {
    if (Provider.of<AuthProvider>(context, listen: false).isLoggedIn()) {
      Provider.of<CartProvider>(context, listen: false).getCartDataAPI(context);
      Provider.of<CartProvider>(context, listen: false).setCartData();

      if (Provider.of<SplashProvider>(context, listen: false)
              .configModel
              .shippingMethod !=
          'sellerwise_shipping') {
        Provider.of<CartProvider>(context, listen: false)
            .getAdminShippingMethodList(context);
      }
    }
  }


  @override
  // void dispose() {
  //   // TODO: implement dispose
  //   super.dispose();
  //   SystemChrome.setEnabledSystemUIMode(SystemUiMode.manual, overlays: [SystemUiOverlay.bottom]);
  //
  // }

  @override
  void initState() {
    _loadData();
    Provider.of<CouponProvider>(context, listen: false).removePrevCouponData();
    super.initState();
    //SystemChrome.setEnabledSystemUIMode(SystemUiMode.manual, overlays: SystemUiOverlay.values); // to re-

    if (Provider
        .of<ProfileProvider>(context, listen: false)
        .userInfoModel
        .isDoc ==
        0) {
      isDocComplete = 0;
    } else {
      isDocComplete = 1;
    }
    if (Provider
        .of<ProfileProvider>(context, listen: false)
        .userInfoModel
        .isDocReq ==
        0) {
      isDocRequest = 0;
    } else {
      isDocRequest = 1;
    }
  }

  double _order = 0;
  @override
  Widget build(BuildContext context) {
    return Consumer<CartProvider>(builder: (context, cart, child) {
      double amount = 0.0;
      double shippingAmount = 0.0;
      double discount = 0.0;
      double tax = 0.0;
      List<CartModel> cartList = [];
      cartList.addAll(cart.cartList);

      //TODO: seller
      List<String> orderTypeShipping = [];
      List<String> sellerList = [];
      List<CartModel> sellerGroupList = [];
      List<List<CartModel>> cartProductList = [];
      List<List<int>> cartProductIndexList = [];
      cartList.forEach((cart) {
        if (!sellerList.contains(cart.cartGroupId)) {
          sellerList.add(cart.cartGroupId);
          sellerGroupList.add(cart);
        }
      });

      sellerList.forEach((seller) {
        List<CartModel> cartLists = [];
        List<int> indexList = [];
        cartList.forEach((cart) {
          if (seller == cart.cartGroupId) {
            cartLists.add(cart);
            indexList.add(cartList.indexOf(cart));
          }
        });
        cartProductList.add(cartLists);
        cartProductIndexList.add(indexList);
      });

      sellerGroupList.forEach((seller) {
        if (seller.shippingType == 'order_wise') {
          orderTypeShipping.add(seller.shippingType);
        }
      });

      if (cart.getData &&
          Provider.of<AuthProvider>(context, listen: false).isLoggedIn() &&
          Provider.of<SplashProvider>(context, listen: false)
                  .configModel
                  .shippingMethod ==
              'sellerwise_shipping') {
        Provider.of<CartProvider>(context, listen: false)
            .getShippingMethod(context, cartProductList);
      }

      for (int i = 0; i < cart.cartList.length; i++) {
        amount += (cart.cartList[i].price - cart.cartList[i].discount) *
            cart.cartList[i].quantity;
        discount += cart.cartList[i].discount * cart.cartList[i].quantity;
        tax += cart.cartList[i].tax * cart.cartList[i].quantity;
      }
      for (int i = 0; i < cart.chosenShippingList.length; i++) {
        shippingAmount += cart.chosenShippingList[i].shippingCost;
      }
      for (int j = 0; j < cartList.length; j++) {
        shippingAmount += cart.cartList[j].shippingCost ?? 0;
      }

      return Scaffold(
        appBar: AppBar(
          backgroundColor: Theme.of(context).highlightColor,
          elevation: 0,
          centerTitle: true,
          leading: IconButton(
            icon: Icon(Icons.arrow_back_ios, size: 20, color: Colors.black),
            onPressed: () => Navigator.of(context).pop(),
          ),
          title: Text(
            "السلة",
            style: titilliumRegular.copyWith(
              fontSize: 17,
              color: Provider.of<ThemeProvider>(context).darkTheme
                  ? Colors.white
                  : Colors.black,
            ),
          ),
          actions: [
            Padding(
              padding: const EdgeInsets.only(left: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  InkWell(
                    onTap:(){
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                          builder: (_) => SupportTicketScreen()));

                    },
                    child: Container(
                      width: 100,
                      height: 30,
                      // color: Colors.grey,
                      decoration: BoxDecoration(
                          color: Color(0xfff2f2f2),
                          border: Border.all(
                            color: Color(0xfff2f2f2),
                          ),
                          borderRadius: BorderRadius.all(Radius.circular(20))),

                      child: Center(
                        child: Text(
                          "تحتاج مساعده؟",
                          style: titilliumsemiBold.copyWith(
                            fontSize: 10,
                            color: Colors.black,
                          ),
                        ),
                      ),
                    ),
                  )
                  // IconButton(
                  //   icon: Icon(
                  //     Icons.search,
                  //     color: Palette.loginhead,
                  //   ),
                  //   onPressed: () {
                  //     Navigator.push(
                  //         context,
                  //         MaterialPageRoute(
                  //             builder: (context) => SearchScreen()));
                  //   },
                  // ),
                ],
              ),
            )
          ],
        ),

        // bottomNavigationBar: (!widget.fromCheckout && !cart.isLoading)
        //     ? Container(height: 150, padding: EdgeInsets.symmetric(horizontal: Dimensions.PADDING_SIZE_LARGE,
        //     vertical: Dimensions.PADDING_SIZE_DEFAULT),
        //       decoration: BoxDecoration(color: Theme.of(context).cardColor,
        //           borderRadius: BorderRadius.all(Radius.circular(20))),
        //
        //       child: cartList.isNotEmpty
        //           ? Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
        //             children: [
        //               Expanded(
        //                   child: Center(
        //                       child: Row(
        //                         children: [
        //                           Text('${getTranslated('total_price', context)}', style: titilliumSemiBold.copyWith(
        //                               fontSize: Dimensions.FONT_SIZE_SMALL),
        //                           ),
        //                           Text(PriceConverter.convertPrice(context, amount+shippingAmount), style: titilliumSemiBold.copyWith(
        //                               color: Theme.of(context).primaryColor,fontSize: Dimensions.FONT_SIZE_EXTRA_SMALL),
        //                           ),
        //                         ],
        //                       ))),
        //               Builder(
        //                 builder: (context) => InkWell(
        //                   onTap: () {
        //                     print('===asd=>${orderTypeShipping.length}');
        //                     if (Provider.of<AuthProvider>(context, listen: false).isLoggedIn()) {
        //                       if (cart.cartList.length == 0) {
        //                         ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(getTranslated('select_at_least_one_product', context)), backgroundColor: Colors.red,));
        //                       }
        //                       /*
        //                       else if(cart.chosenShippingList.length < orderTypeShipping.length && Provider.of<SplashProvider>(context,listen: false).configModel.shippingMethod =='sellerwise_shipping'){
        //                         ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(getTranslated('select_all_shipping_method', context)), backgroundColor: Colors.red));
        //                       } else if(cart.chosenShippingList.length < 1 && Provider.of<SplashProvider>(context,listen: false).configModel.shippingMethod !='sellerwise_shipping' && Provider.of<SplashProvider>(context,listen: false).configModel.inHouseSelectedShippingType =='order_wise'){
        //                         ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(getTranslated('select_all_shipping_method', context)), backgroundColor: Colors.red));
        //                       }
        //                       */
        //                       else {
        //                         Navigator.push(context, MaterialPageRoute(builder: (_) => CheckoutScreen(
        //                           cartList: cartList,totalOrderAmount: amount,shippingFee: shippingAmount, discount: discount,
        //                           tax: tax,
        //                         )));
        //                       }
        //                     } else {showAnimatedDialog(context, GuestDialog(), isFlip: true);}
        //                   },
        //
        //                   child: Container(width: MediaQuery.of(context).size.width/2.5,
        //                     decoration: BoxDecoration(
        //                       color: Theme.of(context).primaryColor,
        //                       borderRadius: BorderRadius.circular(Dimensions.PADDING_SIZE_SMALL),
        //                     ),
        //                     child: Center(
        //                       child: Padding(
        //                         padding: const EdgeInsets.symmetric(horizontal: Dimensions.PADDING_SIZE_EXTRA_LARGE,
        //                             vertical: Dimensions.FONT_SIZE_SMALL),
        //                         child: Text(getTranslated('checkout', context),
        //                             style: titilliumSemiBold.copyWith(fontSize: Dimensions.FONT_SIZE_DEFAULT,
        //                               color: Theme.of(context).cardColor,
        //                             )),
        //                       ),
        //                     ),
        //                   ),
        //                 ),
        //               ),
        //             ])
        //           : SizedBox(),
        //       )
        //     : null,

        body: Stack(children: [
          Column(children: [
            cart.isLoading
                ? Padding(
                    padding: const EdgeInsets.only(top: 200.0),
                    child:Center(child: CupertinoActivityIndicator(radius: 25.0
                        , color: ColorResources.primaryColor,
                        animating: true))
                  )
                : sellerList.length != 0
                    ? Expanded(
                        child: Container(
                          child: Padding(
                            padding: const EdgeInsets.only(top: 15.0 ,left:15  ,right:15 ),
                            child: SingleChildScrollView(
                              child: Column(
                                children: [
                                  Container(
                                      height: 150,
                                      width: MediaQuery.of(context).size.width,
                                      //padding: EdgeInsets.all(Dimensions.HOME_PAGE_PADDING),
                                      decoration: BoxDecoration(
                                        color: Theme.of(context).highlightColor,
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(20)),
                                        border: Border.all(
                                            width: 0.5,
                                            color:Colors.grey.withOpacity(0.5)),
                                      ),
                                      child: Padding(
                                        padding: const EdgeInsets.all(0.0),
                                        child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.stretch,
                                            children: [
                                              Padding(
                                                padding:
                                                    const EdgeInsets.all(8.0),
                                                child: Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .spaceBetween,
                                                    mainAxisSize:
                                                        MainAxisSize.min,
                                                    children: [
                                                      Text(
                                                          getTranslated(
                                                              'itemTotalPrice',
                                                              context),
                                                          textAlign:
                                                              TextAlign.end,
                                                          style: titilliumsemiBold
                                                              .copyWith(
                                                            fontSize: Dimensions
                                                                .FONT_SIZE_EXTRA_SMALL,
                                                          )),
                                                      Text(
                                                        PriceConverter.convertPrice(
                                                            context,
                                                            amount ),
                                                        style: titilliumsemiBold
                                                            .copyWith(
                                                                color: Theme.of(
                                                                        context)
                                                                    .primaryColor,
                                                                fontSize: Dimensions
                                                                    .FONT_SIZE_EXTRA_SMALL),
                                                      ),
                                                    ]),
                                              ),
                                              Padding(
                                                padding:
                                                    const EdgeInsets.all(8.0),
                                                child: Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .spaceBetween,
                                                    mainAxisSize:
                                                        MainAxisSize.min,
                                                    children: [
                                                      Text("رسوم التوصيل",
                                                          textAlign:
                                                              TextAlign.end,
                                                          style: titilliumsemiBold
                                                              .copyWith(
                                                            fontSize: Dimensions
                                                                .FONT_SIZE_EXTRA_SMALL,
                                                          )),
                                                      Text(
                                                        PriceConverter
                                                            .convertPrice(context,
                                                                shippingAmount),
                                                        style: titilliumsemiBold
                                                            .copyWith(
                                                                color: Theme.of(
                                                                        context)
                                                                    .primaryColor,
                                                                fontSize: Dimensions
                                                                    .FONT_SIZE_EXTRA_SMALL),
                                                      ),
                                                    ]),
                                              ),
                                              Expanded(
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                    color: Color(0xfff2f2f2),
                                                    borderRadius:
                                                        BorderRadius.only(
                                                            bottomRight:
                                                                Radius.circular(
                                                                    15),
                                                            bottomLeft:
                                                                Radius.circular(
                                                                    15)),
                                                    border: Border.all(
                                                        width: 0.5,
                                                        color: Color(0xfff2f2f2)),
                                                  ),
                                                  // color: Color(0xfff2f2f2),
                                                  child: Padding(
                                                    padding:
                                                        const EdgeInsets.all(8.0),
                                                    child: Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .spaceBetween,
                                                        mainAxisSize:
                                                            MainAxisSize.min,
                                                        children: [
                                                          Text("الاجمالي",
                                                              textAlign:
                                                                  TextAlign.end,
                                                              style:
                                                                  titilliumvBold
                                                                      .copyWith(
                                                                fontSize: Dimensions
                                                                    .FONT_SIZE_SMALL,
                                                              )),
                                                          Text(
                                                            PriceConverter
                                                                .convertPrice(
                                                                    context,
                                                                    amount+shippingAmount),
                                                            style: titilliumsemiBold.copyWith(
                                                                color: Theme.of(
                                                                        context)
                                                                    .primaryColor,
                                                                fontSize: Dimensions
                                                                    .FONT_SIZE_SMALL),
                                                          ),
                                                        ]),
                                                  ),
                                                ),
                                              ),
                                            ]),
                                      )),
                                  SizedBox(
                                    height: 15,
                                  ),
                                  Container(
                                    padding: EdgeInsets.only(left: 5, right: 5),
                                    height: 65,
                                    decoration: BoxDecoration(
                                      color:ColorResources.white,
                                      borderRadius:
                                          BorderRadius.all(Radius.circular(15)),
                                      border: Border.all(
                                          width: 0.5, color: Colors.grey.withOpacity(0.5)),
                                    ),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                          "عندك كود خصم ؟ وفر زود",
                                          style: titilliumsemiBold.copyWith(
                                            fontSize:
                                                Dimensions.FONT_SIZE_SMALL,
                                          ),
                                        ),
                                        Container(
                                          width: 70,
                                          decoration: BoxDecoration(
                                            gradient: LinearGradient(
                                              begin: Alignment.topRight,
                                              end: Alignment.bottomLeft,
                                              colors: [
                                                Color(0xff53d997),
                                                Color(0xff33d6af),
                                              ],
                                            ),
                                            //color: Color(0xfff2f2f2),
                                            borderRadius: BorderRadius.all(
                                                Radius.circular(15)),
                                            border: Border.all(
                                                width: 0.5,
                                                color: Color(0xfff2f2f2)),
                                          ),
                                          child: Row(
                                            children: [
                                              Icon(
                                                Icons.add,
                                                color: Colors.white,
                                              ),
                                              InkWell(
                                                  onTap: () {
                                                    showModalBottomSheet(
                                                        context: context,
                                                        isScrollControlled:
                                                            true,
                                                        shape: RoundedRectangleBorder(
                                                            borderRadius:
                                                                BorderRadius.vertical(
                                                                    top: Radius
                                                                        .circular(
                                                                            50))),
                                                        builder:
                                                            (context) =>
                                                                Padding(
                                                                  padding: MediaQuery.of(
                                                                          context)
                                                                      .viewInsets,
                                                                  child:
                                                                      Container(
                                                                    padding:
                                                                        EdgeInsets.all(
                                                                            15),
                                                                    width: double
                                                                        .infinity,
                                                                    height: 230,
                                                                    child:
                                                                        Column(
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .center,
                                                                      //mainAxisAlignment: MainAxisAlignment.center,
                                                                      children: [
                                                                        Text(
                                                                            "أدخل كود الخصم",
                                                                            style:
                                                                                titilliumvBold.copyWith(fontSize: Dimensions.FONT_SIZE_LARGE, color: Colors.black),
                                                                            textAlign: TextAlign.center),
                                                                        SizedBox(
                                                                          height:
                                                                              3,
                                                                        ),
                                                                        Text(
                                                                            "قم بادخال كود الخصم للحصول على العرض",
                                                                            style:
                                                                                titilliumsemiBold.copyWith(fontSize: Dimensions.FONT_SIZE_DEFAULT, color: Colors.black.withOpacity(0.35))),
                                                                        SizedBox(
                                                                          height:
                                                                              3,
                                                                        ),
                                                                        validCopoun?
                                                                        Text(
                                                                            "كود صحيح",
                                                                            style:
                                                                            titilliumsemiBold.copyWith(fontSize: Dimensions.FONT_SIZE_SMALL, color: Colors.green.withOpacity(0.7))):
                                                                        Text(
                                                                            "كود خاطئ",
                                                                            style:
                                                                                titilliumsemiBold.copyWith(fontSize: Dimensions.FONT_SIZE_SMALL, color: Colors.red.withOpacity(0.7))),
                                                                        Padding(
                                                                          padding:
                                                                              const EdgeInsets.all(8.0),
                                                                          child:
                                                                              Row(
                                                                            children: [
                                                                              Expanded(
                                                                                flex: 2,
                                                                                child: Container(
                                                                                    height: 55,
                                                                                    decoration: BoxDecoration(
                                                                                      color: Colors.grey.withOpacity(0.1),
                                                                                      borderRadius: BorderRadius.circular(30),
                                                                                      border: Border.all(width: .4, color: Colors.grey.withOpacity(0.3)),
                                                                                      // boxShadow: [BoxShadow(color: Colors.grey, spreadRadius: 1, blurRadius: 1)],
                                                                                    ),
                                                                                    alignment: Alignment.centerLeft,
                                                                                    padding: EdgeInsets.symmetric(horizontal: 15),
                                                                                    child: TextField(
                                                                                    //  autofocus: true,
                                                                                      controller: _copounController,
                                                                                      onChanged: (text){
                                                                                        if (_copounController.text.isEmpty ||
                                                                                            _copounController.text.isEmpty) {
                                                                                          enable = false;
                                                                                        } else {
                                                                                          enable = true;
                                                                                        }
                                                                                        setState(() {});
                                                                                      },
                                                                                      textAlign: TextAlign.center,
                                                                                      style: titilliumRegular.copyWith(color: Colors.black, fontSize: 11),
                                                                                      keyboardType: TextInputType.text,
                                                                                      maxLines: 1,
                                                                                      decoration: InputDecoration(
                                                                                        hintText: "ادخل كود الخصم هنا",
                                                                                        hintStyle: titilliumRegular.copyWith(color: Colors.grey, fontSize: 13),
                                                                                        border: InputBorder.none,
                                                                                      ),
                                                                                    )),
                                                                              ),
                                                                              SizedBox(
                                                                                width: 10,
                                                                              ),
                                                                              Expanded(
                                                                                child: Container(
                                                                                  width: 150,
                                                                                  height: 35,
                                                                                  decoration: BoxDecoration(

                                                                                    color:   enable?
                                                                                    Theme.of(context).primaryColor:Colors.grey.withOpacity(0.5),
                                                                                    borderRadius: BorderRadius.circular(30),
                                                                                    border: Border.all(width: .4, color:
                                                                                    enable?
                                                                                    Theme.of(context).primaryColor:
                                                                                    Colors.grey.withOpacity(0.5),

                                                                                    ),
                                                                                    // boxShadow: [BoxShadow(color: Colors.grey, spreadRadius: 1, blurRadius: 1)],
                                                                                  ),
                                                                                  child: !Provider.of<CouponProvider>(context).isLoading
                                                                                      ? MaterialButton(
                                                                                          onPressed: () {
                                                                                            if (_copounController.text.isNotEmpty) {
                                                                                              Provider.of<CouponProvider>(context, listen: false).initCoupon(_copounController.text, _order).then((value) {
                                                                                                if (value > 0) {
                                                                                                  validCopoun=true;
                                                                                                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('لقد حصلت على ${PriceConverter.convertPrice(context, value)} تخفيض'), backgroundColor: Colors.green));
                                                                                                setState(() {

                                                                                                });
                                                                                                } else {
                                                                                                  validCopoun=false;
                                                                                                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                                                                                    content: Text(getTranslated('invalid_coupon_or', context)),
                                                                                                    backgroundColor: Colors.red,

                                                                                                  )
                                                                                                  );
                                                                                                  setState(() {

                                                                                                  });
                                                                                                }
                                                                                              });
                                                                                            }
                                                                                          },
                                                                                          child: Text("تفعيل", style: titilliumsemiBold.copyWith(color: Colors.white)),
                                                                                        )
                                                                                      : CircularProgressIndicator(valueColor: AlwaysStoppedAnimation<Color>(Theme.of(context).primaryColor)),
                                                                                ),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ));
                                                  },
                                                  child: Text("اضف",
                                                      style: titilliumvBold.copyWith(
                                                          fontSize: Dimensions
                                                              .FONT_SIZE_SMALL,
                                                          color: Colors.white)))
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),

                                  SizedBox(height: 10,),
                                  RefreshIndicator(
                                    onRefresh: () async {
                                      if (Provider.of<AuthProvider>(context,
                                              listen: false)
                                          .isLoggedIn()) {
                                        await Provider.of<CartProvider>(context,
                                                listen: false)
                                            .getCartDataAPI(context);
                                      }
                                    },
                                    child: ListView.builder(
                                      shrinkWrap: true,
                                      physics: NeverScrollableScrollPhysics(),
                                      itemCount: sellerList.length,
                                      padding: EdgeInsets.all(0),
                                      itemBuilder: (context, index) {
                                        return Padding(
                                          padding: EdgeInsets.only(
                                              bottom: Dimensions
                                                  .PADDING_SIZE_SMALL),
                                          child: Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              SizedBox(
                                                  height: Dimensions
                                                      .PADDING_SIZE_SMALL),
                                              Row(
                                                children: [
                                                  Text('تفاصيل السله',
                                                      textAlign:
                                                          TextAlign.start,
                                                      style: titilliumvBold
                                                          .copyWith(
                                                        fontSize: Dimensions
                                                            .FONT_SIZE_SMALL,
                                                      )),
                                                  SizedBox(
                                                    width: 3,
                                                  ),
                                                  Text(
                                                      cartProductList[index]
                                                              .length
                                                              .toString() +
                                                          " منتج",
                                                      style: titilliumvBold.copyWith(
                                                          fontSize: Dimensions
                                                              .FONT_SIZE_EXTRA_SMALLest,
                                                          color: Colors.grey
                                                              .withOpacity(
                                                                  0.60))),
                                                ],
                                              ),
                                              SizedBox(height: 10,),
                                              ListView.separated(
                                                separatorBuilder:
                                                    (BuildContext context,
                                                        int index) {
                                                  return Divider(
                                                    color: Colors.grey
                                                        .withOpacity(0.65),
                                                  );
                                                },
                                                physics:
                                                    NeverScrollableScrollPhysics(),
                                                shrinkWrap: true,
                                                padding: EdgeInsets.all(0),
                                                itemCount:
                                                    cartProductList[index]
                                                        .length,
                                                itemBuilder: (context, i) {
                                                  return CartWidget(
                                                    cartModel:
                                                        cartProductList[index]
                                                            [i],
                                                    index: cartProductIndexList[
                                                        index][i],
                                                    fromCheckout:
                                                        widget.fromCheckout,
                                                  );
                                                },
                                              ),

                                              //Provider.of<SplashProvider>(context,listen: false).configModel.shippingMethod =='sellerwise_shipping'?
                                              Provider.of<SplashProvider>(
                                                                  context,
                                                                  listen: false)
                                                              .configModel
                                                              .shippingMethod ==
                                                          'sellerwise_shipping' &&
                                                      sellerGroupList[index]
                                                              .shippingType ==
                                                          'order_wise'
                                                  ?
                                                  // Padding(
                                                  //   padding: const EdgeInsets.symmetric(horizontal: Dimensions.PADDING_SIZE_DEFAULT),
                                                  //   child: InkWell(
                                                  //     onTap: () {
                                                  //       if(Provider.of<AuthProvider>(context, listen: false).isLoggedIn()) {
                                                  //         showModalBottomSheet(
                                                  //           context: context, isScrollControlled: true, backgroundColor: Colors.transparent,
                                                  //           builder: (context) => ShippingMethodBottomSheet(groupId: sellerGroupList[index].cartGroupId,sellerIndex: index, sellerId: sellerGroupList[index].id),
                                                  //         );
                                                  //       }else {
                                                  //         showCustomSnackBar('not_logged_in', context);
                                                  //       }
                                                  //     },
                                                  //
                                                  //
                                                  //     child: Container(
                                                  //       decoration: BoxDecoration(
                                                  //         border: Border.all(width: 0.5,color: Colors.grey),
                                                  //         borderRadius: BorderRadius.all(Radius.circular(10)),
                                                  //       ),
                                                  //       child: Padding(
                                                  //         padding: const EdgeInsets.all(8.0),
                                                  //         child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                                                  //           Text(getTranslated('SHIPPING_PARTNER', context), style: titilliumRegular),
                                                  //           Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                                                  //             Text(
                                                  //               (cart.shippingList == null || cart.shippingList[index].shippingMethodList == null || cart.chosenShippingList.length == 0 || cart.shippingList[index].shippingIndex == -1) ? ''
                                                  //                   : '${cart.shippingList[index].shippingMethodList[cart.shippingList[index].shippingIndex].title.toString()}',
                                                  //               style: titilliumSemiBold.copyWith(color: ColorResources.getPrimary(context)),
                                                  //               maxLines: 1,
                                                  //               overflow: TextOverflow.ellipsis,
                                                  //             ),
                                                  //             SizedBox(width: Dimensions.PADDING_SIZE_EXTRA_SMALL),
                                                  //             Icon(Icons.keyboard_arrow_down, color: Theme.of(context).primaryColor),
                                                  //           ]),
                                                  //         ]),
                                                  //       ),
                                                  //     ),
                                                  //   )
                                                  //   ,
                                                  // ) :SizedBox(),
                                                  SizedBox()
                                                  : SizedBox()
                                            ],
                                          ),
                                        );
                                      },
                                    ),
                                  ),
                                  Provider.of<SplashProvider>(context,
                                                      listen: false)
                                                  .configModel
                                                  .shippingMethod !=
                                              'sellerwise_shipping' &&
                                          Provider.of<SplashProvider>(context,
                                                      listen: false)
                                                  .configModel
                                                  .inHouseSelectedShippingType ==
                                              'order_wise'
                                      ? InkWell(
                                          onTap: () {
                                            if (Provider.of<AuthProvider>(
                                                    context,
                                                    listen: false)
                                                .isLoggedIn()) {
                                              showModalBottomSheet(
                                                context: context,
                                                isScrollControlled: true,
                                                backgroundColor:
                                                    Colors.transparent,
                                                builder: (context) =>
                                                    ShippingMethodBottomSheet(
                                                        groupId:
                                                            'all_cart_group',
                                                        sellerIndex: 0,
                                                        sellerId: 1),
                                              );
                                            } else {
                                              showCustomSnackBar(
                                                  'not_logged_in', context);
                                            }
                                          },
                                          child: Container(
                                            decoration: BoxDecoration(
                                              border: Border.all(
                                                  width: 0.5,
                                                  color: Colors.grey),
                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(10)),
                                            ),
                                            child: Padding(
                                              padding:
                                                  const EdgeInsets.all(8.0),
                                              child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: [
                                                    Text(
                                                        getTranslated(
                                                            'SHIPPING_PARTNER',
                                                            context),
                                                        style:
                                                            titilliumRegular),
                                                    Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .end,
                                                        children: [
                                                          Text(
                                                            (cart.shippingList ==
                                                                        null ||
                                                                    cart.chosenShippingList
                                                                            .length ==
                                                                        0 ||
                                                                    cart.shippingList
                                                                            .length ==
                                                                        0 ||
                                                                    cart.shippingList[0].shippingMethodList ==
                                                                        null ||
                                                                    cart.shippingList[0]
                                                                            .shippingIndex ==
                                                                        -1)
                                                                ? ''
                                                                : '${cart.shippingList[0].shippingMethodList[cart.shippingList[0].shippingIndex].title.toString()}',
                                                            style: titilliumsemiBold.copyWith(
                                                                color: ColorResources
                                                                    .getPrimary(
                                                                        context)),
                                                            maxLines: 1,
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                          ),
                                                          SizedBox(
                                                              width: Dimensions
                                                                  .PADDING_SIZE_EXTRA_SMALL),
                                                          Icon(
                                                              Icons
                                                                  .keyboard_arrow_down,
                                                              color: Theme.of(
                                                                      context)
                                                                  .primaryColor),
                                                        ]),
                                                  ]),
                                            ),
                                          ),
                                        )
                                      : SizedBox(),
                                ],
                              ),
                            ),
                          ),
                        ),
                      )
                    : Expanded(child: NoOrderInCartScreen(isNoInternet: false)),
            SizedBox(
              height: 50,
            )
          ]),
          sellerList.length != 0?
          Positioned(
            bottom: 5,
            left: 15,
            right: 15,
            child: Container(
              height: 90,
              padding: EdgeInsets.all(15),
              width: 350,
              child: FloatingActionButton(
                backgroundColor: Theme.of(context).primaryColor,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(Radius.circular(30.0))),
                onPressed: () async{

                  if(isDocComplete == 1){  if (Provider.of<AuthProvider>(context, listen: false)
                      .isLoggedIn()) {
                    if (cart.cartList.length == 0) {
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        content: Text(getTranslated(
                            'select_at_least_one_product', context)),
                        backgroundColor: Colors.red,
                      ));
                    }

                    // else if(cart.chosenShippingList.length < orderTypeShipping.length && Provider.of<SplashProvider>(context,listen: false).configModel.shippingMethod =='sellerwise_shipping'){
                    //   ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(getTranslated('select_all_shipping_method', context)), backgroundColor: Colors.red));
                    // } else if(cart.chosenShippingList.length < 1 && Provider.of<SplashProvider>(context,listen: false).configModel.shippingMethod !='sellerwise_shipping' && Provider.of<SplashProvider>(context,listen: false).configModel.inHouseSelectedShippingType =='order_wise'){
                    //   ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(getTranslated('select_all_shipping_method', context)), backgroundColor: Colors.red));
                    // }


                    else {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => CheckoutScreen(
                                cartList: cartList,
                                amount: amount,
                                shippingAmount: shippingAmount,
                                discount: discount,
                                tax: tax,
                                cartProductList:cartProductList,
                                fromCheckout: widget.fromCheckout,
                                sellerList: sellerList,
                                cartProductIndexList:cartProductIndexList,
                                sellerGroupList: sellerGroupList,                                  )));
                      // showModalBottomSheet(
                      //     context: context,
                      //     isScrollControlled:
                      //     true,
                      //     shape: RoundedRectangleBorder(
                      //         borderRadius:
                      //         BorderRadius.vertical(
                      //             top: Radius
                      //                 .circular(
                      //                 50))),
                      //     builder:
                      //         (context) =>
                      //         Container(
                      //           padding:
                      //           EdgeInsets.all(
                      //               15),
                      //           width: 100,
                      //           height: 500,
                      //           child:
                      //           Stack(
                      //             children: [
                      //               Positioned(
                      //                 right: 140,
                      //                 //top: 220,
                      //                 child: Container(
                      //
                      //                   width: 60,
                      //                   height: 20,
                      //                   decoration: BoxDecoration(
                      //                     color: Colors.transparent,
                      //                     borderRadius: BorderRadius.circular(10),
                      //                     border: Border.all(width: .4,color: Colors.white),
                      //                     // boxShadow: [BoxShadow(color: Colors.grey, spreadRadius: 1, blurRadius: 1)],
                      //                   ),
                      //                   child: DefaultTextStyle(
                      //                     style:titilliumvBold.copyWith(fontSize: 10,color: Colors.white),
                      //                     child: Text("اغلاق",textAlign:TextAlign.center),),),),
                      //               Column(
                      //                // mainAxisSize: MainAxisSize.min,
                      //                 crossAxisAlignment:
                      //                 CrossAxisAlignment
                      //                     .center,
                      //                 //mainAxisAlignment: MainAxisAlignment.center,
                      //                 children: [
                      //                   Expanded(
                      //                     flex:3,
                      //                     child: SvgPicture.asset(
                      //                        "assets/svg/auth.svg", height: 190,width:190
                      //                       ,),
                      //                   ),
                      //
                      //                   Text(
                      //                       "عليك استكمال عمليه التسجيل",
                      //                       style:
                      //                       titilliumvBold.copyWith(fontSize: Dimensions.FONT_SIZE_LARGE, color: Colors.black),
                      //                       textAlign: TextAlign.center),
                      //                   // SizedBox(
                      //                   //   height:
                      //                   //   3,
                      //                   // ),
                      //                   Text(
                      //                       "الرجاء استكمال عمليه التسجيل حتي تستطيع القيام بالطلب من التطبيق",textAlign: TextAlign.center,
                      //                       style:
                      //                       titilliumsemiBold.copyWith(fontSize: Dimensions.FONT_SIZE_DEFAULT, color: Colors.black.withOpacity(0.35))),
                      //                   // SizedBox(
                      //                   //   height:
                      //                   //   3,
                      //                   // ),
                      //                    Expanded(
                      //                     child: Padding(
                      //                       padding:
                      //                       const EdgeInsets.all(8.0),
                      //                       child:
                      //                       Column(
                      //                         children: [
                      //
                      //                           Expanded(
                      //                             child: Container(
                      //                               width: double.infinity,
                      //                               height: 35,
                      //                               decoration: BoxDecoration(
                      //
                      //                                 color:
                      //                                 Theme.of(context).primaryColor,
                      //                                 borderRadius: BorderRadius.circular(30),
                      //                                 border: Border.all(width: .4, color:
                      //
                      //                                 Theme.of(context).primaryColor,
                      //
                      //                                 ),
                      //                                 // boxShadow: [BoxShadow(color: Colors.grey, spreadRadius: 1, blurRadius: 1)],
                      //                               ),
                      //                               child: !Provider.of<CouponProvider>(context).isLoading
                      //                                   ? MaterialButton(
                      //                                 onPressed: () {
                      //
                      //                                 },
                      //                                 child: Text("استكمال التسجيل", style: titilliumsemiBold.copyWith(color: Colors.white,fontSize: 17)),
                      //                               )
                      //                                   : CircularProgressIndicator(valueColor: AlwaysStoppedAnimation<Color>(Theme.of(context).primaryColor)),
                      //                             ),
                      //                       ),
                      //                             Expanded(
                      //                               child: Container(
                      //                                 width: double.infinity,
                      //                                 height: 35,
                      //                                 decoration: BoxDecoration(
                      //
                      //                                   color:
                      //                                  Colors.transparent,
                      //                                   borderRadius: BorderRadius.circular(30),
                      //                                   border: Border.all(width: .4, color:
                      //
                      //                                 Colors.white,
                      //
                      //                                   ),
                      //                                   // boxShadow: [BoxShadow(color: Colors.grey, spreadRadius: 1, blurRadius: 1)],
                      //                                 ),
                      //                                 child: !Provider.of<CouponProvider>(context).isLoading
                      //                                     ? MaterialButton(
                      //                                   onPressed: () {
                      //
                      //                                   },
                      //                                   child: Text("لا شكرا تصفح التطبيق", style: titilliumsemiBold.copyWith(color: Colors.black,fontSize: 17)),
                      //                                 )
                      //                                     : CircularProgressIndicator(valueColor: AlwaysStoppedAnimation<Color>(Theme.of(context).primaryColor)),
                      //                               ),
                      //                             ),
                      //
                      //                         ],
                      //                       ),
                      //                     ),
                      //                   ),
                      //                 ],
                      //               ),
                      //             ],
                      //           ),
                      //         ));
                    }
                  } else {
                    showAnimatedDialog(context, GuestDialog(), isFlip: true);
                  }}

                      else if(   isDocRequest == 1){  if (Provider.of<AuthProvider>(context, listen: false)
                      .isLoggedIn()) {
                    if (cart.cartList.length == 0) {
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        content: Text(getTranslated(
                            'select_at_least_one_product', context)),
                        backgroundColor: Colors.red,
                      ));
                    }

                    // else if(cart.chosenShippingList.length < orderTypeShipping.length && Provider.of<SplashProvider>(context,listen: false).configModel.shippingMethod =='sellerwise_shipping'){
                    //   ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(getTranslated('select_all_shipping_method', context)), backgroundColor: Colors.red));
                    // } else if(cart.chosenShippingList.length < 1 && Provider.of<SplashProvider>(context,listen: false).configModel.shippingMethod !='sellerwise_shipping' && Provider.of<SplashProvider>(context,listen: false).configModel.inHouseSelectedShippingType =='order_wise'){
                    //   ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(getTranslated('select_all_shipping_method', context)), backgroundColor: Colors.red));
                    // }


                    else {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => CheckoutScreen(
                                cartList: cartList,
                                amount: amount,
                                shippingAmount: shippingAmount,
                                discount: discount,
                                tax: tax,
                                cartProductList:cartProductList,
                                fromCheckout: widget.fromCheckout,
                                sellerList: sellerList,
                                cartProductIndexList:cartProductIndexList,
                                sellerGroupList: sellerGroupList,                                  )));
                      // showModalBottomSheet(
                      //     context: context,
                      //     isScrollControlled:
                      //     true,
                      //     shape: RoundedRectangleBorder(
                      //         borderRadius:
                      //         BorderRadius.vertical(
                      //             top: Radius
                      //                 .circular(
                      //                 50))),
                      //     builder:
                      //         (context) =>
                      //         Container(
                      //           padding:
                      //           EdgeInsets.all(
                      //               15),
                      //           width: 100,
                      //           height: 500,
                      //           child:
                      //           Stack(
                      //             children: [
                      //               Positioned(
                      //                 right: 140,
                      //                 //top: 220,
                      //                 child: Container(
                      //
                      //                   width: 60,
                      //                   height: 20,
                      //                   decoration: BoxDecoration(
                      //                     color: Colors.transparent,
                      //                     borderRadius: BorderRadius.circular(10),
                      //                     border: Border.all(width: .4,color: Colors.white),
                      //                     // boxShadow: [BoxShadow(color: Colors.grey, spreadRadius: 1, blurRadius: 1)],
                      //                   ),
                      //                   child: DefaultTextStyle(
                      //                     style:titilliumvBold.copyWith(fontSize: 10,color: Colors.white),
                      //                     child: Text("اغلاق",textAlign:TextAlign.center),),),),
                      //               Column(
                      //                // mainAxisSize: MainAxisSize.min,
                      //                 crossAxisAlignment:
                      //                 CrossAxisAlignment
                      //                     .center,
                      //                 //mainAxisAlignment: MainAxisAlignment.center,
                      //                 children: [
                      //                   Expanded(
                      //                     flex:3,
                      //                     child: SvgPicture.asset(
                      //                        "assets/svg/auth.svg", height: 190,width:190
                      //                       ,),
                      //                   ),
                      //
                      //                   Text(
                      //                       "عليك استكمال عمليه التسجيل",
                      //                       style:
                      //                       titilliumvBold.copyWith(fontSize: Dimensions.FONT_SIZE_LARGE, color: Colors.black),
                      //                       textAlign: TextAlign.center),
                      //                   // SizedBox(
                      //                   //   height:
                      //                   //   3,
                      //                   // ),
                      //                   Text(
                      //                       "الرجاء استكمال عمليه التسجيل حتي تستطيع القيام بالطلب من التطبيق",textAlign: TextAlign.center,
                      //                       style:
                      //                       titilliumsemiBold.copyWith(fontSize: Dimensions.FONT_SIZE_DEFAULT, color: Colors.black.withOpacity(0.35))),
                      //                   // SizedBox(
                      //                   //   height:
                      //                   //   3,
                      //                   // ),
                      //                    Expanded(
                      //                     child: Padding(
                      //                       padding:
                      //                       const EdgeInsets.all(8.0),
                      //                       child:
                      //                       Column(
                      //                         children: [
                      //
                      //                           Expanded(
                      //                             child: Container(
                      //                               width: double.infinity,
                      //                               height: 35,
                      //                               decoration: BoxDecoration(
                      //
                      //                                 color:
                      //                                 Theme.of(context).primaryColor,
                      //                                 borderRadius: BorderRadius.circular(30),
                      //                                 border: Border.all(width: .4, color:
                      //
                      //                                 Theme.of(context).primaryColor,
                      //
                      //                                 ),
                      //                                 // boxShadow: [BoxShadow(color: Colors.grey, spreadRadius: 1, blurRadius: 1)],
                      //                               ),
                      //                               child: !Provider.of<CouponProvider>(context).isLoading
                      //                                   ? MaterialButton(
                      //                                 onPressed: () {
                      //
                      //                                 },
                      //                                 child: Text("استكمال التسجيل", style: titilliumsemiBold.copyWith(color: Colors.white,fontSize: 17)),
                      //                               )
                      //                                   : CircularProgressIndicator(valueColor: AlwaysStoppedAnimation<Color>(Theme.of(context).primaryColor)),
                      //                             ),
                      //                       ),
                      //                             Expanded(
                      //                               child: Container(
                      //                                 width: double.infinity,
                      //                                 height: 35,
                      //                                 decoration: BoxDecoration(
                      //
                      //                                   color:
                      //                                  Colors.transparent,
                      //                                   borderRadius: BorderRadius.circular(30),
                      //                                   border: Border.all(width: .4, color:
                      //
                      //                                 Colors.white,
                      //
                      //                                   ),
                      //                                   // boxShadow: [BoxShadow(color: Colors.grey, spreadRadius: 1, blurRadius: 1)],
                      //                                 ),
                      //                                 child: !Provider.of<CouponProvider>(context).isLoading
                      //                                     ? MaterialButton(
                      //                                   onPressed: () {
                      //
                      //                                   },
                      //                                   child: Text("لا شكرا تصفح التطبيق", style: titilliumsemiBold.copyWith(color: Colors.black,fontSize: 17)),
                      //                                 )
                      //                                     : CircularProgressIndicator(valueColor: AlwaysStoppedAnimation<Color>(Theme.of(context).primaryColor)),
                      //                               ),
                      //                             ),
                      //
                      //                         ],
                      //                       ),
                      //                     ),
                      //                   ),
                      //                 ],
                      //               ),
                      //             ],
                      //           ),
                      //         ));
                    }
                  } else {
                    showAnimatedDialog(context, GuestDialog(), isFlip: true);
                  }}
                  else {

                    await showModalBottomSheet(
                      context: context, isScrollControlled: true, backgroundColor: Colors.transparent,
                      builder: (context) => CartBottomSheet(groupId: 'all_cart_group',sellerIndex: 0, sellerId: 1),
                    );



                  }







                },
                child: Padding(
                  padding: const EdgeInsets.only(left: 15, right: 15),
                  child: Row(
                    // mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Expanded(
                          child: Text(
                        "الذهاب للدفع",
                        style: titilliumvBold.copyWith(
                          fontSize: 17,
                          color: Colors.white,
                        ),
                        textAlign: TextAlign.center,
                      )),
                      Icon(
                        Icons.arrow_forward_sharp,
                        color: Colors.white,
                        size: 25,
                      )
                    ],
                  ),
                ),
              ),
            ),
          ) :SizedBox()
        ]),
      );
    });
  }
}
