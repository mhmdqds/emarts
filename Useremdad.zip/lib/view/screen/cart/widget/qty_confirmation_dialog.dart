import 'package:emdad/data/model/response/cart_model.dart';
import 'package:emdad/provider/cart_provider.dart';
import 'package:flutter/material.dart';
import 'package:emdad/localization/language_constrants.dart';
import 'package:emdad/utility/color_resources.dart';
import 'package:emdad/utility/custom_themes.dart';
import 'package:emdad/utility/dimensions.dart';
import 'package:provider/provider.dart';

class QuantityConfirmationDialog extends StatelessWidget {
  final quantityItem;
  final CartModel cartModel;
  final bool isIncrement;
  final int quantity;
  final int index;
  final int maxQty;
  
  QuantityConfirmationDialog({@required this.quantityItem, @required this.isIncrement, @required this.quantity, @required this.index, @required this.maxQty,@required this.cartModel});

  final TextEditingController _quantityController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
      child: Column(mainAxisSize: MainAxisSize.min, children: [

        Padding(
          padding: EdgeInsets.only(left: 10,right: 10,top: 10),

          child: Text('أدخل الكميه', style: titilliumvBold.copyWith(fontSize: Dimensions.FONT_SIZE_LARGE,color: Colors.black.withOpacity(0.67)), textAlign: TextAlign.center),
        ),
        Text('دخل الكميه اللي تبي تحطها بالسله', style: titilliumvBold.copyWith(fontSize: Dimensions.FONT_SIZE_SMALL,color: Colors.black.withOpacity(0.60))),
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 40, vertical: 20),
          child:  Row(
            children: <Widget>[

              Expanded(flex: 4,
                child: Container( height: 55,
                  decoration: BoxDecoration(
                    color: Colors.grey.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(30),
                    border: Border.all(width: .4,color: Colors.grey.withOpacity(0.3)),
                   // boxShadow: [BoxShadow(color: Colors.grey, spreadRadius: 1, blurRadius: 1)],
                  ),
                  alignment: Alignment.centerLeft,
                  padding: EdgeInsets.symmetric(horizontal: 5),
                  child: TextField(
                  controller: _quantityController,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 20.0,
                    ),
                  keyboardType: TextInputType.number,
                  maxLines: 1,
                  decoration: InputDecoration(
                    hintText: quantity.toString(),
                    hintStyle: titilliumRegular.copyWith(color: Colors.black, fontSize: 18),
                    border: InputBorder.none,
                  ),
                      )
                ),
              ),
            ],
          ),
        ),

        Padding(
          padding: EdgeInsets.symmetric(horizontal: 40, vertical: 20),
          child: Column(
            children: [
              Container(
                width: double.infinity,
                  height: 35,
                decoration: BoxDecoration(
                  color: Theme.of(context).primaryColor,
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(width: .4,color: Theme.of(context).primaryColor),
                  // boxShadow: [BoxShadow(color: Colors.grey, spreadRadius: 1, blurRadius: 1)],
                ),
                child: MaterialButton(
                 onPressed: (){
                   Provider.of<CartProvider>(context, listen: false).updateCartProductQuantity(cartModel.id, int.parse(_quantityController.text), context).then((value) {
                     ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                       content: Text(value.message), backgroundColor: value.isSuccess ? Colors.green : Colors.red,
                     ));
                   });
                   Navigator.pop(context);
                 },
                  child:Text(getTranslated('set_quantity', context),
                      style: titilliumBold.copyWith(color: Colors.white)) ,

                 ),
              ),
              SizedBox(height: 6,),
              InkWell(
                onTap: () => Navigator.pop(context),
                child: Text("تخطى",textAlign: TextAlign.center, style: titilliumBold.copyWith(color: Colors.grey.withOpacity(.8))),
              ),


            ],

          ),
        )
        // ,Divider(height: 0, color: ColorResources.HINT_TEXT_COLOR),
        // Row(children: [
        //
        //   Expanded(child: InkWell(
        //     onTap: () {
        //       Provider.of<CartProvider>(context, listen: false).updateCartProductQuantity(cartModel.id, int.parse(_quantityController.text), context).then((value) {
        //         ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        //           content: Text(value.message), backgroundColor: value.isSuccess ? Colors.green : Colors.red,
        //         ));
        //       });
        //       Navigator.pop(context);
        //     },
        //     child: Container(
        //       padding: EdgeInsets.all(Dimensions.PADDING_SIZE_SMALL),
        //       alignment: Alignment.center,
        //       decoration: BoxDecoration(borderRadius: BorderRadius.only(bottomLeft: Radius.circular(10))),
        //       child: Text(getTranslated('set_quantity', context),
        //           style: titilliumBold.copyWith(color: Theme.of(context).primaryColor)),
        //     ),
        //   )),
        //
        //   Expanded(child: InkWell(
        //     onTap: () => Navigator.pop(context),
        //     child: Container(
        //       padding: EdgeInsets.all(Dimensions.PADDING_SIZE_SMALL),
        //       alignment: Alignment.center,
        //       decoration: BoxDecoration(color: ColorResources.RED, borderRadius: BorderRadius.only(bottomRight: Radius.circular(10))),
        //       child: Text(getTranslated('cancel', context), style: titilliumBold.copyWith(color: ColorResources.WHITE)),
        //     ),
        //   )),
        //
        // ]),
      ]),
    );
  }
}
