class ChooseCategoryModel {
  String imageUrl;
  String name;
  bool isSelect;

  ChooseCategoryModel({this.imageUrl, this.name, this.isSelect = false});
}
