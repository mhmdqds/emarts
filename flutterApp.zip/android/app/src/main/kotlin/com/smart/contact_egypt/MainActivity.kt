package com.smart.emarat

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
