import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:contact_egypt/data/model/response/base/api_response.dart';
import 'package:contact_egypt/data/model/response/response_model.dart';
import 'package:contact_egypt/data/model/response/user_info_model.dart';
import 'package:contact_egypt/data/repository/profile_repo.dart';
import 'package:contact_egypt/helper/api_checker.dart';
import 'package:http/http.dart' as http;

class ProfileProvider extends ChangeNotifier {
  final ProfileRepo profileRepo;
  ProfileProvider({@required this.profileRepo});

  List<String> _addressTypeList = [];
  String _addressType = '';
  UserInfoModel _userInfoModel;
  bool _isLoading = false;

  bool _hasData;
  bool _isHomeAddress = true;
  String _addAddressErrorText;

  List<String> get addressTypeList => _addressTypeList;
  String get addressType => _addressType;
  UserInfoModel get userInfoModel => _userInfoModel;
  bool get isLoading => _isLoading;
  bool get hasData => _hasData;
  bool get isHomeAddress => _isHomeAddress;
  String get addAddressErrorText => _addAddressErrorText;

  void setAddAddressErrorText(String errorText) {
    _addAddressErrorText = errorText;
    // notifyListeners();
  }

  void updateAddressCondition(bool value) {
    _isHomeAddress = value;
    notifyListeners();
  }

  bool _checkHomeAddress=false;
  bool get checkHomeAddress=>_checkHomeAddress;

  bool _checkOfficeAddress=false;
  bool get checkOfficeAddress=>_checkOfficeAddress;

  void setHomeAddress() {
    _checkHomeAddress = true;
    _checkOfficeAddress = false;
    notifyListeners();
  }

  void setOfficeAddress() {
    _checkHomeAddress = false;
    _checkOfficeAddress = true;
    notifyListeners();
  }


  updateCountryCode(String value) {
    _addressType = value;
    notifyListeners();
  }



  Future<String> getUserInfo(BuildContext context) async {
    String userID = '-1';
    ApiResponse apiResponse = await profileRepo.getUserInfo();
    if (apiResponse.response != null && apiResponse.response.statusCode == 200) {
      _userInfoModel = UserInfoModel.fromJson(apiResponse.response.data);
      userID = _userInfoModel.id.toString();
    } else {
      ApiChecker.checkApi(context, apiResponse);
    }
    notifyListeners();
    return userID;
  }

  void initAddressTypeList(BuildContext context) async {
    if (_addressTypeList.length == 0) {
      ApiResponse apiResponse = await profileRepo.getAddressTypeList();
      if (apiResponse.response != null && apiResponse.response.statusCode == 200) {
        _addressTypeList.clear();
        _addressTypeList.addAll(apiResponse.response.data);
        _addressType = apiResponse.response.data[0];
      } else {
        ApiChecker.checkApi(context, apiResponse);
      }
      notifyListeners();
    }
  }


  Future<ResponseModel> updateUserInfo(UserInfoModel updateUserModel, String pass, File file, String token) async {
    _isLoading = true;
    notifyListeners();

    ResponseModel responseModel;
    http.StreamedResponse response = await profileRepo.updateProfile(updateUserModel, pass, file, token);
    _isLoading = false;
    if (response.statusCode == 200) {
      Map map = jsonDecode(await response.stream.bytesToString());
      String message = map["message"];
      _userInfoModel = updateUserModel;
      responseModel = ResponseModel(message, true);
      print(message);
    } else {
      print('${response.statusCode} ${response.reasonPhrase}');
      responseModel = ResponseModel('${response.statusCode} ${response.reasonPhrase}', false);
    }
    notifyListeners();
    return responseModel;
  }

  // save office and home address
  void saveHomeAddress(String homeAddress) {
    profileRepo.saveHomeAddress(homeAddress).then((_) {
      notifyListeners();
    });
  }

  void saveOfficeAddress(String officeAddress) {
    profileRepo.saveOfficeAddress(officeAddress).then((_) {
      notifyListeners();
    });
  }

  // for home Address Section
  String getHomeAddress() {
    return profileRepo.getHomeAddress();
  }

  Future<bool> clearHomeAddress() async {
    return await profileRepo.clearHomeAddress();
  }

  // for office Address Section
  String getOfficeAddress() {
    return profileRepo.getOfficeAddress();
  }

  Future<bool> clearOfficeAddress() async {
    return await profileRepo.clearOfficeAddress();
  }
}
