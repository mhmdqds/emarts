
import 'package:contact_egypt/data/model/body/contact_model.dart';
import 'package:contact_egypt/data/model/body/contacts.dart';
import 'package:contact_egypt/data/repository/contact_repo.dart';
import 'package:flutter/material.dart';
import 'package:contact_egypt/data/model/response/base/api_response.dart';
import 'package:contact_egypt/helper/api_checker.dart';

class ContactProvider extends ChangeNotifier {
  final ContactRepo contactRepo;

  ContactProvider({@required this.contactRepo});

  var _responseOk = "";
  get responseOk => _responseOk;

  bool _deletePhoneOk = false;
  bool get deletePhoneOk => _deletePhoneOk;

  List<MyContact> _contactSListFromWeb = [];
  List<MyContact> get contactSListFromWeb => _contactSListFromWeb;


  Future<void>  getNameByPhone(String phone , BuildContext context) async {
    _contactSListFromWeb.clear();
    notifyListeners();
    ApiResponse apiResponse = await contactRepo.getContactList(phone);
    if (apiResponse.response.statusCode == 200) {
      apiResponse.response.data["ContactsPhone"].forEach((contactWeb) => _contactSListFromWeb.add(MyContact.fromJson(contactWeb)));
      notifyListeners();
    } else {
      _contactSListFromWeb.clear();
      ApiChecker.checkApi(context, apiResponse);
      notifyListeners();
    }
    notifyListeners();
  }

  Future<void>  uploadPhone(List<ContactsModel> phoneList , BuildContext context) async {
    ApiResponse apiResponse = await contactRepo.uploadContactList(phoneList);
    print('uploadPhone:::::::::::: ${apiResponse.response} ');
    if (apiResponse.response != null) {
      _responseOk = apiResponse.response.data;
      notifyListeners();
    } else {
      ApiChecker.checkApi(context, apiResponse);
    }
    notifyListeners();
  }

  Future<void>  deletePhone(String phoneID , BuildContext context) async {
    _deletePhoneOk = false;
    ApiResponse apiResponse = await contactRepo.deleteContact(phoneID);
    print('deletePhone:::::::::::: ${apiResponse.response} ');
    if (apiResponse.response != null) {
      _deletePhoneOk = apiResponse.response.data["success"];
      notifyListeners();
    } else {
      ApiChecker.checkApi(context, apiResponse);
    }
    notifyListeners();
  }


}
