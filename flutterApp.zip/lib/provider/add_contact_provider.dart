import 'package:contact_egypt/data/repository/contact_repo.dart';
import 'package:contacts_service/contacts_service.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

class AddContactProvider extends ChangeNotifier {
  final ContactRepo contactRepo;

  AddContactProvider({@required this.contactRepo});

  Contact _contact = Contact( );

  Contact get contact => _contact;
  Contact _newContact = new Contact( );

  Contact get newContact => _newContact;

  Future<void> addContactNameByPhone(String firstName, String lastName,
      String phoneNumber, String phoneNumber2, String phoneNumber3,
      phoneNumber4, BuildContext context) async {
    PermissionStatus permission = await Permission.contacts.status;

    await ContactsService.addContact( _newContact );
    if (permission != PermissionStatus.granted) {
      await Permission.contacts.request( );
      PermissionStatus permission = await Permission.contacts.status;

      if (permission == PermissionStatus.granted) {
        print( "saving" );
        Contact newContact = new Contact( );

        newContact.givenName = "firstName";
        newContact.company = "lastName";
        _newContact.givenName = firstName;
        _newContact.middleName = lastName;
        _newContact.phones = [Item( label: "mobile", value: phoneNumber )];
        _newContact.phones = [Item( label: "work", value: phoneNumber2 )];
        _newContact.phones = [Item( label: "company", value: phoneNumber3 )];
        _newContact.phones = [Item( label: "job", value: phoneNumber4 )];
        newContact.phones =
        [
          Item( label: "mobile", value: phoneNumber ),
          Item( label: "work", value: phoneNumber2 ),
          Item( label: "mobile3", value: phoneNumber3 ),
          Item( label: "mobile4", value: phoneNumber4 ),

        ];
        newContact.postalAddresses = [
          PostalAddress( region: "" )
        ];
        await ContactsService.addContact( newContact );
      }

      notifyListeners( );
    }
  }
}