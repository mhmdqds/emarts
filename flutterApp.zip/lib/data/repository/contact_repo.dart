import 'dart:convert';

import 'package:contact_egypt/data/model/body/contact_model.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:contact_egypt/data/datasource/remote/dio/dio_client.dart';
import 'package:contact_egypt/data/datasource/remote/exception/api_error_handler.dart';
import 'package:contact_egypt/data/model/response/base/api_response.dart';
import 'package:contact_egypt/utility/app_constants.dart';

class ContactRepo {
  final DioClient dioClient;
  ContactRepo({@required this.dioClient});

  Future<ApiResponse> getContactList(String phoneNumber) async {
    try {
      final response = await dioClient.get('${AppConstants.SEARCH_PHONE_Ema}/$phoneNumber');
      return ApiResponse.withSuccess(response);
    } catch (e) {
      return ApiResponse.withError(ApiErrorHandler.getMessage(e));
    }
  }

  Future<ApiResponse> uploadContactList(List<ContactsModel> phoneNumber) async {
    try {
      Response response = await dioClient.post(AppConstants.UPLOAD_PHONE_Ema,
        data: {"ListsList": json.encode(phoneNumber)},
      );
      //final response = await dioClient.get('${AppConstants.UPLOAD_PHONE}/$phoneNumber');
      return ApiResponse.withSuccess(response);
    } catch (e) {
      return ApiResponse.withError(ApiErrorHandler.getMessage(e));
    }
  }

  Future<ApiResponse> deleteContact(String phoneId) async {
    try {
      Response response = await dioClient.get('${AppConstants.DELETE_PHONE_Ema}/$phoneId');
      return ApiResponse.withSuccess(response);
    } catch (e) {
      return ApiResponse.withError(ApiErrorHandler.getMessage(e));
    }
  }



}