// ignore: camel_case_types

import 'package:flutter/cupertino.dart';

class AllPhoneModel with ChangeNotifier {
  String mobile;
  String home;
  String work;
  String workMobile;
  String homeMobile;
  String other;
  String fax;
  AllPhoneModel({this.mobile, this.home, this.work, this.workMobile, this.homeMobile, this.other, this.fax});

  AllPhoneModel.fromJson(Map<String, dynamic> json) {
    mobile = json['mobile'].toString();
    home = json['home'];
    work = json['work'];
    workMobile = json['workMobile'];
    homeMobile = json['homeMobile'];
    other = json['other'];
    fax = json['fax'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['mobile'] = this.mobile;
    data['home'] = this.home;
    data['work'] = this.work;
    data['workMobile'] = this.workMobile;
    data['homeMobile'] = this.homeMobile;
    data['other'] = this.other;
    data['fax'] = this.fax;
    return data;
  }
}


class ContactsModel {
  String conId;
  String displayName;
  String familyName;
  String givenName;
  String middleName;
  String company;
  String phones;
  String phone1;
  String phone2;
  String phone3;
  String phone4;
  String emails;
  String emails2;
  String jobTitle;
  String identifier;
  String birthday;
  String contactprefix;
  String contactsuffix;
  String syncContacts;
  String dateNow;
  bool isLoading = false;
  //int reviewCount;

  ContactsModel(
      this.conId,
      this.displayName,
      this.familyName,
      this.givenName,
      this.middleName,
      this.company,
      this.phones,
      this.phone1,
      this.phone2,
      this.phone3,
      this.phone4,
      this.emails,
      this.emails2,
      this.jobTitle,
      this.identifier,
      this.birthday,
      this.contactprefix,
      this.contactsuffix,
      this.dateNow,
      // this.reviewCount
      );

  ContactsModel.fromJson(Map<String, dynamic> json) {
    conId = json['id'];
    displayName = json['displayName'];
    familyName = json['familyName'];
    givenName = json['givenName'];
    middleName = json['middleName'];
    company = json['company'];
    phones = json['phones'].toString();
    phone1 = json['phone1'].toString();
    phone2 = json['phone2'].toString();
    phone3 = json['phone3'].toString();
    phone4 = json['phone4'].toString();
    emails = json['emails'];
    emails2 = json['emails2'];
    jobTitle = json['jobTitle'].toString();
    identifier = json['identifier'];
    birthday = json['birthday'];
    contactprefix = json['contactprefix'];
    contactsuffix = json['contactsuffix'];
    syncContacts = json['syncContacts'];
    dateNow = json['dateNow'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.conId.toString();
    data['displayName'] = this.displayName.toString();
    data['familyName'] = this.familyName.toString();
    data['givenName'] = this.givenName.toString();
    data['middleName'] = this.middleName.toString();
    data['company'] = this.company.toString();
    data['phone1'] = this.phone1.toString();
    data['phone2'] = this.phone2.toString();
    data['phone3'] = this.phone3.toString();
    data['phone4'] = this.phone4.toString();
    data['emails'] = this.emails;
    data['emails2'] = this.emails2;
    data['jobTitle'] = this.jobTitle;
    data['identifier'] = this.identifier;
    data['birthday'] = this.birthday;
    data['contactprefix'] = this.contactprefix;
    data['res_create_date'] = this.contactsuffix;
    data['syncContacts'] = this.syncContacts;
    data['dateNow'] = this.dateNow;
    return data;
  }

  Map<String, dynamic> toMap() {
    return {
      'conId': conId.toString(),
      'displayName': displayName.toString(),
      'familyName': familyName.toString(),
      'givenName': givenName.toString(),
      'middleName': middleName.toString(),
      'company': company.toString(),
      'phone1': phone1.toString(),
      'phone2': phone2.toString(),
      'phone3': phone3.toString(),
      'phone4': phone4.toString(),
      'emails': emails.toString(),
      'identifier': identifier.toString(),
      'dateNow': dateNow.toString(),
    };
  }

  ContactsModel.fromJsonLocal(Map<String, dynamic> json) {
    try {
      conId = json['conId'].toString();
      displayName = json['displayName'].toString();
      familyName = json['familyName'].toString();
      givenName = json['givenName'].toString();
      company = json['company'].toString();
      phone1 = json['phone1'];
      phone2 = json['phone2'];
      phone3 = json['phone3'];
      phone4 = json['phone4'];
      emails = json['emails'];
      emails2 = json['emails2'];
      jobTitle = json['jobTitle'];
      identifier = json['identifier'];
      birthday = json['birthday'];
      contactprefix = json['contactprefix'];
      contactsuffix = json['contactsuffix'];
      syncContacts = json['syncContacts'];
      dateNow = json['dateNow'];
    } catch (e) {
      print(e.toString());
    }
  }
}






