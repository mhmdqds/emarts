
import 'package:cloud_firestore/cloud_firestore.dart';

class MyContact {
  // String contactId;
  int conId;
  String displayName;
  String familyName;
  String firstName;
  String lastName;
  String givenName;
  String middleName;
  String company;
  String phone1;
  String phone2;
  String phone3;
  String phone4;
  String emails;
  String emails2;
  String jobTitle;
  String identifier;
  String birthday;
  String contactprefix;
  String contactsuffix;
  String syncContacts;
  String countryCode;

  MyContact({
    this.conId,
    this.displayName,
    this.familyName,
    this.firstName,
    this.lastName,
    this.givenName,
    this.middleName,
    this.company,
    this.phone1,
    this.phone2,
    this.phone3,
    this.phone4,
    this.emails,
    this.emails2,
    this.jobTitle,
    this.identifier,
    this.birthday,
    this.contactprefix,
    this.countryCode,
    this.contactsuffix, syncContacts,
  });

  MyContact.fromJson(Map<String, dynamic> json) {
    conId = json['id'];
    displayName = json['displayName'];
    familyName = json['familyName'];
    firstName = json['displayName'];
    lastName = json['displayName'];
    givenName = json['givenName'];
    middleName = json['middleName'];
    company = json['company'] != null ? json['company'] : null;
    phone1 = json['phone1'] != null ? json['phone1'] : null;
    phone2 = json['phone2'] != null ? json['phone2'] : null;
    phone3 = json['phone3'] != null ? json['phone3'] : null;
    phone4 = json['phone4'] != null ? json['phone4'] : null;
    emails = json['emails'].toString();
    identifier = json['identifier'].toString();
    syncContacts = json['syncContacts'];
    countryCode = json['countryCode'];
  }

  factory MyContact.fromJSON(Map<String, dynamic> json) => MyContact(
    conId: json["id"],
    displayName: json["displayName"],
    familyName: json["familyName"],
    givenName: json["givenName"],
    middleName: json["middleName"],
    company: json["company"],
    phone1: json["phone1"].toString(),
    phone2: json["phone2"].toString(),
    phone3: json["phone3"].toString(),
    phone4: json["phone4"].toString(),
    emails: json["emails"],
    emails2: json["emails2"],
    jobTitle: json["jobTitle"].toString(),
    identifier: json["identifier"],
    birthday: json["birthday"],
    contactprefix: json["contactprefix"],
    contactsuffix: json["contactsuffix"],
    syncContacts: json["syncContacts"],
    countryCode: json["countryCode"],
  );
  DocumentReference reference;

  MyContact.fromMap(Map<String, dynamic> map, {this.reference})
      : displayName = map["displayName"],
        familyName = map["familyName"],
        givenName = map["givenName"],
        middleName = map["middleName"],
        phone1 = map["phone1"],
        phone2 = map["phone2"],
        phone3 = map["phone3"],
        phone4 = map["phone4"],
        emails = map["emails"],
        identifier = map["identifier"],
        countryCode = map["countryCode"];


  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.conId.toString();
    data['displayName'] = this.displayName.toString();
    data['familyName'] = this.familyName.toString();
    data['givenName'] = this.givenName.toString();
    data['middleName'] = this.middleName.toString();
    data['company'] = this.company.toString();
    data['phone1'] = this.phone1.toString();
    data['phone2'] = this.phone2.toString();
    data['phone3'] = this.phone3.toString();
    data['phone4'] = this.phone4.toString();
    data['emails'] = this.emails;
    data['emails2'] = this.emails2;
    data['jobTitle'] = this.jobTitle;
    data['identifier'] = this.identifier;
    data['birthday'] = this.birthday;
    data['contactprefix'] = this.contactprefix;
    data['res_create_date'] = this.contactsuffix;
    data['syncContacts'] = this.syncContacts;
    data['countryCode'] = this.countryCode;
    return data;
  }

  Map<String, dynamic> toMap() {
    return {
      'conId': conId.toString(),
      'displayName': displayName.toString(),
      'familyName': familyName.toString(),
      'givenName': givenName.toString(),
      'middleName': middleName.toString(),
      'company': company.toString(),
      'phone1': phone1.toString(),
      'phone2': phone2.toString(),
      'phone3': phone3.toString(),
      'phone4': phone4.toString(),
      'emails': emails,
      'emails2': emails2,
      'jobTitle': jobTitle,
      'identifier': identifier,
      'birthday': birthday,
      'countryCode': countryCode,
    };
  }
}
