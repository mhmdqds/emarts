class SupportTicketBody {
  String _subject;
  String _phone;
  String _description;

  SupportTicketBody(String phone, String subject, String description) {
    this._phone = phone;
    this._subject = subject;
    this._description = description;
  }

  String get subject => _subject;
  String get phone => _phone;
  String get description => _description;

  SupportTicketBody.fromJson(Map<String, dynamic> json) {
    _subject = json['subject'];
    _phone = json['phone'];
    _description = json['description'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['subject'] = this._subject;
    data['phone'] = this._phone;
    data['description'] = this._description;
    return data;
  }
}
