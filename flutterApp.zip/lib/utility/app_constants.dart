import 'package:contact_egypt/data/model/response/language_model.dart';

class AppConstants {
  static const String APP_NAME = 'دليل مصر';
  static const String BASE_URL = 'https://smartwebye.com/contactsphoneapp';
  static const String bannerImageUrl = 'https://smartwebye.com/contactsphoneapp/public/images';
  static const String notificationImageUrl = 'https://smartwebye.com/contactsphoneapp/public/notificationImage';
  static const String USER_ID = 'userId';
  static const String NAME = 'name';

  //egypt
  //static const String SEARCH_PHONE = '/api/searchcontacts';
  //static const String UPLOAD_PHONE = '/api/addstorecontacts';
  //static const String UPLOAD_PHONE_EGYPT = '/api/addphonecontactsegypt';
  //static const String DELETE_PHONE_EGYPT = '/api/deletecontact';
  //static const String REGISTRATION_URI = '/api/v1/auth/register';
  //static const String NOTIFICATION_URI = '/api/notifications';
  
  //emart
  static const String SEARCH_PHONE_kuwait = '/api/searchcontactskuwait';

  static const String UPLOAD_store_kuwait = '/api/addstorecontactskuwait';
  static const String UPLOAD_PHONE_kuwait = '/api/addphonecontactskuwait';
  static const String DELETE_PHONE_kuwait = '/api/deletecontactkuwait';

  static const String UPLOAD_PHONE_EGYPT = '/api/addphonecontactsegypt';
  static const String DELETE_PHONE_EGYPT = '/api/deletecontact';
  static const String SEARCH_PHONE_EGYPT = '/api/searchcontactskuwait';


  static const String SEARCH_PHONE_Ema = '/api/searchcontactsemart';
  static const String DELETE_PHONE_Ema = '/api/deletecontactemart';
  static const String UPLOAD_PHONE_Ema = '/api/addstorecontactsemart';


  //other
  static const String REGISTRATION_URI = '/api/v1/auth/register';
  static const String NOTIFICATION_URI = '/api/notifications';
  static const String CONFIG_URI = '/api/config';
  static const String SUPPORT_TICKET_URI = '/api/support-ticket/create';
  static const String LOGIN_URI = '/api/auth/login';
  static const String SEARCH_URI = '/api/products/search?name=';
  static const String UPDATE_PROFILE_URI = '/api/customer/update-profile';
  static const String CUSTOMER_URI = '/api/customer/info';
  static const String ADD_ADDRESS_URI = '/api/customer/address/add';
  static const String MAIN_BANNER_URI = '/api/banners?banner_type=main_banner';
  static const String FOOTER_BANNER_URI = '/api/banners?banner_type=footer_banner';
  static const String FORGET_PASSWORD_URI = '/api/auth/forgot-password';
  static const String SUPPORT_TICKET_GET_URI = '/api/customer/support-ticket/get';
  static const String SUPPORT_TICKET_CONV_URI = '/api/customer/support-ticket/conv/';
  static const String SUPPORT_TICKET_REPLY_URI = '/api/customer/support-ticket/reply/';
  static const String SUBMIT_REVIEW_URI = '/api/products/reviews/submit';
  static const String COUNTER_URI = '/api/products/counter/';
  static const String MESSAGES_URI = '/api/customer/chat/messages?shop_id=';
  static const String CHAT_INFO_URI = '/api/customer/chat';
  static const String SEND_MESSAGE_URI = '/api/customer/chat/send-message';
  static const String TOKEN_URI = '/api/customer/cm-firebase-token';
  static const String CHECK_PHONE_URI = '/api/auth/check-phone';
  static const String VERIFY_PHONE_URI = '/api/auth/verify-phone';
  static const String SOCIAL_LOGIN_URI = '/api/auth/social-login';
  static const String CHECK_EMAIL_URI = '/api/auth/check-email';
  static const String VERIFY_EMAIL_URI = '/api/auth/verify-email';
  static const String RESET_PASSWORD_URI = '/api/auth/reset-password';
  static const String VERIFY_OTP_URI = '/api/auth/verify-otp';
  

  // sharePreference
  static const String TOKEN = 'token';
  static const String USER = 'user';
  static const String USER_EMAIL = 'user_email';
  static const String USER_PASSWORD = 'user_password';
  static const String HOME_ADDRESS = 'home_address';
  static const String SEARCH_ADDRESS = 'search_address';
  static const String OFFICE_ADDRESS = 'office_address';
  static const String CART_LIST = 'cart_list';
  static const String CONFIG = 'config';
  static const String GUEST_MODE = 'guest_mode';
  static const String CURRENCY = 'currency';
  static const String LANG_KEY = 'lang';
  static const String INTRO = 'intro';

  // order status
  static const String PENDING = 'pending';
  static const String CONFIRMED = 'confirmed';
  static const String PROCESSING = 'processing';
  static const String PROCESSED = 'processed';
  static const String DELIVERED = 'delivered';
  static const String FAILED = 'failed';
  static const String RETURNED = 'returned';
  static const String CANCELLED = 'canceled';
  static const String OUT_FOR_DELIVERY = 'out_for_delivery';
  static const String COUNTRY_CODE = 'country_code';
  static const String LANGUAGE_CODE = 'language_code';
  static const String THEME = 'theme';
  static const String TOPIC = 'دليل مصر';
  static const String USER_ADDRESS = 'user_address';
  static const String version = '10.5';
  static const String Privacy = "Privacy Policy smart web. built the Contact Egypt app app as a Free app. This SERVICE is provided by smart web. at no cost and is intended for use as is. This page is used to inform visitors regarding our policies with the collection, use, and disclosure of Personal Information if anyone decided to use our Service. If you choose to use our Service, then you agree to the collection and use of information in relation to this policy. The Personal Information that we collect is used for providing and improving the Service. we will not use or share your information with anyone except as described in this Privacy Policy. The terms used in this Privacy Policy have the same meanings as in our Terms and Conditions, which is accessible at Contact Egypt app unless otherwise defined in this Privacy Policy. Information Collection and Use For a better experience, while using our Service, we may require you to provide us with certain personally identifiable information, including but not limited to Contact List . The information that we request will be retained by us to enahnce our search result in the app and used as described in this privacy policy. The app does use third party services that may collect information used to identify you. we want to inform you that whenever you use our Service, in a case of an error in the app we collect data and information (through third party products) on your phone errors Log Data. This Log Data may include information such as your device Internet Protocol (“IP”) address, device name, operating system version, the configuration of the app when utilizing our Service, the time and date of your use of the Service, and other statistics. Data being collected Device Hardware Inf device ID or unique identifie Sim card Serial No,IMIE,IMSI Sim card Info Contacts List Device Hardware Info and Sim Info When You Install The App, You agree to share your device hardware information and sim card information we use this information to generate a uineq device id to identity each device use this application to prevent use our service excessively. Contacts Information When You install The App, You agree to share complete contact information contained in Your device’s address book (“Contact Information”) which includes name, email, phone, country, birth date, job/company, address, state, of your contacts this information will be added in our Search database. and we not share it with any third-party. Security we value your trust in providing us your Personal Information, thus we are striving to use commercially acceptable means of protecting it. But remember that no method of transmission over the internet, or method of electronic storage is 100% secure and reliable, and we cannot guarantee its absolute security. Changes to This Privacy Policy we may update our Privacy Policy from time to time. Thus, you are advised to review this page periodically for any changes. we will notify you of any changes by posting the new Privacy Policy on this page. This policy is effective as of 2022-12-12 Contact Us If you have any questions or suggestions about our Privacy Policy, do not hesitate to contact us at mhmdqds@gmail.com سياسة الخصوصيه smart web قامت شركة ببناء تطبيق كاشف الأرقام مصر كتطبيق مجاني وبدون أي مقابل مادي هذه الصفحه تعرض معلومات حول سياسة الخصوصيه الخاصه بنا والتي تتعلق بجمع المعلومات الشخصيه لكل مستخدمي خدماتنا إذا قررت إستخدام خدماتنا فهذا يعني أنك موافق على جمع وإستخدام المعلومات الموضحه والمفصله في سياسه الخصوصيه ، كما لانقوم بمشاركه هذه المعلومات مع اي طرف ثالث حسب ماهو موضح في سياسه الخصوصيه الشروط المستخدمه في هذه السياسه تحمل نفس المعاني والشروط التي الموجوده والموضحه داخل تطبيق كاشف الأرقام مصر سياسة جمع وإستخدام المعلوما للحصول على تجربة أداء افضل عند إستخدام خدماتنا ، نحن ربما نطلب منك بعض المعلومات الحساسه الشخصيه تشمل ايضاً قائمه جهات الإتصال الموجوده في هاتفك . هذه المعلومات التي نطلبها تخضع لسياسه الخصوصيه الموضحه والمفصله هنا التطبيق يستخدم خدمات من طرف الثالث قد تقوم بجمع المعلومات وتحديد هويتك ، وكما نعلمك خدماتنا قد تقوم بجمع معلومات اكثر عند حدوث اي خطاء في التطبيق حول والمتمثله في سجل الأخطاء . قد يحتوي هذا السجل معلومات عن نوع هاتفك و بروتوكول الأنترنت و ال IP المتصل منه ونوع نظام التشغيل وقت وتاريخ الاستخدام للخدمات و كذلك احصائيات اخرى . المعلومات التي يتم جمعها معلومات جهاز الهات المعرف الفريد لجهاز الهاتف معلومات الشريحه Serial No ,IMIE , IMSI جهات الإتصال معلومات الجهاز والشريحه عند تثبيت التطبيق ، فإنك توافق على مشاركة معلومات أجهزة جهازك ومعلومات بطاقة sim التي نستخدمها لإنشاء معرف فريد لتحديد هوية كل جهاز يستخدم هذا التطبيق لمنع استخدام خدمتنا بشكل مفرط. معلومات جهات الإتصال عندما تقوم بتشغيل التطبيق فإنك توافق على مشاركه جميع جهات الإتصال بما في ذلك معلوماتهم مثل الإيميل والدوله والشركه والمنطقه والعنوان ، هذه المعلومات سيتم تخزينها في قاعده بيانات التطبيق ولن يتم مشاركتها مع أي طرف ثالث . الحماية والأمان نحن نقدر ثقتك بتقديمك لنا معلوماتك الشخصيه حيث نقوم بحمايه هذه المعلومات ، ولكن تذكر انه لايوجد أمان بشكل كامل في خدمات الأنترنت أو أمان في وسائل التخزين ، ونحن لانضمن الحمايه الكامله 100% . للخدمات المقدمه على الأنترنت. التغييرات على سياسة الخصوصية هذه قد نقوم بتحديث سياسة الخصوصية الخاصة بنا من وقت إلى آخر. وبالتالي ، ننصحك بمراجعة هذه الصفحة بشكل دوري لأي تغييرات. سنقوم بإعلامك بأي تغييرات عن طريق نشر سياسة الخصوصية الجديدة على هذه الصفحة وسنطالبك بالموافقه على أي تغييرات تطرأ عليها. 2022-12-12 سياسه الخصوصيه هذه فعاله حتى تاريخ للتواصل معن إذا كانت لديك أي استفسارات او مقترحات حول سياسه الخصوصيه هذه لاتتردد في التواصل معنا على الإيميل mhmdqds@gmail.com";
  static const String PrivacyEn = "Privacy Policy smart web. built the Contact Egypt app app as a Free app. This SERVICE is provided by smart web. at no cost and is intended for use as is. This page is used to inform visitors regarding our policies with the collection, use, and disclosure of Personal Information if anyone decided to use our Service. If you choose to use our Service, then you agree to the collection and use of information in relation to this policy. The Personal Information that we collect is used for providing and improving the Service. we will not use or share your information with anyone except as described in this Privacy Policy. The terms used in this Privacy Policy have the same meanings as in our Terms and Conditions, which is accessible at Contact Egypt app unless otherwise defined in this Privacy Policy. Information Collection and Use For a better experience, while using our Service, we may require you to provide us with certain personally identifiable information, including but not limited to Contact List . The information that we request will be retained by us to enahnce our search result in the app and used as described in this privacy policy. The app does use third party services that may collect information used to identify you. we want to inform you that whenever you use our Service, in a case of an error in the app we collect data and information (through third party products) on your phone errors Log Data. This Log Data may include information such as your device Internet Protocol (“IP”) address, device name, operating system version, the configuration of the app when utilizing our Service, the time and date of your use of the Service, and other statistics. Data being collected Device Hardware Inf device ID or unique identifie Sim card Serial No,IMIE,IMSI Sim card Info Contacts List Device Hardware Info and Sim Info When You Install The App, You agree to share your device hardware information and sim card information we use this information to generate a uineq device id to identity each device use this application to prevent use our service excessively. Contacts Information When You install The App, You agree to share complete contact information contained in Your device’s address book (“Contact Information”) which includes name, email, phone, country, birth date, job/company, address, state, of your contacts this information will be added in our Search database. and we not share it with any third-party. Security we value your trust in providing us your Personal Information, thus we are striving to use commercially acceptable means of protecting it. But remember that no method of transmission over the internet, or method of electronic storage is 100% secure and reliable, and we cannot guarantee its absolute security. Changes to This Privacy Policy we may update our Privacy Policy from time to time. Thus, you are advised to review this page periodically for any changes. we will notify you of any changes by posting the new Privacy Policy on this page. This policy is effective as of 2022-12-12 Contact Us If you have any questions or suggestions about our Privacy Policy, do not hesitate to contact us at mhmdqds@gmail.com";
 
  static List<LanguageModel> languages = [
    LanguageModel(imageUrl: '', languageName: 'Arabic', countryCode: 'SA', languageCode: 'ar'),
    LanguageModel(imageUrl: '', languageName: 'English', countryCode: 'US', languageCode: 'en'),
  ];
}
