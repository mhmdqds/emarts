import 'package:flutter/material.dart';
import 'package:contact_egypt/utility/dimensions.dart';

const titRegular = TextStyle(
  fontFamily: 'TitilliumWeb',
  fontSize: Dimensions.FONT_SIZE_DEFAULT,
);

const titSemiBold = TextStyle(
  fontFamily: 'TitilliumWeb',
  fontSize: Dimensions.FONT_SIZE_SMALL,
  fontWeight: FontWeight.w600,
);

const titBold = TextStyle(
  fontFamily: 'TitilliumWeb',
  fontSize: Dimensions.FONT_SIZE_DEFAULT,
  fontWeight: FontWeight.w700,
);
const titItalic = TextStyle(
  fontFamily: 'TitilliumWeb',
  fontSize: Dimensions.FONT_SIZE_DEFAULT,
  fontStyle: FontStyle.italic,
);

const robotoRegular = TextStyle(
  fontFamily: 'Roboto',
  fontSize: Dimensions.FONT_SIZE_DEFAULT,
);

const robotoBold = TextStyle(
  fontFamily: 'Roboto',
  fontSize: Dimensions.FONT_SIZE_DEFAULT,
  fontWeight: FontWeight.w700,
);
