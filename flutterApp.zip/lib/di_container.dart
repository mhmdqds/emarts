import 'package:connectivity/connectivity.dart';
import 'package:contact_egypt/data/repository/contact_repo.dart';
import 'package:contact_egypt/provider/add_contact_provider.dart';
import 'package:contact_egypt/provider/contact_provider.dart';
import 'package:dio/dio.dart';
import 'package:contact_egypt/data/datasource/remote/dio/dio_client.dart';
import 'package:contact_egypt/data/repository/auth_repo.dart';
import 'package:contact_egypt/data/repository/banner_repo.dart';
import 'package:contact_egypt/data/repository/profile_repo.dart';
import 'package:contact_egypt/data/repository/search_repo.dart';
import 'package:contact_egypt/data/repository/splash_repo.dart';
import 'package:contact_egypt/data/repository/support_ticket_repo.dart';
import 'package:contact_egypt/helper/network_info.dart';
import 'package:contact_egypt/provider/auth_provider.dart';
import 'package:contact_egypt/provider/banner_provider.dart';
import 'package:contact_egypt/provider/localization_provider.dart';
import 'package:contact_egypt/provider/profile_provider.dart';
import 'package:contact_egypt/provider/search_provider.dart';
import 'package:contact_egypt/provider/splash_provider.dart';
import 'package:contact_egypt/provider/support_ticket_provider.dart';
import 'package:contact_egypt/provider/theme_provider.dart';
import 'package:contact_egypt/utility/app_constants.dart';
import 'package:get_it/get_it.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'data/datasource/remote/dio/logging_interceptor.dart';

final sl = GetIt.instance;

Future<void> init() async {
  // Core
  sl.registerLazySingleton(() => NetworkInfo(sl()));
  sl.registerLazySingleton(() => DioClient(AppConstants.BASE_URL, sl(), loggingInterceptor: sl(), sharedPreferences: sl()));

  // Repository
  sl.registerLazySingleton(() => BannerRepo(dioClient: sl()));
  sl.registerLazySingleton(() => AuthRepo(dioClient: sl(), sharedPreferences: sl()));
  sl.registerLazySingleton(() => SearchRepo(dioClient: sl(), sharedPreferences: sl()));
  sl.registerLazySingleton(() => ProfileRepo(dioClient: sl(), sharedPreferences: sl()));
  sl.registerLazySingleton(() => SplashRepo(sharedPreferences: sl(), dioClient: sl()));
  sl.registerLazySingleton(() => SupportTicketRepo(dioClient: sl()));
  sl.registerLazySingleton(() => ContactRepo(dioClient: sl()));

  // Provider
  sl.registerFactory(() => BannerProvider(bannerRepo: sl()));
  sl.registerFactory(() => AuthProvider(authRepo: sl()));
  sl.registerFactory(() => SearchProvider(searchRepo: sl()));
  sl.registerFactory(() => ProfileProvider(profileRepo: sl()));
  sl.registerFactory(() => SplashProvider(splashRepo: sl()));
  sl.registerFactory(() => SupportTicketProvider(supportTicketRepo: sl()));
  sl.registerFactory(() => LocalizationProvider(sharedPreferences: sl(), dioClient: sl()));
  sl.registerFactory(() => ThemeProvider(sharedPreferences: sl()));
  sl.registerFactory(() => ContactProvider(contactRepo: sl()));
  sl.registerFactory(() => AddContactProvider(contactRepo: sl()));

  // External
  final sharedPreferences = await SharedPreferences.getInstance();
  sl.registerLazySingleton(() => sharedPreferences);
  sl.registerLazySingleton(() => Dio());
  sl.registerLazySingleton(() => LoggingInterceptor());
  sl.registerLazySingleton(() => Connectivity());
}
