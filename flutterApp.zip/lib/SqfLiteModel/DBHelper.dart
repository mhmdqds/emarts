import 'dart:async';
import 'package:contact_egypt/data/model/body/contact_model.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io' as io;

class DBHelper {
  // only have a single app-wide reference to the database
  static Database _db;
  static final DBHelper instance = DBHelper._instance();
  DBHelper._instance();
  // make this a singleton class
  DBHelper._privateConstructor();
  static final DBHelper instances = DBHelper._privateConstructor();

  //contacts Info Table
  static const String id = 'id';
  static const String conId = 'conId';
  static const String displayName = 'displayName';
  static const String familyName = 'familyName';
  static const String givenName = 'givenName';
  static const String middleName = 'middleName';
  static const String company = 'company';
  static const String phones = 'phones';
  static const String phone1 = 'phone1';
  static const String phone2 = 'phone2';
  static const String phone3 = 'phone3';
  static const String phone4 = 'phone4';
  static const String emails = 'emails';
  static const String emails2 = 'emails2';
  static const String jobTitle = 'jobTitle';
  static const String identifier = 'identifier';
  static const String postalAddresses = 'postalAddresses';
  static const String birthday = 'birthday';
  static const String androidAccountName = 'androidAccountName';
  static const String androidAccountTypeRaw = 'androidAccountTypeRaw';
  static const String contactprefix = 'contactprefix';
  static const String contactsuffix = 'contactsuffix';
  static const String syncContacts = 'syncContacts';
  static const String dateNow = 'dateNow';

  static const String contactTable = 'contactTable_tbl';

  static const String DB_NAME = 'yeloo.db';

  Future<Database> get db async {
    if (_db != null) {
      return _db;
    }
    _db = await initDb();
    return _db;
  }

  initDb() async {
    io.Directory documentsDirectory = await getApplicationDocumentsDirectory();
    String path = join(documentsDirectory.path, DB_NAME);
    print("create db at: $path");
    var db = await openDatabase(path, version: 5, onCreate: _onCreate);
    return db;
  }
  _onCreate(Database db, int version) async {
    await db.execute(
        'CREATE TABLE $contactTable($id INTEGER PRIMARY KEY AUTOINCREMENT,$conId TEXT,$displayName TEXT,$familyName TEXT,$givenName TEXT,$middleName TEXT,$company TEXT,$phones TEXT,$phone1 TEXT,$phone2 TEXT,$phone3 TEXT,$phone4 TEXT,$emails TEXT,$emails2 TEXT,$jobTitle TEXT,$identifier TEXT,$postalAddresses TEXT, $birthday TEXT, $androidAccountName TEXT, $androidAccountTypeRaw TEXT,$contactprefix TEXT,$contactsuffix TEXT,$syncContacts TEXT,$dateNow TEXT)');
  }

  String sql;
  String sql2;

//Insert Record In Post Car Table
  Future<int> insertContactsInfo(List<ContactsModel> contactList) async {
    print("insertContactsOk: try");
    var dbClient = await db;
    try {
        for (var itemRes in contactList) {
          String conIds = itemRes.conId.toString();
          String contactDisplayName = itemRes.displayName.toString();
          String contactPhone1 = itemRes.phone1.toString();
          String contactPhone2 = itemRes.phone2.toString();
          String contactPhone3 = itemRes.phone3.toString();

          sql = "SELECT $conId FROM $contactTable WHERE $conId = $conIds";
          var result = await dbClient.rawQuery(sql);
          if (result.length == 0) {
            await dbClient.insert(contactTable, itemRes.toMap());
          } else {
            sql2 = "SELECT $conId FROM $contactTable WHERE $conId = $conIds and $displayName = $contactDisplayName "
                "and  $phone1 = $contactPhone1 and $phone2 = $contactPhone2 and $phone3 = $contactPhone3";
            //var resultCheck = await dbClient.rawQuery(sql2);
            var resultCheck2 = await dbClient.query(contactTable, where: "conId = ? and displayName = ? and givenName = ? and phone1 = ? and phone2 = ? and phone3 =?",
                whereArgs: [conIds, contactDisplayName, contactPhone1, contactPhone2, contactPhone3] );
            if (resultCheck2.length == 0) {
              await dbClient.update( contactTable, itemRes.toMap(),
                  where: "$conId = ?", whereArgs: [itemRes.conId] );
              print("insertContactsOk: tmmmmam");
              updateContactsToZero();
            }
          }
        }
        print("insertContactsOk: OKKKKK");
    } catch (err) {
      print("ExceptsInfo::::: $err");
    }
    return null;
  }

  /////////GET
  Future<List<ContactsModel>> getAllContactsList() async {
    var contactsInfoMapList = await getAllContactsInfoMapList(); // Get 'Map List' from database
    int countcontactsList = contactsInfoMapList.length;
    List<ContactsModel> contactsLists =  <ContactsModel>[];
    for (int i = 0; i < countcontactsList; i++) {
      contactsLists.add(ContactsModel.fromJsonLocal(contactsInfoMapList[i]));
    }
    return contactsLists;
  }


  Future<int> updateContactsInfo() async {
    var dbClient = await db;
    var result;
    try {
      //result = await dbClient!.rawUpdate('UPDATE $contactTable SET $syncContacts = 1');
      //result = await dbClient!.rawUpdate('UPDATE contactTable SET syncContacts = ?,['1']');
      //result = await dbClient!.rawUpdate('UPDATE contactTable SET syncContacts = 1');      //var result = await dbClient!.update(contactTable, syncContacts, where: '$conId = ?', whereArgs: [contactList.identifier]);
     // result =  await dbClient!.update(contactTable,syncContacts,where: '$syncContacts IS NULL');
      result = await dbClient.rawUpdate('''
            UPDATE $contactTable 
            SET $syncContacts = ?
            WHERE $syncContacts IS NULL
            ''', ['1']);
      print("result1utsInfo: $result");
      return result;
    } catch (err) {
      print("ExcepttsInfo: $err");
    }
    return result;
  }

  Future<int> updateContactsToZero() async {
    var dbClient = await db;
    var result;
    try {
      //result = await dbClient!.rawUpdate('UPDATE $contactTable SET $syncContacts = 1');
      //result = await dbClient!.rawUpdate('UPDATE contactTable SET syncContacts = ?,['1']');
      //result = await dbClient!.rawUpdate('UPDATE contactTable SET syncContacts = 1');      //var result = await dbClient!.update(contactTable, syncContacts, where: '$conId = ?', whereArgs: [contactList.identifier]);
     // result =  await dbClient!.update(contactTable,syncContacts,where: '$syncContacts IS NULL');
      result = await dbClient.rawUpdate('''
            UPDATE $contactTable 
            SET $syncContacts = ?
            WHERE $syncContacts = ?
            ''', ['0','1']);
      print("result1updateContactsInfo: $result");
      return result;
    } catch (err) {
      print("ExcepttsInfo: $err");
    }
    return result;
  }

  Future close() async {
    var dbClient = await db;
    dbClient.close();
  }

  Future<List<Map<String, dynamic>>> getAllContactsInfoMapList() async {
    print("getAllContactsInfoMapList: getAllContactsInfoMapListe");
    var result;
    try {
      var dbClient = await db;
      var result = await dbClient.query(contactTable, where: 'syncContacts IS NULL or displayName = ?', whereArgs: [0], orderBy: '$identifier ASC');
      //var result = await dbClient!.query(contactTable, where: "syncContacts = ? or displayName = ?", whereArgs: [null, 0] );
      //print("resultAllContacts: $result");
      return result;
    } catch (err) {
      print("ExceMapList: $err");
    }
    return result;
  }
}
