import 'package:contact_egypt/localization/language_constrants.dart';
import 'package:contact_egypt/utility/color_resources.dart';
import 'package:contact_egypt/view/base_widget/custom_app_bar.dart';

import 'package:flutter/material.dart';
import 'package:flutter_share/flutter_share.dart';
import 'package:package_info/package_info.dart';

class InviteFriend extends StatefulWidget {
  @override
  _InviteFriendState createState() => _InviteFriendState();
}

class _InviteFriendState extends State<InviteFriend> {
  String msg = 'كاشف الارقام ابحث عن اي رقم وسوف يظهر لك اسمه ';
  String base64Image = '';
  PackageInfo _packageInfo = PackageInfo(
    appName: 'Unknown',
    packageName: 'Unknown',
    version: 'Unknown',
    buildNumber: 'Unknown',
  );

  @override
  void initState() {
    _initPackageInfo();
    super.initState();
  }

  String text = '';
  String subject = '';
  List<String> imagePaths = [];

  Future<void> share() async {
    await FlutterShare.share(
        title: "appName",
        text: "searchInput",
        //'ابحث عن رقم اي شخص وسوف يظهر لك اسمه ',
        linkUrl: '"https://play.google.com/store/apps/details?id=" + $_packageInfo.packageName',
        chooserTitle: "share"
        //'شارك مع اصدقائك'
    );
  }

  Future<void> _initPackageInfo() async {
    final PackageInfo info = await PackageInfo.fromPlatform();
    setState(() {
      _packageInfo = info;
    });
  }


  @override
  Widget build(BuildContext context) {
    return Container(
      color: ColorResources.GREY,
      child: SafeArea(
        top: false,
        child: Scaffold(
          backgroundColor: ColorResources.GREY,
          body: Column(
            children: <Widget>[
              CustomAppBar(title: getTranslated('share', context), isBackButtonExist: true),

              Container(
                padding: EdgeInsets.only(
                    top: MediaQuery.of(context).padding.top,
                    left: 16,
                    right: 16),
                child: Image.asset('assets/images/FriendReferral.png'),
              ),
              Container(
                padding: const EdgeInsets.only(top: 8),
                child: Text(getTranslated('share', context),
                  //'شارك مع اصدقائك',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.only(top: 16),
                child:  Text(getTranslated('InviteFriends', context),
                  //'ادعو اصدقائك لاستخدام التطبيق ',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 16,
                  ),
                ),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(top: 1, bottom: 60),
                  child: Center(
                    child: Container(
                      width: 150,
                      height: 40,
                      decoration: BoxDecoration(
                        color: Colors.blue,
                        borderRadius:
                            const BorderRadius.all(Radius.circular(4.0)),
                        boxShadow: <BoxShadow>[
                          BoxShadow(
                              color: Colors.grey.withOpacity(0.6),
                              offset: const Offset(4, 4),
                              blurRadius: 8.0),
                        ],
                      ),
                      child: Material(
                        color: Colors.transparent,
                        child: InkWell(
                          onTap: () {
                            //LaunchReview.launch();
                            share();
                            print('Share Action.');
                          },
                          child: Center(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: <Widget>[
                                Icon(
                                  Icons.share,
                                  color: Colors.white,
                                  size: 22,
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(4.0),
                                  child: Text(getTranslated('share', context),
                                    //'مشاركة',
                                    style: TextStyle(
                                      fontWeight: FontWeight.w500,
                                      color: Colors.white,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
