import 'package:contact_egypt/localization/language_constrants.dart';
import 'package:contact_egypt/utility/color_resources.dart';
import 'package:contact_egypt/view/base_widget/custom_app_bar.dart';
import 'package:flutter/material.dart';

class FeedbackScreen extends StatefulWidget {
  @override
  _FeedbackScreenState createState() => _FeedbackScreenState();
}

class _FeedbackScreenState extends State<FeedbackScreen> {

  final feedbackController = TextEditingController( );
  final feedbackControllerPhone = TextEditingController( );


  GlobalKey<ScaffoldState> scaffoldState = GlobalKey( );

  @override
  void initState() {
    // You should execute `Admob.requestTrackingAuthorization()` here before showing any ad.

    super.initState( );
  }



  void showSnackBar(String content) {
    ScaffoldMessenger.of( context ).showSnackBar(
      SnackBar(
        content: Text( content ),
        duration: Duration( milliseconds: 1500 ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: ColorResources.GREY,
      child: SafeArea(
        top: false,
        child: Scaffold(
          backgroundColor:  ColorResources.GREY,
          body: SingleChildScrollView(
            child: SizedBox(
              height: MediaQuery
                  .of( context )
                  .size
                  .height,
              child: Column(
                children: <Widget>[
                  CustomAppBar(title: getTranslated('contact_us', context), isBackButtonExist: true),

                  Container(
                    padding: EdgeInsets.only(
                        left: 16,
                        right: 16 ),
                    child: Image.asset('assets/images/feedb.png'),
                  ),
                  Container(
                    padding: const EdgeInsets.only( top: 2 ),
                    child: Text(getTranslated('support', context),
                      //'مقترحاتك',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.only( top: 8 ),
                    child: Text(getTranslated('ticket_description', context),
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 16,
                      ),
                    ),
                  ),
                  _buildPhone( ),
                  _buildComposer( ),
                  Padding(
                    padding: const EdgeInsets.only( top: 8 ),
                    child: Center(
                      child: Container(
                        width: 120,
                        height: 40,
                        decoration: BoxDecoration(
                          color: Colors.blue,
                          borderRadius:
                          const BorderRadius.all( Radius.circular( 4.0 ) ),
                          boxShadow: <BoxShadow>[
                            BoxShadow(
                                color: Colors.grey.withOpacity( 0.6 ),
                                offset: const Offset( 4, 4 ),
                                blurRadius: 8.0 ),
                          ],
                        ),
                        child: Material(
                          color: Colors.transparent,
                          child: InkWell(
                            onTap: () {
                              feedBackApi( );
                              FocusScope.of( context ).requestFocus(
                                  FocusNode( ) );
                            },
                            child: Center(
                              child: Padding(
                                padding: const EdgeInsets.all( 4.0 ),
                                child: Text(getTranslated('send', context),
                                  //'ارسال',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w500,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  feedBackApi() async {

  }

  Widget _buildComposer() {
    return Padding(
      padding: const EdgeInsets.only( top: 16, left: 32, right: 32 ),
      child: Container(
        decoration: BoxDecoration(
          color: ColorResources.GREY,
          borderRadius: BorderRadius.circular( 8 ),
          boxShadow: <BoxShadow>[
            BoxShadow(
                color: Colors.grey.withOpacity( 0.8 ),
                offset: const Offset( 4, 4 ),
                blurRadius: 8 ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular( 25 ),
          child: Container(
            padding: const EdgeInsets.all( 4.0 ),
            constraints: const BoxConstraints( minHeight: 80, maxHeight: 260 ),
            color: ColorResources.GREY,
            child: SingleChildScrollView(
              padding:
              const EdgeInsets.only( left: 10, right: 10, top: 0, bottom: 0 ),
              child: TextField(
                controller: feedbackController,
                maxLines: null,
                onChanged: (String txt) {},
                style: TextStyle(
                  fontSize: 16,
                  color: ColorResources.GREY,
                ),
                cursorColor: Colors.blue,
                decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: getTranslated('issue_description', context),
                  //'ادخل مقترحاتك هنا'),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPhone() {
    return Padding(
      padding: const EdgeInsets.only( top: 16, left: 32, right: 32 ),
      child: Container(
        decoration: BoxDecoration(
          color: ColorResources.GREY,
          borderRadius: BorderRadius.circular( 8 ),
          boxShadow: <BoxShadow>[
            BoxShadow(
                color: Colors.grey.withOpacity( 0.8 ),
                offset: const Offset( 4, 4 ),
                blurRadius: 8 ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular( 25 ),
          child: Container(
            padding: const EdgeInsets.all( 4.0 ),
            constraints: const BoxConstraints( minHeight: 20, maxHeight: 160 ),
            color: ColorResources.GREY,
            child: SingleChildScrollView(
              padding:
              const EdgeInsets.only( left: 10, right: 10, top: 0, bottom: 0 ),
              child: TextField(
                controller: feedbackControllerPhone,
                maxLines: null,
                onChanged: (String txt) {},
                style: TextStyle(
                  fontSize: 16,
                  color: ColorResources.GREY,
                ),
                cursorColor: Colors.blue,
                decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: getTranslated('PHONE_NO', context),
                  //'ادخل مقترحاتك هنا'),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}