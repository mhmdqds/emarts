import 'package:contact_egypt/common/shared.dart';
import 'package:contact_egypt/utility/app_constants.dart';
import 'package:contact_egypt/view/base_widget/custom_app_bar.dart';
import 'package:contact_egypt/view/screen/feedback_screen.dart';
import 'package:contact_egypt/view/screen/invite_friend_screen.dart';
import 'package:contact_egypt/view/screen/support/add_ticket_screen.dart';
import 'package:flutter/material.dart';
import 'package:contact_egypt/localization/language_constrants.dart';
import 'package:contact_egypt/provider/auth_provider.dart';
import 'package:contact_egypt/provider/profile_provider.dart';
import 'package:contact_egypt/utility/color_resources.dart';
import 'package:contact_egypt/utility/custom_themes.dart';
import 'package:contact_egypt/utility/dimensions.dart';
import 'package:contact_egypt/utility/images.dart';
import 'package:contact_egypt/view/screen/more/widget/html_view_Screen.dart';

import 'package:contact_egypt/view/screen/setting/settings_screen.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:provider/provider.dart';


class MoreScreen extends StatefulWidget {
  @override
  State<MoreScreen> createState() => _MoreScreenState();
}

class _MoreScreenState extends State<MoreScreen> {
  bool isGuestMode;
  String version;
  bool singleVendor = false;
  BannerAd myBanner;
  AdWidget adWidget;

  @override
  void initState() {
    isGuestMode = !Provider.of<AuthProvider>(context, listen: false).isLoggedIn();
    if(!isGuestMode) {
      Provider.of<ProfileProvider>(context, listen: false).getUserInfo(context);
      version = AppConstants.version;
    }
    Future.delayed(
      Duration.zero,
          () async {
        initAds();
      },
    );
    super.initState();
  }


  Future<void> initAds() async {
    myBanner = await Shared.getBannerAd(MediaQuery.of(context).size.width.toInt());
    await myBanner.load();
    adWidget = AdWidget(ad: myBanner);
    setState(() {});
  }


  @override
  void dispose() {
    myBanner.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {


    return Scaffold(
      body: Stack(children: [
        // Background
        CustomAppBar(title: getTranslated('settings', context), isBackButtonExist: false),



        Container(
          margin: EdgeInsets.only(top: 120),
          decoration: BoxDecoration(
            color: ColorResources.getIconBg(context),
            borderRadius: BorderRadius.only(topLeft: Radius.circular(20), topRight: Radius.circular(20)),
          ),
          child: SingleChildScrollView(
            physics: BouncingScrollPhysics(),
            child: Column(crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  if (adWidget != null)
                    Container(
                      alignment: Alignment.center,
                      child: adWidget,
                      width: myBanner.size.width.toDouble(),
                      height: myBanner.size.height.toDouble(),
                    ),

                  // Buttons
                  //TitleButton(image: Images.notification_filled, title: getTranslated('notification', context), navigateTo: NotificationScreen()),
                  Divider(thickness: .1, color: Theme.of(context).primaryColor),
                  TitleButton(image: Images.contact_us, title: getTranslated('contact_us', context), navigateTo: FeedbackScreen()),
                  Divider(thickness: .1, color: Theme.of(context).primaryColor),
                  TitleButton(image: Images.wish_image, title: getTranslated('share', context), navigateTo: InviteFriend()),
                  //TODO: seller
                  singleVendor?SizedBox():
                  Divider(thickness: .1, color: Theme.of(context).primaryColor),
                  TitleButton(image: Images.settings, title: getTranslated('settings', context), navigateTo: SettingsScreen()),
                  Divider(thickness: .1, color: Theme.of(context).primaryColor),
                  TitleButton(image: Images.preference, title: getTranslated('support_ticket', context), navigateTo: AddTicketScreen()),
                  Divider(thickness: .1, color: Theme.of(context).primaryColor),
                  TitleButton(image: Images.term_condition, title: getTranslated('terms_condition', context), navigateTo: HtmlViewScreen(
                    title: getTranslated('terms_condition', context),
                    url: AppConstants.Privacy,
                  )),
                  Divider(thickness: .1, color: Theme.of(context).primaryColor),
                  TitleButton(image: Images.privacy_policy, title: getTranslated('privacy_policy', context), navigateTo: HtmlViewScreen(
                    title: getTranslated('privacy_policy', context),
                    url: AppConstants.Privacy,
                  )),

                  Divider(thickness: .1, color: Theme.of(context).primaryColor),

                  ListTile(
                    leading: Image.asset(Images.logo_image, width: 25, height: 25, fit: BoxFit.fill, color: ColorResources.getPrimary(context)),
                    title: Text(getTranslated('app_info', context), style: titRegular.copyWith(fontSize: Dimensions.FONT_SIZE_LARGE)),
                    trailing: Text("1.2"),
                  ),
                ]),
          ),
        ),
      ]),
    );
  }
}

class SquareButton extends StatelessWidget {
  final String image;
  final String title;
  final Widget navigateTo;
  final int count;
  final bool hasCount;


  SquareButton({@required this.image, @required this.title, @required this.navigateTo, @required this.count, @required this.hasCount});

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width - 100;
    return InkWell(
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => navigateTo)),
      child: Column(children: [
        Container(
          width: width / 4,
          height: width / 4,
          padding: EdgeInsets.all(Dimensions.PADDING_SIZE_LARGE),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            color: ColorResources.getPrimary(context),
          ),
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              Image.asset(image, color: Theme.of(context).highlightColor),
            ],
          ),
        ),
        Align(
          alignment: Alignment.center,
          child: Text(title, style: titRegular),
        ),
      ]),
    );
  }
}

class TitleButton extends StatelessWidget {
  final String image;
  final String title;
  final Widget navigateTo;
  TitleButton({@required this.image, @required this.title, @required this.navigateTo});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Image.asset(image, width: 25, height: 25, fit: BoxFit.fill, color: ColorResources.getPrimary(context)),
      title: Text(title, style: titRegular.copyWith(fontSize: Dimensions.FONT_SIZE_LARGE)),
      onTap: () => Navigator.push(
        context,
        /*PageRouteBuilder(
            transitionDuration: Duration(seconds: 1),
            pageBuilder: (context, animation, secondaryAnimation) => navigateTo,
            transitionsBuilder: (context, animation, secondaryAnimation, child) {
              animation = CurvedAnimation(parent: animation, curve: Curves.bounceInOut);
              return ScaleTransition(scale: animation, child: child, alignment: Alignment.center);
            },
          ),*/
        MaterialPageRoute(builder: (_) => navigateTo),
      ),
      /*onTap: () => Navigator.push(context, PageRouteBuilder(
        pageBuilder: (context, animation, secondaryAnimation) => navigateTo,
        transitionsBuilder: (context, animation, secondaryAnimation, child) => FadeTransition(opacity: animation, child: child),
        transitionDuration: Duration(milliseconds: 500),
      )),*/
    );
  }
}

