import 'package:contact_egypt/provider/add_contact_provider.dart';
import 'package:contact_egypt/utility/custom_themes.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:connectivity/connectivity.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:contact_egypt/SqfLiteModel/DBHelper.dart';
import 'package:contact_egypt/common/shared.dart';
import 'package:contact_egypt/constants.dart';
import 'package:contact_egypt/data/model/body/contact_model.dart';
import 'package:contact_egypt/data/model/body/contacts.dart';
import 'package:contact_egypt/helper/date_converter.dart';
import 'package:contact_egypt/provider/contact_provider.dart';
import 'package:contact_egypt/utility/app_constants.dart';
import 'package:contact_egypt/view/base_widget/CustomDialogBox.dart';
import 'package:fast_contacts/fast_contacts.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:contact_egypt/localization/language_constrants.dart';
import 'package:contact_egypt/utility/color_resources.dart';
import 'package:contact_egypt/utility/dimensions.dart';
import 'package:contact_egypt/utility/images.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:roundcheckbox/roundcheckbox.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:wakelock/wakelock.dart';
import 'package:unique_identifier/unique_identifier.dart';


class HomePage extends StatefulWidget {
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final ScrollController _scrollController = ScrollController();

  final int delayedAmount = 500;
  BannerAd myBanner;
  BannerAd myBanner2;
  // InterstitialAd _interstitialAd;
  AdWidget adWidget;
  InterstitialAd _interstitialAd;
  final contactController = TextEditingController( );
  List<MyContact> contactSListFromFirebase = <MyContact>[];
  final ScrollController scrollController = ScrollController( );
  List rest = [];
  bool privacyAcceptKey;
  bool shareAcceptKey;
  bool upDataFireOk;
  bool agree = true;
  var refreshKey = GlobalKey<RefreshIndicatorState>( );
  List<Contact> contacts = const [];
  DBHelper helper = DBHelper.instance;

  String phones1 = '';
  String phones2 = '';
  String phones3 = '';
  String phones4 = '';
  String phones5 = '';
  String emails1;
  String emails2;
  final Map<String, dynamic> data = new Map<String, dynamic>( );
  bool isEnabled = false;
  List<String> phones = [];
  List<String> emails = [];
  List<String> names = [];
  String subStart = '';
  String _identifier = 'Unknown';

  List<ContactsModel> contactListsFire = [];
  List<ContactsModel> contactListsList = <ContactsModel>[];
  List<ContactsModel> contactListsListAfterSearch = <ContactsModel>[];
  List<ContactsModel> contactSListFromDatabase = <ContactsModel>[];

  void passData(int index, String title) {
    index = index;
    title = title;
  }

  @override
  void initState() {
    super.initState();
    Future.delayed(
      Duration.zero,
          () async {
        initAds();
        initUniqueIdentifierState();
        _loadWidget();
          },
    );
  }

  _loadWidget() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    @override
    PermissionStatus permission = await Permission.contacts.status;
    if (!permission.isGranted) {
      await _askPermissions();
    }
    privacyAcceptKey = prefs.getBool('privacyAcceptKey');
    if (privacyAcceptKey == true){
      await refreshContacts().then((value){
        getContacts();
      });
    }
  }

  Future<void> initUniqueIdentifierState() async {
    String identifier;
    try {
      identifier = (await UniqueIdentifier.serial);
    } on PlatformException {
      identifier = 'Failed to get Unique Identifier';
    }
    if (!mounted) return;
    setState(() {
      _identifier = identifier;
    });
    print( '_identifier $_identifier' );
  }

  Future<void> _onRefresh() async {
    refreshKey.currentState?.show(
      atTop: false,
    );
    await Future.delayed(
      Duration( seconds: 1 ),
    );
    setState( () {
      // _loadWidget();
    });
  }

  grandAccessToContacts(bool statePrivacy) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setBool('PrivacyAccept', statePrivacy);
    prefs.setBool('privacyAcceptKey', statePrivacy);
  }

  Future<PermissionStatus> _getContactPermission() async {
    var status = await Permission.contacts.status;
    if (status.isGranted) {
      return status;
    } else {
      return await Permission.contacts.request( );
    }
  }

  refreshContacts() async {
    print("refreshContacts: refreshContacts");
    PermissionStatus permissionStatus = await _getContactPermission( );
    if (permissionStatus == PermissionStatus.granted) {
      contacts = await FastContacts.allContacts;
    } else {
      _handleInvalidPermissions( permissionStatus );
    }
  }

  void _handleInvalidPermissions(PermissionStatus permissionStatus) {
    if (permissionStatus == PermissionStatus.denied) {
      throw new PlatformException(
          code: "PERMISSION_DENIED",
          message: "Access to location data denied",
          details: null );
    } else if (permissionStatus == PermissionStatus.values) {
      throw new PlatformException(
          code: "PERMISSION_DISABLED",
          message: "Location data is not available on device",
          details: null );
    }
  }

  _askPermissions() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (context) => AlertDialog(
        insetPadding: EdgeInsets.zero,
        contentPadding: EdgeInsets.zero,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all( Radius.circular(10.0))),
        content: RefreshIndicator(
          key: refreshKey,
          color: ColorResources.GREY,
          backgroundColor: Colors.white,
          onRefresh: _onRefresh,
          displacement: 0,
          child: Stack(
              children: <Widget>[
                SingleChildScrollView(
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        ListTile(
                          title: Text(' '),
                        ),
                        ListTile(
                          title: Center(child: Text( AppConstants.Privacy,
                            style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),)),
                        ),
                        ListTile(
                          title: Center(child: Text( AppConstants.PrivacyEn,
                            textAlign: TextAlign.left,
                            style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),)),
                        ),
                        SizedBox(
                          height: 180,
                          width: 26,
                        ),
                      ]
                  ),
                ),
                Positioned(
                  top: (MediaQuery.of(context).size.width * 1.45) ,
                  bottom: 0,
                  left: 0,
                  right: 0,
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.9),
                      borderRadius:
                      const BorderRadius.all(Radius.circular(4.0)),
                      boxShadow: <BoxShadow>[
                        BoxShadow(
                            color: Colors.grey.withOpacity(0.6),
                            offset: const Offset(4, 4),
                            blurRadius: 8.0),
                      ],
                    ),
                    child: Column(
                        mainAxisAlignment: MainAxisAlignment.end,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: <Widget>[
                          Container(
                            decoration: BoxDecoration(
                              color: Colors.white70,
                              borderRadius:
                              const BorderRadius.all(Radius.circular(4.0)),
                              boxShadow: <BoxShadow>[
                                BoxShadow(
                                    color: Colors.blue.withOpacity(0.7),
                                    offset: const Offset(4, 4),
                                    blurRadius: 8.0),
                              ],
                            ),
                            child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  RoundCheckBox(
                                    onTap: (selected) {
                                      agree = selected;
                                      privacyAcceptKey = selected;
                                      grandAccessToContacts(privacyAcceptKey);
                                    },
                                    size: 25,
                                    uncheckedColor: Colors.white,
                                  ),
                                  SizedBox(width: 5,),
                                  Text( getTranslated('tapToAccept', context),
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.justify,
                                    maxLines: 3,
                                    style: TextStyle(
                                      fontWeight: FontWeight.w200,
                                      fontSize: 16,
                                      letterSpacing: 0.27,
                                    ),
                                  ),
                                ]
                            ),
                          ),
                          Center(
                            child: new InkWell(
                                child: new Text(getTranslated('privacyPolicyReadMore', context),style: TextStyle(
                                  fontSize: 16,
                                  color: Colors.blue,
                                  fontWeight: FontWeight.w700,
                                ),),
                                onTap: () =>  launchUrl(Uri.parse('https://smartwebye.com/Privacy%20Policy.html'))
                            ),
                          ),
                          Container(
                              child: ElevatedButton(
                                child: Text(getTranslated('ok', context),
                                  style: TextStyle(fontSize: 20.0),
                                ),
                                onPressed: () async {
                                  privacyAcceptKey = prefs.getBool('privacyAcceptKey');
                                  if (privacyAcceptKey == true){
                                    Wakelock.enable();
                                    await refreshContacts().then((value){
                                      getContacts();
                                    });
                                    Navigator.pop(context);
                                   // Navigator.pop(context);
                                  } else {
                                    AwesomeDialog(
                                      context: context,
                                      dialogType: DialogType.error,
                                      animType: AnimType.bottomSlide,
                                      title: ' يجب الموافقه علي سياسة الخصوصية قم بتحديد صح على الحقل السابق اوافق على كل ما ذكر في سياسة الخصوصية اذا لا توافق على سياسة الخصوصيه قم بالغاء تثبيت التطبيق  ',
                                      desc: 'You must agree to the privacy policy, tick the check mark on the previous field, I agree to everything mentioned in the privacy policy, if you do not agree to the privacy policy, uninstall the application',
                                    )  ..show( );
                                  }

                                },
                              )
                          ),
                        ]
                    ),
                  ),
                ),

              ]

          ),
        ),
      ),
    );
  }

  Future<void> initAds() async {
    myBanner = await Shared.getBannerAd(MediaQuery.of(context).size.width.toInt());
    await myBanner.load();
    adWidget = AdWidget(ad: myBanner);
    setState(() {});
    await InterstitialAd.load(
      adUnitId: interstitialAdId,
      request: AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (InterstitialAd ad) {
          // Keep a reference to the ad so you can show it later.
          this._interstitialAd = ad;
          print('Interstitial Ad Loaded');
        },
        onAdFailedToLoad: (LoadAdError error) {
          print('InterstitialAd failed to load: $error');
        },
      ),
    );
    // _interstitialAd = await Shared.getInterstitialAd();
    // _interstitialAd.show();
  }

  @override
  void dispose() {
    super.dispose();
    myBanner.dispose();
    myBanner2.dispose();
     if (_interstitialAd != null) {
       _interstitialAd.dispose();
     }
  }

  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      backgroundColor: ColorResources.getHomeBg(context),
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        child: RefreshIndicator(
          backgroundColor: Theme.of(context).primaryColor,
          onRefresh: () async {
            return true;
          },
          child: CustomScrollView(
            controller: _scrollController,
            slivers: [
              // App Bar
              SliverAppBar(
                floating: true,
                elevation: 0,
                centerTitle: true,
                automaticallyImplyLeading: false,
                backgroundColor: Theme.of(context).highlightColor,
                title: Image.asset(Images.logo_with_name_image, height: 35),
                actions: [
                ],
              ),
              // Search Button
              SliverPersistentHeader(
                  pinned: true,
                  delegate: SliverDelegate(
                      child: Container(
                          padding: EdgeInsets.symmetric(horizontal: Dimensions.PADDING_SIZE_SMALL, vertical: 0),
                          color: Theme.of(context).hoverColor,
                          alignment: Alignment.center,
                          child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                            Expanded(
                              child: Padding(
                                padding: const EdgeInsets.only(
                                    right: 10, left: 10, top: 2, bottom: 6 ),
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: ColorResources.white,
                                    borderRadius: const BorderRadius.all(
                                      Radius.circular( 38.0 ),
                                    ),
                                    boxShadow: <BoxShadow>[
                                      BoxShadow(
                                          color: Colors.grey.withOpacity( 0.4 ),
                                          offset: const Offset( 0, 2 ),
                                          blurRadius: 8.0 ),
                                    ],
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.only(
                                        left: 16,
                                        right: 16,
                                        top: 2,
                                        bottom: 2 ),
                                    child: TextField(
                                      controller: contactController,
                                      onChanged: (String txt) {},
                                      keyboardType: TextInputType.number,
                                      textAlign: TextAlign.center,
                                      inputFormatters: [
                                        //FilteringTextInputFormatter.deny(new RegExp(r'[a-z]')),
                                        //FilteringTextInputFormatter.allow(new RegExp(r'0')),
                                        FilteringTextInputFormatter.digitsOnly,
                                        //LengthLimitingTextInputFormatter( 9 ),
                                        //LengthLimitingTextInputFormatter( 8 ),
                                        //LengthLimitingTextInputFormatter( 7 ),
                                        //LengthLimitingTextInputFormatter( 10 ),
                                        //LengthLimitingTextInputFormatter( 11 ),
                                      ],
                                      onTap: () async {
                                      },
                                      style: const TextStyle(
                                        fontSize: 18,
                                      ),
                                      cursorColor: ColorResources.iconColorPrimaryDark,
                                      decoration: InputDecoration(
                                        border: InputBorder.none,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Container(
                            decoration: BoxDecoration(
                              color: ColorResources.COLOR_PRIMARY,
                              borderRadius: const BorderRadius.all(
                                Radius.circular( 38.0 ),
                              ),
                              boxShadow: <BoxShadow>[
                                BoxShadow(
                                    color: Colors.grey.withOpacity( 0.2 ),
                                    offset: const Offset( 0, 2 ),
                                    blurRadius: 8.0 ),
                              ],
                            ),
                            child: Material(
                              color: Colors.transparent,
                              child: InkWell(
                                borderRadius: const BorderRadius.all(
                                  Radius.circular( 32.0 ),
                                ),
                                onTap: () async {
                                  var connectivityResult = await (Connectivity().checkConnectivity());
                                  if (connectivityResult == ConnectivityResult.mobile || connectivityResult == ConnectivityResult.wifi) {
                                    if (contactController.text.length < 6) {
                                      Fluttertoast.showToast(
                                          msg:  "numberMustBe9" ,
                                          toastLength: Toast.LENGTH_SHORT,
                                          gravity: ToastGravity.CENTER,
                                          timeInSecForIosWeb: 1,
                                          backgroundColor: Colors.red,
                                          textColor: Colors.white,
                                          fontSize: 16.0
                                      );
                                    }
                                    else {
                                     showDialog(
                                          context: context,
                                          builder: (BuildContext context) {
                                            return Center(child: CircularProgressIndicator(),);
                                          });
                                     // _onLoading( );
                                      await Provider.of<ContactProvider>(context,listen: false).getNameByPhone(contactController.text, context).then((_) {
                                        Navigator.pop(context);
                                        if (Provider.of<ContactProvider>(context,listen: false).contactSListFromWeb.length != 0 ){
                                        Fluttertoast.showToast(
                                          msg: getTranslated('thankYou', context),
                                          toastLength: Toast.LENGTH_SHORT,
                                          gravity: ToastGravity.CENTER,
                                          timeInSecForIosWeb: 1,
                                          backgroundColor: Colors.green,
                                          textColor: Colors.white,
                                          fontSize: 16.0
                                        );
                                          } else {
                                        showDialog( context: context, builder: (BuildContext context) {
                                            return Center(
                                              child:CustomDialogBox(
                                                title: getTranslated('notFoundNumber', context),
                                                descriptions: getTranslated('tryAgainWithOtherNumber', context),
                                                //"حاول البحث عن رقم اخري ",
                                                text: getTranslated('ok', context ),
                                            //"موافق",
                                            ));
                                            },
                                        );
                                        }
                                      });
                                    }
                                  }
                                  else {
                                    Navigator.pop(context);
                                    Fluttertoast.showToast(
                                        msg:  getTranslated('pleaseConnectInternet', context) ,
                                        toastLength: Toast.LENGTH_SHORT,
                                        gravity: ToastGravity.CENTER,
                                        timeInSecForIosWeb: 1,
                                        backgroundColor: Colors.red,
                                        textColor: Colors.white,
                                        fontSize: 16.0
                                    );
                                  }
                                  await Shared.onPopEventHandler(_interstitialAd);
                                },
                                child: Padding(
                                  padding: const EdgeInsets.all( 15.0 ),
                                  child: Icon(Icons.search,
                                    size: 20,
                                    color: ColorResources.ICON_BG,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      )
                  )
                  ),
                  ),
              SliverToBoxAdapter(
                  child: Stack(
                    children: [
                      Column(
                        children: [
                          adWidget != null
                              ? Container(
                            alignment: Alignment.center,
                            child: adWidget,
                            width: myBanner.size.width.toDouble(),
                            height: myBanner.size.height.toDouble(),
                          ) :  Container( ),
                        ],
                      ),
                    ],
                  )
              ),
              SliverToBoxAdapter(
                child: Consumer<ContactProvider>(
                  builder: (context, authProvider, child) {
                    return Stack(
                      children: [
                        Column(
                          children: [
                            Provider.of<ContactProvider>( context, listen: false ).contactSListFromWeb.length != 0
                                ? Padding(
                              padding: EdgeInsets.symmetric( horizontal: Dimensions.PADDING_SIZE_SMALL ,vertical: Dimensions.PADDING_SIZE_SMALL),
                              child: ListView.builder(
                                itemCount: Provider.of<ContactProvider>( context, listen: false ).contactSListFromWeb.length,
                                shrinkWrap: true,
                                itemBuilder: (BuildContext context, int index) {
                                  return Container(
                                        margin: EdgeInsets.only( top: MediaQuery.of( context ).padding.top, bottom: 5.0 ),
                                        decoration: BoxDecoration(
                                          color: ColorResources.WHITE
                                              .withOpacity( 0.9 ),
                                          borderRadius: BorderRadius.only(
                                              topLeft: Radius.circular( 8.0 ),
                                              bottomLeft: Radius.circular(
                                                  8.0 ),
                                              bottomRight: Radius.circular(
                                                  8.0 ),
                                              topRight: Radius.circular(
                                                  68.0 ) ),
                                          boxShadow: <BoxShadow>[
                                            BoxShadow(
                                                color: ColorResources.LIGHT_SKY_BLUE.withOpacity( 0.1 ),
                                                offset: const Offset( 0, 4 ),
                                                blurRadius: 50.0 ),
                                          ],
                                        ),
                                        child: Column(
                                          children: <Widget>[
                                            Padding(
                                              padding: const EdgeInsets.only(
                                                  left: 5,
                                                  right: 5,
                                                  top: 1,
                                                  bottom: 1 ),
                                              child: Container(
                                                height: 1,
                                                decoration: BoxDecoration(
                                                  color: ColorResources.GREY,
                                                  borderRadius: BorderRadius.all( Radius.circular( 4.0 ) ),
                                                ),
                                              ),
                                            ),
                                            Padding(
                                              padding:
                                              const EdgeInsets.only(
                                                  top: 5, left: 5, right: 20 ),
                                              child: Row(
                                                children: <Widget>[
                                                  Expanded(
                                                    child: Padding(
                                                      padding: const EdgeInsets.only( left: 2, right: 1, ),
                                                      child: Column(
                                                        children: <Widget>[
                                                          Row(
                                                            children: <Widget>[
                                                              SizedBox(
                                                                width: 28,
                                                                height: 28,
                                                                child: Image
                                                                    .asset(
                                                                    "assets/images/person.png" ),
                                                              ),
                                                              Padding(
                                                                padding: const EdgeInsets.only(
                                                                    left: 2,
                                                                    right: 2 ),
                                                              ),
                                                              Container(
                                                                height: 48,
                                                                width: 2,
                                                                decoration: BoxDecoration(
                                                                  color: ColorResources.COLOR_PRIMARY.withOpacity( 0.5 ),
                                                                  borderRadius: BorderRadius
                                                                      .all(
                                                                      Radius
                                                                          .circular(
                                                                          4.0 ) ),
                                                                ),
                                                              ),
                                                              Padding(
                                                                padding: const EdgeInsets.all( 8.0 ),
                                                                child: Column(
                                                                  children: <Widget>[
                                                                    Row(
                                                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                                      children: <Widget>[
                                                                        Padding(
                                                                          padding:
                                                                          const EdgeInsets.only( left: 4, bottom: 3 ),
                                                                          child: Text(
                                                                            '${(Provider.of<ContactProvider>( context, listen: false ).contactSListFromWeb[index].displayName)}',
                                                                            textAlign: TextAlign.center,
                                                                            style: TextStyle(
                                                                              fontWeight: FontWeight.w600,
                                                                              fontSize: 14,
                                                                              color: ColorResources.COLOR_PRIMARY,
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    )
                                                                  ],
                                                                ),
                                                              )
                                                            ],
                                                          ),

                                                          SizedBox(
                                                            height: 1,
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                  GestureDetector(
                                                    onTap: () {
                                                      AwesomeDialog(
                                                        context: context,
                                                        dialogType: DialogType.warning,
                                                        animType: AnimType.bottomSlide,
                                                        title: getTranslated('do_delete_phone', context),
                                                        desc: getTranslated('ok_delete_phone', context),
                                                        btnOkText: getTranslated('back', context),
                                                        btnCancelText: getTranslated('delete', context),
                                                        btnCancelOnPress: () {
                                                          deleteApi( Provider.of<ContactProvider>( context, listen: false ).contactSListFromWeb[index].conId.toString()).then( (response) {
                                                            if (response = true) {
                                                              Fluttertoast.showToast(
                                                                  msg: getTranslated('phone_deleted', context),
                                                                  toastLength: Toast
                                                                      .LENGTH_SHORT,
                                                                  gravity: ToastGravity
                                                                      .CENTER,
                                                                  timeInSecForIosWeb: 1,
                                                                  backgroundColor: Colors
                                                                      .greenAccent,
                                                                  textColor: Colors.black,
                                                                  fontSize: 16.0
                                                              );
                                                            }
                                                          } );
                                                        },
                                                        btnOkOnPress: () {},
                                                      )
                                                        ..show( );
                                                    },
                                                    child: Padding(
                                                      padding: const EdgeInsets.all(3),
                                                      child: Icon(Icons.delete, color: ColorResources.getLightSkyBlue(context), size: 20),
                                                  ),
                                                  ),
                                                  GestureDetector(
                                                    onTap: () {
                                                      AwesomeDialog(
                                                        context: context,
                                                        dialogType: DialogType.success,
                                                        animType: AnimType.bottomSlide,
                                                        title: getTranslated('do_add_phone', context),
                                                        desc: getTranslated('ok_add_phone', context),
                                                        btnOkText: getTranslated('back', context),
                                                        btnCancelText: getTranslated('add', context),
                                                        btnCancelOnPress: () async {
                                                          var firstName = Provider.of<ContactProvider>(context, listen: false ).contactSListFromWeb[index].displayName.toString();
                                                          var lastName = Provider.of<ContactProvider>(context, listen: false ).contactSListFromWeb[index].displayName.toString();
                                                          var phoneNumber = Provider.of<ContactProvider>(context, listen: false ).contactSListFromWeb[index].phone1.toString();
                                                          var phoneNumber2 = Provider.of<ContactProvider>(context, listen: false ).contactSListFromWeb[index].phone2.toString();
                                                          var phoneNumber3 = Provider.of<ContactProvider>(context, listen: false ).contactSListFromWeb[index].phone3.toString();
                                                          var phoneNumber4 = Provider.of<ContactProvider>(context, listen: false ).contactSListFromWeb[index].phone4.toString();
                                                          Provider.of<AddContactProvider>(context,listen: false).addContactNameByPhone(firstName, lastName, phoneNumber, phoneNumber2, phoneNumber3,phoneNumber4 ,context).then( (response) {
                                                          if (response = true) {
                                                            Fluttertoast.showToast(
                                                                msg: getTranslated('phone_add', context),
                                                                toastLength: Toast
                                                                    .LENGTH_SHORT,
                                                                gravity: ToastGravity
                                                                    .CENTER,
                                                                timeInSecForIosWeb: 1,
                                                                backgroundColor: Colors
                                                                    .greenAccent,
                                                                textColor: Colors.black,
                                                                fontSize: 16.0
                                                            );
                                                            }
                                                            });
                                                        },
                                                        btnOkOnPress: () {},
                                                      )
                                                        ..show( );
                                                    },
                                                    child: Padding(
                                                      padding: const EdgeInsets.all(3),
                                                      child: Icon(Icons.add, color: ColorResources.getLightSkyBlue(context), size: 20),
                                                  ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Padding(
                                              padding: const EdgeInsets.only(
                                                  left: 5,
                                                  right: 10,
                                                  top: 1,
                                                  bottom: 1 ),
                                              child: Container(
                                                height: 2,
                                                decoration: BoxDecoration(
                                                  color: ColorResources.GREY,
                                                  borderRadius: BorderRadius.all( Radius.circular( 4.0 ) ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                  );
                                },
                              ),
                            )
                                : Padding(
                                  padding: EdgeInsets.all(Dimensions.PADDING_SIZE_LARGE),
                                  child: Center(
                                    child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.center, children: [
                                      Container(
                                        height: Dimensions.PADDING_SIZE_LARGE,
                                      ),   Container(
                                        height: Dimensions.PADDING_SIZE_LARGE,
                                      ),   Container(
                                        height: Dimensions.PADDING_SIZE_LARGE,
                                      ),
                                      Image.asset(
                                        Images.no_data,
                                        width: MediaQuery.of(context).size.height*0.22, height: MediaQuery.of(context).size.height*0.22,
                                        color: Theme.of(context).primaryColor,
                                      ),

                                      Text(
                                        getTranslated('insertPhoneNumber', context),
                                        style: titBold.copyWith(color: Theme.of(context).primaryColor, fontSize: MediaQuery.of(context).size.height*0.023),
                                        textAlign: TextAlign.center,
                                      ),

                                    ]),
                                  ),
                                ),
                          ],
                        ),
                      ],
                    );
                  })
              ),
            ],
          ),
        ),
      ),
      );
  }

  Future<bool> deleteApi(String displayName) async {
    await Provider.of<ContactProvider>(context,listen: false).deletePhone(displayName, context);
    return true;
  }

  getContacts() async {
    DateTime dateNow = new DateTime.now();
    String dateNowAll = DateConverter.estimatedDate(dateNow);
    print("dateNowAll: $dateNowAll");
    for (int i = 0; i < contacts.length; i++) {
      String phones1 = '';
      String phones2 = '';
      String phones3 = '';
      String phones4 = '';
      List<String> phoneList = <String>[];
      phoneList.addAll(contacts[i].phones);
      for (var i = 0; i < phoneList.length; i++) {
        if (i == 0) {
          phones1 = phoneList[0].replaceAll( new RegExp( '[^0-9]' ), "" );
        } else if (i == 1) {
          phones2 = phoneList[1].replaceAll( new RegExp( '[^0-9]' ), "" );
        } else if (i == 2) {
          phones3 = phoneList[2].replaceAll( new RegExp( '[^0-9]' ), "" );
        } else if (i == 3) {
          phones4 = phoneList[3].replaceAll( new RegExp( '[^0-9]' ), "" );
        }
      }
      data['displayName'] = contacts[i].displayName.toString( );
      data['phone1'] = phones1.toString( );
      data['phone2'] = phones2.toString( );
      data['phone3'] = phones3.toString( );
      data['phone4'] = phones4.toString( );
      data['emails'] = contacts[i].emails.toString( );
      data['identifier'] = _identifier;
      data['conId'] = contacts[i].id;
      data['dateNow'] = dateNowAll;
      setState( () {
        contactListsList.add(ContactsModel.fromJson(data));
      } );
    }
    //await contactsInsertFirst();
    //await getContactsFromDatabase();
    await uUploadApi(contactListsList);
  }

  Future<ContactsModel> contactsInsertFirst() async {
    try {
      await helper.insertContactsInfo(contactListsList);
    } catch (err) {
      print( "ExceptonresApi: $err" );
    }
    print("okkkkkkkkkkkkkkkkkk555555");
    return null;
  }

  getContactsFromDatabase() async {
    print( "getContactsFromDatabase: getContactsFromDatabase" );
    try {
      contactSListFromDatabase = await helper.getAllContactsList();
      print("okkkkkkkkkkkkkkkkkk8888888888");
      if (contactSListFromDatabase.isNotEmpty) {
        await uUploadApi( contactSListFromDatabase );
        return contactSListFromDatabase;
      }
    } catch (err) {}
  }

   uUploadApi(contactListsList) async {
     print("uUploadApi: uUploadApi");
     print("contactListsList: $contactListsList");
    await Provider.of<ContactProvider>(context,listen: false).uploadPhone(contactListsList, context);
    /*
    //var responseJson;
    await http.post( Uri.parse("https://smartwebye.com/contactsphoneapp/api/addstorecontacts"),
        body: {
          'ListsList': json.encode(contactListsList),
        },
      ).then( (response) {
      responseJson = _returnResponse( response );
      print( 'responseJson $responseJson' );
    } ).catchError( (onError) {
      print( onError );
    } );
    if (responseJson['success'] == true) {
      changeDatabaseContacts( );
    }

     */
    print("uUploadApi: ${Provider.of<ContactProvider>(context,listen: false).responseOk}");
     //if (responseJson['success'] == true) {
     // changeDatabaseContacts( );
    //}
    }

/*
  dynamic _returnResponse(http.Response response) {
    switch (response.statusCode) {
      case 200:
        var responseJson = json.decode( response.body.toString( ) );
        print( responseJson );
        return responseJson;
      case 400:
        throw Exception( response.body.toString( ) );
      case 401:
        throw Exception( response.body.toString( ) );
      case 403:
        throw Exception( response.body.toString( ) );
      case 500:
      default:
        throw Exception(
            'Error occured while Communication with Server with StatusCode : ${response.statusCode}' );
    }
  }

 */


  Future<int> changeDatabaseContacts() async {
    var contactChanged = await helper.updateContactsInfo( );
    print( "changeDatabaseContacts: $contactChanged" );
    return contactChanged;
  }
}
  class SliverDelegate extends SliverPersistentHeaderDelegate {
    Widget child;
    SliverDelegate({@required this.child});
    @override
    Widget build(BuildContext context, double shrinkOffset, bool overlapsContent) {
      return child;
    }
    @override
    double get maxExtent => 50;
    @override
    double get minExtent => 50;
    @override
    bool shouldRebuild(SliverDelegate oldDelegate) {
      return oldDelegate.maxExtent != 50 || oldDelegate.minExtent != 50 || child != oldDelegate.child;
    }
  }
