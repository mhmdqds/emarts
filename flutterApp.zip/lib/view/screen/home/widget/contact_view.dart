import 'package:contact_egypt/provider/contact_provider.dart';
import 'package:contact_egypt/utility/color_resources.dart';
import 'package:contact_egypt/utility/custom_themes.dart';
import 'package:contact_egypt/utility/dimensions.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shimmer/shimmer.dart';

class ContactView extends StatelessWidget {
  final bool isHomePage;
  ContactView({@required this.isHomePage});

  @override
  Widget build(BuildContext context) {

    return Consumer<ContactProvider>(
      builder: (context, brandProvider, child) {
        return brandProvider.contactSListFromWeb.length != 0 ? GridView.builder(
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 4,
            childAspectRatio: (1/1.3),
            mainAxisSpacing: 10,
            crossAxisSpacing: 5,
          ),
          itemCount: brandProvider.contactSListFromWeb.length != 0
              ? isHomePage
              ? brandProvider.contactSListFromWeb.length > 8
              ? 8
              : brandProvider.contactSListFromWeb.length
              : brandProvider.contactSListFromWeb.length
              : 8,
          shrinkWrap: true,
          physics: isHomePage ? NeverScrollableScrollPhysics() : BouncingScrollPhysics(),
          itemBuilder: (BuildContext context, int index) {

            return InkWell(
              onTap: () {

              },
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Center(child: Text(
                    brandProvider.contactSListFromWeb[index].displayName,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: titSemiBold.copyWith(fontSize: Dimensions.FONT_SIZE_SMALL),
                  )),
                ],
              ),
            );

          },
        ) : BrandShimmer(isHomePage: isHomePage);

      },
    );
  }
}

class BrandShimmer extends StatelessWidget {
  final bool isHomePage;
  BrandShimmer({@required this.isHomePage});

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 4,
        childAspectRatio: (1/1.3),
        mainAxisSpacing: 10,
        crossAxisSpacing: 5,
      ),
      itemCount: isHomePage ? 8 : 30,
      shrinkWrap: true,
      physics: isHomePage ? NeverScrollableScrollPhysics() : null,
      itemBuilder: (BuildContext context, int index) {

        return Shimmer.fromColors(
          baseColor: Colors.grey[300],
          highlightColor: Colors.grey[100],
          enabled: Provider.of<ContactProvider>(context).contactSListFromWeb.length == 0,
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Expanded(child: Container(decoration: BoxDecoration(color: ColorResources.WHITE, shape: BoxShape.circle))),
            Container(height: 10, color: ColorResources.WHITE, margin: EdgeInsets.only(left: 25, right: 25)),
          ]),
        );

      },
    );
  }
}
