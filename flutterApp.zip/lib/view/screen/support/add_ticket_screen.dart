import 'package:contact_egypt/common/shared.dart';
import 'package:contact_egypt/constants.dart';
import 'package:contact_egypt/view/base_widget/custom_app_bar.dart';
import 'package:flutter/material.dart';
import 'package:contact_egypt/data/model/body/support_ticket_body.dart';

import 'package:contact_egypt/localization/language_constrants.dart';
import 'package:contact_egypt/provider/support_ticket_provider.dart';
import 'package:contact_egypt/utility/color_resources.dart';
import 'package:contact_egypt/utility/custom_themes.dart';
import 'package:contact_egypt/utility/dimensions.dart';
import 'package:contact_egypt/view/base_widget/button/custom_button.dart';
import 'package:contact_egypt/view/base_widget/show_custom_snakbar.dart';
import 'package:contact_egypt/view/base_widget/textfield/custom_textfield.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:provider/provider.dart';

class AddTicketScreen extends StatefulWidget {
  @override
  _AddTicketScreenState createState() => _AddTicketScreenState();
}

class _AddTicketScreenState extends State<AddTicketScreen> {
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _subjectController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  final FocusNode _phoneNode = FocusNode();
  final FocusNode _subjectNode = FocusNode();
  final FocusNode _descriptionNode = FocusNode();
  final GlobalKey<ScaffoldMessengerState> _scaffoldKey = GlobalKey<ScaffoldMessengerState>();
  BannerAd myBanner;
  BannerAd myBanner2;
  InterstitialAd _interstitialAd;
  AdWidget adWidget;

  @override
  void initState() {
    super.initState();
    Future.delayed(
      Duration.zero,
          () async {
        initAds();
      },
    );
  }

  Future<void> initAds() async {
    myBanner = await Shared.getBannerAd(MediaQuery.of(context).size.width.toInt());
    await myBanner.load();
    adWidget = AdWidget(ad: myBanner);
    setState(() {});
    await InterstitialAd.load(
      adUnitId: interstitialAdId,
      request: AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (InterstitialAd ad) {
          // Keep a reference to the ad so you can show it later.
          this._interstitialAd = ad;
          print('Interstitial Ad Loaded');
        },
        onAdFailedToLoad: (LoadAdError error) {
          print('InterstitialAd failed to load: $error');
        },
      ),
    );
    // _interstitialAd = await Shared.getInterstitialAd();
    // _interstitialAd.show();
  }

  @override
  void dispose() {
    super.dispose();
    myBanner.dispose();
    myBanner2.dispose();
    if (_interstitialAd != null) {
      _interstitialAd.dispose();
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Column(children: [
        CustomAppBar(title: getTranslated('issue_ticket', context), isBackButtonExist: false),

          Expanded(
            child:  ListView( physics: BouncingScrollPhysics(), padding: EdgeInsets.all(Dimensions.PADDING_SIZE_LARGE), children: [

              SizedBox(height: Dimensions.PADDING_SIZE_EXTRA_LARGE),

              Container(
                color: ColorResources.getLowGreen(context),
                margin: EdgeInsets.only(bottom: Dimensions.PADDING_SIZE_LARGE),
                child: ListTile(
                  leading: Icon(Icons.query_builder, color: ColorResources.getPrimary(context)),
                  title: Text(getTranslated('ticket_description', context), style: robotoBold),
                  onTap: () {},
                ),
              ),
              Column(
                children: [
                  adWidget != null
                      ? Container(
                    alignment: Alignment.center,
                    child: adWidget,
                    width: myBanner.size.width.toDouble(),
                    height: myBanner.size.height.toDouble(),
                  ) :  Container( ),
                ],
              ),
                CustomTextField(
                  focusNode: _phoneNode,
                  nextNode: _subjectNode,
                  textInputAction: TextInputAction.next,
                  hintText: getTranslated('enter_phone_number', context),
                  controller: _phoneController,
                ),
                SizedBox(height: Dimensions.PADDING_SIZE_LARGE),


                CustomTextField(
                focusNode: _subjectNode,
                nextNode: _descriptionNode,
                textInputAction: TextInputAction.next,
                hintText: getTranslated('write_your_subject', context),
                controller: _subjectController,
              ),
              SizedBox(height: Dimensions.PADDING_SIZE_LARGE),

              CustomTextField(
                focusNode: _descriptionNode,
                textInputAction: TextInputAction.newline,
                hintText: getTranslated('issue_description', context),
                textInputType: TextInputType.multiline,
                controller: _descriptionController,
                maxLine: 5,
              ),
              SizedBox(height: Dimensions.PADDING_SIZE_EXTRA_LARGE),

              Provider.of<SupportTicketProvider>(context).isLoading
                  ? Center(child: CircularProgressIndicator(valueColor: AlwaysStoppedAnimation<Color>(Theme.of(context).primaryColor)))
                  : Builder(
                key: _scaffoldKey,
                builder: (context) => CustomButton(
                    buttonText: getTranslated('submit', context),
                    onTap: () {
                      if (_subjectController.text.isEmpty) {
                        showCustomSnackBar('Subject box should not be empty', context);
                      } else if (_descriptionController.text.isEmpty) {
                        showCustomSnackBar('Description box should not be empty', context);
                      } else {
                        SupportTicketBody supportTicketModel = SupportTicketBody(_phoneController.text, _subjectController.text, _descriptionController.text);
                        Provider.of<SupportTicketProvider>(context, listen: false).sendSupportTicket(supportTicketModel, callback, context);
                      }
                    }),
              ),

            ]
        ),
        ),
    ])
    );
  }

  void callback (bool isSuccess, String message) {
    print(message);
    if (isSuccess) {
      _phoneController.text = '';
      _subjectController.text = '';
      _descriptionController.text = '';
        Fluttertoast.showToast(
            msg: getTranslated('thankYou', context),
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.greenAccent,
            textColor: Colors.black,
            fontSize: 16.0
        );
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => AddTicketScreen()));
    } else {}
  }
}
