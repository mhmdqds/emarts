import 'package:flutter/material.dart';

class ColorResources {

  static const Color primaryColor = Color(0xFF645BC4);
  static const Color primaryLightColor = Color(0xFFE8F5E9);
  static const Color white = Color.fromRGBO(255,255,255, 1);
  static const Color lightGrey = Color.fromRGBO(239,239,239, 1);
  static const Color darkGrey = Color.fromRGBO(112,112,112, 1);
  static const Color mediumGrey = Color.fromRGBO(132,132,132, 1);
  static const Color grey_153 = Color.fromRGBO(153,153,153, 1);
  static const Color fontGrey = Color.fromRGBO(22, 29, 50, 1);
  static const Color textFieldGrey = Color.fromRGBO(209,209,209, 1);
  static const Color golden = Color.fromRGBO(248, 181, 91, 1);
  static const Color mediumGrey_50 = Color.fromRGBO(132,132,132, .5);
  static const Color appColorPrimary = Color(0xFF1157FA);
  static const Color appColorAccent = Color(0xFF03DAC5);
  static const Color appTextColorPrimary = Color(0xFF212121);
  static const Color iconColorPrimary = Color(0xFFFFFFFF);
  static const Color appTextColorSecondary = Color(0xFF5A5C5E);
  static const Color iconColorSecondary = Color(0xFFA8ABAD);
  static const Color appLayoutBackground = Color(0xFFf8f8f8);
  static const Color appLightPurple = Color(0xFFdee1ff);
  static const Color appLightOrange = Color(0xFFffddd5);
  static const Color appLightParrotGreen = Color(0xFFb4ef93);
  static const Color appIconTintCherry = Color(0xFFffddd5);
  static const Color appIconTintSkyBlue = Color(0xFF73d8d4);
  static const Color appIconTintMustardYellow = Color(0xFFffc980);
  static const Color appIconTintDarkPurple = Color(0xFF8998ff);
  static const Color appTxtTintDarkPurple = Color(0xFF515BBE);
  static const Color appIconTintDarkCherry = Color(0xFFf2866c);
  static const Color appIconTintDarkSkyBlue = Color(0xFF73d8d4);
  static const Color appDarkParrotGreen = Color(0xFF5BC136);
  static const Color appDarkRed = Color(0xFFF06263);
  static const Color appLightRed = Color(0xFFF89B9D);
  static const Color appCat1 = Color(0xFF8998FE);
  static const Color appCat2 = Color(0xFFFF9781);
  static const Color appCat3 = Color(0xFF73D7D3);
  static const Color appCat4 = Color(0xFF87CEFA);
  static const Color appCat5 = appColorPrimary;
  static const Color appShadowColor = Color(0x95E9EBF0);
  static const Color appColorPrimaryLight = Color(0xFFF9FAFF);
  static const Color appSecondaryBackgroundColor = Color(0xFF131d25);
  static const Color appDividerColor = Color(0xFFDADADA);
  static const Color  barber = Color(0xFFD1870B);
  static const Color  barber2 = Color(0xFF9B7C3D);
  static const Color  barber3 = Color(0xFFD7B56F);
  static const Color  barber4 = Color(0xFFBC8514);
  static const Color  bellCommerce = Color(0xFF40BFFF);
  static const Color  food = Color(0xFFFF0303);
  static const Color  furn = Color(0xFF5866A4);
  static const Color  rest = Color(0xFFFFEBA1);
  static const Color  shu = Color(0xFFF6402E);
  static const Color  treShop = Color(0xFFFC8080);
// Dark Theme Colors
  static const Color appBackgroundColorDark = Color(0xFF121212);
  static const Color cardBackgroundBlackDark = Color(0xFF1F1F1F);
  static const Color colorPrimaryBlack = Color(0xFF131d25);
  static const Color appColorPrimaryDarkLight = Color(0xFFF9FAFF);
  static const Color iconColorPrimaryDark = Color(0xFF212121);
  static const Color iconColorSecondaryDark = Color(0xFFA8ABAD);
  static const Color appShadowColorDark = Color(0x1A3E3942);
  static const Color  background = Color(0xFFFFFFFF);
  static const Color  card = Color(0xFFF8F8F8);
  static const Color  fontTitle = Color(0xFF202020);
  static const Color  fontSubtitle = Color(0xFF737373);
  static const Color  fontDisable = Color(0xFF9B9B9B);
  static const Color  disabledButton = Color(0xFFB9B9B9);
  static const Color  divider = Color(0xFFDCDCDC);
  static const Color  success = Color(0xFF388E3C);
  static const Color  warning = Color(0xFFF57C00);
  static const Color  error = Color(0xFFD32F2F);
  static const Color  info = Color(0xFFB6985B);


  static const Map<int, Color> colorMap = {
    50: Color(0x10192D6B),
    100: Color(0x20192D6B),
    200: Color(0x30192D6B),
    300: Color(0x40192D6B),
    400: Color(0x50192D6B),
    500: Color(0x60192D6B),
    600: Color(0x70192D6B),
    700: Color(0x80192D6B),
    800: Color(0x90192D6B),
    900: Color(0xff192D6B),
  };

  static const MaterialColor primary= MaterialColor(0xFF192D6B, colorMap);
}

List<Color> webColors = [appCat1, appCat2, appCat3];

// Light Theme Colors
const appColorPrimary = Color(0xFFB6985B);
const appColorAccent = Color(0xFF03DAC5);
const appTextColorPrimary = Color(0xFF212121);
const iconColorPrimary = Color(0xFFFFFFFF);
const appTextColorSecondary = Color(0xFF5A5C5E);
const iconColorSecondary = Color(0xFFA8ABAD);
const appIconTintDarkCherry = Color(0xFFf2866c);
const appDarkRed = Color(0xFFF06263);
const appLightRed = Color(0xFFF89B9D);
const appCat1 = Color(0xFF8998FE);
const appCat2 = Color(0xFFFF9781);
const appCat3 = Color(0xFF73D7D3);
const appCat4 = Color(0xFF87CEFA);
const appCat5 = appColorPrimary;
const appShadowColor = Color(0x95E9EBF0);
const appColorPrimaryLight = Color(0xFFF9FAFF);
const appSecondaryBackgroundColor = Color(0xFF131d25);
const appDividerColor = Color(0xFFDADADA);
// Dark Theme Colors
const appBackgroundColorDark = Color(0xFF121212);
const cardBackgroundBlackDark = Color(0xFF1F1F1F);
const appColorPrimaryDarkLight = Color(0xFFF9FAFF);
const iconColorPrimaryDark = Color(0xFF212121);
const iconColorSecondaryDark = Color(0xFFA8ABAD);
const appShadowColorDark = Color(0x1A3E3942);
const Color background = Color(0xFFFFFFFF);
const Color card = Color(0xFFF8F8F8);
const Color fontTitle = Color(0xFF202020);
const Color fontSubtitle = Color(0xFF737373);
const Color fontDisable = Color(0xFF9B9B9B);
const Color disabledButton = Color(0xFFB9B9B9);
const Color divider = Color(0xFFDCDCDC);
const Color success = Color(0xFF388E3C);
const Color warning = Color(0xFFF57C00);
const Color error = Color(0xFFD32F2F);
const Color info = Color(0xFFB6985B);