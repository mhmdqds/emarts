import 'package:get/get.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:flutter/material.dart';
import 'package:micro_pos_sys/common/ads/ads_controller.dart';


class AdsBanner extends GetWidget<AdsController> {
  const AdsBanner({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if(controller.isAdReady.value == true){
      return
        SizedBox(
          width: controller.adSize.width.toDouble(),
          height: controller.adSize.height.toDouble(),
          child: AdWidget(ad: controller.myBanner,),
        );
    }return
      const Center(
        child: SizedBox(
          height: 30,
          width: 30,
          child: CircularProgressIndicator(),
        ),
      );

  }
}
