import 'package:get/get.dart';
import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

class AdsController extends GetxController{

  static AdsController instance = Get.find();

  final AdSize adSize = AdSize.banner;
  late BannerAd myBanner;
  RxBool isAdReady = false.obs;

  // static String testAds = 'ca-app-pub-8532139344201808/1550582980';
  // static const bool testMode = true;
  //
  // static String get bannerAdUnitId{
  //   if(testMode){
  //     return testAds;
  //   }
  //   return 'ca-app-pub-8532139344201808/1550582980';
  // }
  //ca-app-pub-9229091413730938/8768660316

  _createBanner(){
    myBanner = BannerAd(
      adUnitId: 'ca-app-pub-8532139344201808/1550582980',
      size: AdSize.banner,
      request: const AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (ad){
          isAdReady.value = true;
        },
        onAdFailedToLoad: (add, error){
          Text('$error');
        }
      ),
    );
  }





  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    _createBanner();
    myBanner.load();
  }

}