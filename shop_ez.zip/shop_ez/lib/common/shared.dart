import 'package:micro_pos_sys/common/constants.dart';
import 'package:micro_pos_sys/common/show_custom_snakbar.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';


class Shared {
  static Future<BannerAd> getBannerAd(int width) async {
    AnchoredAdaptiveBannerAdSize? size =
        await AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(width);
    return BannerAd(
      adUnitId: bannerAdId,
      size: size!,
      request: const AdRequest(),
      listener: const BannerAdListener(),
    );
  }

  static Future<BannerAd> getBannerAd2(int width) async {
    AnchoredAdaptiveBannerAdSize? size =
        await AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(width);
    return BannerAd(
      adUnitId: bannerAdId2,
      size: size!,
      request: const AdRequest(),
      listener: const BannerAdListener(),
    );
  }

  static Future<bool> onPopEventHandler(InterstitialAd ad,
      {bool canShowAd = true}) async {
    if (canShowAd) {
      await ad.show();
    }
    return true;
  }

  static void showToast(String msg, context) {
    showCustomSnackBar(msg, context);
  }
}
