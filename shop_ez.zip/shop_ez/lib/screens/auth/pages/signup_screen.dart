import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:micro_pos_sys/core/constant/colors.dart';
import 'package:micro_pos_sys/core/constant/sizes.dart';
import 'package:micro_pos_sys/core/routes/router.dart';
import 'package:micro_pos_sys/core/utils/snackbar/snackbar.dart';
import 'package:micro_pos_sys/core/utils/validators/validators.dart';
import 'package:micro_pos_sys/db/db_functions/auth/user_db.dart';
import 'package:micro_pos_sys/db/db_functions/brand/brand_database.dart';
import 'package:micro_pos_sys/db/db_functions/category/category_db.dart';
import 'package:micro_pos_sys/db/db_functions/customer/customer_database.dart';
import 'package:micro_pos_sys/db/db_functions/group/group_database.dart';
import 'package:micro_pos_sys/db/db_functions/permission/permission_database.dart';
import 'package:micro_pos_sys/db/db_functions/supplier/supplier_database.dart';
import 'package:micro_pos_sys/db/db_functions/unit/unit_database.dart';
import 'package:micro_pos_sys/db/db_functions/vat/vat_database.dart';
import 'package:micro_pos_sys/model/auth/user_model.dart';
import 'package:micro_pos_sys/model/brand/brand_model.dart';
import 'package:micro_pos_sys/model/category/category_model.dart';
import 'package:micro_pos_sys/model/customer/customer_model.dart';
import 'package:micro_pos_sys/model/group/group_model.dart';
import 'package:micro_pos_sys/model/permission/permission_model.dart';
import 'package:micro_pos_sys/model/supplier/supplier_model.dart';
import 'package:micro_pos_sys/model/unit/unit_model.dart';
import 'package:micro_pos_sys/model/vat/vat_model.dart';
import 'package:micro_pos_sys/widgets/text_field_widgets/text_field_widgets.dart';
import 'package:micro_pos_sys/widgets/wave_clip.dart';

class ScreenSignUp extends StatelessWidget {
  ScreenSignUp({Key? key}) : super(key: key);

  final items = ['سوبر ماركت', 'بقالة', 'مكتبة', 'إتصالات', 'شركة إستيراد', 'مطعم', 'صيدلية', 'أخرى'];

  final GlobalKey<FormState> _formStateKey = GlobalKey<FormState>();
  final TextEditingController shopNameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController usernameController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController mobileNumberController = TextEditingController();
  final TextEditingController countryNameController = TextEditingController();
  final TextEditingController shopCategoryController = TextEditingController();

  final ValueNotifier<bool> obscureStateNotifier = ValueNotifier(false);
  final ValueNotifier<bool> obscureStateConfirmNotifier = ValueNotifier(false);

  @override
  Widget build(BuildContext context) {
    Size _screenSise = MediaQuery.of(context).size;
    return Scaffold(
      body: Stack(
        children: [
          ClipPath(
            clipper: WaveClip(),
            child: Container(
              width: _screenSise.width,
              height: _screenSise.height / 2,
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    mainColor,
                    gradiantColor,
                  ],
                ),
              ),
            ),
          ),
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              //========== Top Image ==========
              SizedBox(
                child: Center(
                  child: Image.asset(
                    'assets/images/pos.png',
                    width: _screenSise.width / 5,
                    // height: _screenSise.width / 3,
                  ),
                ),
                height: _screenSise.height / 4,
              ),

              //========== SignUp Feilds ==========
              Expanded(
                child: Padding(
                  //========== Dividing Screen Half and Half ==========
                  padding: EdgeInsets.only(
                    right: _screenSise.width * 0.05,
                    left: _screenSise.width * 0.05,
                    top: _screenSise.width * 0.10,
                    bottom: _screenSise.width * 0.10,
                  ),
                  child: SingleChildScrollView(
                    child: Form(
                      key: _formStateKey,
                      child: Flex(
                        direction: Axis.vertical,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          //========== Shop Name Field ==========
                          TextFeildWidget(
                            controller: shopNameController,
                            labelText: 'إسم النشاط التجاري (المتجر) *',
                            textInputType: TextInputType.text,
                            prefixIcon: const Icon(
                              Icons.business,
                              color: Colors.black,
                            ),
                            validator: (value) {
                              if (value == null || value.trim().isEmpty) {
                                return 'هذا الحقل مطلوب إدخالة*';
                              }
                              return null;
                            },
                          ),

                          //========== Country Name Field ==========
                          TextFeildWidget(
                            controller: countryNameController,
                            labelText: 'الدولة *',
                            textInputType: TextInputType.text,
                            prefixIcon: const Icon(
                              Icons.flag,
                              color: Colors.black,
                            ),
                            validator: (value) {
                              if (value == null || value.trim().isEmpty) {
                                return 'هذا الحقل مطلوب إدخالة*';
                              }
                              return null;
                            },
                          ),

                          //========== Shop Category DropDown Button ==========
                          DropdownButtonFormField(
                            decoration: const InputDecoration(
                              label: Text(
                                'القسم جملة تجزئية إستيراد خدمات *',
                                style: TextStyle(color: klabelColorGrey),
                              ),
                              prefixIcon: Icon(
                                Icons.store,
                                color: Colors.black,
                              ),
                              contentPadding: EdgeInsets.all(10),
                            ),
                            isExpanded: true,
                            items: items.map((String item) {
                              return DropdownMenuItem<String>(
                                value: item,
                                child: Text(item),
                              );
                            }).toList(),
                            onChanged: (value) {
                              shopCategoryController.text = value.toString();
                            },
                            validator: (value) {
                              if (value == null || shopCategoryController.text.isEmpty) {
                                return 'هذا الحقل مطلوب إدخالة*';
                              }
                              return null;
                            },
                          ),

                          //========== Mobile Number Field ==========
                          TextFeildWidget(
                            controller: mobileNumberController,
                            labelText: 'رقم التلفون *',
                            textInputType: TextInputType.phone,
                            prefixIcon: const Icon(
                              Icons.smartphone,
                              color: Colors.black,
                            ),
                            autovalidateMode: AutovalidateMode.onUserInteraction,
                            validator: (value) {
                              if (value == null || value.trim().isEmpty) {
                                return 'هذا الحقل مطلوب إدخالة*';
                              } else if (!RegExp(r'^(?:[+0][1-9])?[0-9]{10,12}$').hasMatch(value)) {
                                if (value.length != 10) {
                                  return 'Mobile number must 10 digits';
                                } else {
                                  return 'Please enter a valid Phone Number';
                                }
                              }

                              return null;
                            },
                          ),

                          //========== Email Field ==========
                          TextFeildWidget(
                            controller: emailController,
                            labelText: 'الإيمل',
                            textInputType: TextInputType.emailAddress,
                            prefixIcon: const Icon(
                              Icons.email,
                              color: Colors.black,
                            ),
                            autovalidateMode: AutovalidateMode.onUserInteraction,
                            validator: (value) {
                              if (value == null || value.trim().isEmpty) {
                                return null;
                              } else {
                                // Check if the entered email has the right format
                                if (!RegExp(r'\S+@\S+\.\S+').hasMatch(value)) {
                                  return 'يجب إدخال إيميل صحيح';
                                }
                              }
                              // Return null if the entered email is valid
                              return null;
                            },
                          ),

                          //========== Username Field ==========
                          TextFeildWidget(
                            controller: usernameController,
                            labelText: 'إسم المتسخدم *',
                            textInputType: TextInputType.text,
                            prefixIcon: const Icon(
                              Icons.person,
                              color: Colors.black,
                            ),
                            autovalidateMode: AutovalidateMode.onUserInteraction,
                            validator: (value) => Validators.usernameValidator(value),
                          ),

                          //========== Password Field ==========
                          ValueListenableBuilder(
                              valueListenable: obscureStateNotifier,
                              builder: (context, bool obscure, _) {
                                return TextFeildWidget(
                                  controller: passwordController,
                                  labelText: 'كلمة السر *',
                                  textInputType: TextInputType.text,
                                  obscureText: !obscure,
                                  prefixIcon: const Icon(
                                    Icons.security,
                                    color: Colors.black,
                                  ),
                                  suffixIcon: IconButton(
                                    color: Colors.black,
                                    onPressed: () {
                                      obscureStateNotifier.value = !obscure;
                                    },
                                    icon: !obscureStateNotifier.value ? const Icon(Icons.visibility_off) : const Icon(Icons.visibility),
                                  ),
                                  autovalidateMode: AutovalidateMode.onUserInteraction,
                                  validator: (value) => Validators.passwordValidator(value),
                                );
                              }),

                          //========== Confirm Password Field ==========
                          ValueListenableBuilder(
                              valueListenable: obscureStateConfirmNotifier,
                              builder: (context, bool obscure, _) {
                                return TextFeildWidget(
                                  labelText: 'تأكيد كلمة السر *',
                                  textInputType: TextInputType.text,
                                  obscureText: !obscure,
                                  prefixIcon: const Icon(
                                    Icons.security,
                                    color: Colors.black,
                                  ),
                                  suffixIcon: IconButton(
                                    color: Colors.black,
                                    onPressed: () {
                                      obscureStateConfirmNotifier.value = !obscure;
                                    },
                                    icon: !obscure ? const Icon(Icons.visibility_off) : const Icon(Icons.visibility),
                                  ),
                                  autovalidateMode: AutovalidateMode.onUserInteraction,
                                  validator: (value) {
                                    if (passwordController.text == value) {
                                      return null;
                                    } else {
                                      return "كلمة السر غير مطابقة";
                                    }
                                  },
                                );
                              }),
                          kHeight20,

                          //========== SignUp Buttons and Actions ==========
                          signUpButton(context)
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  //========== SignUp Buttons ==========
  Widget signUpButton(BuildContext context) {
    return Column(
      children: [
        MaterialButton(
          minWidth: 150,
          color: mainColor,
          onPressed: () {
            log('Getting Values...');
            onSignUp(context);
          },
          child: const Text(
            'إنشاء الحساب',
            style: TextStyle(color: Colors.white),
          ),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: const [
            Expanded(
              child: Divider(
                thickness: 0.5,
                color: Colors.grey,
              ),
            ),
            kWidth10,
            Text('أو'),
            kWidth10,
            Expanded(
              child: Divider(
                thickness: 0.5,
                color: Colors.grey,
              ),
            ),
          ],
        ),
        MaterialButton(
          minWidth: 150,
          color: Colors.grey[300],
          onPressed: () {
            Navigator.pushReplacementNamed(context, routeLogin);
          },
          child: const Text('دخول'),
        ),
      ],
    );
  }

  //========== SignUp and Verification ==========
  Future<void> onSignUp(BuildContext context) async {
    final isFormValid = _formStateKey.currentState!;

    log('message');

    final String username = usernameController.text.trim(),
        password = passwordController.text,
        mobileNumber = mobileNumberController.text.trim(),
        email = emailController.text.trim(),
        shopName = shopNameController.text.trim(),
        countryName = countryNameController.text.trim(),
        shopCategory = shopCategoryController.text.trim();

    if (isFormValid.validate()) {
      log('shopName = $shopName, countryName = $countryName, shopCategory = $shopCategory, phoneNumber = $mobileNumber, email = $email, username = $username, password = $password');

      // Create group and permission for Owner if not exist
      await createGroupOwner();

      final _user = UserModel(
        groupId: 1,
        shopName: shopName,
        countryName: countryName,
        shopCategory: shopCategory,
        mobileNumber: mobileNumber,
        email: email,
        username: username,
        password: password,
        status: 1,
      );

      try {
        await UserDatabase.instance.createUser(_user);
        kSnackBar(
          context: context,
          success: true,
          content: "User Registered Successfully!",
        );
        createCategory();
        Navigator.pushReplacementNamed(context, routeHome);
        return;
      } catch (e) {
        kSnackBar(context: context, error: true, content: e.toString());
        return;
      }
    }
  }

  //========== Create Owner Group ==========
  Future<void> createGroupOwner() async {
    const GroupModel _groupModel = GroupModel(
      id: 1,
      name: 'Owner',
      description: 'Owner of the Business. Owner have full controll over the application',
    );
    const PermissionModel _permissionModel = PermissionModel(
      groupId: 1,
      user: '1234',
      sale: '1234',
      purchase: '1234',
      returns: '1234',
      products: '1234',
      customer: '1234',
      supplier: '1234',
    );
    const GroupModel _groupModelAdmin = GroupModel(
      id: 2,
      name: 'Admin',
      description: 'Admin has most of the previlege owner has only with few limitations',
    );
    const PermissionModel _permissionModelAdmin = PermissionModel(
      groupId: 2,
      user: '123',
      sale: '123',
      purchase: '123',
      returns: '123',
      products: '123',
      customer: '123',
      supplier: '123',
    );

    try {
      // Creating group for Owner
      await GroupDatabase.instance.createGroup(_groupModel);
      await PermissionDatabase.instance.createPermission(_permissionModel);

      // Creating group for Admin
      await GroupDatabase.instance.createGroup(_groupModelAdmin);
      await PermissionDatabase.instance.createPermission(_permissionModelAdmin);
    } catch (e) {
      log(e.toString());
    }
  }


  //========== Create Category ==========
  Future<void> createCategory() async {
    const CategoryModel _categoryModel = CategoryModel(
      category: 'إلكترونيات',
    );
     const UnitModel _unit = UnitModel(
      unit: 'حبة',
    );
     const BrandModel _brand = BrandModel(
       brand: 'سامسونج',
        );
    const CustomerModel _customerModel = CustomerModel(
      customerType: 'General Customer',
      customer: 'محمد أحمد زبون',
      customerArabic: 'محمد أحمد زبون',
      contactNumber: '777363554',
      email: "MHMDQDS@GMAIL.COM",
      address: 'صنعاء اليمن',
      addressArabic: 'صنعاء اليمن',
      city: 'صنعاء',
      cityArabic: 'صنعاء',
      state: 'السبعين',
      stateArabic:  'السبعين',
      country: "اليمن",
      countryArabic: "اليمن",
      poBox: '00',
    );
    const SupplierModel _supplierModel =  SupplierModel(
      supplierName: 'المفلحي للتجار',
      supplierNameArabic: 'المفلحي للتجار',
      contactName: 'المدير محمد',
      contactNumber: '777363554',
      vatNumber: '0',
      email: 'mhmdqds@gmail.com',
      address: 'sana',
      addressArabic: 'sana',
      city: 'sana',
      cityArabic: 'sana',
      state: 'sana',
      stateArabic: 'sana',
      country: 'yemen',
      countryArabic: 'yemen',
      poBox: '00',
    );
    const _vatModel = VatModel(name: 'ضريبة مبيعات', code: 'ضريبة', rate: 2, type: "بالنسبة");

    try {
      // Creating Category
      await CategoryDatabase.instance.createCategory(_categoryModel);
      await UnitDatabase.instance.createUnit(_unit);
      await BrandDatabase.instance.createBrand(_brand);
      await CustomerDatabase.instance.createCustomer(_customerModel);
      await SupplierDatabase.instance.createSupplier(_supplierModel);
      await VatDatabase.instance.createVAT(_vatModel);
    } catch (e) {
      log(e.toString());
    }
  }
}
