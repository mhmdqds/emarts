import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:micro_pos_sys/core/constant/colors.dart';

import '../../../core/utils/device/device.dart';

class StockTableHeader extends StatelessWidget {
  const StockTableHeader({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Table(
      columnWidths: const {
        0: FractionColumnWidth(0.25),
        1: FractionColumnWidth(0.20),
        2: FractionColumnWidth(0.20),
        3: FractionColumnWidth(0.20),
        4: FractionColumnWidth(0.15),
      },
      border: TableBorder.all(width: 0.5),
      children: [
        TableRow(children: [
          Container(
            color: Colors.blue,
            height: 30,
            alignment: Alignment.center,
            child: AutoSizeText(
              'الأسم',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                  fontSize: DeviceUtil.isTablet ? 13 : 12,
                  color: kWhite,
                  fontWeight: FontWeight.bold),
              minFontSize: 12,
              maxFontSize: 13,
            ),
          ),
          Container(
            color: Colors.blue,
            height: 30,
            alignment: Alignment.center,
            child: AutoSizeText(
              'القسم',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                  fontSize: DeviceUtil.isTablet ? 13 : 12,
                  color: kWhite,
                  fontWeight: FontWeight.bold),
              minFontSize: 12,
              maxFontSize: 13,
            ),
          ),
          Container(
            color: Colors.blue,
            height: 30,
            alignment: Alignment.center,
            child: AutoSizeText(
              'التكلفة',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                  fontSize: DeviceUtil.isTablet ? 13 : 12,
                  color: kWhite,
                  fontWeight: FontWeight.bold),
              minFontSize: 12,
              maxFontSize: 13,
            ),
          ),
          Container(
            color: Colors.blue,
            height: 30,
            alignment: Alignment.center,
            child: AutoSizeText(
              'السعر',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                  fontSize: DeviceUtil.isTablet ? 13 : 12,
                  color: kWhite,
                  fontWeight: FontWeight.bold),
              minFontSize: 12,
              maxFontSize: 13,
            ),
          ),
          Container(
            color: Colors.blue,
            height: 30,
            alignment: Alignment.center,
            child: AutoSizeText(
              'الكمية',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                  fontSize: DeviceUtil.isTablet ? 13 : 12,
                  color: kWhite,
                  fontWeight: FontWeight.bold),
              minFontSize: 12,
              maxFontSize: 13,
            ),
          ),
        ]),
      ],
    );
  }
}
