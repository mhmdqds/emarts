import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:micro_pos_sys/common/ads/ad_manager.dart';
import 'package:micro_pos_sys/common/constants.dart';
import 'package:micro_pos_sys/common/shared.dart';
import 'package:micro_pos_sys/core/routes/router.dart';
import 'package:micro_pos_sys/core/utils/device/device.dart';
import 'package:micro_pos_sys/db/db_functions/purchase/purchase_database.dart';
import 'package:micro_pos_sys/db/db_functions/transactions/transactions_database.dart';
import 'package:micro_pos_sys/model/purchase/purchase_model.dart';
import 'package:micro_pos_sys/model/transactions/transactions_model.dart';

import '../../../core/constant/colors.dart';
import '../../../core/constant/sizes.dart';
import '../../../widgets/app_bar/app_bar_widget.dart';
import '../../../widgets/container/background_container_widget.dart';
import '../../../widgets/padding_widget/item_screen_padding_widget.dart';
import '../widgets/purchase_options_card.dart';

class ScreenPurchase extends StatefulWidget {
  ScreenPurchase({
    Key? key,
  }) : super(key: key);

  @override
  State<ScreenPurchase> createState() => _ScreenPurchaseState();
}

class _ScreenPurchaseState extends State<ScreenPurchase> {

  BannerAd? myBanner;
  AdWidget? adWidget;
  InterstitialAd? _interstitialAd;
  final adManager = AdManager();

  @override
  void initState() {
    Future.delayed(
      Duration.zero,
          () async {
        initAds();
      },
    );
    Future.delayed(const Duration(milliseconds: 500), () async {
      await Shared.onPopEventHandler(_interstitialAd!);
    });
    adManager.showInterstitial();
    adManager.showRewardedAd();
    super.initState();
  }

  Future<void> initAds() async {
    myBanner = await Shared.getBannerAd(MediaQuery.of(context).size.width.toInt());
    await myBanner!.load();
    adWidget = AdWidget(ad: myBanner!);
    setState(() {});
    await InterstitialAd.load(
      adUnitId: interstitialAdId,
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (InterstitialAd ad) {
          // Keep a reference to the ad so you can show it later.
          _interstitialAd = ad;
        },
        onAdFailedToLoad: (LoadAdError error) {
        },
      ),
    );
  }

  //========== Value Notifiers ==========
  final ValueNotifier<num> totalPurchasesNotifier = ValueNotifier(0),
      totalAmountNotifier = ValueNotifier(0),
      paidAmountNotifier = ValueNotifier(0),
      balanceAmountNotifier = ValueNotifier(0),
      taxAmountNotifier = ValueNotifier(0),
      overDueAmountNotifier = ValueNotifier(0);

  @override
  Widget build(BuildContext context) {
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await getPurchaseDetails();
      final List<TransactionsModel> _transaction = await TransactionDatabase.instance.getAllTransactions();

      num totalExpense = 0;
      num totalIncome = 0;

      for (var transaction in _transaction) {
        if (transaction.transactionType == 'Income') {
          totalIncome += num.parse(transaction.amount);
        } else {
          totalExpense += num.parse(transaction.amount);
        }
      }

      log('Total Income == $totalIncome');
      log('Total Expense == $totalExpense');

      log('In the Money == ${totalIncome - totalExpense}');
    });
    return Scaffold(
      appBar: AppBarWidget(
        title: 'المشتريات',
      ),
      body: BackgroundContainerWidget(
        child: ItemScreenPaddingWidget(
          child: Column(
            children: [
              SingleChildScrollView(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Expanded(
                          child: ValueListenableBuilder(
                              valueListenable: totalPurchasesNotifier,
                              builder: (context, num totalPurchases, _) {
                                return PurchaseOptionsCard(
                                  title: 'إجمالي المشتريات',
                                  value: totalPurchases,
                                  currency: false,
                                );
                              }),
                        ),
                        Expanded(
                          child: ValueListenableBuilder(
                              valueListenable: totalAmountNotifier,
                              builder: (context, num totalAmount, _) {
                                return PurchaseOptionsCard(
                                  title: 'إجمالي المبلغ',
                                  value: totalAmount,
                                );
                              }),
                        ),
                        Expanded(
                          child: ValueListenableBuilder(
                              valueListenable: paidAmountNotifier,
                              builder: (context, num paidAmount, _) {
                                return PurchaseOptionsCard(
                                  title: ' المبلغ المدفوع',
                                  value: paidAmount,
                                );
                              }),
                        ),
                      ],
                    ),
                    kHeight10,
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Expanded(
                          child: ValueListenableBuilder(
                              valueListenable: balanceAmountNotifier,
                              builder: (context, num balanceAmount, _) {
                                return PurchaseOptionsCard(
                                  title: 'مبلغ الرصيد',
                                  value: balanceAmount,
                                );
                              }),
                        ),
                        Expanded(
                          child: ValueListenableBuilder(
                              valueListenable: taxAmountNotifier,
                              builder: (context, num taxAmount, _) {
                                return PurchaseOptionsCard(
                                  title: 'مبلغ الضريبة',
                                  value: taxAmount,
                                );
                              }),
                        ),
                        Expanded(
                          child: ValueListenableBuilder(
                              valueListenable: overDueAmountNotifier,
                              builder: (context, num overDueAmount, _) {
                                return PurchaseOptionsCard(
                                  title: 'المبالغ المتأخر',
                                  value: overDueAmount,
                                );
                              }),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              kHeight20,
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Expanded(
                          child: MaterialButton(
                            height: 50,
                            onPressed: () async {
                              await OrientationMode.toLandscape();
                              await Navigator.pushNamed(context, routeAddPurchase);
                              await OrientationMode.toPortrait();
                              await getPurchaseDetails(purchase: true);
                            },
                            color: Colors.green,
                            textColor: kWhite,
                            child: const Text(
                              'إضافة مشتريات',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                        kWidth10,
                        Expanded(
                          child: MaterialButton(
                            height: 50,
                            onPressed: () async {
                              await OrientationMode.toLandscape();
                              await Navigator.pushNamed(context, routePurchaseReturn);
                              await OrientationMode.toPortrait();
                              await getPurchaseDetails();
                            },
                            color: Colors.indigo[400],
                            textColor: kWhite,
                            child: const Text(
                              'مرتجعات المشتريات',
                              textAlign: TextAlign.center,
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                      ],
                    ),
                    kHeight10,
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Expanded(
                          child: MaterialButton(
                            height: 50,
                            onPressed: () async {
                              await Navigator.pushNamed(context, routeListPurchase);
                              await getPurchaseDetails();
                            },
                            color: Colors.deepOrange,
                            textColor: kWhite,
                            child: const Text(
                              'سجل المشتريات',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                        kWidth10,
                        Expanded(
                          child: MaterialButton(
                            height: 50,
                            onPressed: () {
                              Navigator.pushNamed(context, routePurchaseReturnList);
                            },
                            color: Colors.blueGrey,
                            textColor: kWhite,
                            child: const Text(
                              'سجل المرتجعات',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              adWidget != null
                  ? Container(
                    alignment: Alignment.center,
                    child: adWidget,
                    width: myBanner!.size.width.toDouble(),
                    height: myBanner!.size.height.toDouble(),
                  ) :  Container( ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> getPurchaseDetails({final bool purchase = false}) async {
    try {
      final List<PurchaseModel> purchaseModel = await PurchaseDatabase.instance.getAllPurchases();

      // Checking if new Purchase added!
      if (purchase) {
        if (totalPurchasesNotifier.value == purchaseModel.length) return;
      }

      totalPurchasesNotifier.value = purchaseModel.length;
      totalAmountNotifier.value = 0;
      paidAmountNotifier.value = 0;
      balanceAmountNotifier.value = 0;
      taxAmountNotifier.value = 0;
      overDueAmountNotifier.value = 0;

      for (var i = 0; i < purchaseModel.length; i++) {
        totalAmountNotifier.value += num.parse(purchaseModel[i].grantTotal);
        paidAmountNotifier.value += num.parse(purchaseModel[i].paid);
        balanceAmountNotifier.value += num.parse(purchaseModel[i].balance);
        taxAmountNotifier.value += num.parse(purchaseModel[i].vatAmount);
        overDueAmountNotifier.value += num.parse(purchaseModel[i].balance);
      }
    } catch (e) {
      log(e.toString());
    }
  }
}
