import 'package:flutter/material.dart';
import 'package:micro_pos_sys/screens/reports/widgets/reports_grid.dart';
import 'package:micro_pos_sys/widgets/app_bar/app_bar_widget.dart';
import 'package:micro_pos_sys/widgets/padding_widget/item_screen_padding_widget.dart';

class ScreenReports extends StatelessWidget {
  const ScreenReports({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBarWidget(title: 'التقارير'),
      body: SafeArea(
        child: ItemScreenPaddingWidget(
          child: GridView.count(
            crossAxisCount: 3,
            children: List.generate(11, (index) => ReportsGrid(index: index)),
          ),
        ),
      ),
    );
  }
}
