import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:micro_pos_sys/common/ads/ad_manager.dart';
import 'package:micro_pos_sys/common/shared.dart';
import 'package:micro_pos_sys/core/constant/colors.dart';
import 'package:micro_pos_sys/core/constant/sizes.dart';
import 'package:micro_pos_sys/core/constant/text.dart';
import 'package:micro_pos_sys/core/routes/router.dart';

import 'package:micro_pos_sys/widgets/app_bar/app_bar_widget.dart';
import 'package:micro_pos_sys/widgets/button_widgets/material_button_widget.dart';
import 'package:micro_pos_sys/widgets/container/background_container_widget.dart';
import 'package:micro_pos_sys/widgets/padding_widget/item_screen_padding_widget.dart';

class ScreenUserManage extends StatefulWidget {
  const ScreenUserManage({
    Key? key,
  }) : super(key: key);

  @override
  State<ScreenUserManage> createState() => _ScreenUserManageState();
}

class _ScreenUserManageState extends State<ScreenUserManage> {

  BannerAd? myBanner;
  AdWidget? adWidget;
  final adManager = AdManager();

  @override
  void initState() {
    Future.delayed(
      Duration.zero,
          () async {
        initAds();
      },
    );
    adManager.showInterstitial();
    adManager.showRewardedAd();
    super.initState();
  }

  Future<void> initAds() async {
    myBanner = await Shared.getBannerAd(MediaQuery.of(context).size.width.toInt());
    await myBanner!.load();
    adWidget = AdWidget(ad: myBanner!);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    adManager.addAds(true, true, true);
    WidgetsBinding.instance.addPostFrameCallback((_) async {});

    return Scaffold(
      appBar: AppBarWidget(
        title: 'إدارة المستخدمين',
      ),
      body: BackgroundContainerWidget(
        child: ItemScreenPaddingWidget(
          child: Column(
            children: [
              Expanded(
                flex: 3,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Expanded(
                          child: CustomMaterialBtton(
                            height: 50,
                            onPressed: () => Navigator.pushNamed(context, routeAddUser),
                            color: Colors.indigo[400],
                            textColor: kWhite,
                            buttonText: 'إضافة مستخدم',
                            textStyle: kTextBoldWhite,
                            icon: const Icon(Icons.person_add, color: kWhite),
                          ),
                        ),
                        kWidth10,
                        Expanded(
                          child: CustomMaterialBtton(
                            height: 50,
                            onPressed: () => Navigator.pushNamed(context, routeAddGroup),
                            color: kGreen,
                            textColor: kWhite,
                            buttonText: 'إضافة مجموعة',
                            textStyle: kTextBoldWhite,
                            icon: const Icon(Icons.workspace_premium, color: kWhite),
                          ),
                        ),
                      ],
                    ),
                    kHeight10,
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Expanded(
                          child: CustomMaterialBtton(
                            height: 50,
                            onPressed: () => Navigator.pushNamed(context, routeListUser),
                            color: Colors.deepOrange,
                            textColor: kWhite,
                            buttonText: 'قائمة المستخدمين',
                            textStyle: kTextBoldWhite,
                            icon: const Icon(Icons.group, color: kWhite),
                          ),
                        ),
                        kWidth10,
                        Expanded(
                          child: CustomMaterialBtton(
                            height: 50,
                            onPressed: () => Navigator.pushNamed(context, routeListGroup),
                            color: Colors.blueGrey,
                            textColor: kWhite,
                            buttonText: 'قائمة المجموعات',
                            textStyle: kTextBoldWhite,
                            icon: const Icon(Icons.security, color: kWhite),
                          ),
                        ),
                      ],
                    ),
                    adWidget != null
                        ? Container(
                      alignment: Alignment.center,
                      child: adWidget,
                      width: myBanner!.size.width.toDouble(),
                      height: myBanner!.size.height.toDouble(),
                    ) :  Container( ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
