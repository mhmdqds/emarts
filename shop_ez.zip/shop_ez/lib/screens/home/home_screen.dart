import 'dart:developer' show log;
import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:micro_pos_sys/common/ads/ad_manager.dart';
import 'package:micro_pos_sys/common/ads/ads.dart';
import 'package:micro_pos_sys/common/constants.dart';
import 'package:micro_pos_sys/common/shared.dart';
import 'package:micro_pos_sys/core/utils/vat/vat.dart';
import 'package:micro_pos_sys/model/business_profile/business_profile_model.dart';

import '../../core/constant/colors.dart';
import '../../core/routes/router.dart';
import '../../core/utils/device/device.dart';
import '../../core/utils/user/user.dart';
import '../../db/db_functions/auth/user_db.dart';

import '../../widgets/floating_popup_widget/floating_add_options.dart';
import 'widgets/home_card_widget.dart';
import 'widgets/home_drawer.dart';
import 'widgets/home_grid.dart';

class ScreenHome extends StatefulWidget {
  const ScreenHome({this.initialEntry, Key? key}) : super(key: key);
  final int? initialEntry;
  static final ValueNotifier<BusinessProfileModel?> businessNotifier = ValueNotifier(null);

  @override
  State<ScreenHome> createState() => _ScreenHomeState();
}

class _ScreenHomeState extends State<ScreenHome> {
  final _scaffoldKey = GlobalKey<ScaffoldState>();

  final isDialOpen = ValueNotifier(false);
  BannerAd? myBanner;
  AdWidget? adWidget;
  InterstitialAd? _interstitialAd;
  final adManager = AdManager();

  @override
  void initState() {
    Future.delayed(
      Duration.zero,
          () async {
        initAds();
      },
    );
    Future.delayed(const Duration(milliseconds: 500), () async {
      await Shared.onPopEventHandler(_interstitialAd!);
    });
    adManager.showInterstitial();
    adManager.showRewardedAd();
    super.initState();
  }

  Future<void> initAds() async {
    myBanner = await Shared.getBannerAd(MediaQuery.of(context).size.width.toInt());
    await myBanner!.load();
    adWidget = AdWidget(ad: myBanner!);
    setState(() {});
    await InterstitialAd.load(
      adUnitId: interstitialAdId,
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (InterstitialAd ad) {
          // Keep a reference to the ad so you can show it later.
          _interstitialAd = ad;
        },
        onAdFailedToLoad: (LoadAdError error) {
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    adManager.addAds(true, true, true);
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      // await SystemChrome.setPreferredOrientations(
      //     [DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]);
      try {
        await UserUtils.instance.fetchUserDetails();
        ScreenHome.businessNotifier.value = await UserUtils.instance.businessProfile;
        if (VatUtils.instance.vats.isEmpty) await VatUtils.instance.getVats();
      } catch (e) {
        log(e.toString());
      }
    });
    // UserDatabase.instance.getAllUsers();
    if (DeviceUtil.isTablet) {
      log("You're Using a Tablet!");
    } else {
      log("You're Using a Phone!");
    }
    final Size _screenSize = MediaQuery.of(context).size;
    return WillPopScope(
      onWillPop: () async {
        if (isDialOpen.value) {
          isDialOpen.value = false;
          await Shared.onPopEventHandler(_interstitialAd!);
          return false;
        } else {
          return true;
        }
      },
      child: Scaffold(
        key: _scaffoldKey,

        //========== Drawer Widget ==========
        drawer: ValueListenableBuilder(
            valueListenable: ScreenHome.businessNotifier,
            builder: (context, BusinessProfileModel? business, _) {
              return Drawer(
                child: HomeDrawer(
                  businessProfile: business,
                ),
              );
            }),

        //========== AppBar Widget ==========
        appBar: AppBar(
          backgroundColor: appBarColor,
          elevation: 0.0,
          leading: IconButton(
            onPressed: () {
              _scaffoldKey.currentState?.openDrawer();
              adManager.showRewardedAd();
            },
            icon: const Image(
              image: AssetImage('assets/images/hamburger.png'),
              height: 24,
              width: 24,
            ),
          ),
          actions: [
            IconButton(
              onPressed: () async {
                await Shared.onPopEventHandler(_interstitialAd!);
                adManager.showInterstitial();
                showDialog(
                  context: context,
                  builder: (ctx) => AlertDialog(
                    title: const Text('تسجيل الخروج'),
                    content: const Text('هل تريد الخروج من التطبيق فعلاً?'),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
                      TextButton(
                          onPressed: () async => await UserDatabase.instance.logout().then(
                                (_) async {
                                  Navigator.of(context).pushNamedAndRemoveUntil(routeLogin, (Route<dynamic> route) => false);
                                },
                              ),
                          child: const Text('نعم خروج')),
                    ],
                  ),
                );
              },
              icon: const Icon(Icons.logout),
            )
          ],
        ),

        //========== Background Image ==========
        body: SafeArea(
          child: Container(
            width: _screenSize.width,
            height: _screenSize.height,
            decoration: const BoxDecoration(
              image: DecorationImage(
                fit: BoxFit.cover,
                image: AssetImage('assets/images/home.jpg'),
              ),
            ),
            child: Padding(
              padding: EdgeInsets.only(top: _screenSize.height / 6),
              child: Column(
                children: [
                  //========== Home Card Widget ==========
                  const HomeCardWidget(),

                  //========== Home GridView Widget ==========
                  Expanded(
                    child: GridView.count(
                      padding: EdgeInsets.all(_screenSize.width / 50),
                      crossAxisCount: 3,
                      mainAxisSpacing: _screenSize.width / 50,
                      crossAxisSpacing: _screenSize.width / 50,
                      children: List.generate(
                        9,
                        (index) => HomeGrid(
                          index: index,
                          screenSize: _screenSize,
                        ),
                      ),
                    ),
                  ),
                  adWidget != null
                      ? Container(
                        alignment: Alignment.center,
                        child: adWidget,
                        width: myBanner!.size.width.toDouble(),
                        height: myBanner!.size.height.toDouble(),
                      ) :  Container( ),
                ],
              ),
            ),
          ),
        ),
        floatingActionButtonLocation: FloatingActionButtonLocation.startFloat,
        floatingActionButton: FloatingAddOptions(isDialOpen: isDialOpen),
      ),
    );
  }
}
