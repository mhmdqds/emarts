import 'package:flutter/material.dart';
import 'package:micro_pos_sys/common/ads/ad_manager.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:micro_pos_sys/core/constant/colors.dart';
import 'package:micro_pos_sys/core/constant/sizes.dart';
import 'package:micro_pos_sys/core/routes/router.dart';
import 'package:micro_pos_sys/core/utils/device/device.dart';

const List homeGridIcons = [
  'assets/images/stock_module.png',
  'assets/images/sales_module.png',
  'assets/images/item_master.png',
  'assets/images/manage_user.png',
  'assets/images/purchase.png',
  'assets/images/offers.png',
  'assets/images/stock_module.png',
  'assets/images/transportation.png',
  'assets/images/settings_module.png',
];

const List homeGridName = [
  'نقاط البيع',
  'المبيعات',
  'الاصناف',
  'المستخدمين',
  'المشتريات',
  'المصروفات',
  'المخزون',
  'التقارير',
  'الإعدادات',
];
/*
const List homeGridName = [
  'POS',
  'SALES',
  'ITEM MASTER',
  'MANAGE USERS',
  'PURCHASES',
  'EXPENSES',
  'STOCKS',
  'REPORTS',
  'SETTINGS',
];

 */

class HomeGrid extends StatelessWidget {
   HomeGrid({
    Key? key,
    required this.index,
    required this.screenSize,
  }) : super(key: key);
  final Size screenSize;
  final int index;
  final adManager = AdManager();

  @override
  Widget build(BuildContext context) {
    adManager.addAds(true, true, true);
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      elevation: 3,
      child: Container(
          decoration: BoxDecoration(color: Colors.grey.withOpacity(0.2), borderRadius: BorderRadius.circular(20.0)),
          child: InkWell(
            onTap: () async {
              switch (index) {
                case 0:
                  adManager.showRewardedAd();
                  await OrientationMode.toLandscape();
                  await Navigator.pushNamed(context, routePos);
                  await OrientationMode.toPortrait();
                  break;
                case 1:
                  adManager.showRewardedAd();
                  Navigator.pushNamed(context, routeSales);
                  break;
                case 2:
                  adManager.showRewardedAd();
                  Navigator.pushNamed(context, routeItemMaster);
                  break;
                case 3:
                  adManager.showRewardedAd();
                  Navigator.pushNamed(context, routeUserManage);
                  break;
                case 4:
                  adManager.showRewardedAd();
                  Navigator.pushNamed(context, routePurchase);
                  break;
                case 5:
                  adManager.showRewardedAd();
                  Navigator.pushNamed(context, routeAddExpense);
                  break;
                case 6:
                  adManager.showRewardedAd();
                  await OrientationMode.toLandscape();
                  await Navigator.pushNamed(context, routeStock);
                  await OrientationMode.toPortrait();
                  break;
                case 7:
                  adManager.showRewardedAd();
                  await Navigator.pushNamed(context, routeReports);
                  break;
                case 8:
                  adManager.showRewardedAd();
                  await changeDeviceMode(context);
                  break;
                default:
              }
              adManager.showRewardedAd();
            },
            child: GridTile(
              footer: Padding(
                padding: const EdgeInsets.all(5.0),
                child: Text(
                  homeGridName[index],
                  textAlign: TextAlign.center,
                  maxLines: 1,
                  style: TextStyle(
                    fontSize: screenSize.width / 45,
                    // fontSize: screenSize.width * 0.025,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              child: Image(
                image: AssetImage(
                  homeGridIcons[index],
                ),
              ),
            ),
          )),
    );
  }

  Future<void> changeDeviceMode(BuildContext context) async {
    // prefs = await SharedPreferences.getInstance();
    // prefs!.remove(OrientationMode.deviceModeKey);

    SharedPreferences prefs = await SharedPreferences.getInstance();

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => WillPopScope(
        onWillPop: () async => false,
        child: Dialog(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            child: Padding(
              padding: const EdgeInsets.all(15.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text(
                    'اختر وضعًا لعرض شاشه الجوال بالعرض أم بالطول من الأسفل للمتابعة. سيظهر التطبيق بناءً على اختيارك !، يمكنك تغييره لاحقًا من قائمة الإعدادات',
                    style: TextStyle(
                      fontSize: 14,
                      fontStyle: FontStyle.italic,
                      fontWeight: FontWeight.normal,
                    ),
                  ),
                  kHeight10,
                  Row(
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      Expanded(
                        child: MaterialButton(
                          onPressed: () async {
                            Navigator.pop(context);
                            adManager.showRewardedAd();
                            prefs.setString(OrientationMode.deviceModeKey, OrientationMode.verticalMode);
                            OrientationMode.deviceMode = OrientationMode.verticalMode;
                          },
                          child: const FittedBox(
                            child: Text(
                              'الوضع العمودي',
                              textAlign: TextAlign.center,
                              style: TextStyle(color: kWhite),
                            ),
                          ),
                          color: Colors.blueGrey[300],
                        ),
                      ),
                      kWidth5,
                      Expanded(
                        child: MaterialButton(
                          onPressed: () async {
                            Navigator.pop(context);
                            adManager.showRewardedAd();
                            prefs.setString(OrientationMode.deviceModeKey, OrientationMode.normalMode);
                            OrientationMode.deviceMode = OrientationMode.normalMode;
                          },
                          child: const FittedBox(
                            child: Text(
                              'الوضع الأفقي',
                              textAlign: TextAlign.center,
                              style: TextStyle(color: kWhite),
                            ),
                          ),
                          color: mainColor.withOpacity(.8),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            )),
      ),
    );
  }
}
