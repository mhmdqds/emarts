import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:micro_pos_sys/common/ads/ad_manager.dart';
import 'package:micro_pos_sys/common/shared.dart';
import 'package:micro_pos_sys/core/constant/colors.dart';
import 'package:micro_pos_sys/core/routes/router.dart';
import 'package:micro_pos_sys/core/utils/device/device.dart';
import 'package:micro_pos_sys/db/db_functions/sales/sales_database.dart';
import 'package:micro_pos_sys/db/db_functions/transactions/transactions_database.dart';
import 'package:micro_pos_sys/model/sales/sales_model.dart';
import 'package:micro_pos_sys/model/transactions/transactions_model.dart';
import 'package:micro_pos_sys/widgets/app_bar/app_bar_widget.dart';
import 'package:micro_pos_sys/widgets/container/background_container_widget.dart';
import 'package:micro_pos_sys/widgets/padding_widget/item_screen_padding_widget.dart';

import '../../../core/constant/sizes.dart';
import '../widgets/sales_options_card.dart';

class ScreenSales extends StatefulWidget {
  const ScreenSales({
    Key? key,
  }) : super(key: key);

  @override
  State<ScreenSales> createState() => _ScreenSalesState();
}

class _ScreenSalesState extends State<ScreenSales> {
  BannerAd? myBanner;
  AdWidget? adWidget;
  final adManager = AdManager();

  @override
  void initState() {
    Future.delayed(
      Duration.zero,
          () async {
        initAds();
      },
    );
    adManager.showInterstitial();
    adManager.showRewardedAd();
    super.initState();
  }

  Future<void> initAds() async {
    myBanner = await Shared.getBannerAd(MediaQuery.of(context).size.width.toInt());
    await myBanner!.load();
    adWidget = AdWidget(ad: myBanner!);
    setState(() {});
  }


  //========== Value Notifiers ==========
  final ValueNotifier<num> totalSalesNotifier = ValueNotifier(0),
      totalAmountNotifier = ValueNotifier(0),
      paidAmountNotifier = ValueNotifier(0),
      balanceAmountNotifier = ValueNotifier(0),
      taxAmountNotifier = ValueNotifier(0),
      overDueAmountNotifier = ValueNotifier(0);

  @override
  Widget build(BuildContext context) {
    adManager.addAds(true, true, true);
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await getSalesDetails(sale: true);
      final List<TransactionsModel> _transaction = await TransactionDatabase.instance.getAllTransactions();

      num totalExpense = 0;
      num totalIncome = 0;

      for (var transaction in _transaction) {
        if (transaction.transactionType == 'Income') {
          totalIncome += num.parse(transaction.amount);
        } else {
          totalExpense += num.parse(transaction.amount);
        }
      }

      log('Total Income == $totalIncome');
      log('Total Expense == $totalExpense');

      log('In the Money == ${totalIncome - totalExpense}');
    });

    return Scaffold(
      appBar: AppBarWidget(
        title: 'المبيعات',
      ),
      body: BackgroundContainerWidget(
        child: ItemScreenPaddingWidget(
          child: Column(
            children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Expanded(
                        child: ValueListenableBuilder(
                            valueListenable: totalSalesNotifier,
                            builder: (context, num totalSales, _) {
                              return SalesOptionsCard(
                                title: 'إجمالي المبيعات',
                                value: totalSales,
                                currency: false,
                              );
                            }),
                      ),
                      Expanded(
                        child: ValueListenableBuilder(
                            valueListenable: totalAmountNotifier,
                            builder: (context, num totalAmount, _) {
                              return SalesOptionsCard(
                                title: 'إجمالي المبلغ',
                                value: totalAmount,
                              );
                            }),
                      ),
                      Expanded(
                        child: ValueListenableBuilder(
                            valueListenable: paidAmountNotifier,
                            builder: (context, num paidAmount, _) {
                              return SalesOptionsCard(
                                title: ' المبلغ المدفوع',
                                value: paidAmount,
                              );
                            }),
                      ),
                    ],
                  ),
                  kHeight10,
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Expanded(
                        child: ValueListenableBuilder(
                            valueListenable: balanceAmountNotifier,
                            builder: (context, num balanceAmount, _) {
                              return SalesOptionsCard(
                                title: 'مبلغ الرصيد',
                                value: balanceAmount,
                              );
                            }),
                      ),
                      Expanded(
                        child: ValueListenableBuilder(
                            valueListenable: taxAmountNotifier,
                            builder: (context, num taxAmount, _) {
                              return SalesOptionsCard(
                                title: 'مبلغ الضريبة',
                                value: taxAmount,
                              );
                            }),
                      ),
                      Expanded(
                        child: ValueListenableBuilder(
                            valueListenable: overDueAmountNotifier,
                            builder: (context, num overDueAmount, _) {
                              return SalesOptionsCard(
                                title: 'مبالغ يجب تحصليها',
                                value: overDueAmount,
                              );
                            }),
                      ),
                    ],
                  ),
                ],
              ),
              kHeight20,
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Expanded(
                          child: MaterialButton(
                            height: 50,
                            onPressed: () async {
                              await OrientationMode.toLandscape();
                              await Navigator.pushNamed(context, routePos);
                              await OrientationMode.toPortrait();
                              await getSalesDetails(sale: true);
                            },
                            color: Colors.green,
                            textColor: kWhite,
                            child: const Text(
                              'إضافة فاتورة',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                        kWidth10,
                        Expanded(
                          child: MaterialButton(
                            height: 50,
                            onPressed: () async {
                              await OrientationMode.toLandscape();
                              await Navigator.pushNamed(context, routeSalesReturn);
                              await OrientationMode.toPortrait();
                              await getSalesDetails();
                            },
                            color: Colors.indigo[400],
                            textColor: kWhite,
                            child: const Text(
                              'إشعار دائن',
                              textAlign: TextAlign.center,
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                      ],
                    ),
                    kHeight10,
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Expanded(
                          child: MaterialButton(
                            height: 50,
                            onPressed: () async {
                              await Navigator.pushNamed(context, routeSalesList);
                              await getSalesDetails();
                            },
                            color: Colors.deepOrange,
                            textColor: kWhite,
                            child: const Text(
                              'سجل المبيعات',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                        kWidth10,
                        Expanded(
                          child: MaterialButton(
                            height: 50,
                            onPressed: () {
                              Navigator.pushNamed(context, routeSalesReturnList);
                            },
                            color: Colors.blueGrey,
                            textColor: kWhite,
                            child: const Text(
                              'سجل المرتجعات',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              adWidget != null
                  ? Container(
                alignment: Alignment.center,
                child: adWidget,
                width: myBanner!.size.width.toDouble(),
                height: myBanner!.size.height.toDouble(),
              ) :  Container( ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> getSalesDetails({bool sale = false}) async {
    try {
      final List<SalesModel> salesModel = await SalesDatabase.instance.getAllSales();

      // Checking if new Sale added!
      if (sale) {
        if (totalSalesNotifier.value == salesModel.length) return;
      }

      totalSalesNotifier.value = salesModel.length;
      totalAmountNotifier.value = 0;
      paidAmountNotifier.value = 0;
      balanceAmountNotifier.value = 0;
      taxAmountNotifier.value = 0;
      overDueAmountNotifier.value = 0;

      for (var i = 0; i < salesModel.length; i++) {
        totalAmountNotifier.value += num.parse(salesModel[i].grantTotal);
        paidAmountNotifier.value += num.parse(salesModel[i].paid);
        balanceAmountNotifier.value += num.parse(salesModel[i].balance);
        taxAmountNotifier.value += num.parse(salesModel[i].vatAmount);
        overDueAmountNotifier.value += num.parse(salesModel[i].balance);
      }
    } catch (e) {
      log(e.toString());
    }
  }
}
