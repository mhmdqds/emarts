import 'package:shared_value/shared_value.dart';

final SharedValue<bool> isLoggedIn = SharedValue(
  value: false, // initial value
  key: "isLoggedIn", // disk storage key for shared_preferences
);

final SharedValue<String> accessToken = SharedValue(
  value: "", // initial value
  key: "accessToken", // disk storage key for shared_preferences
);

final SharedValue<int> userId = SharedValue(
  value: 0, // initial value
  key: "userId", // disk storage key for shared_preferences
);


final SharedValue<String> shopAvatar = SharedValue(
  value: "", // initial value
  key: "shopAvatar", // disk storage key for shared_preferences
);

final SharedValue<String> userInfoComplete = SharedValue(
  value: "", // initial value
  key: "userInfoComplete", // disk storage key for shared_preferences
);

final SharedValue<String> shopAvatarLogo = SharedValue(
  value: "", // initial value
  key: "shopAvatarLogo", // disk storage key for shared_preferences
);


final SharedValue<String> userPhone = SharedValue(
  value: "", // initial value
  key: "userPhone", // disk storage key for shared_preferences
);


final SharedValue<String> cityLive = SharedValue(
  value: "", // initial value
  key: "cityLive", // disk storage key for shared_preferences
);


final SharedValue<String> userCityId = SharedValue(
  value: "", // initial value
  key: "userCityId", // disk storage key for shared_preferences
);

final SharedValue<int> currencyIdLocal = SharedValue(
  value: 0, // initial value
  key: "currencyIdLocal", // disk storage key for shared_preferences
);


final SharedValue<int> chooseCityLocal = SharedValue(
  value: 0, // initial value
  key: "chooseCity", // disk storage key for shared_preferences
);


final SharedValue<String> deviceToken = SharedValue(
  value: "", // initial value
  key: "deviceToken", // disk storage key for shared_preferences
);


final SharedValue<bool> isFirst = SharedValue(
  value: false, // initial value
  key: "isFirst", // disk storage key for shared_preferences
);


final SharedValue<bool> isLastVersion = SharedValue(
  value: true, // initial value
  key: "isLastVersion", // disk storage key for shared_preferences
);


final SharedValue<String> lastVersionNumber = SharedValue(
  value: "", // initial value
  key: "lastVersionNumber", // disk storage key for shared_preferences
);


final SharedValue<String> currentVersionNumber = SharedValue(
  value: "", // initial value
  key: "currentVersionNumber", // disk storage key for shared_preferences
);


final SharedValue<String> myAppLanguage = SharedValue(
  value: "ar", // initial value
  key: "myAppLanguage", // disk storage key for shared_preferences
);

final SharedValue<String> appMobileLanguage = SharedValue(
  value: "ar", // initial value
  key: "appMobileLanguage", // disk storage key for shared_preferences
);

final SharedValue<bool> myAppLanguageRtl = SharedValue(
  value: false, // initial value
  key: "myAppLanguageRtl", // disk storage key for shared_preferences
);

final SharedValue<String> image1Original = SharedValue(
  value: "", // initial value
  key: "image1Original", // disk storage key for shared_preferences
);

final SharedValue<String> image2Original = SharedValue(
  value: "", // initial value
  key: "image2Original", // disk storage key for shared_preferences
);

final SharedValue<String> image3Original = SharedValue(
  value: "", // initial value
  key: "image3Original", // disk storage key for shared_preferences
);

final SharedValue<int> pollingIdSaved = SharedValue(
  value: 0, // initial value
  key: "pollingIdSaved", // disk storage key for shared_preferences
);

final SharedValue<bool> pollingNewSaved = SharedValue(
  value: false, // initial value
  key: "pollingNewSaved", // disk storage key for shared_preferences
);

