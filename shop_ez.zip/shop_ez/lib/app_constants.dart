
import 'package:micro_pos_sys/model/language_model.dart';

class AppConstants {
  static const String appName = 'إمداد- سوق الجملة';
  static const String baseUrl = 'https://emdadb2b.com';
  static const String userId = 'userId';
  static const String name = 'name';


  // sharePreference
  static const String token = 'token';
  static const String user = 'user';



  static List<LanguageModel> languages = [
    LanguageModel(imageUrl: '', languageName: 'Arabic', countryCode: 'SA', languageCode: 'ar'),
    LanguageModel(imageUrl: '', languageName: 'English', countryCode: 'US', languageCode: 'en'),
  ];
}
class Const {
  static const double buttonRadius = 15;
  static const double margin = 18;
  static const double radius = 12;
  static const double space5 = 5;
  static const double space8 = 8;
  static const double space12 = 12;
  static const double space15 = 15;
  static const double space25 = 25;
  static const int splashDuration = 3;
  static const double textFieldRadius = 15;
}