// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'supplier_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_SupplierModel _$$_SupplierModelFromJson(Map<String, dynamic> json) =>
    _$_SupplierModel(
      id: json['_id'] as int?,
      supplierName: json['supplierName'] as String,
      supplierNameArabic: json['supplierNameArabic'] as String,
      contactName: json['contactName'] as String,
      contactNumber: json['contactNumber'] as String,
      vatNumber: json['vatNumber'] as String?,
      email: json['email'] as String?,
      address: json['address'] as String?,
      addressArabic: json['addressArabic'] as String?,
      city: json['city'] as String?,
      cityArabic: json['cityArabic'] as String?,
      state: json['state'] as String?,
      stateArabic: json['stateArabic'] as String?,
      country: json['country'] as String?,
      countryArabic: json['countryArabic'] as String?,
      poBox: json['poBox'] as String?,
    );

Map<String, dynamic> _$$_SupplierModelToJson(_$_SupplierModel instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'supplierName': instance.supplierName,
      'supplierNameArabic': instance.supplierNameArabic,
      'contactName': instance.contactName,
      'contactNumber': instance.contactNumber,
      'vatNumber': instance.vatNumber,
      'email': instance.email,
      'address': instance.address,
      'addressArabic': instance.addressArabic,
      'city': instance.city,
      'cityArabic': instance.cityArabic,
      'state': instance.state,
      'stateArabic': instance.stateArabic,
      'country': instance.country,
      'countryArabic': instance.countryArabic,
      'poBox': instance.poBox,
    };
