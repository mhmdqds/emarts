// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'sales_return_items_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

SalesReturnItemsModel _$SalesReturnItemsModelFromJson(
    Map<String, dynamic> json) {
  return _SalesReturnItemsModel.fromJson(json);
}

/// @nodoc
mixin _$SalesReturnItemsModel {
  @JsonKey(name: '_id')
  int? get id => throw _privateConstructorUsedError;
  int? get saleId => throw _privateConstructorUsedError;
  String? get originalInvoiceNumber => throw _privateConstructorUsedError;
  int get saleReturnId => throw _privateConstructorUsedError;
  int get productId => throw _privateConstructorUsedError;
  String get productType => throw _privateConstructorUsedError;
  String get productCode => throw _privateConstructorUsedError;
  String get productName => throw _privateConstructorUsedError;
  int get categoryId => throw _privateConstructorUsedError;
  String get productCost => throw _privateConstructorUsedError;
  String get netUnitPrice => throw _privateConstructorUsedError;
  String get unitPrice => throw _privateConstructorUsedError;
  String get quantity => throw _privateConstructorUsedError;
  String get unitCode => throw _privateConstructorUsedError;
  String get subTotal => throw _privateConstructorUsedError;
  String get vatMethod => throw _privateConstructorUsedError;
  int get vatId => throw _privateConstructorUsedError;
  String get vatPercentage => throw _privateConstructorUsedError;
  int get vatRate => throw _privateConstructorUsedError;
  String get vatTotal => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $SalesReturnItemsModelCopyWith<SalesReturnItemsModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SalesReturnItemsModelCopyWith<$Res> {
  factory $SalesReturnItemsModelCopyWith(SalesReturnItemsModel value,
          $Res Function(SalesReturnItemsModel) then) =
      _$SalesReturnItemsModelCopyWithImpl<$Res>;
  $Res call(
      {@JsonKey(name: '_id') int? id,
      int? saleId,
      String? originalInvoiceNumber,
      int saleReturnId,
      int productId,
      String productType,
      String productCode,
      String productName,
      int categoryId,
      String productCost,
      String netUnitPrice,
      String unitPrice,
      String quantity,
      String unitCode,
      String subTotal,
      String vatMethod,
      int vatId,
      String vatPercentage,
      int vatRate,
      String vatTotal});
}

/// @nodoc
class _$SalesReturnItemsModelCopyWithImpl<$Res>
    implements $SalesReturnItemsModelCopyWith<$Res> {
  _$SalesReturnItemsModelCopyWithImpl(this._value, this._then);

  final SalesReturnItemsModel _value;
  // ignore: unused_field
  final $Res Function(SalesReturnItemsModel) _then;

  @override
  $Res call({
    Object? id = freezed,
    Object? saleId = freezed,
    Object? originalInvoiceNumber = freezed,
    Object? saleReturnId = freezed,
    Object? productId = freezed,
    Object? productType = freezed,
    Object? productCode = freezed,
    Object? productName = freezed,
    Object? categoryId = freezed,
    Object? productCost = freezed,
    Object? netUnitPrice = freezed,
    Object? unitPrice = freezed,
    Object? quantity = freezed,
    Object? unitCode = freezed,
    Object? subTotal = freezed,
    Object? vatMethod = freezed,
    Object? vatId = freezed,
    Object? vatPercentage = freezed,
    Object? vatRate = freezed,
    Object? vatTotal = freezed,
  }) {
    return _then(_value.copyWith(
      id: id == freezed
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int?,
      saleId: saleId == freezed
          ? _value.saleId
          : saleId // ignore: cast_nullable_to_non_nullable
              as int?,
      originalInvoiceNumber: originalInvoiceNumber == freezed
          ? _value.originalInvoiceNumber
          : originalInvoiceNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      saleReturnId: saleReturnId == freezed
          ? _value.saleReturnId
          : saleReturnId // ignore: cast_nullable_to_non_nullable
              as int,
      productId: productId == freezed
          ? _value.productId
          : productId // ignore: cast_nullable_to_non_nullable
              as int,
      productType: productType == freezed
          ? _value.productType
          : productType // ignore: cast_nullable_to_non_nullable
              as String,
      productCode: productCode == freezed
          ? _value.productCode
          : productCode // ignore: cast_nullable_to_non_nullable
              as String,
      productName: productName == freezed
          ? _value.productName
          : productName // ignore: cast_nullable_to_non_nullable
              as String,
      categoryId: categoryId == freezed
          ? _value.categoryId
          : categoryId // ignore: cast_nullable_to_non_nullable
              as int,
      productCost: productCost == freezed
          ? _value.productCost
          : productCost // ignore: cast_nullable_to_non_nullable
              as String,
      netUnitPrice: netUnitPrice == freezed
          ? _value.netUnitPrice
          : netUnitPrice // ignore: cast_nullable_to_non_nullable
              as String,
      unitPrice: unitPrice == freezed
          ? _value.unitPrice
          : unitPrice // ignore: cast_nullable_to_non_nullable
              as String,
      quantity: quantity == freezed
          ? _value.quantity
          : quantity // ignore: cast_nullable_to_non_nullable
              as String,
      unitCode: unitCode == freezed
          ? _value.unitCode
          : unitCode // ignore: cast_nullable_to_non_nullable
              as String,
      subTotal: subTotal == freezed
          ? _value.subTotal
          : subTotal // ignore: cast_nullable_to_non_nullable
              as String,
      vatMethod: vatMethod == freezed
          ? _value.vatMethod
          : vatMethod // ignore: cast_nullable_to_non_nullable
              as String,
      vatId: vatId == freezed
          ? _value.vatId
          : vatId // ignore: cast_nullable_to_non_nullable
              as int,
      vatPercentage: vatPercentage == freezed
          ? _value.vatPercentage
          : vatPercentage // ignore: cast_nullable_to_non_nullable
              as String,
      vatRate: vatRate == freezed
          ? _value.vatRate
          : vatRate // ignore: cast_nullable_to_non_nullable
              as int,
      vatTotal: vatTotal == freezed
          ? _value.vatTotal
          : vatTotal // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
abstract class _$$_SalesReturnItemsModelCopyWith<$Res>
    implements $SalesReturnItemsModelCopyWith<$Res> {
  factory _$$_SalesReturnItemsModelCopyWith(_$_SalesReturnItemsModel value,
          $Res Function(_$_SalesReturnItemsModel) then) =
      __$$_SalesReturnItemsModelCopyWithImpl<$Res>;
  @override
  $Res call(
      {@JsonKey(name: '_id') int? id,
      int? saleId,
      String? originalInvoiceNumber,
      int saleReturnId,
      int productId,
      String productType,
      String productCode,
      String productName,
      int categoryId,
      String productCost,
      String netUnitPrice,
      String unitPrice,
      String quantity,
      String unitCode,
      String subTotal,
      String vatMethod,
      int vatId,
      String vatPercentage,
      int vatRate,
      String vatTotal});
}

/// @nodoc
class __$$_SalesReturnItemsModelCopyWithImpl<$Res>
    extends _$SalesReturnItemsModelCopyWithImpl<$Res>
    implements _$$_SalesReturnItemsModelCopyWith<$Res> {
  __$$_SalesReturnItemsModelCopyWithImpl(_$_SalesReturnItemsModel _value,
      $Res Function(_$_SalesReturnItemsModel) _then)
      : super(_value, (v) => _then(v as _$_SalesReturnItemsModel));

  @override
  _$_SalesReturnItemsModel get _value =>
      super._value as _$_SalesReturnItemsModel;

  @override
  $Res call({
    Object? id = freezed,
    Object? saleId = freezed,
    Object? originalInvoiceNumber = freezed,
    Object? saleReturnId = freezed,
    Object? productId = freezed,
    Object? productType = freezed,
    Object? productCode = freezed,
    Object? productName = freezed,
    Object? categoryId = freezed,
    Object? productCost = freezed,
    Object? netUnitPrice = freezed,
    Object? unitPrice = freezed,
    Object? quantity = freezed,
    Object? unitCode = freezed,
    Object? subTotal = freezed,
    Object? vatMethod = freezed,
    Object? vatId = freezed,
    Object? vatPercentage = freezed,
    Object? vatRate = freezed,
    Object? vatTotal = freezed,
  }) {
    return _then(_$_SalesReturnItemsModel(
      id: id == freezed
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int?,
      saleId: saleId == freezed
          ? _value.saleId
          : saleId // ignore: cast_nullable_to_non_nullable
              as int?,
      originalInvoiceNumber: originalInvoiceNumber == freezed
          ? _value.originalInvoiceNumber
          : originalInvoiceNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      saleReturnId: saleReturnId == freezed
          ? _value.saleReturnId
          : saleReturnId // ignore: cast_nullable_to_non_nullable
              as int,
      productId: productId == freezed
          ? _value.productId
          : productId // ignore: cast_nullable_to_non_nullable
              as int,
      productType: productType == freezed
          ? _value.productType
          : productType // ignore: cast_nullable_to_non_nullable
              as String,
      productCode: productCode == freezed
          ? _value.productCode
          : productCode // ignore: cast_nullable_to_non_nullable
              as String,
      productName: productName == freezed
          ? _value.productName
          : productName // ignore: cast_nullable_to_non_nullable
              as String,
      categoryId: categoryId == freezed
          ? _value.categoryId
          : categoryId // ignore: cast_nullable_to_non_nullable
              as int,
      productCost: productCost == freezed
          ? _value.productCost
          : productCost // ignore: cast_nullable_to_non_nullable
              as String,
      netUnitPrice: netUnitPrice == freezed
          ? _value.netUnitPrice
          : netUnitPrice // ignore: cast_nullable_to_non_nullable
              as String,
      unitPrice: unitPrice == freezed
          ? _value.unitPrice
          : unitPrice // ignore: cast_nullable_to_non_nullable
              as String,
      quantity: quantity == freezed
          ? _value.quantity
          : quantity // ignore: cast_nullable_to_non_nullable
              as String,
      unitCode: unitCode == freezed
          ? _value.unitCode
          : unitCode // ignore: cast_nullable_to_non_nullable
              as String,
      subTotal: subTotal == freezed
          ? _value.subTotal
          : subTotal // ignore: cast_nullable_to_non_nullable
              as String,
      vatMethod: vatMethod == freezed
          ? _value.vatMethod
          : vatMethod // ignore: cast_nullable_to_non_nullable
              as String,
      vatId: vatId == freezed
          ? _value.vatId
          : vatId // ignore: cast_nullable_to_non_nullable
              as int,
      vatPercentage: vatPercentage == freezed
          ? _value.vatPercentage
          : vatPercentage // ignore: cast_nullable_to_non_nullable
              as String,
      vatRate: vatRate == freezed
          ? _value.vatRate
          : vatRate // ignore: cast_nullable_to_non_nullable
              as int,
      vatTotal: vatTotal == freezed
          ? _value.vatTotal
          : vatTotal // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_SalesReturnItemsModel implements _SalesReturnItemsModel {
  const _$_SalesReturnItemsModel(
      {@JsonKey(name: '_id') this.id,
      this.saleId,
      this.originalInvoiceNumber,
      required this.saleReturnId,
      required this.productId,
      required this.productType,
      required this.productCode,
      required this.productName,
      required this.categoryId,
      required this.productCost,
      required this.netUnitPrice,
      required this.unitPrice,
      required this.quantity,
      required this.unitCode,
      required this.subTotal,
      required this.vatMethod,
      required this.vatId,
      required this.vatPercentage,
      required this.vatRate,
      required this.vatTotal});

  factory _$_SalesReturnItemsModel.fromJson(Map<String, dynamic> json) =>
      _$$_SalesReturnItemsModelFromJson(json);

  @override
  @JsonKey(name: '_id')
  final int? id;
  @override
  final int? saleId;
  @override
  final String? originalInvoiceNumber;
  @override
  final int saleReturnId;
  @override
  final int productId;
  @override
  final String productType;
  @override
  final String productCode;
  @override
  final String productName;
  @override
  final int categoryId;
  @override
  final String productCost;
  @override
  final String netUnitPrice;
  @override
  final String unitPrice;
  @override
  final String quantity;
  @override
  final String unitCode;
  @override
  final String subTotal;
  @override
  final String vatMethod;
  @override
  final int vatId;
  @override
  final String vatPercentage;
  @override
  final int vatRate;
  @override
  final String vatTotal;

  @override
  String toString() {
    return 'SalesReturnItemsModel(id: $id, saleId: $saleId, originalInvoiceNumber: $originalInvoiceNumber, saleReturnId: $saleReturnId, productId: $productId, productType: $productType, productCode: $productCode, productName: $productName, categoryId: $categoryId, productCost: $productCost, netUnitPrice: $netUnitPrice, unitPrice: $unitPrice, quantity: $quantity, unitCode: $unitCode, subTotal: $subTotal, vatMethod: $vatMethod, vatId: $vatId, vatPercentage: $vatPercentage, vatRate: $vatRate, vatTotal: $vatTotal)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_SalesReturnItemsModel &&
            const DeepCollectionEquality().equals(other.id, id) &&
            const DeepCollectionEquality().equals(other.saleId, saleId) &&
            const DeepCollectionEquality()
                .equals(other.originalInvoiceNumber, originalInvoiceNumber) &&
            const DeepCollectionEquality()
                .equals(other.saleReturnId, saleReturnId) &&
            const DeepCollectionEquality().equals(other.productId, productId) &&
            const DeepCollectionEquality()
                .equals(other.productType, productType) &&
            const DeepCollectionEquality()
                .equals(other.productCode, productCode) &&
            const DeepCollectionEquality()
                .equals(other.productName, productName) &&
            const DeepCollectionEquality()
                .equals(other.categoryId, categoryId) &&
            const DeepCollectionEquality()
                .equals(other.productCost, productCost) &&
            const DeepCollectionEquality()
                .equals(other.netUnitPrice, netUnitPrice) &&
            const DeepCollectionEquality().equals(other.unitPrice, unitPrice) &&
            const DeepCollectionEquality().equals(other.quantity, quantity) &&
            const DeepCollectionEquality().equals(other.unitCode, unitCode) &&
            const DeepCollectionEquality().equals(other.subTotal, subTotal) &&
            const DeepCollectionEquality().equals(other.vatMethod, vatMethod) &&
            const DeepCollectionEquality().equals(other.vatId, vatId) &&
            const DeepCollectionEquality()
                .equals(other.vatPercentage, vatPercentage) &&
            const DeepCollectionEquality().equals(other.vatRate, vatRate) &&
            const DeepCollectionEquality().equals(other.vatTotal, vatTotal));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        const DeepCollectionEquality().hash(id),
        const DeepCollectionEquality().hash(saleId),
        const DeepCollectionEquality().hash(originalInvoiceNumber),
        const DeepCollectionEquality().hash(saleReturnId),
        const DeepCollectionEquality().hash(productId),
        const DeepCollectionEquality().hash(productType),
        const DeepCollectionEquality().hash(productCode),
        const DeepCollectionEquality().hash(productName),
        const DeepCollectionEquality().hash(categoryId),
        const DeepCollectionEquality().hash(productCost),
        const DeepCollectionEquality().hash(netUnitPrice),
        const DeepCollectionEquality().hash(unitPrice),
        const DeepCollectionEquality().hash(quantity),
        const DeepCollectionEquality().hash(unitCode),
        const DeepCollectionEquality().hash(subTotal),
        const DeepCollectionEquality().hash(vatMethod),
        const DeepCollectionEquality().hash(vatId),
        const DeepCollectionEquality().hash(vatPercentage),
        const DeepCollectionEquality().hash(vatRate),
        const DeepCollectionEquality().hash(vatTotal)
      ]);

  @JsonKey(ignore: true)
  @override
  _$$_SalesReturnItemsModelCopyWith<_$_SalesReturnItemsModel> get copyWith =>
      __$$_SalesReturnItemsModelCopyWithImpl<_$_SalesReturnItemsModel>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_SalesReturnItemsModelToJson(this);
  }
}

abstract class _SalesReturnItemsModel implements SalesReturnItemsModel {
  const factory _SalesReturnItemsModel(
      {@JsonKey(name: '_id') final int? id,
      final int? saleId,
      final String? originalInvoiceNumber,
      required final int saleReturnId,
      required final int productId,
      required final String productType,
      required final String productCode,
      required final String productName,
      required final int categoryId,
      required final String productCost,
      required final String netUnitPrice,
      required final String unitPrice,
      required final String quantity,
      required final String unitCode,
      required final String subTotal,
      required final String vatMethod,
      required final int vatId,
      required final String vatPercentage,
      required final int vatRate,
      required final String vatTotal}) = _$_SalesReturnItemsModel;

  factory _SalesReturnItemsModel.fromJson(Map<String, dynamic> json) =
      _$_SalesReturnItemsModel.fromJson;

  @override
  @JsonKey(name: '_id')
  int? get id => throw _privateConstructorUsedError;
  @override
  int? get saleId => throw _privateConstructorUsedError;
  @override
  String? get originalInvoiceNumber => throw _privateConstructorUsedError;
  @override
  int get saleReturnId => throw _privateConstructorUsedError;
  @override
  int get productId => throw _privateConstructorUsedError;
  @override
  String get productType => throw _privateConstructorUsedError;
  @override
  String get productCode => throw _privateConstructorUsedError;
  @override
  String get productName => throw _privateConstructorUsedError;
  @override
  int get categoryId => throw _privateConstructorUsedError;
  @override
  String get productCost => throw _privateConstructorUsedError;
  @override
  String get netUnitPrice => throw _privateConstructorUsedError;
  @override
  String get unitPrice => throw _privateConstructorUsedError;
  @override
  String get quantity => throw _privateConstructorUsedError;
  @override
  String get unitCode => throw _privateConstructorUsedError;
  @override
  String get subTotal => throw _privateConstructorUsedError;
  @override
  String get vatMethod => throw _privateConstructorUsedError;
  @override
  int get vatId => throw _privateConstructorUsedError;
  @override
  String get vatPercentage => throw _privateConstructorUsedError;
  @override
  int get vatRate => throw _privateConstructorUsedError;
  @override
  String get vatTotal => throw _privateConstructorUsedError;
  @override
  @JsonKey(ignore: true)
  _$$_SalesReturnItemsModelCopyWith<_$_SalesReturnItemsModel> get copyWith =>
      throw _privateConstructorUsedError;
}
