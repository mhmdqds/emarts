// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'unit_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_UnitModel _$$_UnitModelFromJson(Map<String, dynamic> json) => _$_UnitModel(
      id: json['_id'] as int?,
      unit: json['unit'] as String,
    );

Map<String, dynamic> _$$_UnitModelToJson(_$_UnitModel instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'unit': instance.unit,
    };
