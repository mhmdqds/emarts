// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'expense_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_ExpenseModel _$$_ExpenseModelFromJson(Map<String, dynamic> json) =>
    _$_ExpenseModel(
      id: json['_id'] as int?,
      expenseCategory: json['expenseCategory'] as String,
      expenseTitle: json['expenseTitle'] as String,
      amount: json['amount'] as String,
      date: json['date'] as String,
      payBy: json['payBy'] as String,
      note: json['note'] as String?,
      vatMethod: json['vatMethod'] as String?,
      vatAmount: json['vatAmount'] as String?,
      vatId: json['vatId'] as int?,
      voucherNumber: json['voucherNumber'] as String?,
      documents: json['documents'] as String?,
    );

Map<String, dynamic> _$$_ExpenseModelToJson(_$_ExpenseModel instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'expenseCategory': instance.expenseCategory,
      'expenseTitle': instance.expenseTitle,
      'amount': instance.amount,
      'date': instance.date,
      'payBy': instance.payBy,
      'note': instance.note,
      'vatMethod': instance.vatMethod,
      'vatAmount': instance.vatAmount,
      'vatId': instance.vatId,
      'voucherNumber': instance.voucherNumber,
      'documents': instance.documents,
    };
