// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'expense_category_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_ExpenseCategoryModel _$$_ExpenseCategoryModelFromJson(
        Map<String, dynamic> json) =>
    _$_ExpenseCategoryModel(
      id: json['_id'] as int?,
      expense: json['expense'] as String,
    );

Map<String, dynamic> _$$_ExpenseCategoryModelToJson(
        _$_ExpenseCategoryModel instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'expense': instance.expense,
    };
