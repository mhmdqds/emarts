import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:micro_pos_sys/app_constants.dart';
import 'package:micro_pos_sys/core/routes/route_generator.dart';
import 'package:micro_pos_sys/core/routes/router.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:micro_pos_sys/db/database.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:micro_pos_sys/lang_config.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await EzDatabase.instance.initDB();
  await SystemChrome.setPreferredOrientations(
    [DeviceOrientation.portraitUp, DeviceOrientation.portraitDown],
  );
  MobileAds.instance.initialize();
  runApp(const ProviderScope(child: MyApp()));
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    List<Locale> _locals = [];
    AppConstants.languages.forEach((language) {
      _locals.add(Locale(language.languageCode, language.countryCode));
    });
    return MaterialApp(
      title: "المحاسب الكامل",
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
        AppLocalizations.delegate,
      ],
      supportedLocales: LangConfig().supportedLocales(),
      initialRoute: routeRoot,
      onGenerateRoute: RouteGenerator.generateRoute,
    );
  }
}
