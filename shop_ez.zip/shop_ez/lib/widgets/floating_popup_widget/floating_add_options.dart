import 'package:flutter/material.dart';
import 'package:flutter_speed_dial/flutter_speed_dial.dart';
import 'package:micro_pos_sys/core/constant/colors.dart';
import 'package:micro_pos_sys/core/routes/router.dart';

class FloatingAddOptions extends StatelessWidget {
  const FloatingAddOptions({
    Key? key,
    required this.isDialOpen,
  }) : super(key: key);

  final ValueNotifier<bool> isDialOpen;

  @override
  Widget build(BuildContext context) {
    return SpeedDial(
      backgroundColor: mainColor,
      overlayColor: Colors.black,
      overlayOpacity: 0.5,
      animatedIcon: AnimatedIcons.add_event,
      spacing: 5,
      openCloseDial: isDialOpen,
      children: [
        SpeedDialChild(
          child: const Icon(Icons.receipt_long_rounded),
          label: 'تعريف صنف',
          onTap: () => Navigator.pushNamed(context, routeItemMaster),
        ),
        SpeedDialChild(
          child: const Icon(Icons.add_business_outlined),
          label: 'الموردين',
          onTap: () => Navigator.pushNamed(context, routeAddSupplier),
        ),
        SpeedDialChild(
          child: const Icon(Icons.person_add_outlined),
          label: 'الزبائن',
          onTap: () => Navigator.pushNamed(context, routeAddCustomer),
        ),

        SpeedDialChild(
          child: const Icon(Icons.playlist_add),
          label: 'الأقسام الفرعية',
          onTap: () => Navigator.pushNamed(context, routeSubCategory),
        ),
        SpeedDialChild(
          child: const Icon(Icons.category_outlined),
          label: 'الاقسام',
          onTap: () => Navigator.pushNamed(context, routeCategory),
        ),
        SpeedDialChild(
          child: const Icon(Icons.numbers),
          label: 'الوحدات',
          onTap: () => Navigator.pushNamed(context, routeUnit),
        ),
        SpeedDialChild(
          child: const Icon(Icons.verified_outlined),
          label: 'الماركات',
          onTap: () => Navigator.pushNamed(context, routeBrand),
        ),
        // SpeedDialChild(
        //   child: const Icon(Icons.add_business_outlined),
        //   label: 'Business Profile',
        //   onTap: () => Navigator.pushNamed(context, routeBusinessProfile),
        // ),
        SpeedDialChild(
          child: const Icon(Icons.price_change_outlined),
          label: 'معدل الضريبة',
          onTap: () => Navigator.pushNamed(context, routeVat),
        ),
        SpeedDialChild(
          child: const Icon(Icons.qr_code_2_outlined),
          label: 'الباركود',
          onTap: () => Navigator.pushNamed(context, routeBarcode),
        ),
      ],
    );
  }
}
