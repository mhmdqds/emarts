package com.micro.pos.accountant

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
