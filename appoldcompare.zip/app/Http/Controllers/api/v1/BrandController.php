<?php

namespace App\Http\Controllers\api\v1;

use App\CPU\BrandManager;
use App\CPU\Helpers;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Model\Brand;
use App\Model\Product;

class BrandController extends Controller
{
    public function get_brands()
    {
        try {
            $brands = BrandManager::get_brands();
        } catch (\Exception $e) {
        }

        return response()->json($brands,200);
    }

    public function get_products($brand_id)
    {
      $products = Product::where(['brand_id' => $brand_id])->get();

        foreach($products as $pro) {

             $pro['qty'] = $pro->carton_unit . ' x ' . $pro->unit_numbers . $pro->unit;
        

        }

        return response()->json($products,200);
    }
}
