import 'dart:async';
import 'dart:io';
import 'package:account_book/Screens/loading.dart';
import 'package:file_picker/file_picker.dart';
//import 'package:image_picker/image_picker.dart';
//import 'package:permission_handler/permission_handler.dart';
import 'package:account_book/models/accounts_model.dart';
import 'package:account_book/widgets/drop_down.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
//import 'package:firebase_core/firebase_core.dart';
//import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:account_book/configurations/app_colors.dart';
import 'package:account_book/configurations/dimension.dart';

class AddAccount extends StatefulWidget {
  const AddAccount({super.key});

  @override
  State<AddAccount> createState() => _AddAccountState();
}

class _AddAccountState extends State<AddAccount> {
  String uploadedImage = '';
  @override
  void initState() {
    super.initState();
  }

  final titleController = TextEditingController();
  final phoneNoController = TextEditingController();
  String imageToDatabase = '';
  String imageToUpload = '';

  bool isLoading=false;

  @override
  Widget build(BuildContext context) {
    // const List<String> typeList = <String>['Customer', 'Supplier', 'Other'];

   
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.mainColor,
        title: const Text('إضافة حساب عميل أو مورد'),
      ),
      body: 
      isLoading==false?
      SingleChildScrollView(
        child: Container(
            padding: EdgeInsets.all(Dimensions.height20),
            child: Column(
              children: [
                GestureDetector(
                  onTap: () async {
                    final result = await FilePicker.platform.pickFiles(
                      allowMultiple: false,
                      type: FileType.custom,
                      allowedExtensions: ['png', 'jpg'],
                    );
                    if (result == null) {
                      showSnackError();

                    } else {
                      // final fileName = result.files.single.name;
                      final filePath = result.files.single.path!;
                      imageToUpload=filePath;
                      // String ImageURL =
                      //     await uploadAccountImage(fileName, filePath);

                      setState(() {
                        uploadedImage = result.files.single.path!;
                      });
                    }
                  },
                  child: Container(
                      width: double.maxFinite,
                      height: 250,
                      decoration: BoxDecoration(
                        image: uploadedImage == ''
                            ? const DecorationImage(
                                image: NetworkImage('url'), opacity: 0)
                            : DecorationImage(
                                image: FileImage(
                                  File(uploadedImage),
                                ),
                                fit: BoxFit.cover),
                        borderRadius: BorderRadius.circular(10),
                        color: const Color.fromARGB(255, 243, 243, 243),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.5),
                            spreadRadius: 1,
                            blurRadius: 7,
                            offset: const Offset(0, 0), // changes position of shadow
                          ),
                        ],
                      ),
                      child: uploadedImage == ''
                          ? Center(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  const Text('إرفع صرره الحساب',
                                      style: TextStyle(
                                          fontSize: 20,
                                          fontWeight: FontWeight.w600)),
                                  const SizedBox(
                                    height: 10,
                                  ),
                                  const Text('فقط PNG and JPG مسموح'),
                                  const SizedBox(
                                    height: 20,
                                  ),
                                  Container(
                                    padding: const EdgeInsets.all(20),
                                    width: 300,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      color: Colors.white,
                                    ),
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: const [
                                        Icon(
                                          Icons.cloud_upload_outlined,
                                          size: 50,
                                        ),
                                        SizedBox(
                                          height: 5,
                                        ),
                                        Text('إضغط هنا لرفع صوره'),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            )
                          : Container(
                              alignment: Alignment.topRight,
                              margin: const EdgeInsets.all(10),
                              child: Container(
                                width: 40,
                                height: 40,
                                padding: const EdgeInsets.all(2),
                                decoration: BoxDecoration(
                                  color: const Color.fromARGB(255, 255, 255, 255),
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: IconButton(
                                    onPressed: () => {
                                          setState(() {
                                            uploadedImage = '';
                                          })
                                        },
                                    icon: const Icon(
                                      Icons.delete_rounded,
                                      size: 20,
                                      color: Colors.red,
                                    )),
                              ),
                            )),
                ),
                SizedBox(
                  height: Dimensions.height15,
                ),
                TextField(
                  controller: titleController,
                  onChanged: (String value) => {debugPrint(value)},
                  decoration: const InputDecoration(
                      border: OutlineInputBorder(),
                      hintText: 'إسم العميل أو المورد',
                      prefixIcon: Icon(Icons.account_box)),
                ),
                SizedBox(
                  height: Dimensions.height15,
                ),
                TextField(
                  controller: phoneNoController,
                  onChanged: (String value) => {debugPrint(value)},
                  decoration: const InputDecoration(
                      border: OutlineInputBorder(),
                      hintText: "رقم الهاتف ",
                      prefixIcon: Icon(Icons.phone)),
                ),
                SizedBox(
                  height: Dimensions.height15,
                ),
                const DropDown(),
              ],
            )),
      ):
      const Loading()
      ,
      floatingActionButton: 
      isLoading==false?
      Container(
        padding: const EdgeInsets.only(top: 15, bottom: 0, right: 15, left: 15),
        margin: const EdgeInsets.only(
          left: 0,
          bottom: 0,
          right: 30,
        ),
        alignment: Alignment.bottomCenter,
        child: FloatingActionButton.extended(
          backgroundColor: AppColors.mainColor,
          onPressed: () async  {
            setState(() {
              isLoading=true;
            });
            
            String imageURL = await uploadAccountImage('${titleController.text} | ${DateTime.now().toString()}',imageToUpload,);
             if(imageURL == ""){
               imageURL = "https://img.freepik.com/free-vector/businessman-character-avatar-isolated_24877-60111.jpg?w=740&t=st=1666973637~exp=1666974237~hmac=85143508f2ec52e9df251ae1b03ef76ebef47326e6a9d433ea2df8a08feea754";
             }
            addNewAccount(imageURL, titleController.text, phoneNoController.text, getdropdownValue());
               
                
             showSnack();
             setState(() {
                  isLoading=false;
                });
            //Timer(Duration(seconds: 1), () {
            //   Navigator.pop(context);
           // });
          },
          label: SizedBox(
              width: Dimensions.height40 * 6,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  Icon(Icons.add),
                  Text('حفظ الحساب'),
                ],
              )),
        ),
      ):
        const Text('')
      
      ,
    );
  }

  Future addNewTransaction() async {
    final newTransaction = {
      'AccountTransactions': FieldValue.arrayUnion([
        {
          'date': DateTime.now(),
          'description': 'Account is Created',
          'amount': 0,
          'type': 'created'
        }
      ])
    };
    final newAccount1 = FirebaseFirestore.instance
        .collection('user')
        .doc(FirebaseAuth.instance.currentUser!.uid)
        .collection('accounts')
        .doc();
    await newAccount1.update(newTransaction);
    //  TransactionItem()
  }

  showSnack(){
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
          backgroundColor: Colors.green,
          content: Row(
            children: [
              const Icon(
                Icons.check_box,
                color: Colors.white,
              ),
              SizedBox(
                width: Dimensions.width10,
              ),
              const Text('تم اضافه الحساب بنجاح'),
            ],
          )),
    );
    Navigator.pop(context);
  }

  showSnackError(){
    ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Error Uploading')));
  }
}
