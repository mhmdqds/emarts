import 'package:account_book/common/ads/ad_manager.dart';
import 'package:account_book/configurations/app_colors.dart';
import 'package:account_book/configurations/big_text.dart';
import 'package:account_book/configurations/dimension.dart';
import 'package:account_book/models/accounts_model.dart';
import 'package:account_book/widgets/empty_data.dart';
import 'package:account_book/widgets/list_element.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../../databases/data_streams.dart';
import '../../widgets/highlight_box.dart';

class Accounts extends StatefulWidget {
  const Accounts({super.key});

  @override
  State<Accounts> createState() => _AccountsState();
}

class _AccountsState extends State<Accounts> {
  final adManager = AdManager();
  final TextEditingController _searchController = TextEditingController();
  late String usernameMessage = '';


  @override
  Widget build(BuildContext context) {
    adManager.addAds(true, false, true);
    bool isLoading = false;
    return isLoading==false
        ? StreamBuilder(
            stream: accountForUser(),
            builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
              debugPrint('Here I am ${snapshot.hasData}');

              if(snapshot.stackTrace.toString().isEmpty){
               isLoading=false;
               return const Text('Error');
              }
              else{
              double negativeBalance = 0;
              double positiveBalance = 0;
              if (snapshot.data.toString()=='null') {

                return  const Text('');

              }
               else if (snapshot.hasError) {
                return Text(snapshot.toString());

              }
              else if (snapshot.hasData) {
                debugPrint(snapshot.toString());

                return Column(children: [
                  Row(
                      children: snapshot.data!.docs.map((e) {
                    if (e['AccountBalance'] >= 0) {
                      positiveBalance = positiveBalance + e['AccountBalance'];
                    } else {
                      negativeBalance =
                          negativeBalance + (-1 * (e['AccountBalance']));
                    }

                  return Container(
                      padding: EdgeInsets.zero,
                      margin: EdgeInsets.zero,
                      decoration: const BoxDecoration(color: Colors.red),
                      width: 0,
                      height: 0,
                      child: const Text(''),
                    );
                  }).toList(growable: false)),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      HighlightBox(
                        size: Dimensions.height40 * 4,
                        text: positiveBalance.toString(),
                        //TotalBalance().toString(),
                        //TotalBalance();
                        //  sendPositive().toString(),
                        arrowIcon: Icons.arrow_upward,
                        message: 'اعطيت مبلغ',
                        textColor: Colors.green,
                        color: AppColors.SucessColor,
                      ),
                      HighlightBox(
                        size: Dimensions.height40 * 4,
                        arrowIcon: Icons.arrow_downward,
                        message: 'اخذت مبلغ',
                        textColor: Colors.red,
                        text: negativeBalance.toString(),
                        color: AppColors.DangerColor,
                      ),
                    ],
                  ),
                  Container(
                    margin: EdgeInsets.only(
                        top: Dimensions.height10, bottom: Dimensions.height10),
                    padding: EdgeInsets.all(Dimensions.height5),
                    height: 50,
                    // width: double.maxFinite,
                    width: MediaQuery.of(context).size.width,
                    decoration: const BoxDecoration(),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children:  [
                         SizedBox(
                          width: 230,
                          height: 40,
                          child: TextField(
                            controller: _searchController,
                            decoration: const InputDecoration(
                              filled: true,
                              fillColor: Colors.white70,
                                hintStyle:TextStyle(color: Colors.grey, fontSize: 15),
                              contentPadding: EdgeInsets.only(right: 10),
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(color: Colors.blueAccent),
                                borderRadius: BorderRadius.all(Radius.circular(30.0)),
                              ),
                              hintText: "البحث ...",
                                border: OutlineInputBorder(
                                     borderSide: BorderSide(color: Colors.green),
                                     borderRadius: BorderRadius.all(Radius.circular(30.0)),
                                  ),
                            ),
                            onChanged: (value){
                              debugPrint('CustomerAccountsData[0].username + == $value');
                              // adapter.filter(value);
                              // adManager.showRewardedAd();
                            },
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 0.0, horizontal: 0.0),
                          child: FloatingActionButton(
                            heroTag: "fab1",
                            backgroundColor: Colors.white.withOpacity(0.9),
                            elevation: 2,
                            child:  const Icon(Icons.search, color: Colors.blueAccent,),
                            onPressed: () {
                              adManager.showRewardedAd();
                            },
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 0.0, horizontal: 0.0),
                          child: FloatingActionButton(
                            heroTag: "fab1",
                            backgroundColor: Colors.white.withOpacity(0.9),
                            elevation: 2,
                            child:  const Icon(Icons.picture_as_pdf, color: Colors.red,),
                            onPressed: () {
                              adManager.showRewardedAd();
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                  Row(mainAxisAlignment: MainAxisAlignment.start, children: [
                    Column(
                      children: [
                        BigText(
                          text: 'كل حسابات العملاء والموردين',
                          size: Dimensions.font15,
                        ),
                      ],
                    ),
                  ]),
                  SizedBox(
                    height: Dimensions.height10,
                  ),
                  SizedBox(
                    height: Dimensions.screenHeight - 50,
                    child: SingleChildScrollView(
                      child:
                          // int s = 0;
                          // snapshot==null?
                          //  // s==0?
                          //     Center(child: Text('There is Nothing is here'))
                          //   :
                      ListView(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          children: snapshot.data!.docs.map((e) {

                              positiveBalance =
                                  positiveBalance + e['AccountBalance'];
                              return ListElement(
                                  account: AccountsModel(
                                      accountId: e['AccountId'],
                                      accountImage: e['AccountImage'],
                                      accountTitle: e['AccountTitle'],
                                      accountPhoneNo: e['AccountPhoneNo'],
                                      accountBalance: e['AccountBalance'],
                                      accountType: e['AccountType']));

                          }).toList()),

                    ),
                  ),

                ]);
              } else {
                return const Empty();
              }
      }
      }
      )
 :  const Text('Error');
  }
}
