import 'dart:async';

import 'package:account_book/common/ads/ad_manager.dart';
import 'package:flutter/material.dart';



import 'package:account_book/models/cash_model.dart';
import 'package:account_book/models/user_model.dart';

import '../../configurations/app_colors.dart';
import '../../configurations/dimension.dart';

class AddCashTransaction extends StatefulWidget {

  //final AccountsModel account;
  final String type;
  final UserModel currentUser;

  const AddCashTransaction({
    Key? key,
    required this.type,
    required this.currentUser,
  }) : super(key: key);

  @override
  State<AddCashTransaction> createState() => _AddCashTransactionState();
}

class _AddCashTransactionState extends State<AddCashTransaction> {
DateTime selectedDate = DateTime.now();


  @override
  void initState() {
    // TODO: implement initState
    dateController.text='${selectedDate.day.toString()} / ${selectedDate.month.toString()} / ${selectedDate.year.toString()}';
    super.initState();
  }
  

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
        context: context,
        initialDate: selectedDate,
        firstDate: DateTime(2015, 8),
        lastDate: DateTime(2101));
        
      //      dateController.text='${selectedDate.day.toString()} / ${selectedDate.month.toString()} / ${selectedDate.year.toString()}';



    if (picked != null && picked != selectedDate) {
      setState(() {
        selectedDate = picked;
       dateController.text='${selectedDate.day.toString()} / ${selectedDate.month.toString()} / ${selectedDate.year.toString()}';
      });
    }
  }
  final adManager = AdManager();
  final amountController = TextEditingController();
  final descriptionController = TextEditingController();
  final dateController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    adManager.addAds(true, false, true);
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.mainColor,
        title: widget.type == 'get'
            ? const Text('حفظ الايراد')
            : widget.type == 'give'
                ? const Text('حفظ المصروف')
                : const Text('Error'),
      ),
      body: SingleChildScrollView(
        child: Container(
            padding: EdgeInsets.all(Dimensions.height20),
            child: Column(
              children: [
                TextField(
                  onTap: () {
                      _selectDate(context);
                            dateController.text='${selectedDate.day.toString()} / ${selectedDate.month.toString()} / ${selectedDate.year.toString()}';     
                  },
                  readOnly: true,
                  
                    controller: dateController,
                    onChanged: (String value) => {
                      debugPrint(value),
                    },
                    decoration: InputDecoration(
                     border: const OutlineInputBorder(),
                     
                      hintText: 'حدد التاريخ',
                      
                      prefixIcon: IconButton(
                          onPressed: () {
                            _selectDate(context);
                            dateController.text='${selectedDate.day.toString()} / ${selectedDate.month.toString()} / ${selectedDate.year.toString()}';
                        
                          },
                          icon: const Icon(Icons.calendar_today)),
                    )),

                    SizedBox(
                  height: Dimensions.height15,
                ),

                TextField(
                  controller: amountController,
                  onChanged: (String value) => {debugPrint(value)},
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    hintText: 'المبلغ',
                    prefixIcon: Icon(Icons.money)
                  ),
                ),
                SizedBox(
                  height: Dimensions.height15,
                ),
                TextField(
                //  cursorHeight: 50,
                  controller: descriptionController,
                  onChanged: (String value) => {debugPrint(value)},
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    hintText: 'البيان التفاصيل (إختياري)',
                    prefixIcon: Icon(Icons.description)
                  ),
                ),
              ],
            )),
      ),
      floatingActionButton: Container(
        padding: const EdgeInsets.only(top: 15, bottom: 0, right: 15, left: 15),
        margin: const EdgeInsets.only(
          left: 0,
          bottom: 0,
          right: 30,
        ),
        alignment: Alignment.bottomCenter,
        child: FloatingActionButton.extended(
          backgroundColor: AppColors.mainColor,
          onPressed: () => {

            addNewCashTransaction(widget.currentUser,selectedDate, double.parse(amountController.text),descriptionController.text, widget.type=='get'?true:false),

            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                duration: const Duration(seconds:2),
                  backgroundColor: Colors.green,
                  content: Row(
                    children: [
                      const Icon(
                        Icons.check_box,
                        color: Colors.white,
                      ),
                      SizedBox(
                        width: Dimensions.width10,
                      ),
                     widget.type == 'get'
            ? Text('${amountController.text} PKR added to cash')
            : widget.type == 'give'
                ? Text('${amountController.text} PKR removed from cash')
                : const Text('Error'),
                    ],
                  )),
            ),
              Navigator.pop(context),
          adManager.showRewardedAd()

        },
          label: SizedBox(
              width: Dimensions.height40 * 6,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.add),
                  widget.type == 'get' ? const Text('حفظ') : const Text('حذف'),
                ],
              )),
        ),
      ),
    );
  }
}
