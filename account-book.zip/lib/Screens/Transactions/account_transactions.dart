//import 'dart:ffi';
import 'package:account_book/Screens/Transactions/add_transaction.dart';
import 'package:account_book/common/ads/ad_manager.dart';
import 'package:account_book/models/transaction_model.dart';
import 'package:account_book/configurations/dimension.dart';
import 'package:account_book/configurations/small_text.dart';
import 'package:account_book/widgets/icon_box.dart';
import 'package:account_book/widgets/highlight_box.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../../models/accounts_model.dart';
import '../../configurations/app_colors.dart';
import '../../databases/data_streams.dart';
import '../../widgets/table_element.dart';

class AccountDetailPage extends StatefulWidget {
  
  final AccountsModel account;

  const AccountDetailPage({super.key, required this.account});

  @override
  State<AccountDetailPage> createState() => _AccountDetailPageState();
}

class _AccountDetailPageState extends State<AccountDetailPage> {
  var value;
  bool isLoading = false;

  double getBalance() {
    return widget.account.accountBalance;
  }
  final adManager = AdManager();
  late AccountTransactions aT;

  late BuildContext globalContext;

  void setTheContext(BuildContext context) {
    globalContext = context;
  }

  BuildContext getTheContext() {
    return globalContext;
  }

  Stream<List<AccountTransactions>> getTrans() => FirebaseFirestore.instance
      .collection("transactions")
      .snapshots()
      .map((snapshots) => snapshots.docs
          .map((docs) => AccountTransactions.fromJson(docs.data()))
          .toList());

  @override
  Widget build(BuildContext context) {
    adManager.addAds(true, false, true);
    CollectionReference collectionRef =
        FirebaseFirestore.instance.collection('transactions');

    Future<void> getData() async {
      // Get docs from collection reference
      QuerySnapshot querySnapshot = await collectionRef.get();

      // Get data from docs and convert map to List
      final allData = querySnapshot.docs.map((doc) => doc.data()).toList();

      debugPrint('Data is here : $allData');
    }

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
          backgroundColor: AppColors.mainColor,
          title: Row(
            //  mainAxisAlignment: MainAxisAlignment,

            children: [
              Container(
                width: 30,
                height: 30,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(30),
                  image: DecorationImage(
                      image: NetworkImage(widget.account.accountImage),
                      fit: BoxFit.cover),
                ),
              ),
              SizedBox(
                width: Dimensions.width15,
              ),
              Container(
                  alignment: Alignment.centerLeft,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Title(
                          color: Colors.white,
                          child: Text(
                              widget.account.accountTitle.length >
                                      Dimensions.height10
                                  ? '${widget.account.accountTitle
                                          .substring(0, 9)}...'
                                  : widget.account.accountTitle,
                              overflow: TextOverflow.ellipsis)),
                    ],
                  )),
            ],
          ),
          actions: [
            Container(
              padding: EdgeInsets.only(left: Dimensions.height10),
              alignment: Alignment.centerRight,
              child: IconButton(
                  onPressed: () {
                    showDialog<String>(
                        context: context,
                        builder: (BuildContext context) => AlertDialog(
                              title: const Text("تأكيد حذف الحساب"),
                              content: Text(
                                  "هل تريد حذف هذا الحساب ${widget.account.accountTitle}"),
                              actions: [
                                TextButton(
                                  onPressed: () {
                                    Navigator.pop(context);
                                    adManager.showRewardedAd();
                                  },
                                  child: const Text('إلغاء'),
                                ),
                                TextButton(
                                  onPressed: () {
                                    
                             deleteAccount(widget.account);  
                              Navigator.pop(context);
                              Navigator.pop(context);
                    
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                              duration: const Duration(seconds:2),
                              backgroundColor: Colors.red,
                                content: Row(children: const [
                              Icon(Icons.delete_sweep),
                              SizedBox(width: 10,),
                              Text('تم الحذف'),
                            ])));
                                    
                                  },
                                  child: const SmallText(
                                    text: 'حذف',
                                    color: Colors.red,
                                  ),
                                ),
                              ],
                            ));
                  },
                  icon: const Icon(Icons.delete)

                  // icon:Icons.delete
                  ),
            ),
            Container(
              padding: EdgeInsets.only(left: Dimensions.height10),
              alignment: Alignment.centerRight,
              child: IconButton(
                  onPressed: () {
                    adManager.showRewardedAd();

                  },
                  icon: const Icon(Icons.edit)

                  // icon:Icons.delete
                  ),
            ),
          ]),
      body: isLoading == true
          ? Center(
              child: CircularProgressIndicator(
                backgroundColor: AppColors.mainBlackColor,
              ),
            )
          : Column(
              children: [
                Expanded(
                  child: SingleChildScrollView(
                    child: Container(
                      padding: const EdgeInsets.only(
                          top: 20, right: 20, left: 20, bottom: 80),
                      child: Column(
                        children: [
                          StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
                            stream: FirebaseFirestore.instance
                                .collection('user')
                                .doc(FirebaseAuth.instance.currentUser!.uid)
                                .collection('accounts')
                                .doc(widget.account.accountId)
                                .snapshots(),
                            builder: (_, snapshot) {
                              if (snapshot.hasError) {
                                return Text('Error = ${snapshot.error}');
                              } else if (snapshot.hasData) {
                                var output = snapshot.data!.data();
                                 value = output!['AccountBalance']; // <-- Your value
                                return HighlightBox(
                                    size: Dimensions.height40 * 9,
                                    color: value >= 0
                                        ? AppColors.SucessColor
                                        : AppColors.DangerColor,
                                    textColor:
                                        value >= 0 ? Colors.green : Colors.red,
                                    text: value >= 0
                                        ? '$value'.toString()
                                        : (value * -1).toString(),
                                    message: 'الرصيد الحالي',
                                    arrowIcon: value >= 0
                                        ? Icons.arrow_upward
                                        : Icons.arrow_downward);
                              }
                              return const Center(child: CircularProgressIndicator());
                            },
                          ),
                          SizedBox(
                            height: Dimensions.height20,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              IconBox(
                                  boxIcon: Icons.call,
                                  boxText: 'الاتصال الأن',
                                  boxWidth: Dimensions.width20 * 5.5,
                                  boxLink: 'tel:${widget.account.accountPhoneNo}'),
                              IconBox(
                                  boxIcon: Icons.mail,
                                  boxText: 'إرسال إيميل',
                                  boxWidth: Dimensions.width20 * 5.5,
                                  boxLink: '${widget.account.accountBalance}'),
                              IconBox(
                                  boxIcon: Icons.whatsapp,
                                  boxText: 'واتس أب',
                                  boxWidth: Dimensions.width20 * 5.5,
                                  boxLink:
                                      'wa.me/:${widget.account.accountPhoneNo}'),
                            ],
                          ),
                          Container(
                            padding: const EdgeInsets.only(top: 10),
                            child: Column(
                              children: [
                                Table(

                                    //  TableCellVerticalAlignment.middle,
                                    columnWidths: const <int, TableColumnWidth>{
                                      0: FlexColumnWidth(),
                                      1: FixedColumnWidth(90),
                                      2: FixedColumnWidth(90),
                                    },
                                    defaultVerticalAlignment:
                                        TableCellVerticalAlignment.middle,
                                    children: <TableRow>[
                                      TableRow(children: <TableCell>[
                                        TableCell(
                                            //   verticalAlignment: TableCellVerticalAlignment.bottom,
                                            child: Container(
                                                padding: const EdgeInsets.all(10),
                                                child: const SmallText(
                                                  text: 'السجل',
                                                  size: 12,
                                                ))),
                                        TableCell(
                                            //   verticalAlignment: TableCellVerticalAlignment.baseline,
                                            child: Container(
                                          padding: const EdgeInsets.all(10),
                                          child: Container(
                                            padding: const EdgeInsets.all(10),
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.end,
                                              children: const [
                                                SmallText(
                                                  text: 'أغطيت',
                                                  size: 12,
                                                ),
                                              ],
                                            ),
                                          ),
                                        )),
                                        TableCell(
                                            //    verticalAlignment: TableCellVerticalAlignment.baseline,
                                            child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.end,
                                          children: const [
                                            SmallText(
                                              text: 'أخذت',
                                              size: 12,
                                            ),
                                          ],
                                        )),
                                      ])
                                    ]),
                                SizedBox(
                                  height: Dimensions.height10,
                                ),
                                StreamBuilder(
                                    stream: transactionsOf(
                                        widget.account.accountId),
                                    builder: (context,
                                        AsyncSnapshot<QuerySnapshot>
                                            snapshot) {
                                      if (!snapshot.hasData) {
                                        return const Center(
                                          child: CircularProgressIndicator(
                                            backgroundColor: Colors.red,
                                            color: Colors.white,
                                          ),
                                          //   Text('No Relvant Data => ${snapshot.data} =>')
                                        );
                                      } else if (snapshot.hasError) {
                                        return const Text('Error');
                                      } else {
                                        //     final transaction = snapshot.data;

                                        return SingleChildScrollView(
                                          child: ListView(
                                              shrinkWrap: true,
                                              physics:
                                                  const NeverScrollableScrollPhysics(),
                                              children: snapshot.data!.docs
                                                  .map((e) {
                                                //  print(e['AccountTransactions'][0]['description']);
                                                return TableElement(
                                                    DateCell:
                                                        //   e['AccountTransactions'].length,
                                                        //[0]['description'],
                                                        e['dateTime']
                                                            .toDate(),
                                                    DescriptionCell:
                                                        e['Description']
                                                            .toString(),
                                                    //    'Description',

                                                    //e['AccountTransactions'][0]['description'].toString(),
                                                    TransactionUp:
                                                        (e['Type'] == 'get')
                                                            ? (e['Amount'])
                                                            : (0.0),
                                                    TransactionDown:
                                                        (e['Type'] ==
                                                                'give')
                                                            ? (e['Amount'])
                                                            : (0.0),
                                                    TransactionBalance: e[
                                                        'PreviousBalance']);
                                              }).toList()),
                                        );
                                      }
                                      // else {
                                      //   return CircularProgressIndicator();
                                      // }
                                    }),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
      floatingActionButton: Container(
        padding: const EdgeInsets.only(
          left: 15,
          right: 35,
          bottom: 15,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            FloatingActionButton.extended(
              backgroundColor: Colors.red,
              onPressed: () => {
                //  Navigator.pushNamed(context, '/page2').then((_) => setState(() {}));

                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => AddTransaction(
                              account: widget.account,
                              type: 'اعطيت',
                                    value:value
                            ))).then((value) => setState(
                      () => {},
                    )),
              adManager.showRewardedAd()
            },
              label: SizedBox(
                  width: Dimensions.height40 * 3,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: const [
                      Text('أنا اعطيت'),
                      Icon(Icons.arrow_upward_outlined),
                    ],
                  )),
            ),
            FloatingActionButton.extended(
                backgroundColor: Colors.green,
                onPressed: () => {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => AddTransaction(
                                    account: widget.account,
                                    type: 'أخذت',
                                    value:value
                                  ))),
                adManager.showRewardedAd()
            },
                label: SizedBox(
                    width: Dimensions.height40 * 3,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: const [
                        Text('أنا اخذت'),
                        Icon(Icons.arrow_downward_outlined),
                      ],
                    ))),
          ],
        ),
      ),
    );
  }

  Widget buildList(AccountTransactions trans) => GestureDetector(
        onTap: () => {
//
        },
        child: Container(
            padding: EdgeInsets.only(
                top: Dimensions.height20, bottom: Dimensions.height20),
            decoration: const BoxDecoration(
                border: Border(
                    top: BorderSide(
                        width: 1, color: Color.fromARGB(255, 197, 197, 197)))),
            child: Column(
              children: [
                Text(
                    '${trans.accountId} Amount Boss-> ${trans.amount} Type-> ${trans.typeAcc}')
              ],
            )),
      );
}
