import 'dart:async';

import 'package:account_book/common/ads/ad_manager.dart';
import 'package:account_book/configurations/small_text.dart';
import 'package:account_book/models/accounts_model.dart';
import 'package:account_book/models/transaction_model.dart';

import 'package:flutter/material.dart';


import '../../configurations/app_colors.dart';
import '../../configurations/dimension.dart';

class AddTransaction extends StatefulWidget {
  final AccountsModel account;
  final String type;
  final double value;
  const AddTransaction({super.key, required this.type, required this.account, required this.value});

  @override
  State<AddTransaction> createState() => _AddTransactionState();
}

class _AddTransactionState extends State<AddTransaction> {
DateTime selectedDate = DateTime.now();
  @override
  void initState() {
    // TODO: implement initState
    dateController.text='${selectedDate.day.toString()} / ${selectedDate.month.toString()} / ${selectedDate.year.toString()}';
    super.initState();
  }
  

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
        context: context,
        initialDate: selectedDate,
        firstDate: DateTime(2015, 8),
        lastDate: DateTime(2101));
        
      //      dateController.text='${selectedDate.day.toString()} / ${selectedDate.month.toString()} / ${selectedDate.year.toString()}';



    if (picked != null && picked != selectedDate) {
      setState(() {
        selectedDate = picked;
       dateController.text='${selectedDate.day.toString()} / ${selectedDate.month.toString()} / ${selectedDate.year.toString()}';
      });
    }
  }

  final adManager = AdManager();
  final amountController = TextEditingController();
  final descriptionController = TextEditingController();
  final dateController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    adManager.addAds(true, false, true);
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.mainColor,
        title: widget.type == 'get'
            ? const Text('I got !!')
            : widget.type == 'give'
                ? const Text('I gave !!')
                : const Text('Error'),
      ),
      body: SingleChildScrollView(
        child: Container(
            padding: EdgeInsets.all(Dimensions.height20),
            child: Column(
            //  mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextField(
                  onTap: () {
                      _selectDate(context);
                            dateController.text='${selectedDate.day.toString()} / ${selectedDate.month.toString()} / ${selectedDate.year.toString()}';     
                  },
                  readOnly: true,
                  
                    controller: dateController,
                    onChanged: (String value) => {
                      debugPrint(value),
                    },
                    decoration: InputDecoration(
                     border: const OutlineInputBorder(),
                     
                      hintText: 'Choose Date',
                      
                      prefixIcon: IconButton(
                          onPressed: () {
                            _selectDate(context);
                            dateController.text='${selectedDate.day.toString()} / ${selectedDate.month.toString()} / ${selectedDate.year.toString()}';
                        
                          },
                          icon: const Icon(Icons.calendar_today)),
                    )),

                    SizedBox(
                  height: Dimensions.height15,
                ),

                TextField(
                  controller: amountController,
                  onChanged: (String value) => {debugPrint(value)},
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    hintText: 'المبلغ',
                    prefixIcon: Icon(Icons.money)
                  ),
                ),
                SizedBox(
                  height: Dimensions.height15,
                ),
                TextField(
                //  cursorHeight: 50,
                  controller: descriptionController,
                  onChanged: (String value) => {debugPrint(value)},
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    hintText: 'التفاصيل ',
                    prefixIcon: Icon(Icons.description)
                  ),
                ),
                SizedBox(height: Dimensions.height10),
                SmallText(text: "رصيدك الحالي: ${widget.value}",color: Colors.red,)

              ],
            )),
      ),
      floatingActionButton: Container(
        padding: const EdgeInsets.only(top: 15, bottom: 0, right: 15, left: 15),
        margin: const EdgeInsets.only(
          left: 0,
          bottom: 0,
          right: 30,
        ),
        alignment: Alignment.bottomCenter,
        child: FloatingActionButton.extended(
          backgroundColor: AppColors.mainColor,
          onPressed: () => {
            createTransaction(
                widget.account,
                selectedDate,
                double.parse(amountController.text),
                widget.type,
                descriptionController.text
                ,widget.value
                ),
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                duration: const Duration(seconds:2),
                  backgroundColor: Colors.green,
                  content: Row(
                    children: [
                      const Icon(
                        Icons.check_box,
                        color: Colors.white,
                      ),
                      SizedBox(
                        width: Dimensions.width10,
                      ),
                      const Text('تمت المعاملة بنجاح'),
                    ],
                  )),
            ),
              Navigator.pop(context),
            adManager.showRewardedAd()

          },
          label: SizedBox(
              width: Dimensions.height40 * 6,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.add),
                  widget.type == 'get' ? const Text('إستلام وحفظ') : const Text('دفع وحفظ'),
                ],
              )),
        ),
      ),
    );
  }
}
