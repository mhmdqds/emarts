import 'package:flutter/material.dart';
import 'package:account_book/utility/dimensions.dart';

const titLumRegular = TextStyle(
  fontFamily: 'Cairo',
  fontSize: Dimensions.FONT_SIZE_DEFAULT,
);

const titLumSemiBold = TextStyle(
  fontFamily: 'Cairo',
  fontSize: Dimensions.FONT_SIZE_DEFAULT,
  fontWeight: FontWeight.w600,
);

const titLumBold = TextStyle(
  fontFamily: 'Cairo',
  fontSize: Dimensions.FONT_SIZE_DEFAULT,
  fontWeight: FontWeight.w700,
);
const titLumItalic = TextStyle(
  fontFamily: 'Cairo',
  fontSize: Dimensions.FONT_SIZE_DEFAULT,
  fontStyle: FontStyle.italic,
);

const robotoRegular = TextStyle(
  fontFamily: 'Cairo',
  fontSize: Dimensions.FONT_SIZE_DEFAULT,
);

const robotoRegularSmall = TextStyle(
  fontFamily: 'Cairo',
  fontSize: Dimensions.FONT_SIZE_EXTRA_SMALL,
);

const robotoBold = TextStyle(
  fontFamily: 'Cairo',
  fontSize: Dimensions.FONT_SIZE_DEFAULT,
  fontWeight: FontWeight.w700,
);
