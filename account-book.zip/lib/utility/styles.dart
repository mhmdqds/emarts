import 'package:flutter/material.dart';
import 'package:account_book/utility/color_resources.dart';
import 'package:account_book/utility/dimensions.dart';

const rubikRegular = TextStyle(
  fontFamily: 'Cairo',
  fontSize: Dimensions.FONT_SIZE_DEFAULT,
  fontWeight: FontWeight.w400,
);

const rubikMedium = TextStyle(
  fontFamily: 'Cairo',
  fontSize: Dimensions.FONT_SIZE_DEFAULT,
  fontWeight: FontWeight.w500,
);

const rubikBold = TextStyle(
  fontFamily: 'Cairo',
  fontSize: Dimensions.FONT_SIZE_DEFAULT,
  fontWeight: FontWeight.w700,
);

const khulaRegular = TextStyle(
  color: ColorResources.blackcColor,
  fontFamily: 'Cairo',
  fontSize: Dimensions.FONT_SIZE_DEFAULT,
);
const khulaBold = TextStyle(
  color: ColorResources.blackcColor,
  fontFamily: 'Cairo',
  fontWeight: FontWeight.bold,
  fontSize: Dimensions.FONT_SIZE_DEFAULT,
);
const khulaSemiBold = TextStyle(
  color: ColorResources.blackcColor,
  fontFamily: 'Cairo',
  fontWeight: FontWeight.w600,
  fontSize: Dimensions.FONT_SIZE_DEFAULT,
);