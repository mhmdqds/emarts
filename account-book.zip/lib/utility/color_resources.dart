import 'package:flutter/material.dart';

// ignore: constant_identifier_names
class ColorResources {
  static const Color primary = Color(0xFFB6985B);
  static const Color primary2 = Color(0xFFDACBAD);
  static const Color primary3 = Color(0xFFEDE5D6);
  static const Color black = Color(0xff000000);
  static const Color white = Color(0xffFFFFFF);
  static const Color hintColor = Color(0xff9E9E9E);

  static const Color primaryDark = Color(0xFF1565C0);
  static const Color primaryLight = Color(0xFF1E88E5);
  static const Color accent = Color(0xFFFF4081);
  static const Color accentDark = Color(0xFFF50057);
  static const Color accentLight = Color(0xFFFF80AB);
  static const Color yellowSee = Color(0xffF5963E);

  static const Color grey_3 = Color(0xFFf7f7f7);
  static const Color grey_5 = Color(0xFFf2f2f2);
  static const Color grey_10 = Color(0xFFe6e6e6);
  static const Color grey_20 = Color(0xFFcccccc);
  static const Color grey_40 = Color(0xFF999999);
  static const Color grey_60 = Color(0xFF666666);
  static const Color grey_80 = Color(0xFF37474F);
  static const Color grey_90 = Color(0xFF263238);
  static const Color grey_95 = Color(0xFF1a1a1a);
  static const Color grey_100_ = Color(0xFF0d0d0d);

  static const Color appColorPrimary = Color(0xFFB6985B);
  static const Color appColorAccent = Color(0xFF03DAC5);
  static const Color appTextColorPrimary = Color(0xFF212121);
  static const Color iconColorPrimary = Color(0xFFFFFFFF);
  static const Color appTextColorSecondary = Color(0xFF5A5C5E);
  static const Color iconColorSecondary = Color(0xFFA8ABAD);
  static const Color appLayoutBackground = Color(0xFFf8f8f8);
  static const Color appLightPurple = Color(0xFFdee1ff);
  static const Color appLightOrange = Color(0xFFffddd5);
  static const Color appLightParrotGreen = Color(0xFFb4ef93);
  static const Color appIconTintCherry = Color(0xFFffddd5);
  static const Color appIconTintSkyBlue = Color(0xFF73d8d4);
  static const Color appTxtTintDarkPurple = Color(0xFF515BBE);
  static const Color appIconTintDarkCherry = Color(0xFFf2866c);
  static const Color appIconTintDarkSkyBlue = Color(0xFF73d8d4);
  static const Color appDarkParrotGreen = Color(0xFF5BC136);
  static const Color appDarkRed = Color(0xFFF06263);
  static const Color appLightRed = Color(0xFFF89B9D);
  static const Color appCat1 = Color(0xFF8998FE);
  static const Color appCat2 = Color(0xFFFF9781);
  static const Color appCat3 = Color(0xFF73D7D3);
  static const Color appCat4 = Color(0xFF87CEFA);
  static const Color appCat5 = appColorPrimary;
  static const Color appShadowColor = Color(0x95E9EBF0);
  static const Color appColorPrimaryLight = Color(0xFFF9FAFF);
  static const Color appSecondaryBackgroundColor = Color(0xFF131d25);
  static const Color appDividerColor = Color(0xFFDADADA);
  static const Color barr = Color(0xFFD1870B);

// Dark Theme Colors
  static const Color appBackgroundColorDark = Color(0xFF121212);
  static const Color cardBackgroundBlackDark = Color(0xFF1F1F1F);
  static const Color colorPrimaryBlack = Color(0xFF131d25);
  static const Color appColorPrimaryDarkLight = Color(0xFFF9FAFF);
  static const Color iconColorPrimaryDark = Color(0xFF212121);
  static const Color iconColorSecondaryDark = Color(0xFFA8ABAD);
  static const Color appShadowColorDark = Color(0x1A3E3942);
  static const Color background = Color(0xFFFFFFFF);
  static const Color card = Color(0xFFF8F8F8);
  static const Color fontTitle = Color(0xFF202020);
  static const Color fontSubtitle = Color(0xFF737373);
  static const Color fontDisable = Color(0xFF9B9B9B);
  static const Color disabledButton = Color(0xFFB9B9B9);
  static const Color divider = Color(0xFFDCDCDC);
  static const Color success = Color(0xFF388E3C);
  static const Color warning = Color(0xFFF57C00);
  static const Color error = Color(0xFFD32F2F);
  static const Color info = Color(0xFF1976D2);
  static const Color base = Color(0xFFB6985B);
  static const Map<int, Color> colorMap = {
    50: Color(0x10192D6B),
    100: Color(0x20192D6B),
    200: Color(0x30192D6B),
    300: Color(0x40192D6B),
    400: Color(0x50192D6B),
    500: Color(0x60192D6B),
    600: Color(0x70192D6B),
    700: Color(0x80192D6B),
    800: Color(0x90192D6B),
    900: Color(0xff192D6B),
  };

  // ignore: constant_identifier_names
  static const Color COLOR_PRIMARY = Color(0xFFB6985B);

  static const Color blackcColor = Color(0xff000000);
  static const Color COLOR_WHITE = Color(0xffFFFFFF);
  static const Color COLOR_GRAY = Color(0xff707070);
  static const Color COLOR_HOME_BACKGROUND = Color(0xffF6F6F6);
  static const Color COLOR_GAINSBORO = Color(0xffDBDBDB);
  static const Color COLOR_MAYA_BLUE = Color(0xff3ECDFF);
  static const Color COLOR_GREY = Color(0xFFA0A4A8);
  static const Color neroColor = Color(0xFF1F1F1F);

  static const Color BORDER_COLOR = Color(0xFFDCDCDC);
  static const Color COLOR_GREY_GONDOLA = Color(0xff363636);
  static const Color primary24 = Color(0xff5C4DB1);

}


class HouseHoldColorResources {
  static const Color primary = Color(0xff5C4DB1);
  static const Color neroColor = Color(0xff212121);
}




