import 'package:flutter/material.dart';
import 'package:account_book/utility/color_resources.dart';
import 'package:account_book/utility/dimensions.dart';

const poppinsRegular = TextStyle(
  color: ColorResources.COLOR_GRAY,
  fontFamily: 'Cairo',
  fontSize: Dimensions.FONT_SIZE_DEFAULT,
);
const poppinsBold = TextStyle(
  color: ColorResources.COLOR_GRAY,
  fontFamily: 'Cairo',
  fontWeight: FontWeight.bold,
  fontSize: Dimensions.FONT_SIZE_DEFAULT,
);
const poppinsMedium = TextStyle(
  color: ColorResources.COLOR_GRAY,
  fontFamily: 'Cairo',
  fontWeight: FontWeight.w500,
  fontSize: Dimensions.FONT_SIZE_DEFAULT,
);
const poppinsSemiBold = TextStyle(
  color: ColorResources.COLOR_GRAY,
  fontFamily: 'Cairo',
  fontWeight: FontWeight.w600,
  fontSize: Dimensions.FONT_SIZE_DEFAULT,
);

const robotoRegular = TextStyle(
  color: ColorResources.COLOR_GREY_GONDOLA,
  fontFamily: 'Cairo',
  fontWeight: FontWeight.w400,
  fontSize: Dimensions.FONT_SIZE_DEFAULT,
);

const robotoMedium = TextStyle(
  color: ColorResources.COLOR_GREY_GONDOLA,
  fontFamily: 'Cairo',
  fontWeight: FontWeight.w500,
  fontSize: Dimensions.FONT_SIZE_DEFAULT,
);
const titLumRegular = TextStyle(
  fontFamily: 'Cairo',
  fontSize: Dimensions.FONT_SIZE_DEFAULT,
);

const titLumSemiBold = TextStyle(
  fontFamily: 'Cairo',
  fontSize: Dimensions.FONT_SIZE_DEFAULT,
  fontWeight: FontWeight.w600,
);

const titLumBold = TextStyle(
  fontFamily: 'Cairo',
  fontSize: Dimensions.FONT_SIZE_DEFAULT,
  fontWeight: FontWeight.w700,
);
const titLumItalic = TextStyle(
  fontFamily: 'Cairo',
  fontSize: Dimensions.FONT_SIZE_DEFAULT,
  fontStyle: FontStyle.italic,
);

const robotoBold = TextStyle(
  fontFamily: 'Cairo',
  fontSize: Dimensions.FONT_SIZE_DEFAULT,
  fontWeight: FontWeight.w700,
);