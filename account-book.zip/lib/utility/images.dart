class Images {
  static const String profile = 'assets/images/eng.png';
  static const String product = 'assets/images/splashh.png';
}
