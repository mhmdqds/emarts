import 'package:flutter/material.dart';
import 'package:account_book/utility/color_resources.dart';
import 'package:account_book/utility/dimensions.dart';

const manropeExtraLight = TextStyle(
  color: HouseHoldColorResources.neroColor,
  fontFamily: 'Cairo',
  fontWeight: FontWeight.w200,
  fontSize: HouseHoldDimensions.FONT_SIZE_DEFAULT,
);
const manropeLight = TextStyle(
  color: HouseHoldColorResources.neroColor,
  fontFamily: 'Cairo',
  fontWeight: FontWeight.w300,
  fontSize: HouseHoldDimensions.FONT_SIZE_DEFAULT,
);

const manropeRegular = TextStyle(
  color: HouseHoldColorResources.neroColor,
  fontFamily: 'Cairo',
  fontWeight: FontWeight.w400,
  fontSize: HouseHoldDimensions.FONT_SIZE_DEFAULT,
);

const manropeMedium = TextStyle(
  color: HouseHoldColorResources.neroColor,
  fontFamily: 'Cairo',
  fontWeight: FontWeight.w500,
  fontSize: HouseHoldDimensions.FONT_SIZE_DEFAULT,
);

const manropeSemiBold = TextStyle(
  color: HouseHoldColorResources.neroColor,
  fontFamily: 'Cairo',
  fontWeight: FontWeight.w600,
  fontSize: HouseHoldDimensions.FONT_SIZE_DEFAULT,
);

const manropeBold = TextStyle(
  color: HouseHoldColorResources.neroColor,
  fontFamily: 'Cairo',
  fontWeight: FontWeight.w700,
  fontSize: HouseHoldDimensions.FONT_SIZE_DEFAULT,
);

const manropeExtraBold = TextStyle(
  color: HouseHoldColorResources.neroColor,
  fontFamily: 'Cairo',
  fontWeight: FontWeight.w800,
  fontSize: HouseHoldDimensions.FONT_SIZE_DEFAULT,
);



