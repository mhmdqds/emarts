class Strings {

  //for Splash  screen
  static const String done = 'Done';
  static const String awesome = 'Awesome !';
  // for auth screen
  static const String continue_ = 'Continue';
  // services
  static const String painting = 'Painting';
  static const String cleaning = 'Cleaning';
  static const String electricity = 'Electricity';
  static const String gas = 'Gas';
  static const String wifi = 'Wifi';
  static const String feature = 'Feature';
  static const String faq = 'FAQ';
  static const String review = 'Review';
  static const String home = 'Home';
  static const String service = 'Service';
  static const String cart = 'Cart';
  static const String profile = 'Profile';
  static const String notification = 'Notification';
}
