import 'package:get/get.dart';
import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

class AdsController extends GetxController{

  static AdsController instance = Get.find();

  final AdSize adSize = AdSize.banner;
  late BannerAd myBanner;
  RxBool isAdReady = false.obs;

  _createBanner(){
    myBanner = BannerAd(
      adUnitId: 'ca-app-pub-8532139344201808/6424832226',
      size: AdSize.banner,
      request: const AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (ad){
          isAdReady.value = true;
        },
        onAdFailedToLoad: (add, error){
          Text('$error');
        }
      ),
    );
  }





  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    _createBanner();
    myBanner.load();
  }

}