import 'package:flutter/material.dart';

class MyTheme{
  /*configurable colors stars*/
  static Color accentColor = const Color.fromRGBO( 153, 153, 153, 0.6 );
  static Color softAccentColor = const Color.fromRGBO(247,189,168, 1);
  static Color splashScreenColor = const Color.fromRGBO(63, 83, 181, 1); // if not sure , use the same color as accent color
  /*configurable colors ends*/


  /*If you are not a developer, do not change the bottom colors*/
  static Color lightGrey = const Color.fromRGBO(239,239,239, 1);
  static Color fontGrey = const Color.fromRGBO(22, 29, 50, 1);
  static Color white = const Color.fromRGBO(255,255,255, 1);
  static Color darkGrey = const Color.fromRGBO(112,112,112, 1);
  static Color mediumGrey = const Color.fromRGBO(132,132,132, 1);
  static Color grey_153 = const Color.fromRGBO(153,153,153, 1);
  static Color textFieldGrey = const Color.fromRGBO(209,209,209, 1);
  static Color shimmerBase = Colors.grey.shade50;
  static Color shimmerHighlighted = Colors.grey.shade200;
  static Color mediumGrey_50 = const Color.fromRGBO(132,132,132, .5);
  static Color golden = const Color.fromRGBO(248, 181, 91, 1);
  static Color appColorPrimary = const Color(0xFF1157FA);
  static Color appColorAccent = const Color(0xFF03DAC5);
  static Color appTextColorPrimary = const Color(0xFF212121);
  static Color iconColorPrimary = const Color(0xFFFFFFFF);
  static Color appTextColorSecondary = const Color(0xFF5A5C5E);
  static Color iconColorSecondary = const Color(0xFFA8ABAD);
  static Color appLayoutBackground = const Color(0xFFf8f8f8);
  static Color appLightParrotGreen = const Color(0xFFb4ef93);
  static Color appIconTintCherry = const Color(0xFFffddd5);
  static Color appIconTintDarkCherry = const Color(0xFFf2866c);
  static Color appDarkRed = const Color(0xFFF06263);
  static Color appLightRed = const Color(0xFFF89B9D);
  static Color appCat1 = const Color(0xFF8998FE);
  static Color appCat2 = const Color(0xFFFF9781);
  static Color appCat3 = const Color(0xFF73D7D3);
  static Color appCat4 = const Color(0xFF87CEFA);
  static Color appCat5 = appColorPrimary;
  static Color appShadowColor = const Color(0x95E9EBF0);
  static Color appColorPrimaryLight = const Color(0xFFF9FAFF);
  static Color appSecondaryBackgroundColor = const Color(0xFF131d25);
  static Color appDividerColor = const Color(0xFFDADADA);
// Dark Theme Colors
  static Color appBackgroundColorDark = const Color(0xFF121212);
  static Color cardBackgroundBlackDark = const Color(0xFF1F1F1F);
  static Color appColorPrimaryDarkLight = const Color(0xFFF9FAFF);
  static Color iconColorPrimaryDark = const Color(0xFF212121);
  static Color iconColorSecondaryDark = const Color(0xFFA8ABAD);
  static Color appShadowColorDark = const Color(0x1A3E3942);
  static Color  background = const Color(0xFFFFFFFF);
  static Color  card = const Color(0xFFF8F8F8);
  static Color  fontTitle = const Color(0xFF202020);
  static Color  fontSubtitle = const Color(0xFF737373);
  static Color  fontDisable = const Color(0xFF9B9B9B);
  static Color  disabledButton = const Color(0xFFB9B9B9);
  static Color  divider = const Color(0xFFDCDCDC);
  static Color  success = const Color(0xFF388E3C);
  static Color  warning = const Color(0xFFF57C00);
  static Color  error = const Color(0xFFD32F2F);
  static Color  info = const Color(0xFFB6985B);


  static Color colorPrimaryBlack =const  Color(0xFF131d25);
}