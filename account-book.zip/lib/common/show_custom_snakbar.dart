import 'package:account_book/common/my_theme.dart';
import 'package:flutter/material.dart';

void showCustomSnackBar(String message, BuildContext context, {bool isError = true}) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
    backgroundColor: isError ? MyTheme.appColorPrimary : Colors.green,
    content: Text(message),
  ));
}
