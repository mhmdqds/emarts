import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as paths;

import 'package:account_book/models/transaction_model.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';

import 'package:firebase_storage/firebase_storage.dart' as firebase_storage;
import 'package:firebase_core/firebase_core.dart' as firebase_core;

class AccountsModel {
  String accountId;
  final String accountImage;
  final String accountTitle;
  final String accountPhoneNo;
  final double accountBalance;
  final String accountType;

  AccountsModel({
    required this.accountId,
    required this.accountImage,
    required this.accountTitle,
    required this.accountPhoneNo,
    required this.accountBalance,
    required this.accountType,
  });

  Map<String, dynamic> toJson() => {
        'AccountId': accountId,
        'AccountImage': accountImage,
        'AccountTitle': accountTitle,
        'AccountPhoneNo': accountPhoneNo,
        'AccountBalance': accountBalance,
        'AccountType': accountType,
      };

  static AccountsModel fromJson(Map<String, dynamic> json) => AccountsModel(
    accountId: json['AccountId'],
    accountBalance: json['AccountBalance'],
    accountImage: json['AccountImage'],
    accountPhoneNo: json['AccountPhoneNo'],
    accountTitle: json['AccountTitle'],
    accountType: json['AccountType'], //A: json['A'],
      );
}

//  Method Creating/adding a new account
//  as a document of account collection to
//  firebase firestore

Future addNewAccount(
    String image, String title, String phone, String type) async {
  final newAccount = FirebaseFirestore.instance
      .collection('user')
      .doc(FirebaseAuth.instance.currentUser!.uid)
      .collection('accounts')
      .doc();

  final acc = AccountsModel(
    accountId: newAccount.id,
    accountImage: image,
    accountTitle: title,
    accountPhoneNo: phone,
    accountBalance: 0,
    accountType: type,
  );
  final firstTransaction = AccountTransactions(
      accountId: acc.accountId,
      dateTime: DateTime.now(),
      amount: 0,
      typeAcc: '',
      description: 'New Account Created',
      previousBalance: acc.accountBalance);

  final json = acc.toJson();
  await newAccount.set(json);

  final transactionLink = FirebaseFirestore.instance
      .collection('user')
      .doc(FirebaseAuth.instance.currentUser!.uid)
      .collection('accounts')
      .doc(acc.accountId)
      .collection('transactions')
      .doc('created | ${DateTime.now()}');

  final json1 = firstTransaction.toJson();
  await transactionLink.set(json1);

  await FirebaseFirestore.instance
      .collection('user')
      .doc(FirebaseAuth.instance.currentUser!.uid)
      .update({'TotalAccounts': FieldValue.increment(1)});
}

//  Method deleting account and all of it's
//  transactions from firebase firestore.

Future<void> deleteAccount(AccountsModel account) async {
  
  FirebaseFirestore db = FirebaseFirestore.instance;
  FirebaseFirestore trans = FirebaseFirestore.instance;

  var deleteTransactions = trans
      .collection("user")
      .doc(FirebaseAuth.instance.currentUser!.uid)
      .collection('accounts')
      .doc(account.accountId)
      .collection('transactions');
  var snapshot = await deleteTransactions.get();
  for (var docs in snapshot.docs) {
    await docs.reference.delete();
  }

  db
      .collection("user")
      .doc(FirebaseAuth.instance.currentUser!.uid)
      .collection('accounts')
      .doc(account.accountId)
      .delete()
      .then(
        (doc) => debugPrint("Account Deleted"),
        onError: (e) => debugPrint("Error updating document $e"),
      );

  await FirebaseFirestore.instance
      .collection('user')
      .doc(FirebaseAuth.instance.currentUser!.uid)
      .update({'TotalAccounts': FieldValue.increment(-1)});

var fileUrl = Uri.decodeFull(paths.basename(account.accountImage)).replaceAll(RegExp(r'(\?alt).*'), '');
final desertRef = firebase_storage.FirebaseStorage.instance.ref(fileUrl);
await desertRef.delete();

}




final firebase_storage.FirebaseStorage storage =
    firebase_storage.FirebaseStorage.instance;

Future<String> uploadAccountImage(
  String fileName,
  String filePath,
) async {
  // File file = File(filePath);
  try {
    FirebaseStorage storage = FirebaseStorage.instance;
    Reference ref = storage.ref('${FirebaseAuth.instance.currentUser!.email}/accounts/').child(fileName);
    await ref.putFile(File(filePath));
    String imageUrl = await ref.getDownloadURL();
    debugPrint("Image URL : $imageUrl");
    return imageUrl;
  } on firebase_core.FirebaseException catch (e) {
    debugPrint(e.toString());
  }

  return '';
}

Future<String?> getImage(String imageName) async {
  if (imageName.isEmpty) {
    return null;
  }
  return null;
  //   var urlRef= firebase_storage.FirebaseStorage.instance.ref().child(path)
  // else{
  // }
}
