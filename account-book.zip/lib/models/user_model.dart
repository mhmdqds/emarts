import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class UserModel {
//  final String UserImage;
    final String username;
    final String password;
    final String email;
    final String phoneNo;
    final double cash;
    final String role;
    final int totalAccounts;

  UserModel({
    required this.username,
    required this.email,
    required this.password,
    required this.phoneNo,
    required this.cash,
    required this.totalAccounts,
    required this.role,
  });

  // factory UserModel.fromFirestore(
  //   DocumentSnapshot<Map<String, dynamic>> snapshot,
  //   SnapshotOptions? options,
  // ) {
  //   final data = snapshot.data();
  //   return UserModel(
  //     username: data?['username'],
  //     email: data?['email'],
  //     password: data?['password'],
  //     phoneNo: data?['phoneNo'],
  //     TotalAccounts: data?['TotalAccounts'],
  //     role: data?["role"],
  //     Cash: data?["Cash"]
  //     //    data?['role'] is Iterable ? List.from(data?['role']) : null,
  //   );
  // }


  // Map<String, dynamic> toFirestore() {
  //   return {
  //     'username': username,
  //       'email': email,
  //       'role': role,
  //       'password': password,
  //       'phoneNo': phoneNo,
  //       'Cash': Cash,
  //       'TotalAccounts': TotalAccounts,
  //       'role': role,
  //   };
  // }


   Map<String, dynamic> toJson() => {
     'username': username,
        'email': email,
        'role': role,
        'password': password,
        'phoneNo': phoneNo,
        'Cash': cash,
        'TotalAccounts': totalAccounts,
        // 'role': role,
      };

  static UserModel fromJson(Map<String, dynamic> json) => UserModel(
        username: json['username'],
         email: json['email'],
        password: json['password'],
        phoneNo: json['phoneNo'],
    cash: json['Cash'],
    totalAccounts: json['TotalAccounts'],
        role: json['role'],
      );
}


Future registerNewUser(
    String username, String password, String phoneNo,String email) async {
  final register = FirebaseFirestore.instance
      .collection('user')
      .doc(FirebaseAuth.instance.currentUser!.uid);

  final newUser = UserModel(
      cash: 0,
      phoneNo: phoneNo,
      username: username,
      email: email,
      password: password,
      totalAccounts: 0,
      role: 'user'
      );

  final json = newUser.toJson();
  await register.set(json);
}



