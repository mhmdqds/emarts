import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import 'user_model.dart';

class CashModel {
  final DateTime dateTime;
  final double totalCash;
  final double amount;
  final String description;
  final bool type;

  CashModel({
    required this.dateTime,
    required this.totalCash,
    required this.amount,
    required this.description,
    required this.type,
  });

  Map<String, dynamic> toJson() => {
        'dateTime': dateTime,
        'TotalCash': totalCash,
        'Amount': amount,
        'Description': description,
        'type': type,
      };

  static CashModel fromJson(Map<String, dynamic> json) => CashModel(
        dateTime: json['dateTime'],
        totalCash: json['TotalCash'],
        amount: json['Amount'],
    description: json['Description'],
        type: json['type'],
      );
}

Future addNewCashTransaction(UserModel currentUser, DateTime date,
    double amount, String description, bool type) async {
  final addOrRemoveCash = FirebaseFirestore.instance
      .collection('user')
      .doc(FirebaseAuth.instance.currentUser!.uid)
      .collection('cash');

  // final StoretoUser = FirebaseFirestore.instance
  //     .collection('user')
  //     .doc(FirebaseAuth.instance.currentUser!.uid);

  final cash = CashModel(
      dateTime: date,
      totalCash: currentUser.cash + amount,
      amount: amount,
      description: description,
      type: type);
  final json = cash.toJson();

  await addOrRemoveCash.doc(type == true ? 'Add | $amount' : 'Remove | $amount')
      .set(json);

  // StoretoUser.set({'Cash': Cash.TotalCash.toDouble()});

  await FirebaseFirestore.instance
      .collection('user')
      .doc(FirebaseAuth.instance.currentUser!.uid)
      .update({
    'Cash': type == true
        ? FieldValue.increment(amount)
        : FieldValue.increment(-amount)
  });
}
