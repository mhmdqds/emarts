import 'package:account_book/models/accounts_model.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';



class AccountTransactions {
  final String accountId;
  final DateTime dateTime;
  final double amount;
  final String description;
  final String typeAcc;
  final double previousBalance;
  


  AccountTransactions({
    required this.accountId,
    required this.dateTime,
    required this.amount,
    required this.description,
    required this.typeAcc,
    required this.previousBalance,

  });

  Map<String, dynamic> toJson() => {
    'AccountId': accountId,
        'dateTime': dateTime,
        'Amount': amount,
        'Description':description,
        'Type': Type,

        'PreviousBalance': previousBalance,
      };

  static AccountTransactions fromJson(Map<String, dynamic> json) =>
      AccountTransactions(
        accountId: json['AccountId'],
        dateTime: json['dateTime'],
        amount: json['Amount'],
        description:json['Description'],
        typeAcc: json['Type'],
        previousBalance: json['PreviousBalance'],
      );
}


Future createTransaction(AccountsModel account, DateTime date, double transAmount,
    String type, String description, double updatedBalance) async {
      
      await FirebaseFirestore.instance
      .collection('user')
      .doc(FirebaseAuth.instance.currentUser!.uid)
      .collection('accounts')
      .doc(account.accountId)
      .update({'AccountBalance': type == 'get'
          ? 
       FieldValue.increment(transAmount)
        : FieldValue.increment(-transAmount)
      });


  final addTransaction = FirebaseFirestore.instance
      .collection('user')
      .doc(FirebaseAuth.instance.currentUser!.uid)
      .collection('accounts')
      .doc(account.accountId)
      .collection('transactions');  

  final aT = AccountTransactions(
      accountId: account.accountId,
      dateTime: date,
      amount: transAmount,
      typeAcc: type,
      description: description,
      previousBalance: type == 'get'?updatedBalance+transAmount:
      type == 'give'
         && updatedBalance > transAmount
         ? updatedBalance - transAmount:

      updatedBalance
      //type == 'get'? 
         // account.AccountBalance
        // + TransAmount
        //  : type == 'give'
        // && account.AccountBalance > TransAmount
        // ? account.AccountBalance - TransAmount
        // : account.AccountBalance
             );

  final json = aT.toJson();
  await addTransaction.doc('$type | ${date.toString()}').set(json);
  
  
}

