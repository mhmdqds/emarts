import 'package:account_book/Screens/Accounts/add_account.dart';
import 'package:account_book/Screens/Cash/add_cash_transaction.dart';
import 'package:account_book/ads_review/animated_custom_dialog.dart';
import 'package:account_book/ads_review/review_ok_dialog.dart';
import 'package:account_book/common/ads/ad_manager.dart';
import 'package:account_book/common/constants.dart';
import 'package:account_book/common/shared.dart';
import 'package:account_book/configurations/app_colors.dart';
import 'package:account_book/configurations/dimension.dart';
import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'Screens/Accounts/account_list.dart';
import 'Screens/Cash/cash.dart';
import 'Screens/Admin/my_account.dart';
import 'models/user_model.dart';
//import 'package:get/get.dart';

class HomePage extends StatefulWidget {

   final UserModel user;
   const HomePage({super.key, required this.user,});
 

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {

   UserModel giveUserData(){
    return widget.user;
  }

   final adManager = AdManager();
   BannerAd? myBanner;
   AdWidget? adWidget;
   InterstitialAd? _interstitialAd;
   bool isReview = true;

  @override
  void initState() {
    super.initState();
    Future.delayed(
      Duration.zero,
          () async {
        initAds();
        adManager.showInterstitial();
        adManager.showRewardedAd();
        initReview();
        },
    );
    Future.delayed(
      const Duration(seconds: 5), () async {
      if(isReview == false){
        showAnimatedDialog(context, const ReviewOkDialog(), dismissible: false, isFlip: false);
      }
    },
    );
  }

  int _pageIndex = 0;

   Future<void> initAds() async {
     myBanner = await Shared.getBannerAd(MediaQuery.of(context).size.width.toInt());
     await myBanner!.load();
     adWidget = AdWidget(ad: myBanner!);
     setState(() {});
     await InterstitialAd.load(
       adUnitId: interstitialAdId,
       request: const AdRequest(),
       adLoadCallback: InterstitialAdLoadCallback(
         onAdLoaded: (InterstitialAd ad) {
           // Keep a reference to the ad so you can show it later.
           _interstitialAd = ad;
           debugPrint('Interstitial Ad Loaded');
         },
         onAdFailedToLoad: (LoadAdError error) {
           debugPrint('InterstitialAd failed to load: $error');
         },
       ),
     );
     // _interstitialAd = await Shared.getInterstitialAd();
     // _interstitialAd.show();
   }

   Future<void> initReview() async {
     SharedPreferences prefs = await SharedPreferences.getInstance();
     setState(() {
       isReview = prefs.getBool('isReview') ?? false;
     });
     debugPrint('isReview -- $isReview');
   }

   @override
   void dispose() {
     myBanner!.dispose();
     if (_interstitialAd != null) {
       _interstitialAd!.dispose();
     }
     super.dispose( );
   }

   @override
  Widget build(BuildContext context) {
    adManager.addAds(true, false, true);
    //  print(
    //      'Height : ${Dimensions.screenHeight} Width : ${Dimensions.screenWidth}');
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: AppColors.mainColor,
        title: SizedBox(
            width: 250,
            child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                // crossAxisAlignment: CrossAxisAlignment.center,
                children:  [
                  IconButton(
                    icon: const Icon(Icons.my_library_books_outlined, color: Colors.white60,),
                    onPressed: () async {
                      adManager.showRewardedAd();
                      // await Shared.onPopEventHandler(_interstitialAd!);
                    },
                  ),
                  // Padding(
                  //   padding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 0.0),
                  //   child: FloatingActionButton(
                  //     heroTag: "fab1",
                  //     backgroundColor: Colors.white,
                  //     elevation: 2,
                  //     child: const Icon(Icons.my_library_books_outlined, color: Colors.black87,),
                  //     onPressed: () {
                  //       adManager.showRewardedAd();
                  //     },
                  //   ),
                  // ),
                  // const Icon(Icons.my_library_books_outlined, color: Colors.blue),
                  const SizedBox(
                    width: 10,
                  ),
                  const Text('المحاسب السريع'),
        ])),
        actions: <Widget>[
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 0.0),
            child: FloatingActionButton(
              heroTag: "fab1",
              backgroundColor: Colors.white,
              elevation: 3,
              child: const Icon(Icons.video_collection_outlined, color: Colors.red,),
              onPressed: () async {
                adManager.showRewardedAd();
                // await Shared.onPopEventHandler(_interstitialAd!);
              },
            ),
          ),

        ],
      ),
      body: Container(
        //padding: EdgeInsets.all(20),
        padding: const EdgeInsets.only(top: 10, right: 20, left: 20, bottom: 70),
        // alignment: Alignment.center,
        child:
            // Expanded(
            //   child:
               SingleChildScrollView(
                 scrollDirection: Axis.vertical,
                 child:
                  _pageIndex==0
                      ? const  Accounts()
                      :_pageIndex==1
                      ? const Cash()
                      : MyAccount(user: widget.user),

                ),
        //  ),
      ),
      floatingActionButton:  Container(
            padding: const EdgeInsets.only(bottom: 0, right: 15, left: 15),
            margin: const EdgeInsets.only(
              left: 0,
              bottom: 0,
              right: 30,
            ),
            decoration: const BoxDecoration(
              //   borderRadius: BorderRadius.circular(20),
              // color: Colors.white
            ),
            child: Container(
              //     mainAxisAlignment: MainAxisAlignment.spaceBetween,

              child: _pageIndex == 1
                  ? Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                    FloatingActionButton.extended(
                      backgroundColor: Colors.green,
                      onPressed: () async => {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    AddCashTransaction(currentUser: widget.user, type: 'get'))),
                        await Shared.onPopEventHandler(_interstitialAd!),
                      adManager.showRewardedAd()

                      },
                      label: SizedBox(
                          width: Dimensions.height40 * 3,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: const [
                              Text('أخذت'),
                              Icon(Icons.arrow_downward_outlined),
                            ],
                          )),
                    ),
                    FloatingActionButton.extended(
                        backgroundColor: Colors.red,
                        onPressed: () async => {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>
                                      AddCashTransaction(currentUser: widget.user, type: 'give'))),
                          await Shared.onPopEventHandler(_interstitialAd!),
                        adManager.showRewardedAd()
                    },
                        label: SizedBox(
                            width: Dimensions.height40 * 3,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: const [
                                Text('أعطيت'),
                                Icon(Icons.arrow_upward_outlined),
                              ],
                            ))),
                ],
              )
                  : _pageIndex == 0
                  ? Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                    FloatingActionButton.extended(
                      backgroundColor: AppColors.mainColor,
                      onPressed: () async => {
                        //    GetOneAccountTransactions("bqj2DKvVYUhbJXYLOmKO"),
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const AddAccount()),
                        ),
                        await Shared.onPopEventHandler(_interstitialAd!),
                      adManager.showRewardedAd()
                    },
                      label: SizedBox(
                          width: Dimensions.height40 * 6,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Icon(Icons.add),
                              SizedBox(
                                width: Dimensions.height10,
                              ),
                              const Text('إضافة عميل/مورد'),
                            ],
                          )),
                    ),
                ],
              )
                  : Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                    FloatingActionButton.extended(
                      backgroundColor: Colors.red,
                      onPressed: () {
                        adManager.showRewardedAd();
                        // Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const Login()));
                        //FirebaseAuth.instance.signOut();
                      },
                      label: SizedBox(
                          width: Dimensions.height40 * 7,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Icon(Icons.logout),
                              SizedBox(
                                width: Dimensions.height10,
                              ),
                              const Text('خروج من التطبيق'),
                            ],
                          )),
                    ),
                ],
              ),
            ),
          // )
        //:Text('data'),
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _pageIndex,
        selectedItemColor: AppColors.mainColor,
        items: items,
        onTap: ((value) => {
              setState(() {
                _pageIndex = value;
              }),
        // adManager.showInterstitial()
            }),
      ),
    );
  }


 // List<Widget> pages = [Accounts(), const Cash(),  MyAccount(user: GiveUserData(),)];

  List<BottomNavigationBarItem> items = [
    const BottomNavigationBarItem(icon: Icon(Icons.menu_book), label: 'دفتر الديون'),
    const BottomNavigationBarItem(icon: Icon(Icons.wallet_outlined), label: 'دفتر النقدية'),
    const BottomNavigationBarItem(icon: Icon(Icons.settings_applications), label: 'الإعدادات',),
  ];
}
