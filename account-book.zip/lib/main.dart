
import 'package:account_book/home_page.dart';
import 'package:account_book/models/user_model.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';

import 'package:account_book/configurations/app_colors.dart';
import 'package:account_book/configurations/big_text.dart';
import 'package:account_book/configurations/small_text.dart';
import 'package:animated_splash_screen/animated_splash_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'Screens/Admin/log_in.dart';

UserModel? currentUser;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  MobileAds.instance.initialize();
  bool isLoginCheck = false;
  User? user = FirebaseAuth.instance.currentUser;

  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    systemNavigationBarDividerColor: Colors.transparent,
  ));
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  SharedPreferences prefs = await SharedPreferences.getInstance();
    debugPrint('user:: $user');
    isLoginCheck =  prefs.getBool("isLogin") ?? false;
    debugPrint('isLoginCheck:: $isLoginCheck');
    if(user != null) {
      currentUser = UserModel(
        username: prefs.getString("username") ?? "",
        email: prefs.getString("email") ?? "",
        password: prefs.getString("password") ?? "",
        phoneNo: prefs.getString("phoneNo") ?? "",
        cash: double.parse(prefs.getString("Cash").toString()),
        totalAccounts: prefs.getInt("TotalAccounts") ?? 0,
        role: prefs.getString("role") ?? "",
      );
    }
  // print(Get.context!.height);
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
        title: 'المحاسب السريع',

        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        supportedLocales: const [
          Locale('en', 'EN'), // English, no country code
          Locale('ar', 'AR'), // Spanish, no country code
        ],
        locale: const Locale("ar", "AR"), // OR Locale('ar', 'AE') OR Other RTL locales,

        theme: ThemeData(
          primarySwatch: Colors.blue,
        ),
        home: AnimatedSplashScreen(
            splashIconSize: double.infinity, //Dimensions.screenHeight,
            duration: 200,
            splash: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                Image(
                    width: 100,
                    height: 100,
                    image: AssetImage('assets/images/accountbooklogo.png')),
                BigText(
                  text: 'المحاسب السريع',
                  color: Colors.white,
                  size: 20,
                ),
                SizedBox(height: 10),
                SmallText(
                  text: 'اسهل تطبيق لأدارة حساباتك',
                  size: 11,
                  color: Colors.white,
                  weight: FontWeight.w100,
                )
              ],
            ),
            nextScreen: FirebaseAuth.instance.currentUser == null
            ? const Login()
            : HomePage(user: currentUser!),
            splashTransition: SplashTransition.fadeTransition,
            backgroundColor: AppColors.mainColor),
             );
  }
}
