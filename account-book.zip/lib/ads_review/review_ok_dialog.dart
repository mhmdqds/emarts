import 'package:flutter/material.dart';
import 'package:launch_review/launch_review.dart';
import 'package:account_book/utility/color_resources.dart';
import 'package:account_book/utility/dimensions.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../utility/custom_themes.dart';

class ReviewOkDialog extends StatefulWidget {
  final bool? isIncrement;

  const ReviewOkDialog({super.key,   this.isIncrement});

  @override
  State<ReviewOkDialog> createState() => _ReviewOkDialogState();
}

class _ReviewOkDialogState extends State<ReviewOkDialog> {

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return MediaQuery(
        data: MediaQuery.of(context).copyWith(textScaleFactor: 1 + (1 / size.height)), // Large
    child: Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(
          width: 400,
          height: 80,
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(15),
            child: const Image(
              image: AssetImage(
                  "assets/images/5-Star-Rating.png"),
            ),
          ),
        ),
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: Dimensions.PADDING_SIZE_LARGE, vertical: 30),
          child: Text('  لكي نستمر في تطوير التطبيق فضلا  \n  اكتب لنا مقترحاتكً \n وقيمنا في المتجر 5 نجمات\nواتحدث عنا بأسلوبك الرائع وشكراً مقدمًا  ',
              style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,fontSize: 16,), textAlign: TextAlign.center,)
        ),
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: Dimensions.PADDING_SIZE_LARGE, vertical: 10),
        ),
        const Divider(height: 0, color: ColorResources.hintColor),
        Row(children: [
          Expanded(child: InkWell(
            onTap: () async {
              Navigator.pop(context);
              LaunchReview.launch(androidAppId: "com.smart.account_book");
              SharedPreferences prefs = await SharedPreferences.getInstance();
              await prefs.setBool('isReview', true);
            },
            child: Container(
              padding: const EdgeInsets.all(Dimensions.PADDING_SIZE_SMALL),
              alignment: Alignment.center,
              decoration: const BoxDecoration(color: ColorResources.primary, borderRadius: BorderRadius.only(topRight: Radius.circular(10), topLeft: Radius.circular(10))),
              child: Text('Review Now\n تقـــيــيــم الآن', style: titLumBold.copyWith(color: ColorResources.white, fontSize: Dimensions.FONT_SIZE_LARGE)),
            ),
          )),
        ]),
      ]),
      ),
    );
  }
}
