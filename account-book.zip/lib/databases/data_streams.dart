import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

// Stream<QuerySnapshot<Map<String, dynamic>>> AllUsers() {
//   return FirebaseFirestore.instance.collection('user').snapshots();
// }

Stream<QuerySnapshot<Map<String, dynamic>>> transactionsOf(String account) {
  return FirebaseFirestore.instance
      .collection('user')
      .doc(FirebaseAuth.instance.currentUser!.uid)
      .collection('accounts')
      .doc(account)
      .collection('transactions')
      .orderBy('dateTime', descending: true)
      .snapshots();
}


Stream<QuerySnapshot<Map<String, dynamic>>> cashTransactionsOfCurrentUser() {
  return FirebaseFirestore.instance
      .collection('user')
      .doc(FirebaseAuth.instance.currentUser!.uid)
      .collection('cash')
      .orderBy('dateTime', descending: true)
      .snapshots();
}




Stream<QuerySnapshot<Map<String, dynamic>>> accountForUser() {
  return FirebaseFirestore.instance
      .collection('user')
      .doc(FirebaseAuth.instance.currentUser!.uid)
      .collection('accounts')
      .snapshots();
}


Stream<QuerySnapshot<Map<String, dynamic>>> allUsers() {
  return FirebaseFirestore.instance
      .collection('user')
      .snapshots();
}


// Get document with ID totalVisitors in collection dashboard
