import 'package:account_book/configurations/app_colors.dart';
import 'package:flutter/material.dart';

import 'package:url_launcher/url_launcher.dart';

import '../configurations/dimension.dart';
import '../configurations/small_text.dart';

class IconBox extends StatelessWidget {
  final IconData boxIcon;
  final String boxText;
  final double boxWidth;
  final String boxLink;
  late Uri _url ;

  IconBox(
      {super.key,
      required this.boxIcon,
      required this.boxText,
      required this.boxWidth,
      required this.boxLink
      });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => {
                   Uri.parse(boxLink),
        debugPrint('$Uri link $boxLink'),
                   _launchUrl   ,
                   
                    ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                  backgroundColor:AppColors.mainColor,
                  content: Row(
                    children: [
                      const Icon(
                        Icons.link,
                        color: Colors.white,
                      ),
                      SizedBox(width: Dimensions.width10,),
                      Text(boxLink),
                    ],
                  )),
            ),


        _launchUrl(),

      },
      child: Container(
          margin:
              EdgeInsets.only(left: Dimensions.width5, right: Dimensions.width5),
          padding: EdgeInsets.only(
              top: Dimensions.height15,
              bottom: Dimensions.height15,
              left: Dimensions.width20,
              right: Dimensions.width20),
              
       //  width:BoxWidth,
          //Dimensions.width20 * 5,
          //height: (Dimensions.height40*2),
    
          decoration: BoxDecoration(
            color: const Color.fromARGB(255, 242, 242, 242),
            borderRadius: BorderRadius.circular(Dimensions.height10),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                boxIcon,
                size: 20,
                color: AppColors.mainColor,
              ),
              SizedBox(
                height: Dimensions.height10,
              ),
              SmallText(
                text: boxText,
                color: AppColors.mainColor,
              )
            ],
          )),
    );
  }



    Future<void> _launchUrl() async {
  if (!await launchUrl(_url)) {
    debugPrint('Error');
    throw 'Could not launch $_url';
   
  }
}
}
