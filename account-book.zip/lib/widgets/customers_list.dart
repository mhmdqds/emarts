import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';


import 'package:account_book/Screens/Transactions/account_transactions.dart';
import 'package:account_book/models/accounts_model.dart';
import 'package:account_book/configurations/big_text.dart';
import 'package:account_book/configurations/dimension.dart';
import 'package:account_book/configurations/small_text.dart';
import '../configurations/app_colors.dart';

class CustomerList extends StatelessWidget {
  final String image;
  final String customerName;
  final double balance;
  final Color color;
  late BuildContext globalContext;
  late FirebaseFirestore db;

  void setTheContext(BuildContext context) {
    globalContext = context;
  }

  BuildContext getTheContext() {
    return globalContext;
  }

  CustomerList({
    Key? key,
    required this.image,
    required this.customerName,
    required this.balance,
    required this.color, 
    //required this.db,
  }) : super(key: key);





  Stream<List<AccountsModel>> getAccount() => FirebaseFirestore.instance
     // .collection('user').doc('o4yqvPnb7z5BCbV4a7DS').
      .collection('accounts').orderBy('AccountTitle',descending: false)
      .snapshots()
      .map((snapshots) => snapshots.docs
          .map((docs) => AccountsModel.fromJson(docs.data()))
          .toList());


    //        Stream<List<AccountTransactions>> GetAccount() => FirebaseFirestore.instance
    //  // .collection('user').doc('o4yqvPnb7z5BCbV4a7DS').
    //   .collection('transactions')
    //   .snapshots()
    //   .map((snapshots) => snapshots.docs
    //       .map((docs) => AccountTransactions.fromJson(docs.data()))
    //       .toList());


          

// void getStarted_readData() =>FirebaseFirestore.instance
//       .collection('accounts').get().then((value){
//       for (var doc in event.docs) {
//         print("${doc.id} => ${doc.data()}");
//       }});
      // .snapshots()
      // .map((snapshots) => snapshots.docs
      //     .map((docs) => AccountsC.fromJson(docs.data()))
      //     .toList());


  @override
  Widget build(BuildContext context) {
    setTheContext(context);

    return SingleChildScrollView(
      physics: const NeverScrollableScrollPhysics(),
      child: StreamBuilder<List<AccountsModel>>(
          stream: getAccount(),
          builder: (context, snapshot) {
            if (snapshot.data == null) {
              return
              Text('لا توجد بيانات ذات صلة${snapshot.data}');

            } else if (snapshot.hasError) {
              return const Text('Error');
            } else if (snapshot.hasData) {
              final accounts = snapshot.data!;

              return ListView(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                children: accounts.map(buildList).toList(),
              );
            } else {
              return const CircularProgressIndicator();
            }
          }),
    );
  }

  Widget buildList(AccountsModel account) => GestureDetector(
        onTap: () => {
          Navigator.push(
              getTheContext(),
              MaterialPageRoute(
                  builder: (context) => AccountDetailPage(account: account))),
        },
        child: Container(
          padding: EdgeInsets.only(
              top: Dimensions.height20, bottom: Dimensions.height20),
          decoration: const BoxDecoration(
              border: Border(
                  top: BorderSide(
                      width: 1, color: Color.fromARGB(255, 197, 197, 197)))),
          child: Column(
            children: [
              Table(
                columnWidths: const <int, TableColumnWidth>{
                  0: FixedColumnWidth(64),
                  1: FlexColumnWidth(),
                  2: IntrinsicColumnWidth(),
                },
                children: <TableRow>[
                  TableRow(
                    children: <Widget>[
                      TableCell(
                        child: Column(
                          children: [
                            Container(
                              width: 50,
                              height: 50,
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(30),
                                  // image: DecorationImage(
                                  //     image:
                                  //         NetworkImage(account.AccountImage),
                                  //     fit: BoxFit.cover)
                                      ),
                            ),
                          ],
                        ),
                      ),
                      TableCell(
                        verticalAlignment: TableCellVerticalAlignment.middle,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            BigText(
                              text: account.accountTitle,
                            //   text: account.AccountId,
                              size: Dimensions.font15,
                            ),
                            SizedBox(height: Dimensions.height10,),
                            Container(
                              width: Dimensions.width30*3,
                                decoration: BoxDecoration(
                                    color: AppColors.SucessColor,
                                    borderRadius: BorderRadius.circular(5)),
                                padding: const EdgeInsets.all(7),
                                child: Row(
                                  children: [

                                //    Icon(Icons.delivery_dining),
                                 account.accountType == 'Supplier'?
                                  //   account.Type == 'get'?
                                      const Icon(Icons.delivery_dining,  color: Colors.grey,
                                      size: 12,):
                                   //   account.Type=='give'
                                     account.accountType ==
                                         'Customer'
                                        ?
                                      const Icon(Icons.sell,  color: Colors.grey,
                                      size: 12,):
                                    const Icon(Icons.account_box,  color: Colors.grey,
                                      size: 12,),
                                    SizedBox(width: Dimensions.width5,),
                                    BigText(
                                       text: account.accountType,
                                  //    text: account.PreviousBalance.toString(),
                                      color: Colors.grey,
                                      size: 12,
                                    ),
                                  ],
                                ))
                          ],
                        ),
                      ),
                      TableCell(
                        child: SmallText(
                          text: 'Rs. ${account.accountBalance}',
                          color: account.accountBalance >= 0
                              ? Colors.green
                              : Colors.red,
                          weight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      );
}
