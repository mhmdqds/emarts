import 'package:account_book/models/accounts_model.dart';
import 'package:account_book/configurations/app_colors.dart';
import 'package:account_book/configurations/big_text.dart';
import 'package:account_book/configurations/dimension.dart';
import 'package:account_book/configurations/small_text.dart';
import 'package:flutter/material.dart';

import '../Screens/Transactions/account_transactions.dart';

class ListElement extends StatefulWidget {
  final AccountsModel account;
  const ListElement({super.key, required this.account});

  @override
  State<ListElement> createState() => _ListElementState();
}

class _ListElementState extends State<ListElement> {

  // account1=widget.account;
  @override
  Widget build(BuildContext context) {
       AccountsModel account1= widget.account;
    return GestureDetector(
      onTap: () => {
      debugPrint('CustomerAccountsData ${widget.account}'),

        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => AccountDetailPage(account: account1)))
                .then((value) { setState(() {});})
      },
      child: Container(
        padding: EdgeInsets.only(
            top: Dimensions.height20, bottom: Dimensions.height20),
        decoration: const BoxDecoration(
            border: Border(
                top: BorderSide(
                    width: 1, color: Color.fromARGB(255, 197, 197, 197)))),
        child: Column(
          children: [
            Table(
              columnWidths: const <int, TableColumnWidth>{
                0: FixedColumnWidth(64),
                1: FlexColumnWidth(),
                2: IntrinsicColumnWidth(),
              },
              children: <TableRow>[
                TableRow(
                  children: <Widget>[
                    TableCell(
                      child: Column(
                        children: [
                          Container(
                            width: 50,
                            height: 50,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(30),
                                image: DecorationImage(
                                    image: NetworkImage(widget.account.accountImage),
                                    fit: BoxFit.cover)),
                          ),
                        ],
                      ),
                    ),
                    TableCell(
                      verticalAlignment: TableCellVerticalAlignment.middle,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          BigText(
                            text: widget.account.accountTitle,
                            //   text: account.AccountId,
                            size: Dimensions.font15,
                          ),
                          SizedBox(
                            height: Dimensions.height10,
                          ),
                          Container(
                              width: Dimensions.width30 * 3,
                              decoration: BoxDecoration(
                                  color: AppColors.SucessColor,
                                  borderRadius: BorderRadius.circular(5)),
                              padding: const EdgeInsets.all(7),
                              child: Row(
                                children: [
                                  //    Icon(Icons.delivery_dining),
                                  widget.account.accountType == 'Supplier'
                                      ?
                                      //   account.Type == 'get'?
                                      const Icon(
                                          Icons.delivery_dining,
                                          color: Colors.grey,
                                          size: 12,
                                        )
                                      :
                                      //   account.Type=='give'
                                      widget.account.accountType == 'Customer'
                                          ? const Icon(
                                              Icons.sell,
                                              color: Colors.grey,
                                              size: 12,
                                            )
                                          : const Icon(
                                              Icons.account_box,
                                              color: Colors.grey,
                                              size: 12,
                                            ),
                                  SizedBox(
                                    width: Dimensions.width5,
                                  ),
                                  BigText(
                                    text: widget.account.accountType,
                                    //    text: account.PreviousBalance.toString(),
                                    color: Colors.grey,
                                    size: 12,
                                  ),
                                ],
                              ))
                        ],
                      ),
                    ),
                    TableCell(
                      child: SmallText(
                        text: 'Rs. ${widget.account.accountBalance}',
                        color: widget.account.accountBalance >= 0
                            ? Colors.green
                            : Colors.red,
                        weight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
