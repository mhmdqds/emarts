package com.example.shop_ez

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
