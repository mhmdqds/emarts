// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'user_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_UserModel _$$_UserModelFromJson(Map<String, dynamic> json) => _$_UserModel(
      id: json['_id'] as int?,
      groupId: json['groupId'] as int,
      shopName: json['shopName'] as String,
      countryName: json['countryName'] as String,
      shopCategory: json['shopCategory'] as String,
      mobileNumber: json['mobileNumber'] as String,
      username: json['username'] as String,
      password: json['password'] as String,
      status: json['status'] as int,
      email: json['email'] as String?,
      name: json['name'] as String?,
      nameArabic: json['nameArabic'] as String?,
      address: json['address'] as String?,
      document: json['document'] as String?,
    );

Map<String, dynamic> _$$_UserModelToJson(_$_UserModel instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'groupId': instance.groupId,
      'shopName': instance.shopName,
      'countryName': instance.countryName,
      'shopCategory': instance.shopCategory,
      'mobileNumber': instance.mobileNumber,
      'username': instance.username,
      'password': instance.password,
      'status': instance.status,
      'email': instance.email,
      'name': instance.name,
      'nameArabic': instance.nameArabic,
      'address': instance.address,
      'document': instance.document,
    };
