// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'supplier_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

SupplierModel _$SupplierModelFromJson(Map<String, dynamic> json) {
  return _SupplierModel.fromJson(json);
}

/// @nodoc
mixin _$SupplierModel {
  @JsonKey(name: '_id')
  int? get id => throw _privateConstructorUsedError;
  String get supplierName => throw _privateConstructorUsedError;
  String get supplierNameArabic => throw _privateConstructorUsedError;
  String get contactName => throw _privateConstructorUsedError;
  String get contactNumber => throw _privateConstructorUsedError;
  String? get vatNumber => throw _privateConstructorUsedError;
  String? get email => throw _privateConstructorUsedError;
  String? get address => throw _privateConstructorUsedError;
  String? get addressArabic => throw _privateConstructorUsedError;
  String? get city => throw _privateConstructorUsedError;
  String? get cityArabic => throw _privateConstructorUsedError;
  String? get state => throw _privateConstructorUsedError;
  String? get stateArabic => throw _privateConstructorUsedError;
  String? get country => throw _privateConstructorUsedError;
  String? get countryArabic => throw _privateConstructorUsedError;
  String? get poBox => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $SupplierModelCopyWith<SupplierModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SupplierModelCopyWith<$Res> {
  factory $SupplierModelCopyWith(
          SupplierModel value, $Res Function(SupplierModel) then) =
      _$SupplierModelCopyWithImpl<$Res>;
  $Res call(
      {@JsonKey(name: '_id') int? id,
      String supplierName,
      String supplierNameArabic,
      String contactName,
      String contactNumber,
      String? vatNumber,
      String? email,
      String? address,
      String? addressArabic,
      String? city,
      String? cityArabic,
      String? state,
      String? stateArabic,
      String? country,
      String? countryArabic,
      String? poBox});
}

/// @nodoc
class _$SupplierModelCopyWithImpl<$Res>
    implements $SupplierModelCopyWith<$Res> {
  _$SupplierModelCopyWithImpl(this._value, this._then);

  final SupplierModel _value;
  // ignore: unused_field
  final $Res Function(SupplierModel) _then;

  @override
  $Res call({
    Object? id = freezed,
    Object? supplierName = freezed,
    Object? supplierNameArabic = freezed,
    Object? contactName = freezed,
    Object? contactNumber = freezed,
    Object? vatNumber = freezed,
    Object? email = freezed,
    Object? address = freezed,
    Object? addressArabic = freezed,
    Object? city = freezed,
    Object? cityArabic = freezed,
    Object? state = freezed,
    Object? stateArabic = freezed,
    Object? country = freezed,
    Object? countryArabic = freezed,
    Object? poBox = freezed,
  }) {
    return _then(_value.copyWith(
      id: id == freezed
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int?,
      supplierName: supplierName == freezed
          ? _value.supplierName
          : supplierName // ignore: cast_nullable_to_non_nullable
              as String,
      supplierNameArabic: supplierNameArabic == freezed
          ? _value.supplierNameArabic
          : supplierNameArabic // ignore: cast_nullable_to_non_nullable
              as String,
      contactName: contactName == freezed
          ? _value.contactName
          : contactName // ignore: cast_nullable_to_non_nullable
              as String,
      contactNumber: contactNumber == freezed
          ? _value.contactNumber
          : contactNumber // ignore: cast_nullable_to_non_nullable
              as String,
      vatNumber: vatNumber == freezed
          ? _value.vatNumber
          : vatNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      email: email == freezed
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String?,
      address: address == freezed
          ? _value.address
          : address // ignore: cast_nullable_to_non_nullable
              as String?,
      addressArabic: addressArabic == freezed
          ? _value.addressArabic
          : addressArabic // ignore: cast_nullable_to_non_nullable
              as String?,
      city: city == freezed
          ? _value.city
          : city // ignore: cast_nullable_to_non_nullable
              as String?,
      cityArabic: cityArabic == freezed
          ? _value.cityArabic
          : cityArabic // ignore: cast_nullable_to_non_nullable
              as String?,
      state: state == freezed
          ? _value.state
          : state // ignore: cast_nullable_to_non_nullable
              as String?,
      stateArabic: stateArabic == freezed
          ? _value.stateArabic
          : stateArabic // ignore: cast_nullable_to_non_nullable
              as String?,
      country: country == freezed
          ? _value.country
          : country // ignore: cast_nullable_to_non_nullable
              as String?,
      countryArabic: countryArabic == freezed
          ? _value.countryArabic
          : countryArabic // ignore: cast_nullable_to_non_nullable
              as String?,
      poBox: poBox == freezed
          ? _value.poBox
          : poBox // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
abstract class _$$_SupplierModelCopyWith<$Res>
    implements $SupplierModelCopyWith<$Res> {
  factory _$$_SupplierModelCopyWith(
          _$_SupplierModel value, $Res Function(_$_SupplierModel) then) =
      __$$_SupplierModelCopyWithImpl<$Res>;
  @override
  $Res call(
      {@JsonKey(name: '_id') int? id,
      String supplierName,
      String supplierNameArabic,
      String contactName,
      String contactNumber,
      String? vatNumber,
      String? email,
      String? address,
      String? addressArabic,
      String? city,
      String? cityArabic,
      String? state,
      String? stateArabic,
      String? country,
      String? countryArabic,
      String? poBox});
}

/// @nodoc
class __$$_SupplierModelCopyWithImpl<$Res>
    extends _$SupplierModelCopyWithImpl<$Res>
    implements _$$_SupplierModelCopyWith<$Res> {
  __$$_SupplierModelCopyWithImpl(
      _$_SupplierModel _value, $Res Function(_$_SupplierModel) _then)
      : super(_value, (v) => _then(v as _$_SupplierModel));

  @override
  _$_SupplierModel get _value => super._value as _$_SupplierModel;

  @override
  $Res call({
    Object? id = freezed,
    Object? supplierName = freezed,
    Object? supplierNameArabic = freezed,
    Object? contactName = freezed,
    Object? contactNumber = freezed,
    Object? vatNumber = freezed,
    Object? email = freezed,
    Object? address = freezed,
    Object? addressArabic = freezed,
    Object? city = freezed,
    Object? cityArabic = freezed,
    Object? state = freezed,
    Object? stateArabic = freezed,
    Object? country = freezed,
    Object? countryArabic = freezed,
    Object? poBox = freezed,
  }) {
    return _then(_$_SupplierModel(
      id: id == freezed
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int?,
      supplierName: supplierName == freezed
          ? _value.supplierName
          : supplierName // ignore: cast_nullable_to_non_nullable
              as String,
      supplierNameArabic: supplierNameArabic == freezed
          ? _value.supplierNameArabic
          : supplierNameArabic // ignore: cast_nullable_to_non_nullable
              as String,
      contactName: contactName == freezed
          ? _value.contactName
          : contactName // ignore: cast_nullable_to_non_nullable
              as String,
      contactNumber: contactNumber == freezed
          ? _value.contactNumber
          : contactNumber // ignore: cast_nullable_to_non_nullable
              as String,
      vatNumber: vatNumber == freezed
          ? _value.vatNumber
          : vatNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      email: email == freezed
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String?,
      address: address == freezed
          ? _value.address
          : address // ignore: cast_nullable_to_non_nullable
              as String?,
      addressArabic: addressArabic == freezed
          ? _value.addressArabic
          : addressArabic // ignore: cast_nullable_to_non_nullable
              as String?,
      city: city == freezed
          ? _value.city
          : city // ignore: cast_nullable_to_non_nullable
              as String?,
      cityArabic: cityArabic == freezed
          ? _value.cityArabic
          : cityArabic // ignore: cast_nullable_to_non_nullable
              as String?,
      state: state == freezed
          ? _value.state
          : state // ignore: cast_nullable_to_non_nullable
              as String?,
      stateArabic: stateArabic == freezed
          ? _value.stateArabic
          : stateArabic // ignore: cast_nullable_to_non_nullable
              as String?,
      country: country == freezed
          ? _value.country
          : country // ignore: cast_nullable_to_non_nullable
              as String?,
      countryArabic: countryArabic == freezed
          ? _value.countryArabic
          : countryArabic // ignore: cast_nullable_to_non_nullable
              as String?,
      poBox: poBox == freezed
          ? _value.poBox
          : poBox // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_SupplierModel implements _SupplierModel {
  const _$_SupplierModel(
      {@JsonKey(name: '_id') this.id,
      required this.supplierName,
      required this.supplierNameArabic,
      required this.contactName,
      required this.contactNumber,
      this.vatNumber,
      this.email,
      this.address,
      this.addressArabic,
      this.city,
      this.cityArabic,
      this.state,
      this.stateArabic,
      this.country,
      this.countryArabic,
      this.poBox});

  factory _$_SupplierModel.fromJson(Map<String, dynamic> json) =>
      _$$_SupplierModelFromJson(json);

  @override
  @JsonKey(name: '_id')
  final int? id;
  @override
  final String supplierName;
  @override
  final String supplierNameArabic;
  @override
  final String contactName;
  @override
  final String contactNumber;
  @override
  final String? vatNumber;
  @override
  final String? email;
  @override
  final String? address;
  @override
  final String? addressArabic;
  @override
  final String? city;
  @override
  final String? cityArabic;
  @override
  final String? state;
  @override
  final String? stateArabic;
  @override
  final String? country;
  @override
  final String? countryArabic;
  @override
  final String? poBox;

  @override
  String toString() {
    return 'SupplierModel(id: $id, supplierName: $supplierName, supplierNameArabic: $supplierNameArabic, contactName: $contactName, contactNumber: $contactNumber, vatNumber: $vatNumber, email: $email, address: $address, addressArabic: $addressArabic, city: $city, cityArabic: $cityArabic, state: $state, stateArabic: $stateArabic, country: $country, countryArabic: $countryArabic, poBox: $poBox)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_SupplierModel &&
            const DeepCollectionEquality().equals(other.id, id) &&
            const DeepCollectionEquality()
                .equals(other.supplierName, supplierName) &&
            const DeepCollectionEquality()
                .equals(other.supplierNameArabic, supplierNameArabic) &&
            const DeepCollectionEquality()
                .equals(other.contactName, contactName) &&
            const DeepCollectionEquality()
                .equals(other.contactNumber, contactNumber) &&
            const DeepCollectionEquality().equals(other.vatNumber, vatNumber) &&
            const DeepCollectionEquality().equals(other.email, email) &&
            const DeepCollectionEquality().equals(other.address, address) &&
            const DeepCollectionEquality()
                .equals(other.addressArabic, addressArabic) &&
            const DeepCollectionEquality().equals(other.city, city) &&
            const DeepCollectionEquality()
                .equals(other.cityArabic, cityArabic) &&
            const DeepCollectionEquality().equals(other.state, state) &&
            const DeepCollectionEquality()
                .equals(other.stateArabic, stateArabic) &&
            const DeepCollectionEquality().equals(other.country, country) &&
            const DeepCollectionEquality()
                .equals(other.countryArabic, countryArabic) &&
            const DeepCollectionEquality().equals(other.poBox, poBox));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(id),
      const DeepCollectionEquality().hash(supplierName),
      const DeepCollectionEquality().hash(supplierNameArabic),
      const DeepCollectionEquality().hash(contactName),
      const DeepCollectionEquality().hash(contactNumber),
      const DeepCollectionEquality().hash(vatNumber),
      const DeepCollectionEquality().hash(email),
      const DeepCollectionEquality().hash(address),
      const DeepCollectionEquality().hash(addressArabic),
      const DeepCollectionEquality().hash(city),
      const DeepCollectionEquality().hash(cityArabic),
      const DeepCollectionEquality().hash(state),
      const DeepCollectionEquality().hash(stateArabic),
      const DeepCollectionEquality().hash(country),
      const DeepCollectionEquality().hash(countryArabic),
      const DeepCollectionEquality().hash(poBox));

  @JsonKey(ignore: true)
  @override
  _$$_SupplierModelCopyWith<_$_SupplierModel> get copyWith =>
      __$$_SupplierModelCopyWithImpl<_$_SupplierModel>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_SupplierModelToJson(this);
  }
}

abstract class _SupplierModel implements SupplierModel {
  const factory _SupplierModel(
      {@JsonKey(name: '_id') final int? id,
      required final String supplierName,
      required final String supplierNameArabic,
      required final String contactName,
      required final String contactNumber,
      final String? vatNumber,
      final String? email,
      final String? address,
      final String? addressArabic,
      final String? city,
      final String? cityArabic,
      final String? state,
      final String? stateArabic,
      final String? country,
      final String? countryArabic,
      final String? poBox}) = _$_SupplierModel;

  factory _SupplierModel.fromJson(Map<String, dynamic> json) =
      _$_SupplierModel.fromJson;

  @override
  @JsonKey(name: '_id')
  int? get id => throw _privateConstructorUsedError;
  @override
  String get supplierName => throw _privateConstructorUsedError;
  @override
  String get supplierNameArabic => throw _privateConstructorUsedError;
  @override
  String get contactName => throw _privateConstructorUsedError;
  @override
  String get contactNumber => throw _privateConstructorUsedError;
  @override
  String? get vatNumber => throw _privateConstructorUsedError;
  @override
  String? get email => throw _privateConstructorUsedError;
  @override
  String? get address => throw _privateConstructorUsedError;
  @override
  String? get addressArabic => throw _privateConstructorUsedError;
  @override
  String? get city => throw _privateConstructorUsedError;
  @override
  String? get cityArabic => throw _privateConstructorUsedError;
  @override
  String? get state => throw _privateConstructorUsedError;
  @override
  String? get stateArabic => throw _privateConstructorUsedError;
  @override
  String? get country => throw _privateConstructorUsedError;
  @override
  String? get countryArabic => throw _privateConstructorUsedError;
  @override
  String? get poBox => throw _privateConstructorUsedError;
  @override
  @JsonKey(ignore: true)
  _$$_SupplierModelCopyWith<_$_SupplierModel> get copyWith =>
      throw _privateConstructorUsedError;
}
