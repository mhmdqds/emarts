// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'expense_category_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

ExpenseCategoryModel _$ExpenseCategoryModelFromJson(Map<String, dynamic> json) {
  return _ExpenseCategoryModel.fromJson(json);
}

/// @nodoc
mixin _$ExpenseCategoryModel {
  @JsonKey(name: '_id')
  int? get id => throw _privateConstructorUsedError;
  String get expense => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ExpenseCategoryModelCopyWith<ExpenseCategoryModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ExpenseCategoryModelCopyWith<$Res> {
  factory $ExpenseCategoryModelCopyWith(ExpenseCategoryModel value,
          $Res Function(ExpenseCategoryModel) then) =
      _$ExpenseCategoryModelCopyWithImpl<$Res>;
  $Res call({@JsonKey(name: '_id') int? id, String expense});
}

/// @nodoc
class _$ExpenseCategoryModelCopyWithImpl<$Res>
    implements $ExpenseCategoryModelCopyWith<$Res> {
  _$ExpenseCategoryModelCopyWithImpl(this._value, this._then);

  final ExpenseCategoryModel _value;
  // ignore: unused_field
  final $Res Function(ExpenseCategoryModel) _then;

  @override
  $Res call({
    Object? id = freezed,
    Object? expense = freezed,
  }) {
    return _then(_value.copyWith(
      id: id == freezed
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int?,
      expense: expense == freezed
          ? _value.expense
          : expense // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
abstract class _$$_ExpenseCategoryModelCopyWith<$Res>
    implements $ExpenseCategoryModelCopyWith<$Res> {
  factory _$$_ExpenseCategoryModelCopyWith(_$_ExpenseCategoryModel value,
          $Res Function(_$_ExpenseCategoryModel) then) =
      __$$_ExpenseCategoryModelCopyWithImpl<$Res>;
  @override
  $Res call({@JsonKey(name: '_id') int? id, String expense});
}

/// @nodoc
class __$$_ExpenseCategoryModelCopyWithImpl<$Res>
    extends _$ExpenseCategoryModelCopyWithImpl<$Res>
    implements _$$_ExpenseCategoryModelCopyWith<$Res> {
  __$$_ExpenseCategoryModelCopyWithImpl(_$_ExpenseCategoryModel _value,
      $Res Function(_$_ExpenseCategoryModel) _then)
      : super(_value, (v) => _then(v as _$_ExpenseCategoryModel));

  @override
  _$_ExpenseCategoryModel get _value => super._value as _$_ExpenseCategoryModel;

  @override
  $Res call({
    Object? id = freezed,
    Object? expense = freezed,
  }) {
    return _then(_$_ExpenseCategoryModel(
      id: id == freezed
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int?,
      expense: expense == freezed
          ? _value.expense
          : expense // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_ExpenseCategoryModel extends _ExpenseCategoryModel {
  const _$_ExpenseCategoryModel(
      {@JsonKey(name: '_id') this.id, required this.expense})
      : super._();

  factory _$_ExpenseCategoryModel.fromJson(Map<String, dynamic> json) =>
      _$$_ExpenseCategoryModelFromJson(json);

  @override
  @JsonKey(name: '_id')
  final int? id;
  @override
  final String expense;

  @override
  String toString() {
    return 'ExpenseCategoryModel(id: $id, expense: $expense)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_ExpenseCategoryModel &&
            const DeepCollectionEquality().equals(other.id, id) &&
            const DeepCollectionEquality().equals(other.expense, expense));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(id),
      const DeepCollectionEquality().hash(expense));

  @JsonKey(ignore: true)
  @override
  _$$_ExpenseCategoryModelCopyWith<_$_ExpenseCategoryModel> get copyWith =>
      __$$_ExpenseCategoryModelCopyWithImpl<_$_ExpenseCategoryModel>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_ExpenseCategoryModelToJson(this);
  }
}

abstract class _ExpenseCategoryModel extends ExpenseCategoryModel {
  const factory _ExpenseCategoryModel(
      {@JsonKey(name: '_id') final int? id,
      required final String expense}) = _$_ExpenseCategoryModel;
  const _ExpenseCategoryModel._() : super._();

  factory _ExpenseCategoryModel.fromJson(Map<String, dynamic> json) =
      _$_ExpenseCategoryModel.fromJson;

  @override
  @JsonKey(name: '_id')
  int? get id => throw _privateConstructorUsedError;
  @override
  String get expense => throw _privateConstructorUsedError;
  @override
  @JsonKey(ignore: true)
  _$$_ExpenseCategoryModelCopyWith<_$_ExpenseCategoryModel> get copyWith =>
      throw _privateConstructorUsedError;
}
