// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'expense_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

ExpenseModel _$ExpenseModelFromJson(Map<String, dynamic> json) {
  return _ExpenseModel.fromJson(json);
}

/// @nodoc
mixin _$ExpenseModel {
  @JsonKey(name: '_id')
  int? get id => throw _privateConstructorUsedError;
  String get expenseCategory => throw _privateConstructorUsedError;
  String get expenseTitle => throw _privateConstructorUsedError;
  String get amount => throw _privateConstructorUsedError;
  String get date => throw _privateConstructorUsedError;
  String get payBy => throw _privateConstructorUsedError;
  String? get note => throw _privateConstructorUsedError;
  String? get vatMethod => throw _privateConstructorUsedError;
  String? get vatAmount => throw _privateConstructorUsedError;
  int? get vatId => throw _privateConstructorUsedError;
  String? get voucherNumber => throw _privateConstructorUsedError;
  String? get documents => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ExpenseModelCopyWith<ExpenseModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ExpenseModelCopyWith<$Res> {
  factory $ExpenseModelCopyWith(
          ExpenseModel value, $Res Function(ExpenseModel) then) =
      _$ExpenseModelCopyWithImpl<$Res>;
  $Res call(
      {@JsonKey(name: '_id') int? id,
      String expenseCategory,
      String expenseTitle,
      String amount,
      String date,
      String payBy,
      String? note,
      String? vatMethod,
      String? vatAmount,
      int? vatId,
      String? voucherNumber,
      String? documents});
}

/// @nodoc
class _$ExpenseModelCopyWithImpl<$Res> implements $ExpenseModelCopyWith<$Res> {
  _$ExpenseModelCopyWithImpl(this._value, this._then);

  final ExpenseModel _value;
  // ignore: unused_field
  final $Res Function(ExpenseModel) _then;

  @override
  $Res call({
    Object? id = freezed,
    Object? expenseCategory = freezed,
    Object? expenseTitle = freezed,
    Object? amount = freezed,
    Object? date = freezed,
    Object? payBy = freezed,
    Object? note = freezed,
    Object? vatMethod = freezed,
    Object? vatAmount = freezed,
    Object? vatId = freezed,
    Object? voucherNumber = freezed,
    Object? documents = freezed,
  }) {
    return _then(_value.copyWith(
      id: id == freezed
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int?,
      expenseCategory: expenseCategory == freezed
          ? _value.expenseCategory
          : expenseCategory // ignore: cast_nullable_to_non_nullable
              as String,
      expenseTitle: expenseTitle == freezed
          ? _value.expenseTitle
          : expenseTitle // ignore: cast_nullable_to_non_nullable
              as String,
      amount: amount == freezed
          ? _value.amount
          : amount // ignore: cast_nullable_to_non_nullable
              as String,
      date: date == freezed
          ? _value.date
          : date // ignore: cast_nullable_to_non_nullable
              as String,
      payBy: payBy == freezed
          ? _value.payBy
          : payBy // ignore: cast_nullable_to_non_nullable
              as String,
      note: note == freezed
          ? _value.note
          : note // ignore: cast_nullable_to_non_nullable
              as String?,
      vatMethod: vatMethod == freezed
          ? _value.vatMethod
          : vatMethod // ignore: cast_nullable_to_non_nullable
              as String?,
      vatAmount: vatAmount == freezed
          ? _value.vatAmount
          : vatAmount // ignore: cast_nullable_to_non_nullable
              as String?,
      vatId: vatId == freezed
          ? _value.vatId
          : vatId // ignore: cast_nullable_to_non_nullable
              as int?,
      voucherNumber: voucherNumber == freezed
          ? _value.voucherNumber
          : voucherNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      documents: documents == freezed
          ? _value.documents
          : documents // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
abstract class _$$_ExpenseModelCopyWith<$Res>
    implements $ExpenseModelCopyWith<$Res> {
  factory _$$_ExpenseModelCopyWith(
          _$_ExpenseModel value, $Res Function(_$_ExpenseModel) then) =
      __$$_ExpenseModelCopyWithImpl<$Res>;
  @override
  $Res call(
      {@JsonKey(name: '_id') int? id,
      String expenseCategory,
      String expenseTitle,
      String amount,
      String date,
      String payBy,
      String? note,
      String? vatMethod,
      String? vatAmount,
      int? vatId,
      String? voucherNumber,
      String? documents});
}

/// @nodoc
class __$$_ExpenseModelCopyWithImpl<$Res>
    extends _$ExpenseModelCopyWithImpl<$Res>
    implements _$$_ExpenseModelCopyWith<$Res> {
  __$$_ExpenseModelCopyWithImpl(
      _$_ExpenseModel _value, $Res Function(_$_ExpenseModel) _then)
      : super(_value, (v) => _then(v as _$_ExpenseModel));

  @override
  _$_ExpenseModel get _value => super._value as _$_ExpenseModel;

  @override
  $Res call({
    Object? id = freezed,
    Object? expenseCategory = freezed,
    Object? expenseTitle = freezed,
    Object? amount = freezed,
    Object? date = freezed,
    Object? payBy = freezed,
    Object? note = freezed,
    Object? vatMethod = freezed,
    Object? vatAmount = freezed,
    Object? vatId = freezed,
    Object? voucherNumber = freezed,
    Object? documents = freezed,
  }) {
    return _then(_$_ExpenseModel(
      id: id == freezed
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int?,
      expenseCategory: expenseCategory == freezed
          ? _value.expenseCategory
          : expenseCategory // ignore: cast_nullable_to_non_nullable
              as String,
      expenseTitle: expenseTitle == freezed
          ? _value.expenseTitle
          : expenseTitle // ignore: cast_nullable_to_non_nullable
              as String,
      amount: amount == freezed
          ? _value.amount
          : amount // ignore: cast_nullable_to_non_nullable
              as String,
      date: date == freezed
          ? _value.date
          : date // ignore: cast_nullable_to_non_nullable
              as String,
      payBy: payBy == freezed
          ? _value.payBy
          : payBy // ignore: cast_nullable_to_non_nullable
              as String,
      note: note == freezed
          ? _value.note
          : note // ignore: cast_nullable_to_non_nullable
              as String?,
      vatMethod: vatMethod == freezed
          ? _value.vatMethod
          : vatMethod // ignore: cast_nullable_to_non_nullable
              as String?,
      vatAmount: vatAmount == freezed
          ? _value.vatAmount
          : vatAmount // ignore: cast_nullable_to_non_nullable
              as String?,
      vatId: vatId == freezed
          ? _value.vatId
          : vatId // ignore: cast_nullable_to_non_nullable
              as int?,
      voucherNumber: voucherNumber == freezed
          ? _value.voucherNumber
          : voucherNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      documents: documents == freezed
          ? _value.documents
          : documents // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_ExpenseModel implements _ExpenseModel {
  const _$_ExpenseModel(
      {@JsonKey(name: '_id') this.id,
      required this.expenseCategory,
      required this.expenseTitle,
      required this.amount,
      required this.date,
      required this.payBy,
      this.note,
      this.vatMethod,
      this.vatAmount,
      this.vatId,
      this.voucherNumber,
      this.documents});

  factory _$_ExpenseModel.fromJson(Map<String, dynamic> json) =>
      _$$_ExpenseModelFromJson(json);

  @override
  @JsonKey(name: '_id')
  final int? id;
  @override
  final String expenseCategory;
  @override
  final String expenseTitle;
  @override
  final String amount;
  @override
  final String date;
  @override
  final String payBy;
  @override
  final String? note;
  @override
  final String? vatMethod;
  @override
  final String? vatAmount;
  @override
  final int? vatId;
  @override
  final String? voucherNumber;
  @override
  final String? documents;

  @override
  String toString() {
    return 'ExpenseModel(id: $id, expenseCategory: $expenseCategory, expenseTitle: $expenseTitle, amount: $amount, date: $date, payBy: $payBy, note: $note, vatMethod: $vatMethod, vatAmount: $vatAmount, vatId: $vatId, voucherNumber: $voucherNumber, documents: $documents)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_ExpenseModel &&
            const DeepCollectionEquality().equals(other.id, id) &&
            const DeepCollectionEquality()
                .equals(other.expenseCategory, expenseCategory) &&
            const DeepCollectionEquality()
                .equals(other.expenseTitle, expenseTitle) &&
            const DeepCollectionEquality().equals(other.amount, amount) &&
            const DeepCollectionEquality().equals(other.date, date) &&
            const DeepCollectionEquality().equals(other.payBy, payBy) &&
            const DeepCollectionEquality().equals(other.note, note) &&
            const DeepCollectionEquality().equals(other.vatMethod, vatMethod) &&
            const DeepCollectionEquality().equals(other.vatAmount, vatAmount) &&
            const DeepCollectionEquality().equals(other.vatId, vatId) &&
            const DeepCollectionEquality()
                .equals(other.voucherNumber, voucherNumber) &&
            const DeepCollectionEquality().equals(other.documents, documents));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(id),
      const DeepCollectionEquality().hash(expenseCategory),
      const DeepCollectionEquality().hash(expenseTitle),
      const DeepCollectionEquality().hash(amount),
      const DeepCollectionEquality().hash(date),
      const DeepCollectionEquality().hash(payBy),
      const DeepCollectionEquality().hash(note),
      const DeepCollectionEquality().hash(vatMethod),
      const DeepCollectionEquality().hash(vatAmount),
      const DeepCollectionEquality().hash(vatId),
      const DeepCollectionEquality().hash(voucherNumber),
      const DeepCollectionEquality().hash(documents));

  @JsonKey(ignore: true)
  @override
  _$$_ExpenseModelCopyWith<_$_ExpenseModel> get copyWith =>
      __$$_ExpenseModelCopyWithImpl<_$_ExpenseModel>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_ExpenseModelToJson(this);
  }
}

abstract class _ExpenseModel implements ExpenseModel {
  const factory _ExpenseModel(
      {@JsonKey(name: '_id') final int? id,
      required final String expenseCategory,
      required final String expenseTitle,
      required final String amount,
      required final String date,
      required final String payBy,
      final String? note,
      final String? vatMethod,
      final String? vatAmount,
      final int? vatId,
      final String? voucherNumber,
      final String? documents}) = _$_ExpenseModel;

  factory _ExpenseModel.fromJson(Map<String, dynamic> json) =
      _$_ExpenseModel.fromJson;

  @override
  @JsonKey(name: '_id')
  int? get id => throw _privateConstructorUsedError;
  @override
  String get expenseCategory => throw _privateConstructorUsedError;
  @override
  String get expenseTitle => throw _privateConstructorUsedError;
  @override
  String get amount => throw _privateConstructorUsedError;
  @override
  String get date => throw _privateConstructorUsedError;
  @override
  String get payBy => throw _privateConstructorUsedError;
  @override
  String? get note => throw _privateConstructorUsedError;
  @override
  String? get vatMethod => throw _privateConstructorUsedError;
  @override
  String? get vatAmount => throw _privateConstructorUsedError;
  @override
  int? get vatId => throw _privateConstructorUsedError;
  @override
  String? get voucherNumber => throw _privateConstructorUsedError;
  @override
  String? get documents => throw _privateConstructorUsedError;
  @override
  @JsonKey(ignore: true)
  _$$_ExpenseModelCopyWith<_$_ExpenseModel> get copyWith =>
      throw _privateConstructorUsedError;
}
