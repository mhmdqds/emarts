// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'permission_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

PermissionModel _$PermissionModelFromJson(Map<String, dynamic> json) {
  return _PermissionModel.fromJson(json);
}

/// @nodoc
mixin _$PermissionModel {
  @JsonKey(name: '_id')
  int? get id => throw _privateConstructorUsedError;
  int? get groupId => throw _privateConstructorUsedError;
  String get user => throw _privateConstructorUsedError;
  String get sale => throw _privateConstructorUsedError;
  String get purchase => throw _privateConstructorUsedError;
  String get returns => throw _privateConstructorUsedError;
  String get products => throw _privateConstructorUsedError;
  String get customer => throw _privateConstructorUsedError;
  String get supplier => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $PermissionModelCopyWith<PermissionModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $PermissionModelCopyWith<$Res> {
  factory $PermissionModelCopyWith(
          PermissionModel value, $Res Function(PermissionModel) then) =
      _$PermissionModelCopyWithImpl<$Res>;
  $Res call(
      {@JsonKey(name: '_id') int? id,
      int? groupId,
      String user,
      String sale,
      String purchase,
      String returns,
      String products,
      String customer,
      String supplier});
}

/// @nodoc
class _$PermissionModelCopyWithImpl<$Res>
    implements $PermissionModelCopyWith<$Res> {
  _$PermissionModelCopyWithImpl(this._value, this._then);

  final PermissionModel _value;
  // ignore: unused_field
  final $Res Function(PermissionModel) _then;

  @override
  $Res call({
    Object? id = freezed,
    Object? groupId = freezed,
    Object? user = freezed,
    Object? sale = freezed,
    Object? purchase = freezed,
    Object? returns = freezed,
    Object? products = freezed,
    Object? customer = freezed,
    Object? supplier = freezed,
  }) {
    return _then(_value.copyWith(
      id: id == freezed
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int?,
      groupId: groupId == freezed
          ? _value.groupId
          : groupId // ignore: cast_nullable_to_non_nullable
              as int?,
      user: user == freezed
          ? _value.user
          : user // ignore: cast_nullable_to_non_nullable
              as String,
      sale: sale == freezed
          ? _value.sale
          : sale // ignore: cast_nullable_to_non_nullable
              as String,
      purchase: purchase == freezed
          ? _value.purchase
          : purchase // ignore: cast_nullable_to_non_nullable
              as String,
      returns: returns == freezed
          ? _value.returns
          : returns // ignore: cast_nullable_to_non_nullable
              as String,
      products: products == freezed
          ? _value.products
          : products // ignore: cast_nullable_to_non_nullable
              as String,
      customer: customer == freezed
          ? _value.customer
          : customer // ignore: cast_nullable_to_non_nullable
              as String,
      supplier: supplier == freezed
          ? _value.supplier
          : supplier // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
abstract class _$$_PermissionModelCopyWith<$Res>
    implements $PermissionModelCopyWith<$Res> {
  factory _$$_PermissionModelCopyWith(
          _$_PermissionModel value, $Res Function(_$_PermissionModel) then) =
      __$$_PermissionModelCopyWithImpl<$Res>;
  @override
  $Res call(
      {@JsonKey(name: '_id') int? id,
      int? groupId,
      String user,
      String sale,
      String purchase,
      String returns,
      String products,
      String customer,
      String supplier});
}

/// @nodoc
class __$$_PermissionModelCopyWithImpl<$Res>
    extends _$PermissionModelCopyWithImpl<$Res>
    implements _$$_PermissionModelCopyWith<$Res> {
  __$$_PermissionModelCopyWithImpl(
      _$_PermissionModel _value, $Res Function(_$_PermissionModel) _then)
      : super(_value, (v) => _then(v as _$_PermissionModel));

  @override
  _$_PermissionModel get _value => super._value as _$_PermissionModel;

  @override
  $Res call({
    Object? id = freezed,
    Object? groupId = freezed,
    Object? user = freezed,
    Object? sale = freezed,
    Object? purchase = freezed,
    Object? returns = freezed,
    Object? products = freezed,
    Object? customer = freezed,
    Object? supplier = freezed,
  }) {
    return _then(_$_PermissionModel(
      id: id == freezed
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int?,
      groupId: groupId == freezed
          ? _value.groupId
          : groupId // ignore: cast_nullable_to_non_nullable
              as int?,
      user: user == freezed
          ? _value.user
          : user // ignore: cast_nullable_to_non_nullable
              as String,
      sale: sale == freezed
          ? _value.sale
          : sale // ignore: cast_nullable_to_non_nullable
              as String,
      purchase: purchase == freezed
          ? _value.purchase
          : purchase // ignore: cast_nullable_to_non_nullable
              as String,
      returns: returns == freezed
          ? _value.returns
          : returns // ignore: cast_nullable_to_non_nullable
              as String,
      products: products == freezed
          ? _value.products
          : products // ignore: cast_nullable_to_non_nullable
              as String,
      customer: customer == freezed
          ? _value.customer
          : customer // ignore: cast_nullable_to_non_nullable
              as String,
      supplier: supplier == freezed
          ? _value.supplier
          : supplier // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_PermissionModel implements _PermissionModel {
  const _$_PermissionModel(
      {@JsonKey(name: '_id') this.id,
      this.groupId,
      this.user = '0',
      this.sale = '0',
      this.purchase = '0',
      this.returns = '0',
      this.products = '0',
      this.customer = '0',
      this.supplier = '0'});

  factory _$_PermissionModel.fromJson(Map<String, dynamic> json) =>
      _$$_PermissionModelFromJson(json);

  @override
  @JsonKey(name: '_id')
  final int? id;
  @override
  final int? groupId;
  @override
  @JsonKey()
  final String user;
  @override
  @JsonKey()
  final String sale;
  @override
  @JsonKey()
  final String purchase;
  @override
  @JsonKey()
  final String returns;
  @override
  @JsonKey()
  final String products;
  @override
  @JsonKey()
  final String customer;
  @override
  @JsonKey()
  final String supplier;

  @override
  String toString() {
    return 'PermissionModel(id: $id, groupId: $groupId, user: $user, sale: $sale, purchase: $purchase, returns: $returns, products: $products, customer: $customer, supplier: $supplier)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_PermissionModel &&
            const DeepCollectionEquality().equals(other.id, id) &&
            const DeepCollectionEquality().equals(other.groupId, groupId) &&
            const DeepCollectionEquality().equals(other.user, user) &&
            const DeepCollectionEquality().equals(other.sale, sale) &&
            const DeepCollectionEquality().equals(other.purchase, purchase) &&
            const DeepCollectionEquality().equals(other.returns, returns) &&
            const DeepCollectionEquality().equals(other.products, products) &&
            const DeepCollectionEquality().equals(other.customer, customer) &&
            const DeepCollectionEquality().equals(other.supplier, supplier));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(id),
      const DeepCollectionEquality().hash(groupId),
      const DeepCollectionEquality().hash(user),
      const DeepCollectionEquality().hash(sale),
      const DeepCollectionEquality().hash(purchase),
      const DeepCollectionEquality().hash(returns),
      const DeepCollectionEquality().hash(products),
      const DeepCollectionEquality().hash(customer),
      const DeepCollectionEquality().hash(supplier));

  @JsonKey(ignore: true)
  @override
  _$$_PermissionModelCopyWith<_$_PermissionModel> get copyWith =>
      __$$_PermissionModelCopyWithImpl<_$_PermissionModel>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_PermissionModelToJson(this);
  }
}

abstract class _PermissionModel implements PermissionModel {
  const factory _PermissionModel(
      {@JsonKey(name: '_id') final int? id,
      final int? groupId,
      final String user,
      final String sale,
      final String purchase,
      final String returns,
      final String products,
      final String customer,
      final String supplier}) = _$_PermissionModel;

  factory _PermissionModel.fromJson(Map<String, dynamic> json) =
      _$_PermissionModel.fromJson;

  @override
  @JsonKey(name: '_id')
  int? get id => throw _privateConstructorUsedError;
  @override
  int? get groupId => throw _privateConstructorUsedError;
  @override
  String get user => throw _privateConstructorUsedError;
  @override
  String get sale => throw _privateConstructorUsedError;
  @override
  String get purchase => throw _privateConstructorUsedError;
  @override
  String get returns => throw _privateConstructorUsedError;
  @override
  String get products => throw _privateConstructorUsedError;
  @override
  String get customer => throw _privateConstructorUsedError;
  @override
  String get supplier => throw _privateConstructorUsedError;
  @override
  @JsonKey(ignore: true)
  _$$_PermissionModelCopyWith<_$_PermissionModel> get copyWith =>
      throw _privateConstructorUsedError;
}
