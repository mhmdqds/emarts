// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'permission_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_PermissionModel _$$_PermissionModelFromJson(Map<String, dynamic> json) =>
    _$_PermissionModel(
      id: json['_id'] as int?,
      groupId: json['groupId'] as int?,
      user: json['user'] as String? ?? '0',
      sale: json['sale'] as String? ?? '0',
      purchase: json['purchase'] as String? ?? '0',
      returns: json['returns'] as String? ?? '0',
      products: json['products'] as String? ?? '0',
      customer: json['customer'] as String? ?? '0',
      supplier: json['supplier'] as String? ?? '0',
    );

Map<String, dynamic> _$$_PermissionModelToJson(_$_PermissionModel instance) =>
    <String, dynamic>{
      '_id': instance.id,
      'groupId': instance.groupId,
      'user': instance.user,
      'sale': instance.sale,
      'purchase': instance.purchase,
      'returns': instance.returns,
      'products': instance.products,
      'customer': instance.customer,
      'supplier': instance.supplier,
    };
