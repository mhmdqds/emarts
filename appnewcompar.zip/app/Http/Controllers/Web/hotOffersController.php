<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Model\Branche;
use Illuminate\Support\Facades\Response;
use DB;
use App\Model\Product;

class hotOffersController extends Controller
{
    
    public function index() {


        $user_ip = getenv('REMOTE_ADDR');
        $geo = unserialize(file_get_contents("http://www.geoplugin.net/php.gp?ip=$user_ip"));
        $country = $geo["geoplugin_countryName"];
        $city = $geo["geoplugin_city"];
        $lat = $geo["geoplugin_latitude"];
        $lon = $geo["geoplugin_longitude"]; 

        $lat_rang_start = $lat - 5;
        $lat_rang_end = $lat + 5;

        $Brand = DB::table('products')->where('discount', '!=', '')->whereBetween('address_latitude', [$lat_rang_start, $lat_rang_end])->get();
    
            return view('web-views.hot_offers.index', compact('Brand'));
            
    }


    public function hot_offers_get() {

        $data = Category::all();

        return response()->json([

            'data' => $data
        ]);

    }
}
