<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SellerReqAdd extends Model
{
    use HasFactory;

    protected $table = 'seller_req_add';

    protected $guarded = [];

}
